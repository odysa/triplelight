"""Replay dotNetRDF fixture receipts without the SDK or binary."""
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source"
RUN = HERE / "run"
FIXTURE = RUN / "fixture"
sys.path.insert(0, str(SOURCE))
from check_answers import audit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


freeze = SOURCE / "FREEZE.json"
assert sha(freeze) == "0a0c43389654e499992063d6731f424a77a9a780fd7c6f748214aacae924f1f8"
members = read(freeze)["files"]
assert {p.name for p in SOURCE.iterdir()} == set(members) | {"FREEZE.json"}
assert all(sha(SOURCE / name) == digest for name, digest in members.items())

resolution = RUN / "RESOLUTION.json"
assert sha(resolution) == "23537c03d4aefa194ec43d34e8a6c10eeadfee65e8164d8d5417f24a20720a4d"
resolved = read(resolution)
assert resolved["freeze_sha256"] == sha(freeze)
assert (resolved["sdk"], resolved["runtime"]) == ("10.0.404", "10.0.15")
lock = RUN / "project/packages.lock.json"
assert sha(lock) == resolved["locked_packages_sha256"] == "4bd16306f4570256dbb19cca67ca75af057d290894dc25d52e97a7da81a78575"
deps = read(lock)["dependencies"]["net10.0"]
assert len(deps) == 12 and deps["dotNetRdf.Core"]["resolved"] == "3.5.2"
feed = resolved["feed"]
assert len(feed) == len(deps)
for name, package in deps.items():
    version = package["resolved"].lower()
    entry = feed[f"{name.lower()}.{version}.nupkg"]
    assert entry["version"] == version and entry["nuget_content_hash"] == package["contentHash"]

runtime = RUN / "RUNTIME.json"
assert sha(runtime) == "a747ba26feaaadd5e5151ddff36582c4f79e5b45135c66e035cd5206c7146208"
rt = read(runtime)
assert rt["resolution_sha256"] == sha(resolution) and rt["freeze_sha256"] == sha(freeze)
for name in ("Fixture.deps.json", "Fixture.runtimeconfig.json"):
    assert sha(RUN / "binary" / name) == rt["binaries"][name]
assert "Build succeeded." in (RUN / "build/compile.stdout").read_text()

notice = (RUN / "resolve/restore-resolve.stdout").read_text()
assert "NU1902" in notice and "AngleSharp" in notice and "GHSA-pgww-w46g-26qg" in notice
assert "CS0534" in (HERE / "v1/compile.stdout").read_text()
assert "HandleQuadInternal" in (HERE / "v1/compile.stdout").read_text()

receipt = read(FIXTURE / "RECEIPT.json")
assert receipt["runtime_sha256"] == sha(runtime) and receipt["pass"] is True
assert receipt["scored"] is False
store = FIXTURE / "graph.nt"
assert store.read_bytes() == (SOURCE / "consumer-fixture.nt").read_bytes()
file_report = {"bytes": store.stat().st_size, "sha256": sha(store)}
stages = {}
for route in ("parser", "memory", "write", "reparse"):
    record = read(FIXTURE / f"{route}.stdout")
    assert record["stage"] == route
    result = audit(record)
    reported = receipt["routes"][route]
    assert result["pass"] and reported["exit"] == 0
    assert all(reported[k] == v for k, v in result.items())
    if route == "write":
        assert record["after_flush"] == record["after_dispose"] == reported["file"] == file_report
        assert reported["file_pass"] is True
    if route == "reparse":
        assert reported["file_unchanged"] is True
    stages[route] = result
assert set(stages) == set(receipt["routes"])

print(json.dumps({
    "engine": "dotNetRDF", "freeze_sha256": sha(freeze), "resolution_sha256": sha(resolution),
    "runtime_sha256": sha(runtime), "scored": False, "stages": stages,
    "typed_checks_passed": sum(len(stage["queries"]) for stage in stages.values()),
    "serialized_graph": file_report, "v1_compile_stop": True,
    "restore_advisory": "GHSA-pgww-w46g-26qg",
}, indent=2, sort_keys=True))
