"""Resolve, build and run the pinned dotNetRDF fixture."""

import argparse
import base64
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import time
import tarfile
from pathlib import Path

from check_answers import audit

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/rdf-jianlin-dotnetrdf39-tiny-v2")
LOCK = Path("/private/tmp/rdf-bench.lock/owner")
OWNER = "Jianlin task39 dotNetRDF fixture v2\n"
SDK = "10.0.404"
RUNTIME = "10.0.15"
SDK_URL = f"https://builds.dotnet.microsoft.com/dotnet/Sdk/{SDK}/dotnet-sdk-{SDK}-osx-arm64.tar.gz"
SDK_SHA512 = "1c9a13f625d0c08f08ef5a53597bababe3d2473527e98db2199210940c69dd5fc599a39a4d7c30ebf297ca2334a81b2f64b9bf05ff99585de9af4a5d85215e96"
PACKAGE = "dotnetrdf.core"
VERSION = "3.5.2"
GIB = 1 << 30


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write("\n")


def source_check(expected):
    path = HERE / "FREEZE.json"
    require(sha(path) == expected, "freeze digest drift")
    files = load(path)["files"]
    current = {p.name for p in HERE.iterdir()}
    require(current == set(files) | {"FREEZE.json"}, "source file inventory drift")
    for name, digest in files.items():
        p = HERE / name
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, f"source drift: {name}")


def check_lock():
    require(LOCK.read_text() == OWNER, "exact own lock required")


def bytes_used():
    allocated = 0
    logical = 0
    for path in ROOT.rglob("*"):
        try:
            item = path.lstat()
        except FileNotFoundError:
            continue
        allocated += item.st_blocks * 512
        if stat.S_ISREG(item.st_mode):
            logical += item.st_size
    return allocated, logical


def guard(deadline):
    check_lock()
    require(time.monotonic() < deadline, "phase deadline")
    require(shutil.disk_usage(ROOT).free >= 42 * GIB, "42 GiB free-space guard")
    allocated, logical = bytes_used()
    require(allocated < 4 * GIB and logical < 8 * GIB, "owned root size guard")


def command(args, env, cwd, out, label, deadline):
    stdout_path = out / (label + ".stdout")
    limit = min(deadline, time.monotonic() + (300 if out.name in {"resolve", "build"} else 100))
    guard(limit)
    with stdout_path.open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(args, stdout=stdout, stderr=stderr, cwd=cwd, env=env, start_new_session=True)
        try:
            while child.poll() is None:
                guard(limit)
                require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                        "diagnostic output limit")
                time.sleep(0.25)
            require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                    "diagnostic output limit")
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    guard(limit)
    return child.returncode, stdout_path


def environment(package_cache):
    return {
        "PATH": "/usr/bin:/bin",
        "HOME": str(ROOT / "home"),
        "TMPDIR": str(ROOT / "tmp"),
        "DOTNET_ROOT": str(ROOT / "sdk"),
        "DOTNET_CLI_HOME": str(ROOT / "home"),
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "DOTNET_NOLOGO": "1",
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
        "DOTNET_MULTILEVEL_LOOKUP": "0",
        "DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE": "true",
        "DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER": "1",
        "MSBUILDDISABLENODEREUSE": "1",
        "NUGET_PACKAGES": str(ROOT / package_cache),
        "NUGET_HTTP_CACHE_PATH": str(ROOT / "nuget-http"),
        "NUGET_PLUGINS_CACHE_PATH": str(ROOT / "nuget-plugins"),
    }


def sdk_step(args, out, label, deadline, packages="packages"):
    host = ROOT / "sdk/dotnet"
    rc, output = command([str(host), *args], environment(packages), ROOT / "project", out, label, deadline)
    require(rc == 0, f"{label} exited {rc}")
    return output


def digest(path, algorithm):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, algorithm).digest()


def resolve(freeze):
    check_lock()
    require(shutil.disk_usage(ROOT.parent).free >= 48 * GIB, "48 GiB launch floor")
    ROOT.mkdir()
    deadline = time.monotonic() + 480
    out = ROOT / "resolve"
    out.mkdir()
    try:
        result = resolve_sdk_and_packages(freeze, out, deadline)
        save(ROOT / "RESOLUTION.json", result)
    except Exception as error:
        save(ROOT / "RESOLVE-FAILED.json", {"error": repr(error)})
        raise
    print(sha(ROOT / "RESOLUTION.json"))


def resolve_sdk_and_packages(freeze, out, deadline):
    for name in ("home", "tmp", "sdk", "project", "feed"):
        (ROOT / name).mkdir()
    archive = ROOT / "sdk.tar.gz"
    rc, _ = command(
        ["/usr/bin/curl", "-q", "--fail", "--silent", "--show-error", "--proto", "=https",
         "--max-filesize", "300000000", "--max-time", "180", "--output", str(archive), SDK_URL],
        environment("packages"), ROOT, out, "download-sdk", deadline,
    )
    require(rc == 0, f"SDK acquisition exited {rc}")
    require(digest(archive, "sha512").hex() == SDK_SHA512, "SDK archive digest drift")
    sdk_root = ROOT / "sdk"
    with tarfile.open(archive, "r:gz") as tar:
        expanded = 0
        for entry in tar:
            require(entry.isfile() or entry.isdir(), f"unexpected SDK archive entry: {entry.name}")
            expanded += entry.size
            require(expanded < 2 * GIB, "SDK expansion cap")
            tar.extract(entry, sdk_root, filter="data")
    guard(deadline)

    project = ROOT / "project"
    for name in ("Fixture.csproj", "Program.cs", "nuget.config"):
        shutil.copyfile(HERE / name, project / name)
    save(project / "global.json", {"sdk": {"version": SDK, "rollForward": "disable"}})
    version = sdk_step(["--version"], out, "sdk-version", deadline).read_text().strip()
    require(version == SDK, "unexpected SDK version")
    runtimes = sdk_step(["--list-runtimes"], out, "runtimes", deadline).read_text().splitlines()
    require(any(row.startswith(f"Microsoft.NETCore.App {RUNTIME} ") for row in runtimes), "runtime mismatch")
    sdk_step(
        ["restore", "Fixture.csproj", "--use-lock-file", "--configfile", "nuget.config"],
        out, "restore-resolve", deadline,
    )
    lock_path = project / "packages.lock.json"
    require(sha(lock_path) == "4bd16306f4570256dbb19cca67ca75af057d290894dc25d52e97a7da81a78575",
            "reviewed NuGet lock drift")
    frameworks = load(lock_path)["dependencies"]
    require(set(frameworks) == {"net10.0"}, "unexpected package framework")
    locked = frameworks["net10.0"]
    candidates = {name.lower(): item for name, item in locked.items()}
    require(candidates[PACKAGE]["resolved"] == VERSION and candidates[PACKAGE]["type"] == "Direct",
            "direct package version drift")
    feed = {}
    for name, item in candidates.items():
        version = item["resolved"].lower()
        key = f"{name}.{version}.nupkg"
        installed = ROOT / "packages" / name / version
        archive_path = installed / key
        archive_hash = base64.b64encode(digest(archive_path, "sha512")).decode()
        content_hash = item["contentHash"]
        require(load(installed / ".nupkg.metadata")["contentHash"] == content_hash,
                f"NuGet content checksum mismatch: {name}")
        shutil.copyfile(archive_path, ROOT / "feed" / key)
        feed[key] = {
            "name": name, "version": version, "archive_sha512_base64": archive_hash,
            "nuget_content_hash": content_hash,
        }
    guard(deadline)
    source_check(freeze)
    return {
        "freeze_sha256": freeze, "sdk": SDK, "runtime": RUNTIME,
        "sdk_archive_sha512": SDK_SHA512, "dotnet_host_sha256": sha(ROOT / "sdk/dotnet"),
        "locked_packages_sha256": sha(lock_path), "feed": feed, "scored": False,
    }


def build(freeze, expected):
    check_lock()
    deadline = time.monotonic() + 300
    resolved = ROOT / "RESOLUTION.json"
    require(sha(resolved) == expected, "resolution digest drift")
    receipt = load(resolved)
    require(receipt["freeze_sha256"] == freeze, "dependency lock belongs to another freeze")
    project = ROOT / "project"
    lock_path = project / "packages.lock.json"
    require(sha(lock_path) == receipt["locked_packages_sha256"], "NuGet lock drift")
    require(sha(ROOT / "sdk/dotnet") == receipt["dotnet_host_sha256"], "SDK host drift")
    require(load(project / "global.json") == {"sdk": {"version": SDK, "rollForward": "disable"}},
            "SDK selection drift")
    for path in ("Fixture.csproj", "Program.cs", "nuget.config"):
        require(sha(project / path) == sha(HERE / path), f"project input drift: {path}")
    feed = ROOT / "feed"
    require({p.name for p in feed.iterdir()} == set(receipt["feed"]), "local feed inventory drift")
    for key, metadata in receipt["feed"].items():
        require(base64.b64encode(digest(feed / key, "sha512")).decode() == metadata["archive_sha512_base64"],
                f"local package drift: {key}")
    out = ROOT / "build"
    out.mkdir()
    try:
        sdk_step(
            ["restore", "Fixture.csproj", "--locked-mode", "--configfile", "nuget.config",
             "--source", str(feed), "--force", "-p:NuGetAudit=false"],
            out, "restore-locked", deadline, packages="offline-packages",
        )
        for item in receipt["feed"].values():
            metadata = ROOT / "offline-packages" / item["name"] / item["version"] / ".nupkg.metadata"
            require(load(metadata)["contentHash"] == item["nuget_content_hash"], "locked restore content drift")
        sdk_step(
            ["build", "Fixture.csproj", "--configuration", "Release", "--no-restore",
             "--disable-build-servers", "--output", str(ROOT / "binary")],
            out, "compile", deadline, packages="offline-packages",
        )
        require(sha(lock_path) == receipt["locked_packages_sha256"], "build changed dependency lock")
        source_check(freeze)
        binary = ROOT / "binary"
        actual = {p.relative_to(binary).as_posix(): sha(p) for p in binary.rglob("*") if p.is_file()}
        require("Fixture.dll" in actual, "worker assembly missing")
        save(ROOT / "RUNTIME.json", {
            "freeze_sha256": freeze, "resolution_sha256": expected, "binaries": actual,
            "dotnet_host_sha256": receipt["dotnet_host_sha256"],
        })
    except Exception as error:
        save(out / "FAILED.json", {"error": repr(error)})
        raise
    print(sha(ROOT / "RUNTIME.json"))


def fixture(freeze, expected):
    check_lock()
    deadline = time.monotonic() + 400
    runtime = ROOT / "RUNTIME.json"
    require(sha(runtime) == expected, "runtime digest drift")
    registered = load(runtime)
    require(registered["freeze_sha256"] == freeze, "runtime belongs to another freeze")
    binary = ROOT / "binary"

    def verify():
        require(sha(ROOT / "sdk/dotnet") == registered["dotnet_host_sha256"], "SDK host drift")
        actual = {p.relative_to(binary).as_posix(): sha(p) for p in binary.rglob("*") if p.is_file()}
        require(actual == registered["binaries"], "worker binary inventory drift")

    verify()
    out = ROOT / "fixture"
    out.mkdir()
    store = out / "graph.nt"
    routes = {}
    receipt = {"runtime_sha256": expected, "routes": routes, "scored": False}
    try:
        for route in ("parser", "memory", "write", "reparse"):
            if route == "reparse" and not routes["write"].get("file_pass"):
                routes[route] = {"pass": False, "skipped": "file write did not pass"}
                continue
            rc, raw = command(
                [str(ROOT / "sdk/dotnet"), str(binary / "Fixture.dll"), route,
                 str(HERE / "consumer-fixture.nt"), str(HERE / "queries.json"), str(store)],
                environment("offline-packages"), out, out, route, deadline,
            )
            if rc != 0:
                routes[route] = {"exit": rc, "pass": False}
                continue
            record = load(raw)
            require(record["stage"] == route, "observation stage drift")
            observed = {"exit": rc, **audit(record)}
            if route == "write":
                after = record.get("after_dispose")
                file_pass = (
                    store.is_file() and after == record.get("after_flush")
                    and after == {"bytes": store.stat().st_size, "sha256": sha(store)}
                )
                observed.update({"file_pass": file_pass, "file": after})
                observed["pass"] &= file_pass
            if route == "reparse":
                observed["file_unchanged"] = routes["write"]["file"] == {
                    "bytes": store.stat().st_size, "sha256": sha(store),
                }
                observed["pass"] &= observed["file_unchanged"]
            routes[route] = observed
        verify()
        source_check(freeze)
        receipt["pass"] = len(routes) == 4 and all(r["pass"] for r in routes.values())
    except Exception as error:
        receipt.update({"pass": False, "error": repr(error)})
        raise
    finally:
        save(out / "RECEIPT.json", receipt)
    print(json.dumps({"pass": receipt["pass"], "routes": len(routes)}))
    return receipt["pass"]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("stage", choices=("resolve", "build", "fixture"))
    p.add_argument("--freeze", required=True)
    p.add_argument("--bind")
    args = p.parse_args()
    source_check(args.freeze)
    if args.stage == "resolve":
        resolve(args.freeze)
    else:
        require(args.bind, "resolution or runtime digest required")
        if args.stage == "build":
            build(args.freeze, args.bind)
        elif not fixture(args.freeze, args.bind):
            raise SystemExit(1)


if __name__ == "__main__":
    main()
