using System.Security.Cryptography;
using System.Text.Json;
using VDS.RDF;
using VDS.RDF.Parsing;
using VDS.RDF.Parsing.Handlers;
using VDS.RDF.Query;

internal static class Program
{
    private const string LockFile = "/private/tmp/rdf-bench.lock/owner";
    private const string LockOwner = "Jianlin task39 dotNetRDF fixture v2\n";
    private static readonly string[] Labels =
        ["group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false"];

    private static void CheckLock()
    {
        if (File.ReadAllText(LockFile) != LockOwner)
            throw new InvalidOperationException("exact own fixture lock required");
    }

    private static Dictionary<string, string> Term(INode node)
    {
        var value = new Dictionary<string, string>();
        switch (node)
        {
            case IUriNode iri:
                value["type"] = "uri";
                value["value"] = iri.Uri.OriginalString;
                break;
            case IBlankNode blank:
                value["type"] = "bnode";
                value["value"] = blank.InternalID;
                break;
            case ILiteralNode literal:
                value["type"] = "literal";
                value["value"] = literal.Value;
                if (literal.DataType != null)
                    value["datatype"] = literal.DataType.OriginalString;
                if (!string.IsNullOrEmpty(literal.Language))
                    value["xml:lang"] = literal.Language;
                break;
            default:
                throw new InvalidOperationException($"unexpected RDF node {node.NodeType}");
        }
        return value;
    }

    private static object TripleData(Triple triple) => new
    {
        s = Term(triple.Subject),
        p = Term(triple.Predicate),
        o = Term(triple.Object)
    };

    private sealed class ParserCapture : BaseRdfHandler
    {
        internal readonly List<object> Triples = [];
        public override bool AcceptsAll => true;

        protected override bool HandleQuadInternal(Triple triple, IRefNode graph) =>
            throw new InvalidOperationException("unexpected quad in N-Triples parser");

        protected override bool HandleTripleInternal(Triple triple)
        {
            if (Triples.Count >= 128)
                throw new InvalidOperationException("fixture contains more than 128 parsed triples");
            Triples.Add(TripleData(triple));
            return true;
        }
    }

    private static object Query(LeviathanQueryProcessor engine, string label, string text)
    {
        var parser = new SparqlQueryParser(SparqlQuerySyntax.Sparql_1_1);
        if (engine.ProcessQuery(parser.ParseFromString(text)) is not SparqlResultSet result)
            throw new InvalidOperationException("expected a result set");
        if (label == "ask_false")
        {
            if (result.ResultsType != SparqlResultsType.Boolean)
                throw new InvalidOperationException("expected an ASK result");
            return new { boolean = result.Result };
        }
        if (result.ResultsType != SparqlResultsType.VariableBindings || result.Count > 128)
            throw new InvalidOperationException("expected no more than 128 SELECT bindings");
        var variables = result.Variables.ToArray();
        var declared = variables.ToHashSet();
        if (declared.Count != variables.Length)
            throw new InvalidOperationException("duplicate projected variable");
        var bindings = new List<Dictionary<string, Dictionary<string, string>>>();
        foreach (var row in result)
        {
            var binding = new Dictionary<string, Dictionary<string, string>>();
            foreach (var (name, value) in row)
            {
                if (!declared.Contains(name))
                    throw new InvalidOperationException($"undeclared variable {name}");
                if (value != null)
                    binding.Add(name, Term(value));
            }
            bindings.Add(binding);
        }
        return new { head = new { vars = variables }, results = new { bindings } };
    }

    private static object FileReceipt(string path)
    {
        using var stream = File.OpenRead(path);
        return new { bytes = stream.Length, sha256 = Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant() };
    }

    private static object GraphRoute(string stage, string fixture, string path, Dictionary<string, string> queries)
    {
        using var graph = new Graph { NormalizeLiteralValues = false };
        var parser = new NTriplesParser(NTriplesSyntax.Rdf11);
        object? afterFlush = null;
        object? afterDispose = null;
        switch (stage)
        {
            case "memory":
                parser.Load(graph, fixture);
                break;
            case "write":
                if (File.Exists(path) || Directory.Exists(path))
                    throw new IOException("graph file must be fresh");
                using (var wrapper = new FileGraphPersistenceWrapper(graph, path))
                {
                    parser.Load(wrapper, fixture);
                    wrapper.Flush();
                    afterFlush = FileReceipt(path);
                }
                afterDispose = FileReceipt(path);
                break;
            case "reparse":
                if (!File.Exists(path))
                    throw new IOException("serialized graph must exist before reparse");
                parser.Load(graph, path);
                break;
            default:
                throw new ArgumentException($"unknown route {stage}");
        }

        if (graph.Name != null)
            throw new InvalidOperationException("fixture must load into the unnamed graph");
        var native = graph.Triples.Take(129).Select(TripleData).ToArray();
        if (native.Length > 128)
            throw new InvalidOperationException("native fixture exceeds 128 triples");
        int length = graph.Triples.Count;
        using var store = new TripleStore();
        store.Add(graph);
        using var engine = new LeviathanQueryProcessor(store);
        var observed = new Dictionary<string, object>();
        foreach (string label in Labels)
        {
            CheckLock();
            try
            {
                observed[label] = new { answer = Query(engine, label, queries[label]) };
            }
            catch (Exception error)
            {
                observed[label] = new { error = $"{error.GetType().Name}: {error.Message}" };
            }
        }
        return new
        {
            stage, native, length, queries = observed, default_graph = graph.Name == null,
            parser_syntax = "Rdf11", normalize_literals = graph.NormalizeLiteralValues,
            after_flush = afterFlush, after_dispose = afterDispose
        };
    }

    private static int Main(string[] args)
    {
        try
        {
            CheckLock();
            if (args.Length != 4)
                throw new ArgumentException("usage: fixture MODE INPUT.nt QUERIES.json STORE.nt");
            var queries = JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllBytes(args[2]))
                ?? throw new InvalidOperationException("missing queries");
            object result;
            if (args[0] == "parser")
            {
                var handler = new ParserCapture { NormalizeLiteralValues = false };
                new NTriplesParser(NTriplesSyntax.Rdf11).Load(handler, args[1]);
                result = new { stage = "parser", native = handler.Triples,
                    parser_syntax = "Rdf11", normalize_literals = handler.NormalizeLiteralValues };
            }
            else
            {
                result = GraphRoute(args[0], args[1], args[3], queries);
            }
            CheckLock();
            Console.WriteLine(JsonSerializer.Serialize(result));
            return 0;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error);
            return 1;
        }
    }
}
