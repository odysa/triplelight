# dotNetRDF 3.5.2 fixture execution

This is a nine-triple correctness check using the native dotNetRDF parser and Leviathan evaluator. A memory route, a graph written through the file wrapper, and a fresh process that reparses the file each check native length, exact triples and eight typed SPARQL answers. The file route uses a whole-graph RDF serialization. It exercises neither an indexed persistent store nor crash recovery.

After review, a named handoff and a fresh free-space check, claim the lock with owner `Jianlin task39 dotNetRDF fixture v2`. The fresh root is `/private/tmp/rdf-jianlin-dotnetrdf39-tiny-v2`. Launch requires 48 GiB available, with a 42 GiB free-space guard and owned-root caps of 4 GiB allocated and 8 GiB logical. The SDK download is capped at 300 MB, and extraction at 2 GiB. Resolve is capped at 480 seconds, build at 300, and fixture at 400.

```sh
rtk proxy python3 -E -s -B supervise.py resolve --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B supervise.py build --freeze FREEZE_SHA256 --bind RESOLUTION_SHA256
rtk proxy python3 -E -s -B supervise.py fixture --freeze FREEZE_SHA256 --bind RUNTIME_SHA256
```

Resolve acquires the checksummed Microsoft SDK archive, verifies actual SDK and runtime, and restores into private locations with NuGet.org as the sole source. The generated lock file records the full package closure. Verify that the lock matches the reviewed v1 lock digest and announce the new resolution digest before build. The local feed binds the full nupkg archive hashes, and the lock binds NuGet's package content hashes. These hashes can differ for signed packages. The build stage first performs a locked restore into a fresh cache using the local feed, then builds with restore disabled. [NuGet content hash implementation](https://github.com/NuGet/NuGet.Client/blob/dev/src/NuGet.Core/NuGet.Packaging/PackageArchiveReader.cs)

Announce the runtime digest before starting the fixture. The parser runs with literal normalization disabled. Every query route verifies the graph is unnamed, and the checker independently verifies native length and typed count. The file write stage records hashes after flush and dispose, and the final stage reparses the file in a separate process. Query errors are retained. A failed file write blocks its dependent reparse.

Preserve all phase receipts, then release the exact own lock once all owned processes exit. GoRDFlib's answer comparison is reused without any dependency on its binary.

The v1 restore passed and the C# build stopped before engine execution because the parser handler lacked the required quad override. V2 adds that override to reject unexpected quads on the N-Triples-only path and uses a fresh root. The v1 receipts remain intact.
