#!/usr/bin/env python3
"""One 120s untimed child; no lock acquisition/release or dependency installation."""
import argparse,hashlib,json,os,signal,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OWNER='Jianlin task39 RDFLib tiny feasibility v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lock():
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip()!=OWNER:raise RuntimeError('exact own lock required')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);ap.add_argument('--freeze-sha256',required=True);ap.add_argument('--expected-python',type=Path,required=True);ap.add_argument('--expected-python-sha256',required=True);a=ap.parse_args()
    lock()
    if Path(sys.executable).absolute() != a.expected_python.absolute() or sha(sys.executable) != a.expected_python_sha256:
        raise RuntimeError('announced isolated interpreter path/hash mismatch')
    if sha(ROOT/'FREEZE.json')!=a.freeze_sha256:raise RuntimeError('freeze mismatch')
    f=json.loads((ROOT/'FREEZE.json').read_text())
    def unchanged():return all(sha(ROOT/n)==h for n,h in f['files'].items())
    if not unchanged():raise RuntimeError('source/input mismatch')
    a.out.mkdir(exist_ok=False)
    record={'interpreter_path':str(a.expected_python.absolute()),'interpreter_sha256':sha(sys.executable),'scored':False,'full_workload_qualified':False,'profile_verdicts':{'default':False,'preserve-lexical':False},'timeout':False}
    try:
        with (a.out/'child.stdout').open('wb') as out,(a.out/'child.stderr').open('wb') as err:
            p=subprocess.Popen([str(a.expected_python),'-B',str(ROOT/'run.py'),'--fixtures',str(ROOT),'--out',str(a.out/'child')],stdout=out,stderr=err,start_new_session=True)
            try:record['exit_code']=p.wait(timeout=120)
            except subprocess.TimeoutExpired:
                record['timeout']=True;os.killpg(p.pid,signal.SIGKILL);record['exit_code']=p.wait()
        if record['exit_code']==0 and not record['timeout']:
            summary=json.loads((a.out/'child/summary.json').read_text())
            profiles=summary.get('profiles',[])
            if (len(profiles)==2 and [p.get('profile') for p in profiles]==['default','preserve-lexical']
                and summary.get('full_workload_qualified') is False and summary.get('input_identities_unchanged') is True):
                for profile in profiles:
                    record['profile_verdicts'][profile['profile']]=(profile.get('tiny_controls_pass') is True and len(profile.get('checks',{}))==7 and all(v is True for v in profile['checks'].values()) and 'error' not in profile)
            record['profiles_completed']=[p.get('profile') for p in profiles]==['default','preserve-lexical']
    finally:
        record['source_inputs_unchanged']=unchanged()
        if not record['source_inputs_unchanged']:record['profile_verdicts']={k:False for k in record['profile_verdicts']}
        (a.out/'supervisor.json').write_text(json.dumps(record,indent=2)+'\n')
    lock()
    if not record['source_inputs_unchanged'] or record.get('exit_code')!=0 or record['timeout']:raise SystemExit(1)
if __name__=='__main__':main()
