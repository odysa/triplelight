#!/usr/bin/env python3
"""Prospective RDFLib Memory feasibility only; no timers or large inputs."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import platform
import importlib.metadata as metadata
import sys


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def key(term):
    if term is None:
        return None
    if term['type'] == 'literal':
        lang = term.get('xml:lang', '').lower()
        dt = term.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if lang else 'http://www.w3.org/2001/XMLSchema#string')
        return ('literal', term['value'], dt, lang)
    return (term['type'], term['value'])


def bag(answer):
    cols = answer['head']['vars']
    return Counter(tuple(key(row.get(v)) for v in cols) for row in answer['results']['bindings'])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fixtures', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != 'Jianlin task39 RDFLib tiny feasibility v1':
        raise SystemExit('exact own lock required')
    expected_inputs = {'consumer-fixture.nt': '419291c55eb34af3bdc59a43ddcda019436ade3e1075ca034c3505247d8e9266', 'consumer-fixture.rq': 'c09c8b5bb1b2deca899383d71e89963908536cb231b0494a56e3664be528756d', 'consumer-fixture-jena.json': 'b8b6e0bf2ae822a6b354d2846a440ae572516a73cc08d6432df93b8008cab5bd'}
    if any(sha(args.fixtures / n) != h for n, h in expected_inputs.items()):
        raise SystemExit("fixture identity mismatch")
    if metadata.version('rdflib') != '7.6.0' or metadata.version('pyparsing') != '3.3.3':
        raise SystemExit('pinned dependency version mismatch')
    import rdflib
    args.out.mkdir(parents=True, exist_ok=False)
    nt = args.fixtures / 'consumer-fixture.nt'
    rq = args.fixtures / 'consumer-fixture.rq'
    refpath = args.fixtures / 'consumer-fixture-jena.json'
    reference = json.loads(refpath.read_text())
    identity = {'python': sys.version, 'executable': sys.executable,
                'platform': platform.platform(), 'rdflib': rdflib.__version__,
                'inputs': {p.name: sha(p) for p in [nt, rq, refpath]},
                'source_sha256': sha(Path(__file__)), 'scored': False,
                'pyparsing': metadata.version('pyparsing'),
                'module_sha256': sha(Path(rdflib.__file__)),
                'executable_sha256': sha(Path(sys.executable))}
    (args.out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    queries = {'group': rq.read_text(),
               'empty': 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }',
               'unbound': 'SELECT ?o ?missing WHERE { <urn:s> <urn:v> ?o OPTIONAL { <urn:s> <urn:absent> ?missing } }',
               'ask_false': 'ASK { <urn:absent> <urn:v> ?o }'}
    default = rdflib.NORMALIZE_LITERALS
    records = []
    try:
        # Both configurations are specified before observing either outcome.
        for profile, normalize in [('default', default), ('preserve-lexical', False)]:
            rdflib.NORMALIZE_LITERALS = normalize
            graph = rdflib.Graph(store='Memory')
            record = {'profile': profile, 'normalize_literals': normalize, 'answers': {}, 'checks': {}}
            try:
                graph.parse(nt, format='nt')
                record['stored_triples'] = len(graph)
                # Diagnostics only: never part of the seven answer checks.
                record['normalization_diagnostic'] = {'requested': normalize}
                try:
                    int_iri = rdflib.URIRef('http://www.w3.org/2001/XMLSchema#int')
                    record['normalization_diagnostic']['constructor_lexical'] = str(rdflib.Literal('01', datatype=int_iri))
                    record['normalization_diagnostic']['parsed_int_lexicals'] = [str(o) for o in graph.objects(rdflib.URIRef('urn:s'), rdflib.URIRef('urn:v')) if isinstance(o, rdflib.Literal) and o.datatype == int_iri]
                except Exception as diagnostic_error:
                    record['normalization_diagnostic']['error'] = repr(diagnostic_error)
                for label, query in queries.items():
                    result = graph.query(query)
                    if result.type == 'ASK':
                        answer = {'boolean': bool(result.askAnswer)}
                    else:
                        def term(t):
                            if isinstance(t, rdflib.URIRef):
                                return {'type': 'uri', 'value': str(t)}
                            if isinstance(t, rdflib.BNode):
                                return {'type': 'bnode', 'value': str(t)}
                            if isinstance(t, rdflib.Literal):
                                obj = {'type': 'literal', 'value': str(t)}
                                if t.language:
                                    obj['xml:lang'] = t.language
                                if t.datatype:
                                    obj['datatype'] = str(t.datatype)
                                return obj
                            raise TypeError('unknown RDF term type')
                        cols = [str(v) for v in result.vars]
                        bindings = [{v: term(t) for v, t in zip(cols, row) if t is not None} for row in result]
                        answer = {'head': {'vars': cols}, 'results': {'bindings': bindings}}
                    record['answers'][label] = answer
                record['checks'] = {
                    'group_projection': record['answers']['group']['head']['vars'] == reference['head']['vars'],
                    'group_strict_term_bag': bag(record['answers']['group']) == bag(reference),
                    'empty_projection': record['answers']['empty'] == {'head': {'vars': ['o']}, 'results': {'bindings': []}},
                    'unbound_projection': record['answers']['unbound']['head']['vars'] == ['o', 'missing'],
                    'unbound_strict_object_bag': bag({'head': {'vars': ['o']}, 'results': record['answers']['unbound']['results']}) == bag({'head': {'vars': ['o']}, 'results': {'bindings': [{'o': r['o']} for r in reference['results']['bindings']]}}),
                    'unbound_cells': all('missing' not in r for r in record['answers']['unbound']['results']['bindings']),
                    'false_ask': record['answers']['ask_false'] == {'boolean': False}}
            except Exception as e:
                record['error'] = str(e)
            finally:
                graph.close()
            record['tiny_controls_pass'] = 'error' not in record and len(record['checks']) == 7 and all(record['checks'].values())
            (args.out / (profile + '.json')).write_text(json.dumps(record, indent=2) + '\n')
            records.append(record)
    finally:
        rdflib.NORMALIZE_LITERALS = default
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != 'Jianlin task39 RDFLib tiny feasibility v1':
        raise RuntimeError('exact own lock lost')
    (args.out / 'summary.json').write_text(json.dumps({'scored': False, 'profiles': records,
          'full_workload_qualified': False, 'input_identities_unchanged': all(sha(args.fixtures / n) == h for n, h in identity['inputs'].items())}, indent=2) + '\n')


if __name__ == '__main__':
    main()
