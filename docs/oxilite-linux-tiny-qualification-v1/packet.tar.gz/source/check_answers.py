#!/usr/bin/env python3
"""Independent native-answer consumer; no engine imports or archived checker execution."""
from pathlib import Path
from collections import Counter
import json
MODES=['memory','disk-load','disk-reopen']
CASES=['group','plain','distinct','count','distinct_count','empty','unbound','ask_false']
X='http://www.w3.org/2001/XMLSchema#'
def key(t):
 if t is None:return None
 if t['type']!='literal':return(t['type'],t['value'])
 lang=t.get('xml:lang','').lower();return('literal',t['value'],t.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if lang else X+'string'),lang)
def bag(a):return Counter(tuple(key(r.get(v)) for v in a['head']['vars']) for r in a['results']['bindings'])
def evaluate(source,out):
 ref=json.loads((source/'consumer-fixture-jena.json').read_text());objects=[r['o'] for r in ref['results']['bindings']]
 plain={'head':{'vars':['o']},'results':{'bindings':[{'o':t} for t in objects]}}
 count={'head':{'vars':['n']},'results':{'bindings':[{'n':{'type':'literal','value':'9','datatype':X+'integer'}}]}}
 expected={'group':ref,'plain':plain,'distinct':plain,'count':count,'distinct_count':count,'empty':{'head':{'vars':['o']},'results':{'bindings':[]}},'unbound':{'head':{'vars':['o','missing']},'results':plain['results']},'ask_false':{'boolean':False}}
 verdicts={};details={}
 for mode in MODES:
  details[mode]={}
  try:
   summary=json.loads((out/mode/'summary.json').read_text());valid=summary.get('mode')==mode and type(summary.get('stored_quads')) is int and summary['stored_quads']==9 and summary.get('scored') is False and summary.get('full_workload_qualified') is False
   for label in CASES:
    record=json.loads((out/mode/(label+'.json')).read_text());a=record['answer'];want=expected[label];checks={'no_error':'error' not in record}
    if label=='ask_false':checks['answer']=type(a.get('boolean')) is bool and a==want
    else:checks['projection']=a['head']['vars']==want['head']['vars'];checks['typed_bag']=bag(a)==bag(want)
    if label=='unbound':checks['missing_unbound']=all('missing' not in row for row in a['results']['bindings'])
    details[mode][label]=checks
   verdicts[mode]=valid and all(all(c.values()) for c in details[mode].values())
  except (OSError,ValueError,KeyError,TypeError,AttributeError) as e:verdicts[mode]=False;details[mode]['error']=repr(e)
 return {'profiles':verdicts,'checks':details,'tiny_admitted':all(verdicts.values()),'full_workload_qualified':False,'scored':False}
