#!/usr/bin/env python3
"""Install one offline wheel; record runtime without importing the engine or issuing queries."""
import hashlib,importlib.metadata,json,platform,subprocess,sys,csv,base64
from pathlib import Path
S=Path('/src');R=Path('/runtime');pins=json.loads((S/'PINS.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert platform.machine()=='aarch64' and platform.python_version()==pins['expected_python_version']
w=Path('/wheel')/pins['wheel']['filename'];assert w.stat().st_size==pins['wheel']['bytes'] and sha(w)==pins['wheel']['sha256']
installer_version=importlib.metadata.version('pip')
target=R/'site';assert not target.exists()
subprocess.run([sys.executable,'-m','pip','install','--no-index','--no-deps','--no-compile','--disable-pip-version-check','--target',str(target),str(w)],check=True)
sys.path.insert(0,str(target));dist=importlib.metadata.distribution('oxilite');assert dist.version=='0.10.0'
files={str(p.relative_to(R)):sha(p) for p in sorted(target.rglob('*')) if p.is_file()};assert files
record=next(target.glob('*.dist-info/RECORD'));verified=0
for name,digest,size in csv.reader(record.open()):
 p=target/name;assert p.resolve().is_relative_to(target.resolve()) and p.is_file()
 if digest:
  algo,value=digest.split('=',1);assert algo=='sha256';assert base64.urlsafe_b64encode(hashlib.sha256(p.read_bytes()).digest()).decode().rstrip('=')==value
 if size:assert p.stat().st_size==int(size)
 verified+=1
identity={'pip_version':installer_version,'python':platform.python_version(),'machine':platform.machine(),'executable':sys.executable,'executable_sha256':sha(Path(sys.executable).resolve()),'distribution_version':dist.version,'files':files,'record_entries_verified':verified,'engine_imported':False,'queries_executed':False}
(R/'RUNTIME.json').write_text(json.dumps(identity,sort_keys=True,indent=2)+'\n')
