#!/usr/bin/env python3
"""One-use setup or Linux tiny attempt. Caller owns acquisition and release of the shared lock."""
import argparse,hashlib,json,os,signal,subprocess,sys,time,urllib.request,shutil
from pathlib import Path
from check_answers import evaluate
S=Path(__file__).resolve().parent
ROOT=Path('/private/tmp/rdf-jianlin-oxilite39-linux-tiny-v1')
OWNER='Jianlin task39 Oxilite Linux tiny v1'
NAME='jianlin-oxilite39-linux-tiny-v1'
class Abort(RuntimeError):pass
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lock():
 if Path('/tmp/rdf-bench.lock/owner').read_text().strip()!=OWNER:raise Abort('exact own lock required')
def call(*args):
 p=subprocess.run(['docker',*args],capture_output=True,text=True,timeout=30)
 if p.returncode:raise Abort('docker command failed '+repr(args[:2])+': '+p.stderr[-1000:])
 return p.stdout
def inspect(cid):return json.loads(call('inspect',cid))[0]
def exists(name):
 # List failure is uncertainty, never interpreted as absence.
 names=call('ps','-a','--format','{{.Names}}').splitlines();return name in names
def guard():
 lock();size=sum(p.stat().st_blocks*512 for p in ROOT.rglob('*') if p.is_file())
 free=shutil.disk_usage(ROOT).free
 if size>1<<30 or free<42<<30:raise Abort('tiny disk guard exceeded')
 return {'allocated_bytes':size,'free_bytes':free}
def source_ok(expected):
 if sha(S/'FREEZE.json')!=expected:raise Abort('source freeze digest mismatch')
 for n,h in json.loads((S/'FREEZE.json').read_text())['files'].items():
  if sha(S/n)!=h:raise Abort('source changed '+n)
def runtime_ok(expected):
 p=ROOT/'runtime/RUNTIME.json'
 if sha(p)!=expected:raise Abort('runtime manifest changed')
 r=json.loads(p.read_text())
 for n,h in r['files'].items():
  if sha(ROOT/'runtime'/n)!=h:raise Abort('installed file changed '+n)
def sanitized(info,mounts,pins,imageid):
 h=info['HostConfig'];c=info['Config'];actual={m['Destination']:(m['Source'],m['RW']) for m in info['Mounts']}
 checks={'container_platform':info['Platform']=='linux','image':info['Image']==imageid,'cpus':h['NanoCpus']==4_000_000_000,'memory':h['Memory']==12<<30,'swap':h['MemorySwap']==12<<30,'network':h['NetworkMode']=='none','cgroup':h['CgroupnsMode']=='private','readonly':h['ReadonlyRootfs'] is True,'mounts':actual==mounts,'owner_label':c['Labels'].get('org.triplelight.jianlin.qualification')==NAME,'tmpfs':h.get('Tmpfs',{}).get('/tmp')=='rw,noexec,nosuid,size=64m','threads':'RAYON_NUM_THREADS=4' in c['Env'],'pythonpath':'PYTHONPATH=/runtime/site' in c['Env']}
 if not all(checks.values()):raise Abort('container inspection failed '+repr(checks))
 return {'checks':checks,'image_id':imageid,'mounts':{k:{'source':v[0],'rw':v[1]} for k,v in actual.items()},'command':c['Cmd']}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['setup','tiny']);ap.add_argument('--freeze-sha256',required=True);ap.add_argument('--runtime-sha256');a=ap.parse_args()
 lock();source_ok(a.freeze_sha256);pins=json.loads((S/'PINS.json').read_text())
 if a.stage=='setup':
  ROOT.mkdir(exist_ok=False)
 else:
  if not a.runtime_sha256:raise Abort('tiny requires reviewed runtime hash')
  runtime_ok(a.runtime_sha256)
 phase=ROOT/a.stage;phase.mkdir(exist_ok=False);receipt={'stage':a.stage,'started_unix':time.time(),'freeze_sha256':a.freeze_sha256,'scored':False,'error':None,'cleanup':'not-created'};cid=None;proc=None;created_possible=False
 cap=180 if a.stage=='setup' else 120;deadline=time.monotonic()+cap;name=NAME+'-'+a.stage
 def signal_handler(signum,frame):raise Abort('signal '+str(signum))
 for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,signal_handler)
 try:
  receipt['preflight']=guard();receipt['work_cap_seconds']=cap
  if shutil.disk_usage(ROOT).free<64<<30:raise Abort('at least 64 GiB free required')
  if exists(name):raise Abort('container name preexists')
  image=json.loads(call('image','inspect',pins['python_image']))[0];assert image['Os']=='linux' and image['Architecture']=='arm64';imageid=image['Id'];receipt['image_id']=imageid
  mounts={'/src':(str(S),False),'/tmp/rdf-bench.lock':('/private/tmp/rdf-bench.lock',False)}
  if a.stage=='setup':
   wheels=ROOT/'wheels';wheels.mkdir();w=wheels/pins['wheel']['filename']
   with urllib.request.urlopen(pins['wheel']['url'],timeout=30) as response,w.open('xb') as dst:
    count=0
    while chunk:=response.read(1<<20):
     count+=len(chunk)
     if count>pins['wheel']['bytes']:raise Abort('wheel exceeds pinned size')
     dst.write(chunk);guard()
     if time.monotonic()>deadline:raise Abort('setup cap during download')
   if w.stat().st_size!=pins['wheel']['bytes'] or sha(w)!=pins['wheel']['sha256']:raise Abort('wheel identity mismatch')
   runtime=ROOT/'runtime';runtime.mkdir();mounts|={'/runtime':(str(runtime),True),'/wheel':(str(wheels),False)};script='/src/install_inside.py'
  else:
   mounts|={'/runtime':(str(ROOT/'runtime'),False),'/out':(str(phase/'out'),True)};(phase/'out').mkdir();script='/src/profiles_inside.py'
  cmd=['create','--pull=never','--name',name,'--platform',pins['platform'],'--label','org.triplelight.jianlin.qualification='+NAME,'--cpus=4','--memory=12g','--memory-swap=12g','--network=none','--cgroupns=private','--read-only','--tmpfs','/tmp:rw,noexec,nosuid,size=64m','-e','RAYON_NUM_THREADS=4','-e','PYTHONPATH=/runtime/site','-e','PYTHONDONTWRITEBYTECODE=1']
  for dest,(src,rw) in mounts.items():cmd+=['--mount','type=bind,src='+src+',dst='+dest+('' if rw else ',readonly')]
  cmd += [pins['python_image'],'sh','-c','grep MemTotal /proc/meminfo; exec python3 -B "$1"','sh',script]
  # The exact prechecked name is owned from the create attempt onward; on uncertain create inspect that name only.
  if time.monotonic()>=deadline:raise Abort('whole-stage cap before create')
  created_possible=True;cid=call(*cmd).strip();receipt['container_id']=cid;receipt['inspect']=sanitized(inspect(cid),mounts,pins,imageid)
  with (phase/'container.stdout').open('xb') as stdout,(phase/'container.stderr').open('xb') as stderr:
   proc=subprocess.Popen(['docker','start','-a',cid],stdout=stdout,stderr=stderr,start_new_session=True)
   with (phase/'samples.jsonl').open('x') as samples:
    while proc.poll() is None:
     g=guard();g['monotonic']=time.monotonic();samples.write(json.dumps(g)+'\n');samples.flush()
     if time.monotonic()>=deadline:raise Abort('whole-stage cap')
     time.sleep(.5)
   receipt['attach_exit']=proc.wait()
  info=inspect(cid);receipt['exit_code']=info['State']['ExitCode'];receipt['oom_killed']=info['State']['OOMKilled'];receipt['running']=info['State']['Running']
  if receipt['attach_exit']!=0 or receipt['exit_code']!=0 or receipt['oom_killed'] or receipt['running']:raise Abort('container did not complete normally')
  source_ok(a.freeze_sha256);guard()
  if time.monotonic()>=deadline:raise Abort('whole-stage cap after child exit')
  if a.stage=='setup':
   runtime=json.loads((ROOT/'runtime/RUNTIME.json').read_text());assert runtime['engine_imported'] is False and runtime['queries_executed'] is False;runtime_ok(sha(ROOT/'runtime/RUNTIME.json'));receipt['runtime_sha256']=sha(ROOT/'runtime/RUNTIME.json')
  else:
   runtime_ok(a.runtime_sha256);profiles=json.loads((phase/'out/PROFILES.json').read_text());assert profiles==[{'mode':m,'exit_code':0} for m in ['memory','disk-load','disk-reopen']];receipt['answers']=evaluate(S,phase/'out')
 except BaseException as e:receipt['error']=repr(e)
 finally:
  for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,signal.SIG_IGN)
  try:
   if cid is None and created_possible:
    candidate=inspect(name)
    if candidate['Config']['Labels'].get('org.triplelight.jianlin.qualification')!=NAME:raise Abort('uncertain create owner mismatch')
    cid=candidate['Id']
   if cid:
    state=inspect(cid)
    if state['Config']['Labels'].get('org.triplelight.jianlin.qualification')!=NAME:raise Abort('cleanup owner mismatch')
    if state['State']['Running']:call('stop','--time','5',cid)
    call('wait',cid)
   if proc:
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
   if cid:call('rm',cid)
   if created_possible and exists(name):raise Abort('container remains')
   receipt['cleanup']='verified-removed' if cid else 'not-created'
  except BaseException as e:receipt['cleanup']='unverified';receipt['cleanup_error']=repr(e)
  try:source_ok(a.freeze_sha256);lock();receipt['source_and_lock_postcheck']=True
  except BaseException as e:receipt['source_and_lock_postcheck']=False;receipt['postcheck_error']=repr(e)
  receipt['ended_unix']=time.time();receipt['elapsed_including_cleanup_seconds']=receipt['ended_unix']-receipt['started_unix'];receipt['lock_release']='caller only after child/container cleanup verified';(phase/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
 good=receipt['error'] is None and receipt['cleanup']=='verified-removed' and receipt['source_and_lock_postcheck'] is True
 if a.stage=='tiny':good=good and receipt.get('answers',{}).get('tiny_admitted') is True
 print(json.dumps({'stage':a.stage,'success':good,'receipt':str(phase/'RECEIPT.json')}));return 0 if good else 1
if __name__=='__main__':sys.exit(main())
