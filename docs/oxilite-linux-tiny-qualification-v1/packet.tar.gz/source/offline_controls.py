#!/usr/bin/env python3
"""Engine-free consumer mutations and mocked supervisor failure paths; never invoke Docker."""
import copy,json,runpy,shutil,sys,tempfile
from pathlib import Path
from unittest.mock import patch
SOURCE=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE))
from check_answers import evaluate
OLD=Path('/private/tmp/rdf-jianlin-oxilite39-v1/attempt-1')
results=[]
def record(label,ok):
 results.append({'case':label,'pass':bool(ok)})
 if not ok:raise AssertionError(label)
with tempfile.TemporaryDirectory(prefix='oxilite39-controls-') as temp:
 root=Path(temp);base=root/'answers';base.mkdir()
 for mode in ['memory','disk-load','disk-reopen']:shutil.copytree(OLD/mode,base/mode)
 record('retained macOS native answers pass new independent consumer',evaluate(SOURCE,base)['tiny_admitted'] is True)
 for label,filename,mutate in [
  ('boolean false must not be integer zero','memory/ask_false.json',lambda v:v['answer'].__setitem__('boolean',0)),
  ('wrong COUNT datatype','disk-load/count.json',lambda v:v['answer']['results']['bindings'][0]['n'].__setitem__('datatype','http://www.w3.org/2001/XMLSchema#int')),
  ('lost projection on empty answer','memory/empty.json',lambda v:v['answer']['head'].__setitem__('vars',[])),
  ('unbound changed into empty literal','disk-reopen/unbound.json',lambda v:v['answer']['results']['bindings'][0].__setitem__('missing',{'type':'literal','value':''})),
  ('literal lexical form changed','memory/plain.json',lambda v:next(t['o'] for t in v['answer']['results']['bindings'] if t['o'].get('value')=='01').__setitem__('value','1')),
  ('one bag multiplicity added','disk-load/distinct.json',lambda v:v['answer']['results']['bindings'].append(copy.deepcopy(v['answer']['results']['bindings'][0]))),
  ('boolean stored count rejected','memory/summary.json',lambda v:v.__setitem__('stored_quads',True)),
  ('one missing profile file','disk-reopen/plain.json',None)]:
  path=base/filename;original=path.read_bytes()
  if mutate:
   v=json.loads(original);mutate(v);path.write_text(json.dumps(v))
  else:path.unlink()
  record(label,evaluate(SOURCE,base)['tiny_admitted'] is False);path.write_bytes(original)
 for scenario in ['success','preexisting-name','uncertain-create','wrong-owner-inspection','nonzero-exit','cap-stop','remove-failure']:
  module=runpy.run_path(str(SOURCE/'supervise.py'),run_name='control_only');g=module['main'].__globals__;r=root/scenario;r.mkdir();g['ROOT']=r;g['lock']=lambda:None;g['source_ok']=lambda expected:None;g['runtime_ok']=lambda expected:None;g['guard']=lambda:{'free_bytes':100<<30,'allocated_bytes':0};g['exists']=lambda name:scenario=='preexisting-name'
  calls=[]; started=[False];clock=[0]
  def fake_call(*a):
   calls.append(a)
   if a[:2]==('image','inspect'):return json.dumps([{'Os':'linux','Architecture':'arm64','Id':'image-id'}])
   if a[0]=='create':
    if scenario=='uncertain-create':raise RuntimeError('injected create communication failure')
    return 'our-id'
   if a[0]=='rm' and scenario=='remove-failure':raise RuntimeError('injected removal failure')
   if a[0]=='stop':started[0]=False
   if a[0] in ['wait','rm','stop']:return '0'
   raise AssertionError(a)
  g['call']=fake_call
  def fake_inspect(cid):
   if scenario=='uncertain-create':raise RuntimeError('injected inspect unavailable')
   mounts=[{'Destination':dest,'Source':src,'RW':rw} for dest,src,rw in [('/src',str(SOURCE),False),('/tmp/rdf-bench.lock','/private/tmp/rdf-bench.lock',False),('/runtime',str(r/'runtime'),False),('/out',str(r/'tiny/out'),True)]]
   return {'Platform':'linux','Id':'our-id','Image':'image-id','HostConfig':{'NanoCpus':4_000_000_000,'Memory':12<<30,'MemorySwap':12<<30,'NetworkMode':'none','CgroupnsMode':'private','ReadonlyRootfs':True,'Tmpfs':{'/tmp':'rw,noexec,nosuid,size=64m'}},'Config':{'Labels':{'org.triplelight.jianlin.qualification':'foreign' if scenario=='wrong-owner-inspection' else g['NAME']},'Env':['RAYON_NUM_THREADS=4','PYTHONPATH=/runtime/site'],'Cmd':['fixture']},'Mounts':mounts,'State':{'Running':scenario=='cap-stop' and started[0],'ExitCode':1 if scenario=='nonzero-exit' else 0,'OOMKilled':False}}
  g['inspect']=fake_inspect
  class FakeProcess:
   def __init__(self,*args,**kwargs):
    self.pid=999999;started[0]=True
    out=r/'tiny/out'
    for mode in ['memory','disk-load','disk-reopen']:shutil.copytree(OLD/mode,out/mode)
    (out/'PROFILES.json').write_text(json.dumps([{'mode':m,'exit_code':0} for m in ['memory','disk-load','disk-reopen']]))
   def poll(self):return None if scenario=='cap-stop' else 0
   def wait(self,timeout=None):return 0
  def fake_mono():
   if scenario=='cap-stop' and started[0]:clock[0]+=600
   return clock[0]
  with patch('time.monotonic',fake_mono),patch('subprocess.Popen',FakeProcess),patch('shutil.disk_usage',return_value=type('Disk',(),{'free':100<<30})()),patch.object(sys,'argv',['supervise.py','tiny','--freeze-sha256','mock','--runtime-sha256','mock']):
   code=g['main']()
  receipt=json.loads((r/'tiny/RECEIPT.json').read_text())
  if scenario=='success':record('mock complete phase admitted only after verified cleanup',code==0 and receipt['cleanup']=='verified-removed')
  elif scenario in ['uncertain-create','wrong-owner-inspection','remove-failure']:record(scenario+' remains unverified and fails closed',code==1 and receipt['cleanup']=='unverified')
  elif scenario=='cap-stop':record('whole-stage cap stops only exact created container and retains failure',code==1 and receipt['cleanup']=='verified-removed' and ('stop','--time','5','our-id') in calls)
  else:record(scenario+' rejected',code==1 and receipt['error'] is not None)
 m=runpy.run_path(str(SOURCE/'supervise.py'),run_name='control_only');g=m['exists'].__globals__;g['call']=lambda *args:(_ for _ in ()).throw(RuntimeError('inventory unavailable'))
 try:g['exists']('x');safe=False
 except RuntimeError:safe=True
 record('inventory command failure cannot become absence',safe)
print(json.dumps({'engine_imported':False,'docker_invoked':False,'cases':results,'all_pass':all(v['pass'] for v in results)},indent=2))
