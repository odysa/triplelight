#!/usr/bin/env python3
"""Run fixed profiles in distinct child processes, with one enclosing container cap."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
R=Path('/runtime');S=Path('/src');out=Path('/out');runtime=json.loads((R/'RUNTIME.json').read_text())
def check():
 assert Path('/tmp/rdf-bench.lock/owner').read_text().strip()=='Jianlin task39 Oxilite Linux tiny v1'
 for n,h in runtime['files'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
 assert hashlib.sha256(Path(sys.executable).resolve().read_bytes()).hexdigest()==runtime['executable_sha256']
check();assert not (out/'PROFILES.json').exists();records=[]
try:
 for mode in ['memory','disk-load','disk-reopen']:
  check()
  with (out/(mode+'.stdout')).open('xb') as stdout,(out/(mode+'.stderr')).open('xb') as stderr:
   c=subprocess.run([sys.executable,'-B',str(S/'run.py'),'--mode',mode,'--out',str(out/mode)],stdout=stdout,stderr=stderr)
  records.append({'mode':mode,'exit_code':c.returncode})
  if c.returncode:raise RuntimeError('profile driver failure; no retry')
finally:
 (out/'PROFILES.json').write_text(json.dumps(records,indent=2)+'\n')
check()
