"""Audit saved Blazegraph LUBM-100 result records without starting an engine."""

import hashlib
import json
import sys
from pathlib import Path

PACKET = Path(__file__).resolve().parent
SOURCE = PACKET / "source"
RUN = PACKET / "run"
sys.path.insert(0, str(SOURCE))
from check_answers import replay


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit():
    registration_path = PACKET / "registration/REGISTRATION.json"
    registration = load(registration_path)
    binding = load(PACKET / "registration/LAUNCH_BINDING.json")
    final = load(RUN / "QUALIFICATION.json")
    source_freeze = SOURCE / "FREEZE.json"
    all_files = load(source_freeze)["files"]
    require(all(sha(SOURCE / p) == digest for p, digest in all_files.items()), "source digest drift")
    require(sha(source_freeze) == registration["freeze"], "freeze mismatch")
    require(sha(RUN / "RUNTIME.json") == registration["runtime"], "runtime mismatch")
    runtime = load(RUN / "RUNTIME.json")
    require({p.name: sha(p) for p in (RUN / "classes").iterdir()} == runtime["classes"],
            "compiled worker identity mismatch")
    require(sha(RUN / "SMOKE.json") == registration["smoke"], "fixture mismatch")
    require(sha(registration_path) == final["registration"] == binding["registration_sha256"],
            "registration mismatch")
    require(final["raft_message_id"] == binding["raft_message_id"], "launch binding mismatch")
    pins = load(SOURCE / "BINDINGS.json")
    require(sha(SOURCE / "BINDINGS.json") == registration["inputs"], "input and query manifest mismatch")
    for path, digest in pins["count_receipts"].items():
        require(sha(SOURCE / "workload" / path) == digest, "prior count receipt changed")
    smoke = load(RUN / "SMOKE.json")
    for key in ("load_count", "explicit_load_count", "reopen_count", "explicit_reopen_count"):
        require(smoke[key] == 9, "fixture native count mismatch")
    require(smoke["status"] == "pass" and smoke["include_inferred"] is True and smoke["runtime"] == registration["runtime"],
            "fixture profile mismatch")
    for field in ("input_before", "input_after_import"):
        if field in final:
            require(all(final[field][k] == pins["input"][k] for k in ("bytes", "mtime_ns", "sha256")),
                    f"{field} input identity mismatch")

    previous = None
    phases = {}
    container_ids = {}
    for name in registration["stages"]:
        directory = RUN / name
        status = final["stages"][name]
        item = {"status": status}
        phases[name] = item
        receipt_file = directory / "RECEIPT.json"
        if status == "not-run":
            require(not receipt_file.exists(), f"{name} impossible not-run status")
            continue
        if not receipt_file.exists():
            require(status == "failed", f"{name} completion receipt absent")
            continue
        receipt = load(receipt_file)
        require(receipt["stage"] == name, "stage identity drift")
        if receipt.get("container_id"):
            container_ids[name] = receipt["container_id"]
        item["cleanup"] = receipt["cleanup"]
        item["worker"] = receipt.get("exit")
        item["resources"] = receipt.get("resources")
        if name != "load" and "journal_before_sha256" in receipt:
            require(previous == receipt["journal_before_sha256"], "journal provenance mismatch")
        sample_path = directory / "samples.jsonl"
        if sample_path.exists():
            samples = [json.loads(line) for line in sample_path.read_text().splitlines()]
            if samples:
                item["allocated_bytes_sampled_peak"] = max(sample["allocated"] for sample in samples)
                item["free_bytes_sampled_floor"] = min(sample["free"] for sample in samples)
        if status != "complete":
            item["error"] = receipt.get("error")
            continue
        require(receipt["cleanup"] == "verified-removed" and receipt["status"] == "complete", "failed cleanup or phase")
        require(receipt["exit"] == {"attached": 0, "worker": 0, "oom_killed": False, "running": False}, "bad process exit")
        require("postflight_error" not in receipt, "phase postflight failure")
        actual = receipt["binding"]
        require(actual["image_id"] == runtime["image_id"] and actual["cpus"] == 4
                and actual["memory"] == actual["memory_plus_swap"] == 12 << 30
                and actual["network"] == "none" and actual["read_only"] is True, "resource binding mismatch")
        run_stdout = (directory / "stdout").read_text().splitlines()
        require(run_stdout.count("inline_xsd=false") == run_stdout.count("truth_maintenance=false") == 1,
                "unexpected inference or inline settings")
        if name in {"load", "reopen"}:
            count = pins["expected_unique_triples"]
            require(run_stdout.count(f"exact_triples={count}") == run_stdout.count(f"exact_explicit_triples={count}") == 1,
                    "native count gate failed")
            require(final[name + "_counts"] == {"total": count, "explicit": count}, "summary count mismatch")
            journal = load(directory / "JOURNAL.json")
            previous = journal["sha256"]
            item.update(counts=final[name + "_counts"], journal=journal)

    query_results = RUN / "queries/out/answers"
    if query_results.exists() and "replay_error" not in final:
        answers = replay(SOURCE / "workload", query_results, SOURCE / "BINDINGS.json", registration["inputs"])
        require(answers["labels"] == final["queries"], "answer result drift")
        require({k: v for k, v in answers.items() if k != "labels"} == final["answer_summary"],
                "answer summary drift")
    else:
        answers = None
    # An end-to-end pass requires exact complete primary answers and all own postchecks.
    admitted = bool(answers and answers["all_primary_pass"] and final.get("identities_postchecked")
                    and all(status == "complete" for status in final["stages"].values()) and "error" not in final)
    require(admitted == final["admitted_primary"], "admission drift")
    release = load(RUN / "WORKLOAD_LOCK_RELEASE.json")
    require(release["containers"] == container_ids and release["owner"] == registration["owner"],
            "lock-release identity mismatch")
    return {
        "registration": sha(registration_path), "phases": phases, "answers": answers,
        "admitted_primary": admitted, "scored": False,
    }


if __name__ == "__main__":
    print(json.dumps(audit(), indent=2, sort_keys=True))
