"""Run the registered LUBM-100 attempt after the exact streaming fixture passes."""

import argparse
import json
import shutil
import signal
import time
from pathlib import Path

from check_answers import replay
from run_qualification import (
    GIB, OWNER, ROOT, SOURCE, digest, gate_output, guard, image_id, load_json, phase, preflight,
    require, resource_sample, sizes, validate_runtime, write_json,
)


def input_identity(pins):
    path = Path(pins["path"])
    before = path.stat()
    require(before.st_size == pins["bytes"] and before.st_mtime_ns == pins["mtime_ns"],
            "LUBM input size or mtime differs from the frozen input")
    value = digest(path, time.monotonic() + 180)
    after = path.stat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
            and value == pins["sha256"], "LUBM input identity changed")
    return {"bytes": after.st_size, "mtime_ns": after.st_mtime_ns, "sha256": value}


def qualification(registration, registration_sha, binding_path):
    require(digest(registration) == registration_sha, "registration digest drift")
    launch = load_json(binding_path)
    require(launch["registration_sha256"] == registration_sha and launch["raft_message_id"],
            "record the actual Raft launch binding")
    reg = load_json(registration)
    freeze, runtime_sha = reg["freeze"], reg["runtime"]
    pins_path = SOURCE / "BINDINGS.json"
    smoke_path = ROOT / "SMOKE.json"
    require(
        reg == {
            "owner": OWNER, "root": str(ROOT), "freeze": freeze, "runtime": runtime_sha,
            "smoke": digest(smoke_path), "inputs": digest(pins_path), "stages": ["load", "reopen", "queries"],
            "import_and_reopen_seconds": 1800, "query_seconds": 900, "scored": False,
            "include_inferred": True, "axioms": "NoAxioms", "truth_maintenance": False,
            "require_total_equals_explicit": True,
        },
        "registration contract differs from the frozen workload",
    )
    preflight(freeze)
    require(shutil.disk_usage(ROOT).free >= 64 * GIB, "64 GiB launch floor")
    image = image_id()
    runtime = ROOT / "classes"
    smoke = load_json(smoke_path)
    require(smoke["status"] == "pass" and smoke["freeze"] == freeze and smoke["runtime"] == runtime_sha
            and smoke["include_inferred"] is True
            and all(smoke[key] == 9 for key in ("load_count", "reopen_count", "explicit_load_count", "explicit_reopen_count")),
            "streaming fixture gate missing")
    validate_runtime(runtime, freeze, image, runtime_sha)
    pins = load_json(pins_path)
    order = (SOURCE / "workload/queries/ORDER.txt").read_text().splitlines()
    require(order == [query["label"] for query in pins["queries"]] and len(set(order)) == 30,
            "query order differs from the frozen labels")
    directory = ROOT / "lubm-db"
    directory.mkdir()
    journal = directory / "store.jnl"
    workfile = "/db/store.jnl"
    data = Path(pins["input"]["path"])
    expected_count = pins["expected_unique_triples"]
    report = {
        "registration": registration_sha, "raft_message_id": launch["raft_message_id"],
        "stages": {stage: "not-run" for stage in reg["stages"]},
        "queries": [{"label": label, "status": "not-run"} for label in order],
        "scored": False, "admitted_primary": False,
    }
    try:
        report["input_before"] = input_identity(pins["input"])
        deadline = time.monotonic() + reg["import_and_reopen_seconds"]
        report["stages"]["load"] = "started"
        load = phase("load", ["load", workfile, "/input.nt"], deadline, runtime, image, directory, data=data)
        gate_output(load, "load", expected_count)
        loaded = {"sha256": digest(journal, deadline), **sizes(journal)}
        write_json(load / "JOURNAL.json", loaded)
        report["stages"]["load"] = "complete"
        report["load_counts"] = {"total": expected_count, "explicit": expected_count}
        report["stages"]["reopen"] = "started"
        reopen = phase("reopen", ["reopen", workfile], deadline, runtime, image, directory,
                       journal_sha=loaded["sha256"])
        gate_output(reopen, "reopen", expected_count)
        reopened = {"sha256": digest(journal, deadline), **sizes(journal)}
        write_json(reopen / "JOURNAL.json", reopened)
        guard(resource_sample(), deadline)
        report["stages"]["reopen"] = "complete"
        report["reopen_counts"] = {"total": expected_count, "explicit": expected_count}
        report["input_after_import"] = input_identity(pins["input"])
        preflight(freeze)
        validate_runtime(runtime, freeze, image, runtime_sha)
        deadline = time.monotonic() + reg["query_seconds"]
        report["stages"]["queries"] = "started"
        query = phase("queries", ["query", workfile, "/queries", "/out/answers"],
                      deadline, runtime, image, directory, journal_sha=reopened["sha256"],
                      query_source=SOURCE / "workload/queries")
        gate_output(query, "query")
        report["stages"]["queries"] = "complete"
    except BaseException as error:
        report["error"] = repr(error)
        for stage, status in report["stages"].items():
            if status == "started":
                report["stages"][stage] = "failed"
    finally:
        handlers = {sig: signal.signal(sig, signal.SIG_IGN) for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)}
        try:
            if "input_before" in report and "input_after_import" not in report:
                try:
                    report["input_after_import"] = input_identity(pins["input"])
                except (OSError, RuntimeError) as error:
                    report["input_postcheck_error"] = repr(error)
            postflight(report, journal, freeze, runtime, image, runtime_sha, pins_path, reg)
        finally:
            write_json(ROOT / "QUALIFICATION.json", report)
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    print(json.dumps({"stages": report["stages"], "admitted_primary": report["admitted_primary"]}))
    return report


def postflight(report, journal, freeze, runtime, image, runtime_sha, pins_path, registration):
    try:
        preflight(freeze)
        validate_runtime(runtime, freeze, image, runtime_sha)
        guard(resource_sample(), time.monotonic() + 10)
        report["journal_size"] = sizes(journal) if journal.is_file() else None
        report["identities_postchecked"] = True
    except BaseException as error:
        report["postcheck_error"] = repr(error)
    output = ROOT / "queries/out/answers"
    if output.is_dir():
        try:
            answers = replay(SOURCE / "workload", output, pins_path, registration["inputs"])
            report["queries"] = answers["labels"]
            report["answer_summary"] = {key: value for key, value in answers.items() if key != "labels"}
            report["admitted_primary"] = (
                not report.get("error") and report.get("identities_postchecked") is True
                and answers["all_primary_pass"] is True
            )
        except (OSError, ValueError, RuntimeError) as error:
            report["replay_error"] = repr(error)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--binding", type=Path, required=True)
    args = parser.parse_args()

    def cancel(signum, _frame):
        raise RuntimeError(f"interrupted by signal {signum}")

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, cancel)
    report = qualification(args.registration, args.sha256, args.binding)
    raise SystemExit(0 if report["admitted_primary"] else 1)


if __name__ == "__main__":
    main()
