# Execution contract

Root: `/private/tmp/rdf-jianlin-blazegraph39-all-statements-v1`. The lock owner text is `Jianlin task39 Blazegraph all-statements LUBM v1`. Confirm the shared-machine queue and current infrastructure rules, announce the exact stage window, and acquire the lock before running either command. Release only the exact lock after checking that the called process exited and each of its labelled containers is gone. The compile and fixture window is independent of the larger workload window.

Use the existing local Temurin and Maven jar identities. No image pull or dependency install is part of this attempt. Launch Python with `-E -s -B`, and keep the frozen source directory unchanged. Commands print the hashes of successful receipts.

```sh
rtk proxy python3 -E -s -B scratch/blazegraph39-all-statements-v1/run_qualification.py compile --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B scratch/blazegraph39-all-statements-v1/run_qualification.py smoke --freeze FREEZE_SHA256 --runtime RUNTIME_SHA256
```

Compile creates the root and records its exact image, jar, compiler and class identities. It mounts no RDF. Announce the resulting runtime receipt before the smoke. The smoke starts three separate JVMs and verifies each journal handoff before opening the next one. It requires nine stored triples in both exact count checks, with total equal to explicit at each boundary, nine exact typed SELECT terms, one `"9"^^xsd:integer` COUNT from the native query API, and an empty result with projection `o`. The query process can only read the query files. Python normalizes the standard plain-string and language-literal representation for the fixture comparison. Store profiles and the worker remain identical in the subsequent workload.

Schedule the workload only after review of the real runtime and pass receipt. Its registration object has keys `owner`, `root`, `freeze`, `runtime`, `smoke`, `inputs`, `stages`, `import_and_reopen_seconds`, `query_seconds` `scored`, `include_inferred`, `axioms`, `truth_maintenance` and `require_total_equals_explicit`, constrained by the executable. Use the exact `BINDINGS.json` SHA as `inputs`. Record the real Raft registration or launch message and the exact reviewed registration SHA in the separate binding file using `raft_message_id` and `registration_sha256`. Verify the binding against the conversation before invoking the worker.

```sh
rtk proxy python3 -E -s -B scratch/blazegraph39-all-statements-v1/run_workload.py --registration REGISTRATION.json --sha256 REGISTRATION_SHA256 --binding LAUNCH_BINDING.json
```

Each process starts offline and leaves its tabular or diagnostic output in the named phase. Report boundaries, exact counts, typed answer failures and incomplete phases according to their receipts. A normal qualification failure uses a nonzero CLI exit and preserves the root. Do not retry the same root. If the Docker control plane cannot prove a process exited and its labelled container is gone, retain the lock and resolve that specific container. A process or reviewer must never infer an empty answer from missing or partial output.
