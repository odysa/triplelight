#!/bin/sh
set -eu
test "$(cat /guard/owner)" = 'Jianlin task39 Blazegraph all-statements LUBM v1'
test "$(uname -m)" = aarch64
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS CLASSPATH
mkdir -p /out/metrics
grep '^MemTotal:' /proc/meminfo > /out/metrics/memtotal
for name in memory.max memory.swap.max cpu.max memory.events; do
    cat "/sys/fs/cgroup/$name" > "/out/metrics/before.$name"
done
if [ "$1" = compile ]; then
    java -version
    javac -version
    rc=0
    javac -encoding UTF-8 -J-Xmx512m -J-XX:ActiveProcessorCount=4 -cp /engine.jar \
        -d /runtime /BlazegraphWorkload.java || rc=$?
else
    rc=0
    java -Xmx8g -XX:ActiveProcessorCount=4 -Djava.io.tmpdir=/tmp \
        -cp /runtime:/engine.jar BlazegraphWorkload "$@" || rc=$?
fi
for name in memory.events memory.peak memory.current; do
    cat "/sys/fs/cgroup/$name" > "/out/metrics/after.$name"
done
test "$(cat /guard/owner)" = 'Jianlin task39 Blazegraph all-statements LUBM v1'
exit "$rc"
