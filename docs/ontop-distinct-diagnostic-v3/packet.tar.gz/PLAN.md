# Ontop COUNT(DISTINCT) diagnostic design

The published Ontop 5.5.0 and DuckDB JDBC 1.5.6.0 profile returned all nine typed RDF terms in its DISTINCT projection and eight in COUNT(DISTINCT). Two different equivalences can each explain a count of eight on this one fixture. The IRI and string have the same lexical text, and the xsd:int and xsd:integer terms have the same numeric value. The original packet has no reformulated SQL for those queries.

Use four fresh databases. Start each one from the exact archived source.sql and the unchanged R2RML mapping. Apply only these fixture deltas, before opening the repository. All four profiles retain the duplicate IRI and the NULL source row. Every profile still has nine distinct RDF terms.

| Profile | Fixture delta | Exact RDF count | If only lexical text is counted | If only equal numeric terms collapse |
| --- | --- | ---: | ---: | ---: |
| Original | None | 9 | 8 | 8 |
| Split text | Change row 2 from urn:iri to urn:split-text, keeping xsd:string | 9 | 9 | 8 |
| Split number | Change row 5 from 1 to 2, keeping xsd:integer | 9 | 8 | 9 |
| Split both | Apply both changes | 9 | 9 | 9 |

A model in which both equivalences collapse yields 7, 8, 8, 9. Compare observed result patterns with these predictions. A matching pattern supports an explanation for this fixture. A cause claim also requires reformulation evidence and a check that the aggregate operates on the suspected key.

Retain the unmodified plain projection, DISTINCT projection, term GROUP BY, COUNT and COUNT(DISTINCT) queries. Check all term identities and count datatypes per profile, using reference terms derived before execution from the preserved RDF fixture and deltas. Keep the aggregate and DISTINCT projection outputs separate. Capture the reformulated SQL for both SELECT DISTINCT and COUNT(DISTINCT) using Ontop's diagnostic API if available, with successful execution still checked through the RDF4J repository API. Record the API and source identity for the diagnostic path. If separate backends produce the diagnostics and answers, treat SQL as evidence from the diagnostic path only. Preserve missing or mismatched diagnostics.

Use the pinned macOS ARM64 JDK, Ontop and JDBC artifacts from the original packet. Prepare a fresh bounded execution registration with per-profile output paths, time and data limits. Keep the accepted packet and original runtime directory read-only. No timings or admission updates follow from these diagnostics. The design has no execution authorization or observed runtime results.
