# Ontop DISTINCT diagnostic execution

The single attempt uses the archived R2RML mapping, fixture SQL and five SPARQL queries. Each JDBC fixture is created from scratch in a separate process. The only changes are the two row values listed in PLAN.md. The typed consumer uses the archived Jena reference. It reports the four COUNT(DISTINCT) values and any matching fixture model only when the other controls pass. Native SQL and Ontop's intermediate query are captured independently of the answers for DISTINCT and COUNT(DISTINCT). Classify the aggregate key from the saved plan before attributing a cause.

Run on the shared macOS ARM64 benchmark host after the named handoff. Before compiling, verify the assigned slot, the exact lock owner and the source freeze. The existing Java 25, Ontop and DuckDB JDBC files stay read-only. The supervisor hashes the retained runtime files against the original manifest, compiles the diagnostic worker into a new directory using that compiler and explicit classpath, and checks the new class digest before each launch. It rechecks the input and runtime files at the end.

- Fresh attempt root is /private/tmp/rdf-jianlin-ontop46-distinct-v3.
- The exact lock owner text is Jianlin task46 Ontop DISTINCT diagnostic v3.
- The compiler is limited to 45 seconds. Each of the four profiles has a 60-second wall limit and a 2 GiB Java heap. The heap limit applies only to the managed heap.
- The supervisor checks the 42 GB host free-space floor and samples total output against 256 MiB while each child is alive. The Java children inherit a 110 MiB per-file limit, which accommodates the pinned 107,640,704-byte macOS library. Before querying, each worker records and verifies the extracted library's bytes and SHA-256 against the pinned jar entry. The original JDBC jar and its normal unpack-and-load path are retained. ([DuckDB JDBC 1.5.6.0 native loader](https://github.com/duckdb/duckdb-java/blob/v1.5.6.0/src/main/java/org/duckdb/DuckDBNative.java))
- The pinned loader registers its temporary library for deletion on normal JVM exit. After every child exits, the supervisor checks its private temp directory before the next profile. If the one expected library is still present and its size and hash match the pinned jar, the supervisor removes that copy and records its identity. It preserves unverified files and stops before starting another profile. The 256 MiB attempt cap includes all temporary files while they exist.
- A timeout, ownership mismatch or resource stop ends the attempt and keeps its receipts. A failed query or diagnostic call is recorded separately. The supervisor can continue bounds-compliant profiles after an ordinary process failure to retain diagnostics. The attempt has no retry, scores or workload admission.

From the directory containing this protocol, use the reviewed digest.

```sh
rtk proxy python3 -B supervise.py --freeze-sha256 <reviewed-freeze-sha256>
```

The replay consumer can be run from any directory with the corresponding attempt root. The Java source and supervisor have been inspected and the Python consumer has passed offline controls. The previous attempt compiled, then all four JVMs stopped during native library extraction at the 32 MiB limit before JDBC fixture setup or SPARQL. Its evidence remains in the v1 output root. This revised source is uncompiled and unrun.
