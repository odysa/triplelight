"""Conservative query-shape screen of the frozen aggregate and BI manifests."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

COUNT_DISTINCT = re.compile(r"\bCOUNT\s*\(\s*DISTINCT\b", re.IGNORECASE)
LITERALS_AND_COMMENTS = re.compile(r"""<[^<>\s]*>|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\#[^\n]*""")


def inspect(query, aggregate_sql):
    aggregate_sql.translate(query)
    tokens = aggregate_sql.TOKEN.findall(query)
    start, end = tokens.index("{"), tokens.index("}")
    body = tokens[start + 1:end]
    if body and body[-1] == ".":
        body.pop()
    triples = [group.split() for group in " ".join(body).split(" . ")]
    if any(len(group) != 3 for group in triples):
        raise ValueError("unrecognized curated BGP")
    targets = [tokens[i+3] for i in range(len(tokens)-3)
               if [part.upper() for part in tokens[i:i+3]] == ["COUNT", "(", "DISTINCT"]]
    result = {}
    for var in targets:
        positions = sorted({place for triple in triples for place, term in zip("spo", triple, strict=True) if term == var})
        if not positions:
            raise ValueError(f"unbound DISTINCT variable {var}")
        result[var] = {"positions": positions, "resource_required": "s" in positions or "p" in positions}
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("registry", type=Path)
    ap.add_argument("routing", type=Path)
    args = ap.parse_args()
    sys.path.insert(0, str(args.routing.resolve()))
    import aggregate_sql

    result = {"aggregates": {}, "bi": {}}
    for kind, manifest, root in (
        ("aggregates", "aggregate-routing-draft.json", "agg72"),
        ("bi", "bi-routing-draft.json", "bi10m/queries"),
    ):
        labels = json.loads((args.routing / manifest).read_text())
        for name, entry in sorted(labels.items()):
            text = (args.registry / root / name).read_bytes()
            digest = hashlib.sha256(text).hexdigest()
            if digest != entry["query_sha256"]:
                raise ValueError(f"query bytes changed: {name}")
            query = text.decode("utf-8")
            value = {"query_sha256": digest}
            if kind == "aggregates":
                targets = inspect(query, aggregate_sql)
                masked = LITERALS_AND_COMMENTS.sub(" ", query)
                if len(COUNT_DISTINCT.findall(masked)) != len(targets):
                    raise ValueError(f"DISTINCT count screen disagrees: {name}")
                value["count_distinct_targets"] = targets
                value["needs_domain_evidence"] = any(not target["resource_required"] for target in targets.values())
            else:
                value["count_distinct_occurrences"] = len(COUNT_DISTINCT.findall(LITERALS_AND_COMMENTS.sub(" ", query)))
                value["warmup"] = entry["warmup"]
            result[kind][name] = value
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
