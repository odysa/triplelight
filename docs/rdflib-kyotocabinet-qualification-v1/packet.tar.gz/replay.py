"""Replay Kyoto Cabinet packaging and fixture evidence using the standard library and retained raw records."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

XSD = 'http://www.w3.org/2001/XMLSchema#'
LANG_STRING = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
PREFIX = '<urn:s> <urn:v> '
SUBJECT = ('uri', 'urn:s', '', '')
PREDICATE = ('uri', 'urn:v', '', '')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def fixture_object(encoded):
    if encoded.startswith('<') and encoded.endswith('>'):
        return 'uri', encoded[1:-1], '', ''
    lexical, end = json.JSONDecoder().raw_decode(encoded)
    assert isinstance(lexical, str)
    suffix = encoded[end:]
    if suffix.startswith('@'):
        return 'literal', lexical, LANG_STRING, suffix[1:].lower()
    if suffix.startswith('^^<') and suffix.endswith('>'):
        return 'literal', lexical, suffix[3:-1], ''
    assert not suffix
    return 'literal', lexical, XSD + 'string', ''


def typed(term):
    kind = term['type']
    assert kind in ('literal', 'uri')
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype', LANG_STRING if language else XSD + 'string') if kind == 'literal' else ''
    return kind, term['value'], datatype, language


def reference(source):
    expected = Counter()
    for line in (source / 'consumer-fixture.nt').read_text().splitlines():
        assert line.startswith(PREFIX) and line.endswith(' .')
        expected[SUBJECT, PREDICATE, fixture_object(line[len(PREFIX):-2])] += 1
    jena = load(source / 'consumer-fixture-jena.json')['results']['bindings']
    assert len(expected) == sum(expected.values()) == 9
    assert expected == Counter((SUBJECT, PREDICATE, typed(item['o'])) for item in jena)
    return expected


def bag(rows):
    return Counter(tuple(typed(term) for term in row) for row in rows)


def compare(expected, actual):
    return {'exact': expected == actual, 'terms': sum(actual.values()),
            'missing': sorted((expected - actual).items()),
            'extra': sorted((actual - expected).items())}


def source_identity(source):
    manifest = source / 'FREEZE.json'
    for path, expected in load(manifest).items():
        assert digest(source / path) == expected, path
    return digest(manifest)


def supervisor(root, stage, freeze):
    check = load(root / stage / 'SUPERVISOR.json')
    assert check['stage'] == stage and check['source_sha256'] == freeze
    assert check['cleanup'] in ('verified-removed', 'not-created')
    if 'error' not in check:
        assert check['cleanup'] == 'verified-removed'
        assert check['exit_code'] == check['attach_exit'] == 0
        assert check['oom_killed'] is check['running'] is False
    return check


def packaging_summary(root, stage, profile, freeze):
    check = supervisor(root, stage, freeze)
    receipt = root / 'runtime/PACKAGING.json'
    outcome = {'supervisor_error': check.get('error')}
    if not receipt.exists():
        assert check.get('error')
        return outcome
    package = load(receipt)
    assert package['profile'] == profile and package['rdf_data_opened'] is False
    if 'error' not in check:
        assert check['packaging_sha256'] == digest(receipt)
        assert package['state'] == check['packaging_state']
    if package['state'] == 'adapter-wheel-build-failed':
        assert package['build_exit'] != 0
    if profile == 'modern':
        assert package['adapter_imported'] is False and not (root / 'runtime/RUNTIME.json').exists()
    outcome.update(state=package['state'], build_exit=package.get('build_exit'),
                   python=package['python'], error=package.get('error'))
    if 'pip_check' in package:
        outcome['pip_check'] = package['pip_check']
    return outcome


def storage_summary(root, freeze, runtime, expected):
    stage = 'historical-storage'
    check = supervisor(root, stage, freeze)
    out = root / stage / 'out'
    summary = {'supervisor_error': check.get('error'), 'profiles': {}}
    if not (out / 'OBSERVATIONS.json').is_file():
        assert check.get('error')
        return summary
    observation = load(out / 'OBSERVATIONS.json')
    assert observation['runtime_sha256'] == digest(runtime)
    assert observation['historical_profile'] is True and observation['full_workload_qualified'] is False
    probe = load(runtime).get('normalization_probe')
    assert observation['normalization_probe'] == probe
    if not check.get('error'):
        assert set(observation['profiles']) == {'default', 'preserve'}

    for profile, phases in observation['profiles'].items():
        assert profile in ('default', 'preserve')
        if phases.get('state') == 'skipped-normalization-switch-not-confirmed':
            assert profile == 'preserve' and probe != {'normal': '1', 'preserve': '01'}
            summary['profiles'][profile] = phases
            continue
        actual = summary['profiles'][profile] = {}
        if profile == 'preserve':
            assert probe == {'normal': '1', 'preserve': '01'}
        if not check.get('error'):
            assert set(phases) == {'load', 'reopen'}
        parsed = None
        for boundary in ('load', 'reopen'):
            if boundary not in phases:
                continue
            item = phases[boundary]
            if item.get('state') == 'skipped-after-load-error':
                assert boundary == 'reopen' and phases['load']['step'] != 'complete'
                actual[boundary] = item
                continue
            result = actual[boundary] = {'step': item['step'], 'exit': item['exit']}
            if item['step'] == 'worker-exit':
                assert item['exit'] != 0
                continue
            row = load(out / profile / (boundary + '.json'))
            assert item['exit'] == 0 and row['step'] == item['step']
            assert row['boundary'] == boundary and row['profile'] == profile
            assert row['create'] is (boundary == 'load')
            result['error'] = row.get('error')
            if 'parsed' in row:
                assert boundary == 'load'
                parsed = bag(row['parsed'])
                result['parsed'] = compare(expected, parsed)
                assert row['parsed_count'] == result['parsed']['terms']
                assert row['parsed_exact'] is result['parsed']['exact']
            if item['step'] != 'complete':
                assert result['error']
                continue
            assert row['closed'] is True and row['open_result'] == 1
            assert parsed is not None
            assert profile != 'preserve' or row['normalize_literals'] is False
            observed = bag(row['triples'])
            result.update(graph_length=row['count'],
                          count_exact=type(row['count']) is int and row['count'] == 9,
                          to_reference=compare(expected, observed), to_parsed=compare(parsed, observed))
            assert row['exact_bag'] is result['to_reference']['exact']
            diagnostic = row['shared_evaluator']
            assert diagnostic['passes'] is (diagnostic.get('columns') == ['o'] and diagnostic.get('rows') == [])
            result['diagnostic_rows'] = len(diagnostic['rows']) if 'rows' in diagnostic else None
            result['diagnostic_error'] = diagnostic.get('error')
            inventory = item['inventory']
            assert any(name.endswith('.kch') and meta['bytes'] > 0 for name, meta in inventory.items())
            result['kch_files'] = sorted(name for name in inventory if name.endswith('.kch'))
    return summary


def replay(root):
    source = root / 'source'
    freeze = source_identity(source)
    expected = reference(source)
    retired_freeze = source_identity(root / 'source-v1')
    assert reference(root / 'source-v1') == expected
    modern = packaging_summary(root / 'modern', 'modern', 'modern', retired_freeze)
    failed = root / 'historical-v1'
    stage = supervisor(failed, 'historical-setup', retired_freeze)
    failure = load(failed / 'runtime/RUNTIME.json')
    assert stage['runtime_sha256'] == digest(failed / 'runtime/RUNTIME.json')
    assert stage['runtime_state'] == failure['state'] == 'debian-binding-import'
    assert failure['rdf_data_opened'] is False and 'liblzo2.so.2' in failure['error_text']
    assert not (failed / 'historical-storage').exists()
    old = root / 'historical'
    historical = packaging_summary(old, 'historical-setup', 'historical', freeze)
    result = {'source_sha256': freeze, 'reference_terms': sum(expected.values()),
              'modern_packaging': modern, 'historical_packaging': historical,
              'historical_v1_native_loader_error': failure['error_text']}
    runtime = old / 'runtime/RUNTIME.json'
    if not runtime.exists():
        assert historical.get('supervisor_error') or historical['state'] != 'ready-for-import-probe'
        return result
    probe = load(runtime)
    setup = supervisor(old, 'historical-setup', freeze)
    assert probe['rdf_data_opened'] is False
    assert setup['runtime_sha256'] == digest(runtime) and setup['runtime_state'] == probe['state']
    result['historical_runtime'] = {'sha256': setup['runtime_sha256'], 'state': probe['state'],
                                    'error': probe.get('error'), 'installed_files': len(probe['installed'])}
    if probe['state'] == 'ready':
        pins = load(source / 'PINS.json')['historical']
        expected_native = {str(Path('debian') / value['package_path']): value['sha256']
                           for value in pins['native_files'].values()}
        assert probe['native'] == expected_native
        assert 'kyotocabinet' + probe['python_extension_suffix'] in pins['native_files']
        assert len(probe['installed']) == 358
        result['historical_storage'] = storage_summary(old, freeze, runtime, expected)
    else:
        assert not (old / 'historical-storage').exists() and probe.get('error')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('packet_directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.packet_directory), sort_keys=True, indent=2))
