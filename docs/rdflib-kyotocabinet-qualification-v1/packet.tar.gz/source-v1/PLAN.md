# RDFLib Kyoto Cabinet qualification plan

Use the unmodified adapter source at `c65bf64f278078b9fb6d1242b5dadced77d3ef28`. Its setup script calls the old `distutils.util.run_2to3` function and requests setuptools' legacy source conversion. Its store also imports `rdflib.py3compat.b`. That name exists in the published RDFLib 4.2.2 wheel. It is absent from the inspected RDFLib 5.0.0, 6.0.0 and 7.6.0 distributions. The declared `Kyoto_Cabinet` project currently returns HTTP 404 on PyPI. [Pinned adapter source](https://github.com/RDFLib/rdflib-kyotocabinet/tree/c65bf64f278078b9fb6d1242b5dadced77d3ef28) · [RDFLib 4.2.2](https://pypi.org/project/rdflib/4.2.2/)

## Modern packaging control

Run only the build of the untouched source in the pinned Linux ARM64 CPython 3.12.16 Bookworm image from the LevelDB check, with setuptools 80.9.0 and wheel 0.45.1. Disable network and dependency resolution so any first packaging error is observable. Record the exact stage, exit and traceback. Keep the PyPI dependency lookup separate from the observed build result. This control does not import the plugin or open RDF data.

## Historic dependency profile

Use the pinned Linux ARM64 Bullseye CPython 3.9.23 image. Install the exact RDFLib 4.2.2, pyparsing 2.4.7 and isodate 0.6.1 distribution wheels and their six dependency. Build the untouched adapter offline with setuptools 57.5.0, wheel 0.37.1 and the standard-library distutils conversion. The published source's conversion belongs to the build step. No ad hoc source edits or compatibility shims.

Use the Debian ARM64 Kyoto Cabinet Python package 1.22-3+b3 as the provider of the `kyotocabinet` module, the Debian library 1.2.76-4.2+b1 and liblzo2-2 2.10-2. Extract them into the private runtime, verify the exact native extension and library contents and check loaded paths. Use native library names from the recorded ELF table. This is an explicit distribution substitution for the unavailable pip dependency. Explain any missing Python distribution metadata. Verify the adapter entry point and runtime receipts before opening the fixture. Keep build, import, and store errors distinct. [Debian Python binding](https://packages.debian.org/bullseye/python3-kyotocabinet) · [Debian runtime library](https://packages.debian.org/bullseye/libkyotocabinet16v5)

If setup succeeds, parse, load and reopen the same nine-term fixture across independent default and literal-preserving RDFLib profiles. Keep the graph identifier fixed across load and a fresh child reopen with creation disabled. Compare the parsed and stored term bags and enumerate the resulting database files at both boundaries. Capture the separate `FILTER(false)` diagnostic without assuming that this older evaluator returns the same result as RDFLib 7.6.0. Stop at the first failure in any profile and preserve the observed step and completed sibling evidence. The outcome will describe only this isolated historical profile.

Before execution, pin the image, artifacts, harness, container mounts and caps, and verify the current machine handoff and free space. Use distinct private roots and offline read-only-root containers for the modern and historic checks. No engine build, install, import or timing has run for this candidate. `DISCOVERY.json` records the preliminary artifact and ELF verification.
