"""Engine-free controls for the native storage harness."""
import ast
from copy import deepcopy
import json
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
import sys
import tempfile

import storage_inside as storage
import supervise as host
from runtime import LABEL, LABEL_KEY, PINS, SOURCE, expected_native, load


def rejects(call, expected):
    try:
        call()
    except RuntimeError as exc:
        assert str(exc) == expected
    else:
        raise AssertionError(f'expected rejection: {expected}')


def main():
    for path in SOURCE.glob('*.py'):
        ast.parse(path.read_text(), filename=str(path), feature_version=(3, 9))
    ref = load(SOURCE / 'consumer-fixture-jena.json')
    fixtures = [[{'type': 'uri', 'value': 'urn:s'}, {'type': 'uri', 'value': 'urn:v'}, row['o']]
                for row in ref['results']['bindings']]
    assert storage.exact_bag(fixtures)
    assert not storage.exact_bag(fixtures[:-1] + fixtures[:1])
    assert not storage.exact_bag(fixtures + fixtures[:1])
    normalized = deepcopy(fixtures)
    index = next(i for i, row in enumerate(fixtures) if row[2]['value'] == '01')
    normalized[index][2]['value'] = '1'
    assert not storage.exact_bag(normalized)

    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory).resolve()
        db = root / 'db'
        db.mkdir()
        data = db / 'data.kch'
        data.write_bytes(b'data')
        assert storage.inventory(db) == {'data.kch': {'bytes': 4, 'sha256': sha256(b'data').hexdigest()}}
        (db/'link').symlink_to(data)
        rejects(lambda: storage.inventory(db), 'unexpected Kyoto Cabinet file type')

        pins = deepcopy(PINS['historical']['native_files'])
        for name, pin in pins.items():
            file = root / pin['package_path']
            file.parent.mkdir(parents=True, exist_ok=True)
            payload = name.encode()
            file.write_bytes(payload)
            pin['sha256'] = sha256(payload).hexdigest()
            for link in pin['soname'] or []:
                (file.parent/link).symlink_to(name)
        with patch.dict(PINS['historical'], native_files=pins):
            assert set(expected_native(root)) == set(pins)
            name = 'liblzo2.so.2.0.0'
            file = root / pins[name]['package_path']
            file.write_bytes(b'changed')
            rejects(lambda: expected_native(root), f'wrong native Debian file: {name}')

    mounts = {'/src': (Path('/private/tmp/leveldb39-source'), False)}
    environment = ['LD_LIBRARY_PATH=' + host.LOADER]
    command = ['python']
    container = {'HostConfig': {'NetworkMode': 'none', 'ReadonlyRootfs': True, 'CgroupnsMode': 'private',
                                'NanoCpus': host.CPUS * 10**9, 'Memory': host.MEMORY,
                                'MemorySwap': host.MEMORY, 'Tmpfs': {'/tmp': host.TMPFS}},
                 'Config': {'Labels': {LABEL_KEY: LABEL}, 'Env': environment, 'Cmd': command},
                 'Platform': 'linux', 'Image': 'image-id',
                 'Mounts': [{'Destination': '/src', 'Source': str(mounts['/src'][0]), 'RW': False}]}
    validate = lambda info: host.configuration(info, container['Image'], mounts, environment, command)
    assert validate(container)['network'] == 'none'
    for key, wrong in [('NetworkMode', 'bridge'), ('ReadonlyRootfs', False), ('MemorySwap', host.MEMORY * 2)]:
        changed = deepcopy(container)
        changed['HostConfig'][key] = wrong
        rejects(lambda: validate(changed), 'container binding check failed')
    changed = deepcopy(container)
    changed['Mounts'][0]['RW'] = True
    rejects(lambda: validate(changed), 'container binding check failed')

    assert not {'rdflib', 'kyotocabinet', 'rdflib_kyotocabinet'}.intersection(sys.modules)
    print(json.dumps({'python_syntax': '3.9', 'engine_imported': False,
                      'exact_bag_controls': 4, 'inventory_controls': 2, 'native_pin_controls': 2,
                      'container_binding_controls': 5}, sort_keys=True))


if __name__ == '__main__':
    main()
