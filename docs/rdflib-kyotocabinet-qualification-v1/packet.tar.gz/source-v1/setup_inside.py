"""Record packaging and runtime setup without opening an RDF fixture."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import sysconfig

from runtime import (DEBIAN, IMAGE_PYTHON, PINS, PYTHON, RUNTIME, adapter_identity,
                     expected_native, installed, native_identity, platform_check, require, sha, write)

INPUTS = Path('/inputs')
BUILD = RUNTIME / 'build'
PREPARE = RUNTIME / 'PACKAGING.json'
RECEIPT = RUNTIME / 'RUNTIME.json'
PIP = [PYTHON, '-I', '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check', '--no-cache-dir']


def run(*command):
    return subprocess.run(command, check=True)


def probe():
    platform_check()
    require(Path(sys.executable) == PYTHON, 'wrong historical Python entry point')
    record = {'state': 'native-identity', 'rdf_data_opened': False,
              'python_sha256': sha(PYTHON), 'installed': installed()}
    try:
        expected_native()
        record['state'] = 'debian-binding-import'
        suffix = sysconfig.get_config_var('EXT_SUFFIX')
        record['python_extension_suffix'] = suffix
        require(suffix and 'kyotocabinet' + suffix in PINS['historical']['native_files'],
                'Debian binding extension tag differs from interpreter ABI tag')
        record['native'] = native_identity()
        record['state'] = 'adapter-import'
        rdflib = adapter_identity()
        record['literal_normalization_default'] = getattr(rdflib, 'NORMALIZE_LITERALS', None)
        if record['literal_normalization_default'] is not None:
            from rdflib.namespace import XSD
            original = rdflib.NORMALIZE_LITERALS
            try:
                rdflib.NORMALIZE_LITERALS = True
                normal = str(rdflib.Literal('01', datatype=XSD.int))
                rdflib.NORMALIZE_LITERALS = False
                preserve = str(rdflib.Literal('01', datatype=XSD.int))
            finally:
                rdflib.NORMALIZE_LITERALS = original
            record['normalization_probe'] = {'normal': normal, 'preserve': preserve}
        record['state'] = 'ready'
    except Exception as exc:
        record.update(error=repr(exc), error_text=str(exc))
    write(RECEIPT, record)


def setup(profile):
    platform_check(profile)
    require(Path(sys.executable).resolve() == IMAGE_PYTHON.resolve(), 'wrong image interpreter')
    pins = PINS[profile]
    old = profile == 'historical'
    for entry in pins['archives'] + pins['wheels']:
        file = INPUTS / entry['filename']
        require(file.stat().st_size == entry['bytes'] and sha(file) == entry['sha256'],
                f'changed artifact {file.name}')

    report = {'profile': profile, 'rdf_data_opened': False, 'adapter_imported': False,
              'state': 'venv', 'python': sys.version}
    try:
        BUILD.mkdir()
        run(IMAGE_PYTHON, '-I', '-B', '-m', 'venv', PYTHON.parent.parent)
        report['state'] = 'toolchain-install'
        run(*PIP, 'install', '--no-index', '--no-deps', '--no-compile',
            *(INPUTS / item['filename'] for item in pins['wheels']))
        report['pip'] = subprocess.check_output([*PIP, '--version'], text=True).strip()
        report['distutils_provider'] = os.environ.get('SETUPTOOLS_USE_DISTUTILS', 'default')
        distutils = subprocess.run(
            [PYTHON, '-I', '-B', '-c',
             'from distutils import util; print(util.__file__); print(hasattr(util, "run_2to3"))'],
            capture_output=True, text=True, check=False)
        report['distutils_util'] = {'returncode': distutils.returncode,
                                    'stdout': distutils.stdout, 'stderr': distutils.stderr}
        report['state'] = 'adapter-wheel-build'
        build = subprocess.run([*PIP, 'wheel', '--no-index', '--no-deps', '--no-build-isolation',
                                '--use-pep517', '-w', BUILD, INPUTS / pins['archives'][0]['filename']],
                               check=False)
        report['build_exit'] = build.returncode
        if build.returncode:
            report['state'] = 'adapter-wheel-build-failed'
            return
        wheels = list(BUILD.glob('*.whl'))
        require(len(wheels) == 1, 'wrong number of adapter wheels')
        report['built_wheels'] = {wheel.name: sha(wheel) for wheel in wheels}
        if not old:
            report['state'] = 'modern-build-completed'
            return

        report['state'] = 'debian-extract'
        for entry in pins['archives'][1:]:
            file = INPUTS / entry['filename']
            arch = subprocess.check_output(['dpkg-deb', '-f', file, 'Architecture'], text=True).strip()
            require(arch == 'arm64', 'wrong Debian architecture')
            run('dpkg-deb', '-x', file, DEBIAN)
        expected_native()

        report['state'] = 'adapter-install'
        run(*PIP, 'install', '--no-index', '--no-deps', '--no-compile', *wheels)
        dependencies = subprocess.run([*PIP, 'check'], capture_output=True, text=True, check=False)
        report['pip_check'] = {'returncode': dependencies.returncode, 'stdout': dependencies.stdout,
                               'stderr': dependencies.stderr}
        lines = dependencies.stdout.lower().splitlines()
        require(dependencies.returncode == 1 and len(lines) == 1 and 'kyoto-cabinet' in lines[0].replace('_', '-')
                and 'not installed' in lines[0], 'unexpected dependency check outcome')
        report['state'] = 'ready-for-import-probe'
    except Exception as exc:
        report.update(error=repr(exc), error_text=str(exc))
        raise
    finally:
        write(PREPARE, report)
    if old:
        run(PYTHON, '-E', '-s', '-B', Path(__file__), 'probe')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('modern', 'historical', 'probe'))
    mode = parser.parse_args().mode
    if mode == 'probe':
        probe()
    else:
        setup(mode)
