# Kyoto Cabinet execution

Verify `FREEZE.json` and the current machine handoff before claiming the lock. The exact owner is `Jianlin task39 Kyoto Cabinet v1`. Confirm that both new run roots are absent and the data volume has at least 40 GB free. While holding the lock, inspect the exact ARM64 images in `PINS.json`. Pull only a missing exact digest and retain the pull receipt. The modern and historical profiles use distinct host roots ending in `-modern` and `-historical` under `/private/tmp/rdf-jianlin-kyotocabinet39-v1-*`.

```bash
rtk proxy python3 -E -s -B scratch/rdflib-kyotocabinet39-plan-v1/supervise.py modern --freeze-sha256 <freeze>
rtk proxy python3 -E -s -B scratch/rdflib-kyotocabinet39-plan-v1/supervise.py historical-setup --freeze-sha256 <freeze>
```

Read each `SUPERVISOR.json`, the exact `runtime/PACKAGING.json` and the container logs. An adapter wheel build failure is a retained packaging observation. The modern control never imports the adapter and never receives a writable database output mount. The historical runtime additionally verifies the Debian files, the Python extension suffix, all installed wheel RECORD entries and the loaded shared objects. The Debian extension supplies the import without satisfying pip's distribution metadata check. Retain the exact output from `pip check`. The runtime probe records the live normalization switch and verifies the historical adapter entry point before any RDF data access.

If the historical setup supervisor records `runtime_state: ready` and verified cleanup, announce the digest before running:

```bash
rtk proxy python3 -E -s -B scratch/rdflib-kyotocabinet39-plan-v1/supervise.py historical-storage --freeze-sha256 <freeze> --runtime-sha256 <ready-runtime>
```

Storage uses the same frozen Python and library identities in fresh worker processes. The runtime is read-only. Preserve mode is enabled only if the live RDFLib probe normalized the test literal with the switch on and preserved it with the switch off. The in-memory parse precedes writing. Each profile stops after its first failed storage step. Reopen uses the existing database and passes creation disabled. The shared evaluator diagnostic has its own outcome.

The modern build, historical setup and storage caps are 120, 180 and 90 seconds. Each container uses two CPUs, 2 GiB RAM and no additional swap. Each private root has a 2 GiB allocation ceiling. There is no network in any container. The host supervises attached runs and verifies cleanup by the exact container label. Release only the exact owned lock after the children exit and all created containers are removed. Do not amend the pinned adapter or rerun an observed stage in place. There is no timing workload in this harness.
