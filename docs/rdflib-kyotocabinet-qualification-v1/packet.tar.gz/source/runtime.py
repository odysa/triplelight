"""Shared identity and receipt checks. Compatible with Python 3.9."""
from base64 import urlsafe_b64encode
from hashlib import sha256
from importlib.metadata import distribution
import json
from pathlib import Path
import platform
import sys

SOURCE = Path(__file__).resolve().parent
PINS = json.loads((SOURCE / 'PINS.json').read_bytes())
RUNTIME = Path('/runtime')
DEBIAN = RUNTIME / 'debian'
PYTHON = RUNTIME / 'venv/bin/python'
IMAGE_PYTHON = Path('/usr/local/bin/python3')
OWNER = 'Jianlin task39 Kyoto Cabinet v2'
LABEL = 'jianlin-kyotocabinet39-v2'
LABEL_KEY = 'org.triplelight.jianlin.qualification'
LOCK = Path('/guard/owner')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1 << 18), b''):
            digest.update(block)
    return digest.hexdigest()


def write(path, record):
    with path.open('x') as output:
        json.dump(record, output, indent=2, sort_keys=True)
        output.write('\n')


def load(path):
    return json.loads(path.read_bytes())


def platform_check(profile='historical'):
    require(LOCK.read_text() == OWNER + '\n', 'exact Kyoto Cabinet owner required')
    require(platform.system() == 'Linux' and platform.machine() == 'aarch64'
            and platform.python_version() == PINS[profile]['python'], 'wrong Linux ARM64 Python')


def installed():
    prefix = PYTHON.parent.parent
    files = {}
    for name, version in PINS['historical']['versions'].items():
        dist = distribution(name)
        require(dist.version == version and dist.files, f'wrong historical distribution {name}')
        for member in dist.files:
            path = Path(dist.locate_file(member)).resolve(strict=True)
            require(path.is_relative_to(prefix), f'installed file escaped private venv: {member}')
            digest = sha(path)
            if member.hash:
                encoded = urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip('=')
                require(member.hash.mode == 'sha256' and encoded == member.hash.value
                        and path.stat().st_size == member.size, f'RECORD mismatch: {member}')
            else:
                require(str(member).endswith('.dist-info/RECORD'), f'unsigned RECORD entry: {member}')
            files[str(path.relative_to(RUNTIME))] = digest
    return files


def expected_native(root=DEBIAN):
    expected = {}
    for name, identity in PINS['historical']['native_files'].items():
        path = root / identity['package_path']
        require(path.name == name and path.resolve(strict=True) == path and sha(path) == identity['sha256'],
                f'wrong native Debian file: {name}')
        for soname in identity['soname'] or []:
            require((path.parent / soname).resolve(strict=True) == path, f'wrong SONAME target: {soname}')
        expected[name] = path
    return expected


def native_identity():
    expected = expected_native()
    extension = expected['kyotocabinet.cpython-39-aarch64-linux-gnu.so']
    sys.path.insert(0, str(extension.parent))
    import kyotocabinet

    require(Path(kyotocabinet.__file__).resolve(strict=True) == extension, 'wrong Kyoto extension origin')
    mapped = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith('/'):
            path = Path(fields[5])
            if path.name.startswith(('libkyotocabinet.so', 'liblzo2.so', 'kyotocabinet.cpython')):
                mapped.add(path.resolve(strict=True))
    require(mapped == set(expected.values()), 'mapped library paths differ from Debian native pins')
    return {str(path.relative_to(RUNTIME)): sha(path) for path in sorted(mapped)}


def adapter_identity():
    import rdflib
    from rdflib_kyotocabinet.KyotoCabinet import KyotoCabinet
    from rdflib.store import Store

    require(rdflib.plugin.get('KyotoCabinet', Store) is KyotoCabinet, 'wrong RDFLib KyotoCabinet entry point')
    return rdflib


def runtime_identity(digest):
    platform_check()
    receipt = RUNTIME / 'RUNTIME.json'
    require(sha(receipt) == digest, 'changed historical runtime digest')
    record = load(receipt)
    require(record['state'] == 'ready' and record['rdf_data_opened'] is False, 'historical runtime is not ready')
    require(Path(sys.executable) == PYTHON and sha(PYTHON) == record['python_sha256'],
            'storage must run with the registered Python')
    require(installed() == record['installed'], 'installed historical files changed')
    require(native_identity() == record['native'], 'loaded historical libraries changed')
    return adapter_identity()
