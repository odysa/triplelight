# Kyoto Cabinet historical retry

Revision 1 completed the modern packaging observation. That stage is excluded from this retry. The historical stage built and installed the adapter and checked the Debian files, but the native loader could not find LZO. The verified Debian files are split between private `lib/aarch64-linux-gnu` and `usr/lib/aarch64-linux-gnu` directories. This revision derives the loader path from the pinned ELF files that declare a SONAME. The extension ABI check, exact mappings and input package pins are unchanged.

Verify `FREEZE.json`, live machine ownership, 40 GB free on the data volume, and a fresh `/private/tmp/rdf-jianlin-kyotocabinet39-v2-historical`. The exact owner is `Jianlin task39 Kyoto Cabinet v2`. Use the already-local pinned historical ARM64 image.

```bash
rtk proxy python3 -E -s -B scratch/rdflib-kyotocabinet39-plan-v2/supervise.py historical-setup --freeze-sha256 <freeze>
```

Retain the packaging and runtime records and confirm exact cleanup. If setup is ready, announce the runtime digest before running storage.

```bash
rtk proxy python3 -E -s -B scratch/rdflib-kyotocabinet39-plan-v2/supervise.py historical-storage --freeze-sha256 <freeze> --runtime-sha256 <runtime>
```

The setup and storage caps are 180 and 90 seconds. The CPU, memory, root allocation, network and mounted-directory restrictions are unchanged. Release the exact lock once both owned processes have exited and any created containers have been removed. Preserve revision 1 as well as the revision 2 receipts.
