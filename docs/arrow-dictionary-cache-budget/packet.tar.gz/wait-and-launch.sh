#!/bin/bash
# Waits (max 90 min) for the machine lock to be free, then runs the registered A2 launch once.
set -u
REG=a40674ec9c233c114aff8c22d56fdb2f8ec85c3e2e4fe3ba6f471b9b061d74b1
MSG=98b796e9-b0e6-498a-b721-67476bf05367
end=$(( $(date +%s) + 5400 ))
while [ -e /tmp/rdf-bench.lock ]; do
  [ "$(date +%s)" -ge "$end" ] && { echo "timeout waiting for lock"; exit 9; }
  sleep 20
done
docker ps --format '{{.Names}} {{.Status}}' > /tmp/a37/foreign-containers-before-scored-v2.txt
docker stats --no-stream --format '{{.Name}} {{.CPUPerc}}' > /tmp/a37/foreign-cpu-before-scored-v2.txt
bash /tmp/a37/launch.sh "$REG" "$MSG"; rc=$?
docker ps --format '{{.Names}} {{.Status}}' > /tmp/a37/foreign-containers-after-scored-v2.txt
docker stats --no-stream --format '{{.Name}} {{.CPUPerc}}' > /tmp/a37/foreign-cpu-after-scored-v2.txt
echo "launch exit $rc"
exit $rc
