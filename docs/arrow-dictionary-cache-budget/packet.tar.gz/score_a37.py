"""Task #34 step-4 Phase A2: cache-budget sweep (1x/1.5x/2x), trace-on, A1 counter windows plus page-cache context.
Derived from the reviewed a34 v2 supervisor (same container, cgroup, cache-drop, clone, inventory, cleanup, lock and
binding rules; strict types).

  score_a37.py qualify --owner=<lock owner>    untimed: per cell, probe `qualify` then one dry `phase` per order
  score_a35.py register                        write /tmp/a37/scored-v1/registration.json once
  score_a37.py bind <registration-sha256> <message-uuid>
  score_a37.py run <registration-sha256>       requires the lock held by the registered owner
"""
import hashlib, json, math, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path

sys.dont_write_bytecode = True
S = Path("/tmp/a37")
LOCK = Path("/tmp/rdf-bench.lock")
REPO = Path("<agent-workspace>/rdfdb")
BENCH = REPO / "bench"
WT = Path("/tmp/a34-wt")
IMG = "debian@sha256:a72b4433de1cf7d6bae0c4cee74d0547f58601a643b3375f070c51600d63b6b2"
STORES = {"lubm1000": BENCH / "tools/rdfdb-diskvm-lubm1000"}
PREPARED = {"lubm1000": Path("/tmp/s36/prepared/lubm1000/stats-0.v1")}
# Frozen per-cell answer values: the passed a34 qualification v3 (PR #45), instrumented-path canonical sums.
A34_QUAL = Path("/tmp/a34/qual/QUAL.json")
A34_QUAL_SHA256 = "043661d23c8484320f1f4754c9152cc403408cbc2e1aac221531c1421ab55bf9"
# (cell, store, query file, locality?)
CELLS = [("lubm1000-q9", "lubm1000", BENCH / "lubm/q9.rq", True),
         ("lubm1000-q14", "lubm1000", BENCH / "lubm/q14.rq", False)]
BATCH_ROWS = 8192
CAP = 1200
CPUS, MEM = 4, 12 << 30
SIGNALS = (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)
WRAP = ('grep MemTotal /proc/meminfo > /out/meminfo.start; cat /sys/fs/cgroup/memory.max > /out/memory.max; '
        '/bin/probe "$@" > /out/probe.json 2> /out/probe.stderr; rc=$?; '
        'cat /sys/fs/cgroup/memory.peak > /out/memory.peak.after-close; cat /sys/fs/cgroup/memory.events > /out/memory.events.after-close; exit $rc')
ALLOWED_OUT = {"meminfo.start", "memory.max", "probe.json", "probe.stderr", "memory.peak.after-close", "memory.events.after-close"}
ALLOWED_NEW_DB = {"LOCK", "wal.log"}
SIDECAR = "stats-0.v1"
OUT = S / "scored-v2"  # v1 (dfc53301...) registered, never bound or run
OWNER = "Kaiming a37 scored v2"
TASK = "(internal discussion)"
ME = "@Kaiming-He"
REPS = 5
ORDERS = ["control-first", "profiled-first", "control-first", "profiled-first", "control-first"]
STAGES = ["collect_ms", "decode_ms", "scratch_ms", "build_ms", "consume_ms", "release_ms"]
DESIGN = {
    "question": "Phase A2: with the cache budget set to fixed values (4007, 6011, 8014 MiB = 1x, 1.5x, 2x of the A1 derived "
                "default) and all else equal, how do slot-7 conversion-window hits, misses, evictions, read_at attempts, "
                "returned bytes and decode_ms change for LUBM-1000 Q9 and Q14, alongside query-window counters, ids_ms, "
                "cgroup memory.stat and /proc/self/io? Descriptive. Misses, evictions and decode time falling together is "
                "consistent with a capacity effect, not proof of cause.",
    "factor": "set_cache_budget_mb(B) before the first open, required to return Ok; the setter moves the aggregate target "
              "for both dictionary and index caches. After open, the constructed caches' capacities are read through "
              "probe-only hidden accessors (never merged) and must equal the library formulas for B (dictionary: B/3/16 "
              "bytes per shard; each disk index: B/(9*16*256*24) blocks per shard)",
    "trace": "trace-on only (TRIPLELIGHT_TRACE_BLOCK_CACHE=1, checked by inspection); A1's trace-off observations stay in A1",
    "windows": "as A1: all 8 slots x 5 counters around query_ids and around the conversion pass separately, plus cgroup "
               "memory.stat (anon, file, file_mapped, active/inactive_file, pgfault, pgmajfault, pgscan, pgsteal, "
               "workingset_refault_file) and /proc/self/io (rchar, read_bytes, syscr) before and after each window",
    "units": "hits/misses are block-cache lookups; reads are read_at attempts; bytes are bytes returned; read_bytes is Linux "
             "storage reads attributed to the process, not macOS host physical I/O; file/anon are gauges reported as "
             "before/after with signed net changes",
    "no_worker": "as A1 (stats_origin Persisted; refresh_stats not called on that open path; thread counts diagnostic only)",
    "order": "per cell 5 repetitions x 3 budgets, budget order rotated (r1 1x 1.5x 2x, r2 1.5x 2x 1x, r3 2x 1x 1.5x, r4 1x "
             "1.5x 2x, r5 1.5x 2x 1x); within each phase the a35 pass order; positions retained and uneven; the two "
             "passes are not independent repeats",
    "memory": "an OOM or memory.events oom/oom_kill is a registered resource stop for that phase (stop rule unchanged), "
              "reported as a resource outcome; whole-process peak memory reported per phase",
    "reported": "per cell and budget: medians and ranges of slot-7 conversion counters and decode_ms, query-window counters "
                "and ids_ms, control and profiled totals by repetition and position, memory.stat/proc_io deltas, peak "
                "memory; derived per-cache capacities labelled derived, beside the observed constructed capacities",
    "gates": "a36 v3 gates (answers, stages, locality, counters, continuity, trace mode, stats origin, container, identities) "
             "plus: budget set equals the registered value; constructed capacities equal the formulas; memory.stat and "
             "proc_io fields present as non-negative ints",
    "stop_rule": "first failing gate, error, timeout, cap, OOM, lock mismatch, identity drift or failed cleanup stops the attempt; "
                 "no retries, no discarded observations",
    "limitations": "macOS host cache not controlled; distinct blocks unmeasured; counters process-global; probe-only "
                   "worktree diff (accessors) disclosed; equal outputs detect answer divergence only",
}


class Abort(Exception):
    pass


def on_signal(signum, _frame): raise Abort(f"signal {signum}")


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def sha_big(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 24), b""): h.update(chunk)
    return h.hexdigest()


def tree(p):
    h = hashlib.sha256()
    for f in sorted(x for x in Path(p).rglob("*") if x.is_file()):
        h.update(str(f.relative_to(p)).encode() + b"\0" + sha_big(f).encode() + b"\n")
    return h.hexdigest()


def atomic(path, value):
    tmp = Path(str(path) + ".tmp"); tmp.write_text(json.dumps(value, indent=1)); os.replace(tmp, path)


def lock_owner():
    try: return (LOCK / "owner").read_text()
    except OSError: return None


def require_lock(owner):
    if lock_owner() != owner + "\n": raise Abort(f"lock owner is {lock_owner()!r}, expected {owner!r}")


def docker(*args, check=True, timeout=120):
    try: r = subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired: raise RuntimeError(f"docker {args[0]} timed out after {timeout}s")
    if check and r.returncode != 0: raise RuntimeError(f"docker {args[0]}: {r.stderr.strip()}")
    return r


def inspect_ok(info, mounts, pdir, trace):
    hc, cfg = info["HostConfig"], info["Config"]
    got = {m["Destination"]: {"source": m["Source"], "rw": m["RW"]} for m in info["Mounts"]}
    want = {dst: {"source": src, "rw": rw} for src, dst, rw in mounts}
    img = json.loads(docker("image", "inspect", IMG).stdout)[0]
    checks = {"image_digest": cfg["Image"] == IMG and info["Image"] == img["Id"],
              "platform": info["Platform"] == "linux" and img["Os"] == "linux" and img["Architecture"] == "arm64",
              "cpus": hc["NanoCpus"] == CPUS * 1_000_000_000, "memory": hc["Memory"] == MEM and hc["MemorySwap"] == MEM,
              "network": hc["NetworkMode"] == "none", "cgroupns": hc["CgroupnsMode"] == "private",
              "read_only_root": hc["ReadonlyRootfs"] is True and not hc.get("Tmpfs"),
              "env": "RAYON_NUM_THREADS=4" in cfg["Env"], "mounts": got == want,
              # Trace mode is process-wide and keyed on presence: trace-off requires the variable to be absent.
              "trace_env": (("TRIPLELIGHT_TRACE_BLOCK_CACHE=1" in cfg["Env"]) if trace else not any(e.startswith("TRIPLELIGHT_TRACE_BLOCK_CACHE") for e in cfg["Env"]))}
    atomic(pdir / "inspect.json", {"checks": checks, "image_id": info["Image"], "mounts": got, "env": cfg["Env"], "cmd": cfg["Cmd"]})
    return all(checks.values())


def guarded(receipt, step, fn):
    try: return fn()
    except Exception as exc:
        receipt.setdefault("cleanup_errors", []).append(f"{step}: {exc!r}"); return None


def remove_named(name, receipt, key):
    guarded(receipt, f"{key}-rm", lambda: docker("rm", "-f", name, check=False, timeout=60))
    probe = guarded(receipt, f"{key}-probe", lambda: docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}", check=False))
    receipt[key] = ("unverified" if probe is None or probe.returncode != 0 else "removed" if probe.stdout.strip() == "" else "still-present")
    return receipt[key] == "removed"


def drop_caches(hname, receipt):
    if docker("ps", "-a", "--filter", f"name=^{hname}$", "--format", "{{.Names}}").stdout.strip():
        raise Abort(f"helper {hname} already exists; refusing to touch it")
    try:
        r = docker("run", "--name", hname, "--privileged", "--network", "none", IMG, "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches", check=False, timeout=300)
        if r.returncode != 0: raise Abort(f"drop_caches failed: {r.stderr.strip()}")
    finally:
        if not remove_named(hname, receipt, "dropcache_helper_cleanup"): raise Abort(f"helper {hname} not confirmed removed")


def cleanup(name, created, proc, clone, receipt):
    old = {s: signal.signal(s, signal.SIG_IGN) for s in SIGNALS}
    try:
        if created:
            guarded(receipt, "stop", lambda: docker("stop", "-t", "10", name, check=False, timeout=60))
            if proc is not None:
                def reap():
                    try: proc.wait(timeout=60)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
                guarded(receipt, "reap", reap)
            remove_named(name, receipt, "container_cleanup")
        else:
            receipt["container_cleanup"] = "not-created"
        if receipt.get("cleanup_errors"): receipt["container_cleanup"] = "unverified"
        if clone is not None:
            if receipt["container_cleanup"] in ("removed", "not-created"):
                guarded(receipt, "rm-clone", lambda: subprocess.run(["rm", "-rf", str(clone)], check=False, timeout=600))
                receipt["private_clone_removed"] = guarded(receipt, "probe-clone", lambda: not clone.exists()) is True
            else:
                receipt["private_clone_removed"] = False; receipt["clone_kept"] = str(clone)
    finally:
        for s, h in old.items(): signal.signal(s, h)


def write_once(path, value):
    with open(path, "x") as f: f.write(json.dumps(value, indent=1))


def finite_pos(x): return type(x) in (int, float) and math.isfinite(x) and x > 0  # bool excluded


def exact(got, want):
    """Equality with identical JSON types (True is not 1, 1.0 is not 1)."""
    return type(got) is type(want) and got == want


def run_phase(pid, cell, store, qf, args, outdir, owner, base_tree, *, trace):
    pdir = outdir / pid; pdir.mkdir()
    name = f"a37-{outdir.name}-{pid}"
    receipt = {"phase": pid, "container": name, "args": args}
    created, proc, clone, result = False, None, None, None
    try:
        require_lock(owner)
        if docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}").stdout.strip():
            raise Abort(f"container {name} already exists; refusing to touch it")
        out = pdir / "out"; out.mkdir()
        clone = S / "clones" / f"{outdir.name}-{pid}"; clone.parent.mkdir(exist_ok=True); clone.mkdir()
        subprocess.run(["cp", "-c", "-R", str(STORES[store]), str(clone / "base-0")], check=True, timeout=600)
        (clone / "CURRENT").write_text("base-0\n")
        subprocess.run(["cp", "-c", str(PREPARED[store]), str(clone / SIDECAR)], check=True, timeout=60)
        sidecar_before = sha(clone / SIDECAR)
        before = sorted(str(p.relative_to(clone)) for p in clone.rglob("*"))
        drop_caches(f"{name}-dropcache", receipt)
        mounts = [(str(S / "bin/arrow_budget"), "/bin/probe", False), (str(qf), "/q.rq", False), (str(clone), "/db", True), (str(out), "/out", True)]
        cmd = ["create", "--name", name, "--network", "none", "--cpus", str(CPUS), "--memory", "12g", "--memory-swap", "12g",
               "--cgroupns", "private", "--read-only", "-e", "RAYON_NUM_THREADS=4", *(["-e", "TRIPLELIGHT_TRACE_BLOCK_CACHE=1"] if trace else [])]
        for src, dst, rw in mounts: cmd += ["-v", f"{src}:{dst}" + ("" if rw else ":ro")]
        cmd += [IMG, "sh", "-c", WRAP, "sh", "/db", "/q.rq", *args]
        created = True
        docker(*cmd)
        if not inspect_ok(json.loads(docker("inspect", name).stdout)[0], mounts, pdir, trace): raise Abort("container inspection failed")
        t0 = time.monotonic()
        proc = subprocess.Popen(["docker", "start", "-a", name], stdout=open(pdir / "container.log", "w"), stderr=subprocess.STDOUT)
        capped = False
        while proc.poll() is None:
            require_lock(owner)
            if time.monotonic() - t0 >= CAP:
                capped = True
                docker("stop", "-t", "10", name, check=False, timeout=60)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    docker("kill", name, check=False, timeout=60)
                    try: proc.wait(timeout=30)
                    except subprocess.TimeoutExpired: raise Abort("container did not exit after stop and kill")
                break
            time.sleep(1)
        state = json.loads(docker("inspect", name).stdout)[0]["State"]
        receipt.update({"exit_code": state["ExitCode"], "oom_killed": state["OOMKilled"], "capped": capped, "seconds": time.monotonic() - t0})
        found = sorted(str(p.relative_to(out)) for p in out.rglob("*"))
        new_db = sorted(set(str(p.relative_to(clone)) for p in clone.rglob("*")) - set(before))
        base_ok = tree(clone / "base-0") == base_tree and (clone / "CURRENT").read_text() == "base-0\n"
        side_ok = (clone / SIDECAR).exists() and sha(clone / SIDECAR) == sidecar_before
        receipt["inventory"] = {"out": found, "new_in_clone": new_db, "base_tree_unchanged": base_ok, "sidecar_unchanged": side_ok}
        try: events = dict(l.split() for l in (out / "memory.events.after-close").read_text().splitlines())
        except (OSError, ValueError): events = None
        receipt["memory_events"] = events
        receipt["memory_peak_bytes"] = int((out / "memory.peak.after-close").read_text()) if (out / "memory.peak.after-close").exists() else None
        try: receipt["memtotal_kB"] = int((out / "meminfo.start").read_text().split()[1])
        except (OSError, ValueError, IndexError): receipt["memtotal_kB"] = None
        receipt["probe_stderr"] = (out / "probe.stderr").read_text()[-2000:] if (out / "probe.stderr").exists() else ""
        unexpected = [f for f in found if f not in ALLOWED_OUT] + [f for f in new_db if f not in ALLOWED_NEW_DB] + ([] if base_ok and side_ok else ["base-0, CURRENT or stats file modified"])
        if unexpected: result = {"status": "unexpected-files", "unexpected": unexpected}
        elif capped or state["OOMKilled"] or state["ExitCode"] != 0 or events is None: result = {"status": "incomplete", "exit_code": state["ExitCode"]}
        elif int(events.get("oom_kill", 0)) or int(events.get("oom", 0)): result = {"status": "oom-event"}
        else: result = {"status": "ran", "probe": json.loads((out / "probe.json").read_text())}
    except Abort as exc:
        result = {"status": "aborted", "error": str(exc)}
    except Exception as exc:
        result = {"status": "supervisor-error", "error": repr(exc)}
    finally:
        cleanup(name, created, proc, clone, receipt)
        if result is None: result = {"status": "aborted", "error": "interrupted"}
        if receipt["container_cleanup"] not in ("removed", "not-created") or receipt.get("private_clone_removed") is False:
            result = {**result, "status": "cleanup-unverified"}
        receipt["result"] = result
        atomic(pdir / "receipt.json", receipt)
    return result


def bind(expected_sha, message_id):
    if sha(OUT / "registration.json") != expected_sha: raise SystemExit("registration changed since review")
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", message_id):
        raise SystemExit("need the full message UUID returned by raft task reply")
    r = subprocess.run(["raft", "task", "read", TASK, "--around", message_id, "--limit", "1"], capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit(f"raft task read failed: {r.stderr.strip()}")
    head = next((l for l in r.stdout.splitlines() if f" msg={message_id} " in l), None)
    if not head or not (f"] {ME} " in head or f"] {ME}:" in head) or expected_sha not in r.stdout:
        raise SystemExit("message not found, not mine, or does not quote the registration digest")
    (OUT / "raft_message.txt").write_text(r.stdout)
    write_once(OUT / "raft_receipt.json", {"registration_sha256": expected_sha, "task": TASK, "message_id": message_id,
                                           "header": head, "read_sha256": sha(OUT / "raft_message.txt"), "bound_unix": time.time()})
    print("bound", message_id)


def verify_qualification(expected):
    if sha(S / "QUAL.SHA256") != expected: raise Abort("qualification manifest changed")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise Abort(f"qualification file {f} changed")


def frozen_values():
    q = json.loads(A34_QUAL.read_text())
    return {c: q[c]["probe"]["canonical"]["instr"]["sum"] for c, *_ in CELLS}


def nonneg(x): return type(x) in (int, float) and math.isfinite(x) and x >= 0
def finite(x): return type(x) in (int, float) and math.isfinite(x)


def same_sum(label, got, want, problems):
    for f in ("rows", "cells", "batches", "checksum"):
        if not exact(got.get(f), want[f]): problems.append(f"{label}: {f} {got.get(f)!r} != {want[f]!r}")


def locality_problems(loc, want, problems):
    same_sum("locality", loc.get("sum", {}), want, problems)
    pb = loc.get("per_batch_distinct_cells_gaps_runs")
    if not isinstance(pb, list) or not exact(loc.get("batches"), len(pb)) or len(pb) != want["batches"]:
        problems.append("locality: batch list"); return
    for i, row in enumerate(pb):
        if not (isinstance(row, list) and len(row) == 4 and all(type(x) is int and x >= 0 for x in row)):
            problems.append(f"locality: batch {i} malformed"); return
        d, c, g, r = row
        if g != max(d - 1, 0) or (r == 0) != (d == 0) or r > d: problems.append(f"locality: batch {i} gaps/runs inconsistent")
        width = want["cells"] // want["rows"]
        expect_cells = min(BATCH_ROWS, want["rows"] - i * BATCH_ROWS) * width
        if c != expect_cells or not 0 <= d <= c: problems.append(f"locality: batch {i} cells {c} != {expect_cells} or distinct out of range")
    gb, rb = loc.get("gap_buckets"), loc.get("run_buckets")
    if not (isinstance(gb, list) and len(gb) == 5 and all(type(x) is int and x >= 0 for x in gb)): problems.append("locality: gap buckets"); return
    if not (isinstance(rb, list) and len(rb) == 4 and all(type(x) is int and x >= 0 for x in rb)): problems.append("locality: run buckets"); return
    if sum(gb) != sum(x[2] for x in pb): problems.append("locality: gap bucket total")
    if sum(rb) != sum(x[3] for x in pb) or not exact(loc.get("runs"), sum(rb)): problems.append("locality: run bucket total")
    if not exact(loc.get("distinct_ids_sum"), sum(x[0] for x in pb)): problems.append("locality: distinct sum")
    # Gap-1 pairs per batch are exactly distinct - runs (each maximal run of length L has L - 1 unit gaps).
    if gb[0] != sum(x[0] - x[3] for x in pb): problems.append("locality: gap-1 count != sum(distinct - runs)")
    # Run lengths sum to the distinct IDs; bucket bounds 1 | 2-15 | 16-255 | >=256 must admit that total.
    total_d = sum(x[0] for x in pb)
    lo = rb[0] * 1 + rb[1] * 2 + rb[2] * 16 + rb[3] * 256
    hi = None if rb[3] else rb[0] * 1 + rb[1] * 15 + rb[2] * 255
    if lo > total_d or (hi is not None and hi < total_d): problems.append("locality: run buckets infeasible for the distinct total")
    if not exact(loc.get("cells"), sum(x[1] for x in pb)) or loc["cells"] != want["cells"]: problems.append("locality: cells")


def pass_problems(p, want, problems, label):
    same_sum(label, p.get("sum", {}), want, problems)
    if not (finite(p.get("ids_ms")) and p["ids_ms"] > 0 and finite(p.get("total_ms")) and p["total_ms"] > 0): problems.append(f"{label}: times")
    st = p.get("stages")
    if p.get("pass") == "control":
        if st is not None or "stage_sum_ms" in p or "remainder_ms" in p: problems.append(f"{label}: control has stages")
        return
    if not isinstance(st, dict): problems.append(f"{label}: stages missing"); return
    for k in STAGES:
        if not nonneg(st.get(k)): problems.append(f"{label}: {k} {st.get(k)!r}")
    if type(st.get("distinct_ids_decoded")) is not int or st["distinct_ids_decoded"] < 0: problems.append(f"{label}: distinct_ids_decoded")
    # The probe writes stage_sum_ms and remainder_ms beside `stages`, at the pass level.
    if not (finite(p.get("stage_sum_ms")) and finite(p.get("remainder_ms"))): problems.append(f"{label}: sum/remainder")
    elif all(nonneg(st.get(k)) for k in STAGES) and finite(p.get("total_ms")):
        s = sum(st[k] for k in STAGES)
        if abs(s - p["stage_sum_ms"]) > 1e-3 or abs(p["total_ms"] - s - p["remainder_ms"]) > 2e-3: problems.append(f"{label}: sum/remainder arithmetic")


SYS_REQUIRED = {"memory_stat": ["anon", "file", "pgmajfault"], "proc_io": ["rchar", "read_bytes"]}
# Cumulative counters (never decrease while the process and cgroup live); everything else in memory.stat is a gauge.
SYS_CUMULATIVE = {"memory_stat": ["pgfault", "pgmajfault", "pgscan", "pgsteal", "workingset_refault_file"],
                  "proc_io": ["rchar", "read_bytes", "syscr"]}


def sys_monotonic_problems(p, problems):
    """Cumulative fields are non-decreasing within each window and across windows in actual pass order; required
    fields always, optional ones wherever both sides are observed. Gauges (anon, file, ...) may fall."""
    seq = []
    for x in p.get("passes", []):
        for w in ("query_window", "convert_window"):
            win = x.get(w) or {}
            seq.append((f"{x.get('pass')} {w}", win.get("sys_before"), win.get("sys_after")))
    points = []
    for name, b, a in seq: points += [(name + " before", b), (name + " after", a)]
    for (n1, s1), (n2, s2) in zip(points, points[1:]):
        if not (isinstance(s1, dict) and isinstance(s2, dict)): continue
        for grp, keys in SYS_CUMULATIVE.items():
            g1, g2 = s1.get(grp) or {}, s2.get(grp) or {}
            for k in keys:
                v1, v2 = g1.get(k), g2.get(k)
                if type(v1) is int and type(v2) is int and v2 < v1: problems.append(f"{grp}.{k} decreased from {n1} to {n2}")


def budget_problems(p, budget_mb, problems):
    """The set budget equals the registered value, and the constructed caches hold the formula capacities."""
    sys_monotonic_problems(p, problems)
    if not exact(p.get("budget_mb_set"), budget_mb): problems.append(f"budget_mb_set {p.get('budget_mb_set')!r} != {budget_mb}")
    caps = p.get("cache_capacities")
    d, i = expected_capacities(budget_mb)
    want = {"dictionary_by_term_shard_budget_bytes": d, "dictionary_by_id_shard_budget_bytes": d, **{f"index{k}_shard_capacity_blocks": i for k in range(6)}}
    if not isinstance(caps, dict) or set(caps) != set(want) or not all(exact(caps[k], v) for k, v in want.items()):
        problems.append(f"constructed cache capacities {caps!r} != formula {want!r}")
    for x in p.get("passes", []):
        for w in ("query_window", "convert_window"):
            win = x.get(w) or {}
            for side in ("sys_before", "sys_after"):
                sv = win.get(side)
                if not isinstance(sv, dict): problems.append(f"{x.get('pass')} {w} {side} missing"); continue
                for grp, keys in SYS_REQUIRED.items():
                    g = sv.get(grp)
                    if not isinstance(g, dict) or not all(type(g.get(k)) is int and g[k] >= 0 for k in keys): problems.append(f"{x.get('pass')} {w} {side} {grp} fields")
                    elif not all((type(v) is int and v >= 0) or v is None for v in g.values()): problems.append(f"{x.get('pass')} {w} {side} {grp} types")


def counter_problems(p, trace, problems):
    """Counter windows: exact non-negative ints, 8 slots x 5 counters, after >= before; trace-off deltas all zero;
    observed trace mode matches the registered mode; statistics loaded from the persisted file."""
    if p.get("trace_enabled") is not trace or p.get("trace_env_present") is not trace: problems.append("trace mode mismatch")
    o = p.get("stats_origin")
    if not (isinstance(o, dict) and o.get("kind") == "Persisted"): problems.append("stats origin not Persisted")
    pm, bud = p.get("physical_memory_bytes"), p.get("derived_default_budget_mb")
    if type(pm) is not int or pm <= 0: problems.append("physical_memory_bytes not a positive int")
    elif type(bud) is not int or bud != max(1, pm // 4 // (1024 * 1024)): problems.append("derived budget != max(1, physical//4//MiB)")
    # Counters are process-global and never reset: continuity across windows in actual pass order
    # (query.after <= convert.before; previous convert.after <= next query.before).
    seq = []
    for x in p.get("passes", []):
        for w in ("query_window", "convert_window"):
            win = x.get(w)
            if isinstance(win, dict): seq.append((f"{x.get('pass')} {w}", win.get("before"), win.get("after")))
    def le(m1, m2):
        try: return all(m1[i][j] <= m2[i][j] for i in range(8) for j in range(5))
        except (TypeError, IndexError, KeyError): return False
    for (n1, _, a1), (n2, b2, _) in zip(seq, seq[1:]):
        if not le(a1, b2): problems.append(f"counter continuity broken between {n1} and {n2}")
    for x in p.get("passes", []):
        for w in ("query_window", "convert_window"):
            win = x.get(w)
            if not isinstance(win, dict): problems.append(f"{x.get('pass')} {w} missing"); continue
            b, a = win.get("before"), win.get("after")
            ok = all(isinstance(m, list) and len(m) == 8 and all(isinstance(r, list) and len(r) == 5 and all(type(v) is int and v >= 0 for v in r) for r in m) for m in (b, a))
            if not ok: problems.append(f"{x.get('pass')} {w} counters malformed"); continue
            if any(a[i][j] < b[i][j] for i in range(8) for j in range(5)): problems.append(f"{x.get('pass')} {w} counter decreased")
            if not trace and any(a[i][j] != b[i][j] for i in range(8) for j in range(5)): problems.append(f"{x.get('pass')} {w} nonzero delta with trace off")
            if trace and w == "convert_window" and a[7][0] + a[7][1] == b[7][0] + b[7][1]: problems.append(f"{x.get('pass')} convert window: no slot-7 lookups with trace on")
            for k in ("threads_before", "threads_after"):
                if type(win.get(k)) is not int or win[k] < 1: problems.append(f"{x.get('pass')} {w} {k}")


def phase_gate(ph, p, reg):
    problems = []
    counter_problems(p, ph.get("trace", False), problems)
    budget_problems(p, ph["budget_mb"], problems)
    want = reg["frozen_values"][ph["cell"]]
    loc_cell = next(c for c in CELLS if c[0] == ph["cell"])[3]
    if p.get("mode") != "phase" or p.get("order") != ph["order"]: problems.append("probe mode/order mismatch")
    same_sum("warmup", p.get("warmup", {}), want, problems)
    passes = p.get("passes", [])
    want_kinds = ["control", "profiled"] if ph["order"] == "control-first" else ["profiled", "control"]
    if [x.get("pass") for x in passes] != want_kinds or not all(exact(x.get("position"), i + 1) for i, x in enumerate(passes)): problems.append("pass order mismatch")
    for x in passes: pass_problems(x, want, problems, f"pass {x.get('pass')}")
    if not (finite(p.get("stats_ready_ms")) and p["stats_ready_ms"] > 0): problems.append("stats_ready_ms")
    if loc_cell:
        loc = p.get("locality")
        if not isinstance(loc, dict): problems.append("locality missing")
        else:
            locality_problems(loc, want, problems)
            prof = next((x for x in passes if x.get("pass") == "profiled"), None)
            if prof and isinstance(prof.get("stages"), dict) and not exact(prof["stages"].get("distinct_ids_decoded"), loc.get("distinct_ids_sum")):
                problems.append("profiled distinct_ids_decoded != locality distinct_ids_sum")
    elif "locality" in p: problems.append("unexpected locality")
    return problems


def qual_gate(cell, p, want, loc_cell, trace=False, *, budget_mb):
    problems = []
    counter_problems(p, trace, problems)
    budget_problems(p, budget_mb, problems)
    if p.get("mode") != "qualify": problems.append("mode")
    passes = p.get("passes", [])
    if [x.get("pass") for x in passes] != ["control", "profiled"]: problems.append("qualify passes")
    for x in passes: pass_problems(x, want, problems, f"qualify {x.get('pass')}")
    if loc_cell:
        if not isinstance(p.get("locality"), dict): problems.append("locality missing")
        else:
            locality_problems(p["locality"], want, problems)
            if passes and isinstance(passes[-1].get("stages"), dict) and not exact(passes[-1]["stages"].get("distinct_ids_decoded"), p["locality"].get("distinct_ids_sum")):
                problems.append("distinct mismatch")
    return problems


BUDGETS = {"1x": 4007, "1.5x": 6011, "2x": 8014}  # MiB (Jianlin eccecd55, Alex 223f25b7)
BUDGET_ORDER = [["1x", "1.5x", "2x"], ["1.5x", "2x", "1x"], ["2x", "1x", "1.5x"], ["1x", "1.5x", "2x"], ["1.5x", "2x", "1x"]]
MIB = 1024 * 1024
INDEX_BLOCK_BYTES = 9 * 16 * 256 * 24  # disk_index: budget / (9 * 16 * BLOCK_ROWS * ROW) blocks per shard


def expected_capacities(budget_mb):
    """Per-cache capacities the library formulas give for a budget (labelled derived in the report)."""
    dict_shard = budget_mb * MIB // 3 // 16
    idx_shard = max(1, budget_mb * MIB // INDEX_BLOCK_BYTES)
    return dict_shard, idx_shard


def schedule():
    phases, n = [], 0
    for cell, store, _, _ in CELLS:
        for i in range(REPS):
            for pos, b in enumerate(BUDGET_ORDER[i]):
                n += 1
                phases.append({"id": f"{n:02d}-{cell}-r{i + 1}-{b}", "cell": cell, "store": store, "rep": i + 1,
                               "order": ORDERS[i], "trace": True, "budget": b, "budget_mb": BUDGETS[b], "budget_position": pos + 1})
    return phases


def args_for(cell, mode, *, budget_mb):
    loc = next(c for c in CELLS if c[0] == cell)[3]
    return [*mode, "--budget-mb", str(budget_mb), *(["--locality"] if loc else [])]


def extract_batch(path):
    """The exact text of `fn batch(&mut self)` in a Rust source file, by brace matching."""
    src = Path(path).read_text(); i = src.index("    fn batch(&mut self)"); j = src.index("{", i); d = 0
    for k in range(j, len(src)):
        if src[k] == "{": d += 1
        elif src[k] == "}":
            d -= 1
            if d == 0: return src[i:k + 1] + "\n"
    raise ValueError("unbalanced")


def comparison_verified():
    """Regenerates both function extracts from the actual frozen library and probe sources and the unified diff, and
    requires byte equality with the published comparison files."""
    lib, prof = extract_batch(WT / "bindings/c/src/arrow.rs"), extract_batch(WT / "bindings/c/examples/arrow_budget.rs")
    if (S / "lib_batch.rs").read_text() != lib or (S / "profiled_batch.rs").read_text() != prof: return False
    d = subprocess.run(["/usr/bin/diff", "-u", "--label", "lib_batch.rs", "--label", "profiled_batch.rs", str(S / "lib_batch.rs"), str(S / "profiled_batch.rs")],
                       capture_output=True, text=True)
    return d.returncode == 1 and d.stdout == (S / "batch-source-comparison.diff").read_text()


def identities():
    return {"supervisor_sha256": sha(Path(__file__)), "probe_source_sha256": sha(WT / "bindings/c/examples/arrow_budget.rs"),
            "library_arrow_source_sha256": sha(WT / "bindings/c/src/arrow.rs"),
            "batch_source_comparison_sha256": sha(S / "batch-source-comparison.diff"),
            "batch_source_comparison_verified": comparison_verified(),
            "build_script_sha256": sha(S / "build.sh"), "binary_sha256": sha(S / "bin/arrow_budget"),
            "launcher_sha256": sha(S / "launch.sh"), "launch_controls_sha256": sha(S / "launch_controls.sh"),
            "launch_controls_output_sha256": sha(S / "launch_controls.txt"),
            "worktree_head": subprocess.run(["/usr/bin/git", "-C", str(WT), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip(),
            "worktree_diff_sha256": hashlib.sha256(subprocess.run(["/usr/bin/git", "-C", str(WT), "diff", "HEAD"], capture_output=True, check=True).stdout).hexdigest(),
            "queries": {c: sha(q) for c, _, q, _ in CELLS}, "a34_qualification_sha256": sha(A34_QUAL),
            "prepared_sidecars": {s: sha(p) for s, p in PREPARED.items()}}


def gate_controls():
    """Offline negative controls on the frozen dry-run probes; no engine runs."""
    import copy
    q = S / "qual"
    reg = {"frozen_values": frozen_values()}
    out = {"cases": [], "all_pass": True}
    def record(name, ok): out["cases"].append({"case": name, "ok": ok}); out["all_pass"] &= ok
    for cell, _, _, loc_cell in CELLS:
        for order, b in (("control-first", "1x"), ("profiled-first", "1.5x"), ("control-first", "2x")):
            trace = True
            base = json.loads((q / f"{cell}-dry-{order}-{b}" / "out/probe.json").read_text())
            ph = {"cell": cell, "order": order, "trace": trace, "budget_mb": BUDGETS[b]}
            record(f"{cell}/{order}: unmutated passes", phase_gate(ph, base, reg) == [])
            falling = copy.deepcopy(base)
            w = falling["passes"][0]["convert_window"]
            w["sys_after"]["memory_stat"]["anon"] = max(0, w["sys_before"]["memory_stat"]["anon"] - 4096)
            w["sys_after"]["memory_stat"]["file"] = max(0, w["sys_before"]["memory_stat"]["file"] - 4096)
            record(f"{cell}/{order}: falling anon/file gauges accepted", phase_gate(ph, falling, reg) == [])
            pi = [x["pass"] for x in base["passes"]].index("profiled"); ci = 1 - pi
            muts = {
                "stage = true": lambda p: p["passes"][pi]["stages"].__setitem__("decode_ms", True),
                "stage negative": lambda p: p["passes"][pi]["stages"].__setitem__("build_ms", -0.5),
                "stage inf": lambda p: p["passes"][pi]["stages"].__setitem__("collect_ms", float("inf")),
                "stage missing": lambda p: p["passes"][pi]["stages"].pop("release_ms"),
                "remainder inconsistent": lambda p: p["passes"][pi].__setitem__("remainder_ms", p["passes"][pi]["remainder_ms"] + 5),
                "remainder missing": lambda p: p["passes"][pi].pop("remainder_ms"),
                "stage_sum = true": lambda p: p["passes"][pi].__setitem__("stage_sum_ms", True),
                "distinct as float": lambda p: p["passes"][pi]["stages"].__setitem__("distinct_ids_decoded", float(p["passes"][pi]["stages"]["distinct_ids_decoded"])),
                "control has stages": lambda p: p["passes"][ci].__setitem__("stages", p["passes"][pi]["stages"]),
                "total = true": lambda p: p["passes"][ci].__setitem__("total_ms", True),
                "ids_ms = 0": lambda p: p["passes"][pi].__setitem__("ids_ms", 0),
                "checksum changed": lambda p: p["passes"][pi]["sum"].__setitem__("checksum", "0" * 16),
                "batches as float": lambda p: p["passes"][ci]["sum"].__setitem__("batches", float(p["passes"][ci]["sum"]["batches"])),
                "warmup rows changed": lambda p: p["warmup"].__setitem__("rows", p["warmup"]["rows"] + 1),
                "order swapped": lambda p: p["passes"].reverse(),
                "position = 1.0": lambda p: p["passes"][0].__setitem__("position", 1.0),
                "mode changed": lambda p: p.__setitem__("mode", "qualify"),
                "budget set wrong": lambda p: p.__setitem__("budget_mb_set", p["budget_mb_set"] + 1),
                "budget as float": lambda p: p.__setitem__("budget_mb_set", float(p["budget_mb_set"])),
                "dictionary capacity wrong": lambda p: p["cache_capacities"].__setitem__("dictionary_by_id_shard_budget_bytes", p["cache_capacities"]["dictionary_by_id_shard_budget_bytes"] + 1),
                "index capacity wrong": lambda p: p["cache_capacities"].__setitem__("index3_shard_capacity_blocks", p["cache_capacities"]["index3_shard_capacity_blocks"] - 1),
                "capacities missing": lambda p: p.__setitem__("cache_capacities", None),
                "sys snapshot missing": lambda p: p["passes"][0]["convert_window"].pop("sys_after"),
                "read_bytes null": lambda p: p["passes"][1]["query_window"]["sys_before"]["proc_io"].__setitem__("read_bytes", None),
                "anon negative": lambda p: p["passes"][0]["query_window"]["sys_after"]["memory_stat"].__setitem__("anon", -1),
                "read_bytes decreases within window": lambda p: p["passes"][0]["convert_window"]["sys_after"]["proc_io"].__setitem__("read_bytes", p["passes"][0]["convert_window"]["sys_before"]["proc_io"]["read_bytes"] - 1),
                "pgmajfault decreases within window": lambda p: p["passes"][1]["query_window"]["sys_after"]["memory_stat"].__setitem__("pgmajfault", p["passes"][1]["query_window"]["sys_before"]["memory_stat"]["pgmajfault"] - 1),
                "rchar reset between query and conversion": lambda p: p["passes"][0]["convert_window"]["sys_before"]["proc_io"].__setitem__("rchar", 0),
                "syscr reset between passes": lambda p: p["passes"][1]["query_window"]["sys_before"]["proc_io"].__setitem__("syscr", 0),
                "trace flag flipped": lambda p: p.__setitem__("trace_enabled", not p["trace_enabled"]),
                "trace env flipped": lambda p: p.__setitem__("trace_env_present", not p["trace_env_present"]),
                "origin scanned": lambda p: p.__setitem__("stats_origin", {"kind": "Scanned"}),
                "counter as float": lambda p: p["passes"][0]["convert_window"]["after"][7].__setitem__(0, float(p["passes"][0]["convert_window"]["after"][7][0])),
                "counter decreased": lambda p: p["passes"][0]["convert_window"]["after"][7].__setitem__(1, p["passes"][0]["convert_window"]["before"][7][1] - 1 if p["passes"][0]["convert_window"]["before"][7][1] > 0 else -1),
                "counter slot missing": lambda p: p["passes"][1]["query_window"]["before"].pop(),
                "window missing": lambda p: p["passes"][1].pop("convert_window"),
                "threads = true": lambda p: p["passes"][0]["query_window"].__setitem__("threads_after", True),
                "physical memory negative": lambda p: p.__setitem__("physical_memory_bytes", -p["physical_memory_bytes"]),
                "derived budget wrong": lambda p: p.__setitem__("derived_default_budget_mb", p["derived_default_budget_mb"] + 1),
                # trace-off must have zero deltas; trace-on must show slot-7 lookups in the conversion window
                "delta flip": lambda p: (p["passes"][0]["convert_window"]["after"][7].__setitem__(3, p["passes"][0]["convert_window"]["after"][7][3] + 4096)
                                         if not trace else p["passes"][0]["convert_window"].__setitem__("after", p["passes"][0]["convert_window"]["before"])),
            }
            if trace:  # trace-off counters are all zero, so a reset there is a no-op, not a mutation
                muts.update({
                    "counters reset between windows": lambda p: p["passes"][0].__setitem__("convert_window", {**p["passes"][0]["convert_window"],
                        "before": [[0] * 5 for _ in range(8)], "after": [[v - b for v, b in zip(ra, rb)] for ra, rb in zip(p["passes"][0]["convert_window"]["after"], p["passes"][0]["convert_window"]["before"])]}),
                    "counters reset between passes": lambda p: p["passes"][1].__setitem__("query_window", {**p["passes"][1]["query_window"],
                        "before": [[0] * 5 for _ in range(8)], "after": [[v - b for v, b in zip(ra, rb)] for ra, rb in zip(p["passes"][1]["query_window"]["after"], p["passes"][1]["query_window"]["before"])]}),
                })
            if loc_cell:
                muts.update({
                    "locality missing": lambda p: p.pop("locality"),
                    "locality gap total": lambda p: p["locality"]["gap_buckets"].__setitem__(0, p["locality"]["gap_buckets"][0] + 1),
                    "locality batch gaps": lambda p: p["locality"]["per_batch_distinct_cells_gaps_runs"][0].__setitem__(2, p["locality"]["per_batch_distinct_cells_gaps_runs"][0][2] + 1),
                    "locality distinct != profiled": lambda p: p["passes"][pi]["stages"].__setitem__("distinct_ids_decoded", p["passes"][pi]["stages"]["distinct_ids_decoded"] + 1),
                    "locality checksum": lambda p: p["locality"]["sum"].__setitem__("checksum", "0" * 16),
                    "gap-1 moved to 2-15": lambda p: (p["locality"]["gap_buckets"].__setitem__(0, p["locality"]["gap_buckets"][0] - 1),
                                                       p["locality"]["gap_buckets"].__setitem__(1, p["locality"]["gap_buckets"][1] + 1)),
                    "all runs in 2-15": lambda p: p["locality"].__setitem__("run_buckets", [0, sum(p["locality"]["run_buckets"]), 0, 0]),
                    "cell shifted between batches": lambda p: (p["locality"]["per_batch_distinct_cells_gaps_runs"][0].__setitem__(1, p["locality"]["per_batch_distinct_cells_gaps_runs"][0][1] - 1),
                                                                p["locality"]["per_batch_distinct_cells_gaps_runs"][1].__setitem__(1, p["locality"]["per_batch_distinct_cells_gaps_runs"][1][1] + 1)),
                    "distinct > cells": lambda p: (lambda b: (b.__setitem__(0, b[1] + 1)))(p["locality"]["per_batch_distinct_cells_gaps_runs"][0]),
                })
            else:
                muts["unexpected locality"] = lambda p: p.__setitem__("locality", {})
            for name, m in muts.items():
                p = copy.deepcopy(base); m(p)
                record(f"{cell}/{order}: {name} fails", phase_gate(ph, p, reg) != [])
    return out


def qualify(owner):
    """Untimed. Per cell: probe `qualify`, then one dry `phase` per order gated exactly like a scored phase. Dry timings are
    discarded and never reported."""
    require_lock(owner)
    if sha(A34_QUAL) != A34_QUAL_SHA256: raise SystemExit("a34 qualification changed")
    q = S / "qual"; q.mkdir(exist_ok=False)
    ids = identities(); base_trees = {s: tree(p) for s, p in STORES.items()}; ids["stores"] = base_trees
    if ids["batch_source_comparison_verified"] is not True: raise SystemExit("source comparison does not match the frozen sources")
    atomic(q / "identities.json", ids)
    want = frozen_values(); reg = {"frozen_values": want}
    results, ok = {}, True
    for cell, store, qf, loc_cell in CELLS:
        pid = f"{cell}-qualify-1x"
        r = run_phase(pid, cell, store, qf, args_for(cell, ["qualify"], budget_mb=BUDGETS["1x"]), q, owner, base_trees[store], trace=True)
        if r["status"] == "ran":
            problems = qual_gate(cell, r["probe"], want[cell], loc_cell, True, budget_mb=BUDGETS["1x"])
            r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
        results[pid] = r; print(pid, r["status"], r.get("problems") or r.get("error") or "", flush=True)
        if r["status"] != "pass": ok = False; break
        for order, b in (("control-first", "1x"), ("profiled-first", "1.5x"), ("control-first", "2x")):
            pid = f"{cell}-dry-{order}-{b}"
            d = run_phase(pid, cell, store, qf, args_for(cell, ["phase", order], budget_mb=BUDGETS[b]), q, owner, base_trees[store], trace=True)
            if d["status"] == "ran":
                problems = phase_gate({"cell": cell, "order": order, "trace": True, "budget_mb": BUDGETS[b]}, d["probe"], reg)
                d = {"status": "pass" if not problems else "gate-failed", "problems": problems, "timings": "discarded"}
            else: d = {k: v for k, v in d.items() if k != "probe"}
            results[pid] = d; print(pid, d["status"], d.get("problems") or d.get("error") or "", flush=True)
            if d["status"] != "pass": ok = False; break
        if not ok: break
    atomic(q / "QUAL.json", results)
    after = identities(); after["stores"] = {s: tree(p) for s, p in STORES.items()}
    if after != ids: print("IDENTITY DRIFT during qualification", flush=True); raise SystemExit(1)
    if not ok or len(results) != 4 * len(CELLS): raise SystemExit(1)
    sched = selftest_schedule(); atomic(q / "selftest_schedule.json", sched)
    if not sched["pass"]: print("SCHEDULE SELFTEST FAILED", flush=True); raise SystemExit(1)
    controls = gate_controls(); atomic(q / "gate_controls.json", controls)
    if not controls["all_pass"]: print("GATE CONTROLS FAILED", flush=True); raise SystemExit(1)
    rels = sorted(str(f.relative_to(S)) for f in q.rglob("*") if f.is_file()) + [
        "score_a37.py", "build.sh", "bin/arrow_budget", "probe.rs", "batch-source-comparison.diff", "lib_batch.rs", "profiled_batch.rs", "probe-worktree.raw.diff",
        "launch.sh", "launch_controls.sh", "launch_controls.txt"]
    (S / "QUAL.SHA256").write_text("".join(f"{sha(S / r)}  {r}\n" for r in rels))
    print("frozen", sha(S / "QUAL.SHA256"), f"controls {sum(c['ok'] for c in controls['cases'])}/{len(controls['cases'])}", flush=True)


def register():
    if OUT.exists(): raise SystemExit(f"{OUT} exists; registration is prospective and never overwritten")
    if (S / "launch_controls.txt").read_text().splitlines()[-1] != "LAUNCH-CONTROLS PASS": raise SystemExit("launcher controls did not pass")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise SystemExit(f"qualification file {f} changed")
    OUT.mkdir(parents=True)
    ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
    reg = {"schema": "a37-scored-registration-v2", "attempt_label": "a37-scored-v2", "lock_owner": OWNER, "image": IMG,
           "design": DESIGN, "identities": ids, "qualification_sha256": sha(S / "QUAL.SHA256"), "frozen_values": frozen_values(),
           "batch_rows": BATCH_ROWS, "container": {"cpus": CPUS, "memory": MEM, "memory_swap": MEM, "network": "none", "cgroupns": "private",
           "read_only_root": True, "env": ["RAYON_NUM_THREADS=4"], "platform": "linux/arm64"}, "cap_s": CAP, "phases": schedule(),
           "registered_unix": time.time()}
    write_once(OUT / "registration.json", reg)
    print(sha(OUT / "registration.json"))


def scored_call(phase_fn, ph, attempt, owner, reg):
    """The one place a scored phase is mapped to a run_phase call (used by run() and by selftest-schedule)."""
    qf = next(c for c in CELLS if c[0] == ph["cell"])[2]
    return phase_fn(ph["id"], ph["cell"], ph["store"], qf, args_for(ph["cell"], ["phase", ph["order"]], budget_mb=ph["budget_mb"]), attempt, owner,
                    reg["identities"]["stores"][ph["store"]], trace=ph["trace"])


def selftest_schedule(reg_path=None):
    """Dry: walks the registered (or current) schedule through scored_call with run_phase stubbed; checks every phase's
    trace mode, probe arguments and identity mapping. No containers, no lock."""
    reg = json.loads(Path(reg_path).read_text()) if reg_path else {"phases": schedule(), "identities": {"stores": {s: "TREE" for s in STORES}}}
    calls, problems = [], []
    def stub(pid, cell, store, qf, args, outdir, owner, base_tree, *, trace):
        calls.append({"pid": pid, "cell": cell, "args": args, "trace": trace, "qf": str(qf), "tree": base_tree}); return {"status": "stub"}
    for ph in reg["phases"]: scored_call(stub, ph, Path("/nonexistent"), "selftest", reg)
    if len(calls) != len(reg["phases"]): problems.append("call count")
    for ph, c in zip(reg["phases"], calls):
        loc = next(x for x in CELLS if x[0] == ph["cell"])[3]
        want_args = ["phase", ph["order"], "--budget-mb", str(BUDGETS[ph["budget"]]), *(["--locality"] if loc else [])]
        if ph["budget_mb"] != BUDGETS[ph["budget"]]: problems.append(f"{ph['id']}: budget_mb mapping")
        if c["trace"] is not ph["trace"]: problems.append(f"{ph['id']}: trace {c['trace']} != {ph['trace']}")
        if c["args"] != want_args: problems.append(f"{ph['id']}: args {c['args']}")
        if c["tree"] != reg["identities"]["stores"][ph["store"]]: problems.append(f"{ph['id']}: store tree")
        if not ph["id"].endswith("-" + ph["budget"]) or ph["trace"] is not True: problems.append(f"{ph['id']}: id/budget label or trace mismatch")
    import inspect as _inspect
    p = _inspect.signature(run_phase).parameters.get("trace")
    if p is None or p.kind is not _inspect.Parameter.KEYWORD_ONLY or p.default is not _inspect.Parameter.empty:
        problems.append("run_phase trace must be keyword-only with no default")
    try:
        run_phase("x", "c", "s", "q", [], Path("/nonexistent"), "o", "t")  # omission must raise, not default
        problems.append("run_phase accepted a call without trace")
    except TypeError: pass
    from collections import Counter as _C
    out = {"phases": len(calls), "trace_on": sum(c["trace"] for c in calls), "trace_off": sum(not c["trace"] for c in calls),
           "budgets": dict(_C(ph["budget"] for ph in reg["phases"])), "problems": problems, "pass": not problems}
    print(json.dumps(out, indent=1)); return out


def run(expected_sha):
    reg_path = OUT / "registration.json"
    if sha(reg_path) != expected_sha: raise SystemExit("registration changed since review")
    receipt = json.loads((OUT / "raft_receipt.json").read_text())
    if receipt["registration_sha256"] != expected_sha: raise SystemExit("Raft receipt binds a different registration")
    reg = json.loads(reg_path.read_text())
    owner = reg["lock_owner"]; require_lock(owner)
    attempt = OUT / "attempt"; attempt.mkdir()
    status = {p["id"]: {"status": "not-run"} for p in reg["phases"]}; atomic(attempt / "status.json", status)
    stopped, memtotal, post = True, None, {}
    try:
        ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
        if ids != reg["identities"]: raise Abort("identities differ from registration")
        verify_qualification(reg["qualification_sha256"])
        write_once(attempt / "started.json", {"registration_sha256": expected_sha, "raft_message_id": receipt["message_id"], "unix": time.time()})
        stopped = False
        for ph in reg["phases"]:
            status[ph["id"]] = {"status": "running"}; atomic(attempt / "status.json", status)
            r = scored_call(run_phase, ph, attempt, owner, reg)
            if r["status"] == "ran":
                problems = phase_gate(ph, r["probe"], reg)
                mt = json.loads((attempt / ph["id"] / "receipt.json").read_text()).get("memtotal_kB")
                memtotal = memtotal or mt
                if mt is None or mt != memtotal: problems.append(f"MemTotal {mt} != cohort {memtotal}")
                r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
            status[ph["id"]] = r; atomic(attempt / "status.json", status)
            if r["status"] != "pass": stopped = True; break
    except BaseException as exc:
        stopped = True
        status = {k: ({"status": "aborted", "error": repr(exc)} if v["status"] == "running" else v) for k, v in status.items()}
        post["error"] = repr(exc)
    finally:
        for sg in SIGNALS: signal.signal(sg, signal.SIG_IGN)
        try:
            ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
            post["identities_unchanged"] = ids == reg["identities"]
            try: verify_qualification(reg["qualification_sha256"]); post["qualification_unchanged"] = True
            except Abort as exc: post["qualification_unchanged"] = False; post["qualification_error"] = str(exc)
        except BaseException as exc: post.update({"identities_unchanged": "unverified", "postcheck_error": repr(exc)})
        post.update({"stopped_early": stopped, "cohort_MemTotal_kB": memtotal, "unix": time.time()})
        atomic(attempt / "status.json", status); write_once(attempt / "postcheck.json", post)
    print(json.dumps({k: v["status"] for k, v in status.items()}, indent=1))
    return 0 if post["identities_unchanged"] is True and post.get("qualification_unchanged") is True and not stopped and all(v["status"] == "pass" for v in status.values()) else 1


if __name__ == "__main__":
    for s in SIGNALS: signal.signal(s, on_signal)
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "qualify" and a[1].startswith("--owner="): qualify(a[1][8:])
    elif a == ["register"]: register()
    elif len(a) == 3 and a[0] == "bind": bind(a[1], a[2])
    elif len(a) == 2 and a[0] == "run": sys.exit(run(a[1]))
    elif a == ["schedule"]: print(json.dumps(schedule(), indent=1))
    elif a == ["gate-controls"]: print(json.dumps(gate_controls(), indent=1))
    elif a and a[0] == "selftest-schedule": sys.exit(0 if selftest_schedule(a[1] if len(a) > 1 else None)["pass"] else 1)
    else: raise SystemExit(__doc__)
