"""Summarize the a37 scored-v2 attempt: per cell x budget, slot-7 conversion-window deltas, timings, memory."""
import json, statistics, sys
from pathlib import Path
A = Path(sys.argv[1])
status = json.loads((A / 'status.json').read_text())
F = ('hits', 'misses', 'reads', 'bytes', 'evictions')
def delta(w, slot):
    return dict(zip(F, (a - b for a, b in zip(w['after'][slot], w['before'][slot]))))
def sysd(w, k1, k2):
    return w['sys_after'][k1][k2] - w['sys_before'][k1][k2]
cells = {}
for name, st in status.items():
    assert st['status'] == 'pass', name
    _, ds, q, rep, budget = name.split('-', 4)
    r = json.loads((A / name / 'receipt.json').read_text())
    p = st['probe']
    for ps in p['passes']:
        cw = ps['convert_window']
        rec = {'phase': name, 'rep': rep, 'pass': ps['pass'], 'position': ps['position'],
               'budget_mb': p['budget_mb_set'], 'slot7': delta(cw, 7),
               'other_slots_moved': [s for s in range(8) if s != 7 and any(delta(cw, s).values())],
               'query_slot_totals': {s: delta(ps['query_window'], s) for s in range(8) if any(delta(ps['query_window'], s).values())},
               'ids_ms': ps['ids_ms'], 'total_ms': ps['total_ms'],
               'decode_ms': (ps['stages'] or {}).get('decode_ms'),
               'conv_read_bytes': sysd(cw, 'proc_io', 'read_bytes'), 'conv_rchar': sysd(cw, 'proc_io', 'rchar'),
               'conv_pgmajfault': sysd(cw, 'memory_stat', 'pgmajfault'),
               'peak_bytes': r['memory_peak_bytes'], 'dict_shard_bytes': p['cache_capacities']['dictionary_by_id_shard_budget_bytes']}
        cells.setdefault((q, budget), []).append(rec)
def rng(v): return [min(v), statistics.median(v), max(v)]
out = {}
for (q, b), recs in sorted(cells.items()):
    s7 = {f: rng([r['slot7'][f] for r in recs]) for f in F}
    out[f'{q} {b}'] = {
        'budget_mb': recs[0]['budget_mb'], 'dict_by_id_shard_budget_bytes': recs[0]['dict_shard_bytes'],
        'passes': len(recs), 'slot7_min_med_max': s7,
        'other_slots_moved_in_convert': sorted({s for r in recs for s in r['other_slots_moved']}),
        'control_total_ms': rng([r['total_ms'] for r in recs if r['pass'] == 'control']),
        'profiled_total_ms': rng([r['total_ms'] for r in recs if r['pass'] == 'profiled']),
        'profiled_decode_ms': rng([r['decode_ms'] for r in recs if r['pass'] == 'profiled']),
        'ids_ms': rng([r['ids_ms'] for r in recs]),
        'conv_read_bytes': rng([r['conv_read_bytes'] for r in recs]),
        'conv_pgmajfault': rng([r['conv_pgmajfault'] for r in recs]),
        'peak_GiB': rng([round(r['peak_bytes'] / 2**30, 3) for r in recs]),
    }
print(json.dumps({'cells': out, 'passes': [r for v in cells.values() for r in v]}, indent=1))
