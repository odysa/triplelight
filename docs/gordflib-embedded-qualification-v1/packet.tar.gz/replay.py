"""Replay recorded goRDFlib native and SPARQL observations without running Go."""
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source"
RUN = HERE / "run"
FIXTURE = RUN / "fixture"
sys.path.insert(0, str(SOURCE))
from check_answers import audit


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def inventory(root):
    return {
        p.relative_to(root).as_posix(): {"logical_bytes": p.stat().st_size, "sha256": sha(p)}
        for p in sorted(root.rglob("*")) if p.is_file()
    }


freeze_path = SOURCE / "FREEZE.json"
freeze = sha(freeze_path)
assert freeze == "a56d67fb97e65323c22780c5eb65c2d4891fe79b80d48ad68916e5553934cdc2"
files = read(freeze_path)["files"]
assert {p.name for p in SOURCE.iterdir()} == set(files) | {"FREEZE.json"}
for name, digest in files.items():
    assert sha(SOURCE / name) == digest

runtime_path = RUN / "RUNTIME.json"
runtime = sha(runtime_path)
assert runtime == "5638e5336504bfeae6190b0f4ddc70ffb754418e35346cb793582992a5e06f4f"
rt = read(runtime_path)
assert rt["freeze_sha256"] == freeze
assert read(RUN / "SETUP.json") == {"pass": True, "runtime_sha256": runtime}
assert rt["toolchain"]["version"] == "go version go1.26.4 darwin/arm64"
assert sha(SOURCE / "main.go") == rt["worker_inputs"]["main.go"]
for name in ("go.mod", "go.sum"):
    assert sha(RUN / "worker" / name) == rt["worker_inputs"][name]
setup = RUN / "setup"
assert sha(setup / "build-info.stdout") == rt["go_build_info_sha256"]
assert sha(setup / "module-graph.stdout") == rt["module_graph_sha256"]
modules = (setup / "module-graph.stdout").read_text().splitlines()
assert {"github.com/tggo/goRDFlib v0.10.5", "github.com/dgraph-io/badger/v4 v4.9.1",
        "modernc.org/sqlite v1.46.1"} <= set(modules)
license_bytes = (setup / "MODULE-LICENSE").read_bytes()
assert hashlib.sha1(f"blob {len(license_bytes)}\0".encode() + license_bytes).hexdigest() == rt["module"]["license_blob"]

receipt = read(FIXTURE / "RECEIPT.json")
assert receipt["runtime_sha256"] == runtime and receipt["pass"] is True and receipt["scored"] is False
routes = {}
for profile, stage in (("parser", "parse"), ("memory", "load"), ("badger", "load"), ("badger", "reopen"),
                       ("sqlite", "load"), ("sqlite", "reopen")):
    label = f"{profile}-{stage}"
    record = read(FIXTURE / f"{label}.stdout")
    assert (record["profile"], record["stage"]) == (profile, stage)
    assert record["read_only"] is (label == "badger-reopen")
    result = audit(record)
    prior = receipt["stages"][label]
    assert result["pass"] and prior["exit"] == 0
    assert all(prior[k] == v for k, v in result.items())
    routes[label] = result
assert set(routes) == set(receipt["stages"])

stores = {}
for profile in ("badger", "sqlite"):
    load_files = receipt["stages"][f"{profile}-load"]["files_after"]
    reopen_files = receipt["stages"][f"{profile}-reopen"]["files_after"]
    assert load_files == reopen_files
    actual = inventory(FIXTURE / profile)
    expected = {p: {k: v for k, v in meta.items() if k != "allocated_bytes"} for p, meta in reopen_files.items()}
    assert actual == expected
    stores[profile] = actual

v1 = HERE / "v1"
assert read(v1 / "SETUP.json")["pass"] is False
assert "module lookup disabled by GOPROXY=off" in (v1 / "module-graph.stderr").read_text()
print(json.dumps({
    "engine": "goRDFlib", "freeze_sha256": freeze, "runtime_sha256": runtime,
    "scored": False, "stages": routes, "closed_store_files": stores,
    "typed_checks_passed": sum(len(item["queries"]) for item in routes.values()),
    "v1_stopped_before_build": True,
}, indent=2, sort_keys=True))
