# goRDFlib embedded fixture

This harness uses the pinned Go module against the same nine-triple input as the Grafeo and sparq fixtures. The native APIs run in separate parser, memory, Badger-load, Badger-reopen, SQLite-load and SQLite-reopen processes. A loader must finish and close successfully before its store reopens.

After prospective review and a named handoff, verify the shared-host free space is at least 48 GiB and the root is absent. Claim the shared lock atomically with owner `Jianlin task39 goRDFlib fixture v2` and announce it. The owned root is `/private/tmp/rdf-jianlin-gordflib39-tiny-v2`. The guard requires 42 GiB of free space during the run. It samples and caps the owned root at 4 GiB allocated and 8 GiB logical, including module and build caches. Setup is capped at 360 seconds. Each fixture command has a 100-second wall-clock cap, with a 600-second fixture cap.

```sh
rtk proxy python3 -E -s -B supervise.py setup --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B supervise.py fixture --freeze FREEZE_SHA256 --runtime RUNTIME_SHA256
```

Setup uses the existing ARM64 Go installation, checks the pinned module and licence, acquires dependencies with the public Go checksum database, verifies the module cache and builds with proxy and checksum-network lookups disabled. Record the actual module graph, local toolchain identity and build information. Announce the new runtime receipt hash before fixture execution.

Badger reopens read-only. An error returned by its read-only constructor allows a single separately labelled read-write reopen, which does not change the read-only verdict. SQLite uses the normal constructor. Store inventories include any sidecars present after each close. The fixture records any file change at reopen alongside native and typed result checks.

Preserve source, setup and fixture receipts before any follow-up. Release the exact own lock after all owned processes exit. The run checks small-fixture correctness without collecting workload timings.

The first setup reached module verification, then the offline module graph lookup stopped because the cache lacked transitive metadata. This revision explicitly prefetches the full resolved module list before verification. Build and graph resolution still run offline. The first setup root and receipts remain intact.
