package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	rdf "github.com/tggo/goRDFlib"
	"github.com/tggo/goRDFlib/nt"
	"github.com/tggo/goRDFlib/sparql"
	"github.com/tggo/goRDFlib/store/badgerstore"
	"github.com/tggo/goRDFlib/store/sqlitestore"
)

const lock = "/private/tmp/rdf-bench.lock/owner"
const owner = "Jianlin task39 goRDFlib fixture v2\n"

type nativeTerm struct {
	Kind      string `json:"type"`
	Value     string `json:"value"`
	Datatype  string `json:"datatype,omitempty"`
	Language  string `json:"xml:lang,omitempty"`
	Direction string `json:"direction,omitempty"`
}

type triple struct {
	Subject   nativeTerm `json:"s"`
	Predicate nativeTerm `json:"p"`
	Object    nativeTerm `json:"o"`
}

type observation struct {
	Answer any    `json:"answer,omitempty"`
	Error  string `json:"error,omitempty"`
}

type report struct {
	Profile    string                 `json:"profile"`
	Stage      string                 `json:"stage"`
	Native     []triple               `json:"native"`
	Length     *int                   `json:"length"`
	Closed     *bool                  `json:"close_returned"`
	ReadOnly   bool                   `json:"read_only"`
	Queries    map[string]observation `json:"queries"`
	OpenError  string                 `json:"open_error,omitempty"`
	StageError string                 `json:"stage_error,omitempty"`
}

func requireLock() error {
	data, err := os.ReadFile(lock)
	if err != nil {
		return err
	}
	if string(data) != owner {
		return errors.New("exact fixture lock required")
	}
	return nil
}

func term(t rdf.Term) (nativeTerm, error) {
	switch v := t.(type) {
	case rdf.URIRef:
		return nativeTerm{Kind: "uri", Value: v.Value()}, nil
	case rdf.BNode:
		return nativeTerm{Kind: "bnode", Value: v.Value()}, nil
	case rdf.Literal:
		return nativeTerm{Kind: "literal", Value: v.Lexical(),
			Datatype: v.Datatype().Value(), Language: v.Language(), Direction: v.Dir()}, nil
	default:
		return nativeTerm{}, fmt.Errorf("unexpected native term %T", t)
	}
}

func appendTriple(out *[]triple, s rdf.Subject, p rdf.URIRef, o rdf.Term) error {
	if len(*out) >= 128 {
		return errors.New("fixture native projection exceeds 128 rows")
	}
	subject, err := term(s)
	if err != nil {
		return err
	}
	predicate, err := term(p)
	if err != nil {
		return err
	}
	object, err := term(o)
	if err != nil {
		return err
	}
	*out = append(*out, triple{subject, predicate, object})
	return nil
}

func query(ctx context.Context, g *rdf.Graph, label, text string) (any, error) {
	result, err := sparql.QueryContext(ctx, g, text)
	if err != nil {
		return nil, err
	}
	if label == "ask_false" {
		if result.Type != "ASK" {
			return nil, fmt.Errorf("unexpected ASK result type %q", result.Type)
		}
		return map[string]bool{"boolean": result.AskResult}, nil
	}
	if result.Type != "SELECT" || len(result.Bindings) > 128 {
		return nil, fmt.Errorf("unexpected SELECT result: type %q, rows %d", result.Type, len(result.Bindings))
	}
	columns := make(map[string]bool, len(result.Vars))
	for _, name := range result.Vars {
		if columns[name] {
			return nil, fmt.Errorf("duplicate projection %q", name)
		}
		columns[name] = true
	}
	rows := make([]map[string]nativeTerm, 0, len(result.Bindings))
	for _, binding := range result.Bindings {
		row := make(map[string]nativeTerm, len(binding))
		for key, value := range binding {
			if !columns[key] {
				return nil, fmt.Errorf("undeclared binding %q", key)
			}
			if value == nil {
				continue
			}
			v, err := term(value)
			if err != nil {
				return nil, err
			}
			row[key] = v
		}
		rows = append(rows, row)
	}
	return map[string]any{
		"head":    map[string]any{"vars": result.Vars},
		"results": map[string]any{"bindings": rows},
	}, nil
}

func openGraph(profile, stage, path string) (*rdf.Graph, func() error, error) {
	switch profile {
	case "memory":
		return rdf.NewGraph(), nil, nil
	case "badger":
		opts := []badgerstore.Option{badgerstore.WithDir(path)}
		if stage == "reopen" {
			opts = append(opts, badgerstore.WithReadOnly())
		}
		s, err := badgerstore.New(opts...)
		if err != nil {
			return nil, nil, err
		}
		return rdf.NewGraph(rdf.WithStore(s)), s.Close, nil
	case "sqlite":
		s, err := sqlitestore.New(sqlitestore.WithFile(path))
		if err != nil {
			return nil, nil, err
		}
		return rdf.NewGraph(rdf.WithStore(s)), s.Close, nil
	default:
		return nil, nil, fmt.Errorf("unsupported profile %q", profile)
	}
}

func validate(profile, stage, path string) error {
	switch {
	case profile == "parser" && stage == "parse":
		return nil
	case profile == "memory" && stage == "load":
		return nil
	case (profile == "badger" || profile == "sqlite") && stage == "load":
		if _, err := os.Lstat(path); !os.IsNotExist(err) {
			return errors.New("persistent path must be absent")
		}
		return nil
	case (profile == "badger" || profile == "sqlite") && stage == "reopen",
		profile == "badger" && stage == "reopen-read-write":
		_, err := os.Stat(path)
		return err
	default:
		return fmt.Errorf("invalid profile and stage %q %q", profile, stage)
	}
}

func observeGraph(ctx context.Context, out *report, g *rdf.Graph, fixture []byte, queries map[string]string) error {
	if out.Stage == "load" {
		if err := nt.Parse(ctx, g, bytes.NewReader(fixture)); err != nil {
			return fmt.Errorf("parse into graph: %w", err)
		}
	}
	n, err := g.Len(ctx)
	if err != nil {
		return fmt.Errorf("native graph length: %w", err)
	}
	out.Length = &n
	for t, err := range g.Triples(ctx, nil, nil, nil) {
		if err != nil {
			return fmt.Errorf("native projection: %w", err)
		}
		if err := appendTriple(&out.Native, t.Subject, t.Predicate, t.Object); err != nil {
			return err
		}
	}
	for _, label := range []string{"group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false"} {
		if err := requireLock(); err != nil {
			return err
		}
		text, ok := queries[label]
		if !ok {
			return fmt.Errorf("missing query %q", label)
		}
		answer, err := query(ctx, g, label, text)
		if err != nil {
			out.Queries[label] = observation{Error: err.Error()}
		} else {
			out.Queries[label] = observation{Answer: answer}
		}
	}
	return nil
}

func execute(ctx context.Context, out *report, path string, input []byte, queries map[string]string) error {
	if err := validate(out.Profile, out.Stage, path); err != nil {
		return err
	}
	if out.Profile == "parser" {
		return nt.ParseStreamContext(ctx, bytes.NewReader(input), func(s rdf.Subject, p rdf.URIRef, o rdf.Term) error {
			return appendTriple(&out.Native, s, p, o)
		})
	}
	g, closeStore, err := openGraph(out.Profile, out.Stage, path)
	if err != nil {
		out.OpenError = err.Error()
		return fmt.Errorf("open store: %w", err)
	}
	err = observeGraph(ctx, out, g, input, queries)
	if closeStore != nil {
		closeErr := closeStore()
		closed := closeErr == nil
		out.Closed = &closed
		err = errors.Join(err, closeErr)
	}
	return err
}

func run() error {
	profile := flag.String("profile", "", "parser, memory, badger, or sqlite")
	stage := flag.String("stage", "", "parse, load, reopen, or reopen-read-write")
	path := flag.String("store", "", "persistent store path")
	fixture := flag.String("fixture", "", "frozen N-Triples input")
	queryPath := flag.String("queries", "", "frozen query JSON")
	flag.Parse()
	if err := requireLock(); err != nil {
		return err
	}
	data, err := os.ReadFile(*fixture)
	if err != nil {
		return err
	}
	queryBytes, err := os.ReadFile(*queryPath)
	if err != nil {
		return err
	}
	var queries map[string]string
	if err := json.Unmarshal(queryBytes, &queries); err != nil {
		return err
	}
	out := report{Profile: *profile, Stage: *stage, Native: []triple{},
		ReadOnly: *profile == "badger" && *stage == "reopen", Queries: map[string]observation{}}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	err = execute(ctx, &out, *path, data, queries)
	if err != nil {
		out.StageError = err.Error()
	}
	if lockErr := requireLock(); lockErr != nil {
		return errors.Join(err, lockErr)
	}
	return errors.Join(err, writeJSON(os.Stdout, out))
}

func writeJSON(w io.Writer, out report) error {
	encoder := json.NewEncoder(w)
	encoder.SetIndent("", "  ")
	return encoder.Encode(out)
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
