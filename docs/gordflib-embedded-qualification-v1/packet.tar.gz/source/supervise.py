"""Build the pinned Go fixture worker and supervise the recorded routes."""

import argparse
import hashlib
import json
import os
import re
import shutil
import signal
import stat
import subprocess
import time
from pathlib import Path

from check_answers import audit

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/rdf-jianlin-gordflib39-tiny-v2")
LOCK = Path("/private/tmp/rdf-bench.lock/owner")
OWNER = "Jianlin task39 goRDFlib fixture v2\n"
MODULE = "github.com/tggo/goRDFlib"
VERSION = "v0.10.5"
MODULE_SUM = "h1:30C9M8c6ay1rX9TdgMyywbLt4Kq/s4zXQL/Ux2jl7CY="
MOD_SUM = "h1:wiMiAkxfix5QjqXmFejVIMrt0LVQRHwlvIhTRvuA0B0="
LICENSE_BLOB = "e56d673e30e1a70c71c7fc4e90e34bec0e048abf"
GIB = 1 << 30


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write("\n")


def source_check(expected):
    path = HERE / "FREEZE.json"
    require(sha(path) == expected, "freeze digest drift")
    files = load(path)["files"]
    current = {p.name for p in HERE.iterdir()}
    require(current == set(files) | {"FREEZE.json"}, "source file inventory drift")
    for name, digest in files.items():
        p = HERE / name
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, f"source drift: {name}")


def check_lock():
    require(LOCK.read_text() == OWNER, "exact own lock required")


def bytes_used():
    allocated = 0
    logical = 0
    for path in ROOT.rglob("*"):
        try:
            item = path.lstat()
        except FileNotFoundError:
            continue
        allocated += item.st_blocks * 512
        if stat.S_ISREG(item.st_mode):
            logical += item.st_size
    return allocated, logical


def guard(deadline):
    check_lock()
    require(time.monotonic() < deadline, "phase deadline")
    require(shutil.disk_usage(ROOT).free >= 42 * GIB, "42 GiB free-space guard")
    allocated, logical = bytes_used()
    require(allocated < 4 * GIB and logical < 8 * GIB, "owned root size guard")


def command(args, env, cwd, out, label, deadline):
    stdout_path = out / (label + ".stdout")
    limit = min(deadline, time.monotonic() + (300 if out.name == "setup" else 100))
    guard(limit)
    with stdout_path.open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(args, stdout=stdout, stderr=stderr, cwd=cwd, env=env, start_new_session=True)
        try:
            while child.poll() is None:
                guard(limit)
                require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                        "diagnostic output limit")
                time.sleep(0.25)
            require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                    "diagnostic output limit")
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    guard(limit)
    return child.returncode, stdout_path


def environment(online=False):
    # Avoid user Go settings, shared caches, and private proxy configuration.
    env = {
        "PATH": "/opt/homebrew/bin:/usr/bin:/bin",
        "HOME": str(ROOT / "home"),
        "TMPDIR": str(ROOT / "tmp"),
        "GOTMPDIR": str(ROOT / "tmp"),
        "GOCACHE": str(ROOT / "build-cache"),
        "GOMODCACHE": str(ROOT / "module-cache"),
        "GOENV": "off",
        "GOWORK": "off",
        "GOTOOLCHAIN": "local",
        "GOFLAGS": "-mod=readonly",
        "GOPROXY": "https://proxy.golang.org" if online else "off",
        "GOSUMDB": "sum.golang.org" if online else "off",
        "GOOS": "darwin",
        "GOARCH": "arm64",
        "CGO_ENABLED": "0",
    }
    return env


def setup(freeze, go):
    check_lock()
    require(shutil.disk_usage(ROOT.parent).free >= 48 * GIB, "48 GiB launch floor")
    ROOT.mkdir()
    try:
        build_worker(freeze, go)
    except Exception as error:
        save(ROOT / "SETUP.json", {"pass": False, "failure": repr(error)})
        raise
    save(ROOT / "SETUP.json", {"pass": True, "runtime_sha256": sha(ROOT / "RUNTIME.json")})
    print(sha(ROOT / "RUNTIME.json"))


def build_worker(freeze, go):
    deadline = time.monotonic() + 360
    out = ROOT / "setup"
    out.mkdir()
    work = ROOT / "worker"
    work.mkdir()
    for name in ("home", "tmp"):
        (ROOT / name).mkdir()
    for name in ("main.go", "go.mod.in", "go.sum.in"):
        shutil.copyfile(HERE / name, work / name.removesuffix(".in"))

    def go_step(label, *args, online=False):
        rc, output = command([str(go), *args], environment(online), work, out, label, deadline)
        require(rc == 0, f"{label} exited {rc}")
        return output

    version = go_step("version", "version").read_text().strip()
    matched = re.fullmatch(r"go version go(\d+)\.(\d+)\.(\d+) darwin/arm64", version)
    require(matched and tuple(map(int, matched.groups())) >= (1, 26, 0), "Go >=1.26.0 ARM64 required")
    pinned = load(go_step("module", "mod", "download", "-json", f"{MODULE}@{VERSION}", online=True))
    require(pinned["Path"] == MODULE and pinned["Version"] == VERSION, "module identity mismatch")
    require(pinned["Sum"] == MODULE_SUM and pinned["GoModSum"] == MOD_SUM, "module checksum mismatch")
    license_file = Path(pinned["Dir"]) / "LICENSE"
    license_bytes = license_file.read_bytes()
    blob = hashlib.sha1(f"blob {len(license_bytes)}\0".encode() + license_bytes).hexdigest()
    require(blob == LICENSE_BLOB, "tagged licence drift")
    shutil.copyfile(license_file, out / "MODULE-LICENSE")
    go_step("module-lock", "mod", "tidy", online=True)
    go_step("module-prefetch", "mod", "download", "all", online=True)
    go_step("module-verify", "mod", "verify")
    graph = go_step("module-graph", "list", "-m", "-mod=readonly", "all")
    expected_backends = {"github.com/dgraph-io/badger/v4 v4.9.1", "modernc.org/sqlite v1.46.1"}
    require(expected_backends <= set(graph.read_text().splitlines()), "pinned backend dependency version drift")
    goroot = go_step("goroot", "env", "GOROOT").read_text().strip()
    binary = ROOT / "gordflib-fixture"
    fingerprints = {name: sha(work / name) for name in ("main.go", "go.mod", "go.sum")}
    go_step("build", "build", "-mod=readonly", "-trimpath", "-buildvcs=false", "-o", str(binary), ".")
    build_info = go_step("build-info", "version", "-m", str(binary))
    require(fingerprints == {name: sha(work / name) for name in fingerprints}, "offline build changed inputs")
    require(fingerprints["main.go"] == sha(HERE / "main.go"), "worker source drift")
    source_check(freeze)
    runtime = {
        "freeze_sha256": freeze,
        "toolchain": {"path": str(go), "version": version, "sha256": sha(go), "goroot": goroot},
        "module": {
            "path": MODULE, "version": VERSION, "sum": MODULE_SUM, "go_mod_sum": MOD_SUM,
            "zip_sha256": sha(Path(pinned["Zip"])), "go_mod_sha256": sha(Path(pinned["GoMod"])),
            "license": "BSD-3-Clause", "license_blob": blob,
        },
        "setup_proxy": environment(True)["GOPROXY"], "setup_sumdb": environment(True)["GOSUMDB"],
        "offline_go_flags": environment()["GOFLAGS"],
        "worker_inputs": fingerprints,
        "worker_sha256": sha(binary), "go_build_info_sha256": sha(build_info),
        "module_graph_sha256": sha(graph),
    }
    save(ROOT / "RUNTIME.json", runtime)


def store_inventory(store_root):
    files = {}
    for path in sorted(store_root.rglob("*")):
        if path.is_file():
            item = path.stat()
            files[path.relative_to(store_root).as_posix()] = {
                "logical_bytes": item.st_size, "allocated_bytes": item.st_blocks * 512, "sha256": sha(path),
            }
    return files


def fixture(freeze, expected_runtime):
    check_lock()
    rpath = ROOT / "RUNTIME.json"
    require(sha(rpath) == expected_runtime, "runtime digest drift")
    runtime = load(rpath)
    require(load(ROOT / "SETUP.json") == {"pass": True, "runtime_sha256": expected_runtime}, "setup receipt mismatch")
    binary = ROOT / "gordflib-fixture"
    require(runtime["freeze_sha256"] == freeze, "runtime belongs to another freeze")
    require(sha(binary) == runtime["worker_sha256"], "worker binary drift")
    out = ROOT / "fixture"
    out.mkdir()
    deadline = time.monotonic() + 600
    store_paths = {profile: out / profile for profile in ("badger", "sqlite")}
    for p in store_paths.values():
        p.mkdir()
    paths = {"badger": store_paths["badger"] / "index", "sqlite": store_paths["sqlite"] / "index.sqlite"}
    stages = {}
    receipt = {"runtime_sha256": expected_runtime, "scored": False, "stages": stages}

    def observe(profile, stage):
        label = f"{profile}-{stage}"
        rc, raw = command(
            [str(binary), "--profile", profile, "--stage", stage, "--store", str(paths.get(profile, "")),
             "--fixture", str(HERE / "consumer-fixture.nt"), "--queries", str(HERE / "queries.json")],
            environment(), out, out, label, deadline,
        )
        record = load(raw)
        require((record["profile"], record["stage"]) == (profile, stage), "observation identity changed")
        result = audit(record)
        result["pass"] &= rc == 0
        stages[label] = {"exit": rc, **result}
        if profile in paths:
            stages[label]["files_after"] = store_inventory(store_paths[profile])
            guard(deadline)
        return record

    try:
        observe("parser", "parse")
        observe("memory", "load")
        for profile in ("badger", "sqlite"):
            loaded = observe(profile, "load")
            if loaded["close_returned"] is not True or "stage_error" in loaded:
                stages[f"{profile}-reopen"] = {"pass": False, "skipped": "load and close gate"}
                continue
            reopened = observe(profile, "reopen")
            if profile == "badger" and reopened.get("open_error"):
                observe(profile, "reopen-read-write")
        source_check(freeze)
        require(sha(binary) == runtime["worker_sha256"], "worker changed during fixture")
        primary = {k: v for k, v in stages.items() if k != "badger-reopen-read-write"}
        receipt["pass"] = len(primary) == 6 and all(x["pass"] for x in primary.values())
    except Exception as error:
        receipt.update({"pass": False, "failure": repr(error)})
        raise
    finally:
        save(out / "RECEIPT.json", receipt)
    print(json.dumps({"pass": receipt["pass"], "stage_count": len(stages)}))
    return receipt["pass"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("setup", "fixture"))
    parser.add_argument("--freeze", required=True)
    parser.add_argument("--go", default="/opt/homebrew/bin/go")
    parser.add_argument("--runtime")
    args = parser.parse_args()
    source_check(args.freeze)
    if args.stage == "setup":
        setup(args.freeze, Path(args.go).resolve(strict=True))
    else:
        require(args.runtime, "runtime digest required")
        if not fixture(args.freeze, args.runtime):
            raise SystemExit(1)


if __name__ == "__main__":
    main()
