#!/bin/bash
# Builds startup_probe for linux/arm64 from worktree $1 into /tmp/s36/bin-$2; $3 = extra RUSTFLAGS ("" or "--cfg tl_origin").
# Sources are copied in first (virtiofs staleness).
set -eu
IMG=rust@sha256:0b0ea86881537b3f645aace7e8e39556289f8787db057317c8d4978548213b9e
mkdir -p /tmp/s36/bin-$2 /tmp/s36/target-$2
docker run --rm --platform linux/arm64 -v $1:/src:ro -v /tmp/s36/target-$2:/t -v /tmp/s36/bin-$2:/out -e CARGO_TARGET_DIR=/t -e RUSTFLAGS="${3:-}" $IMG \
  sh -c "mkdir /b && cp -r /src/src /src/crates /src/examples /src/tests /src/Cargo.toml /src/Cargo.lock /src/rust-toolchain.toml /b/ && cd /b && cargo build --locked --release --example startup_probe && cp /t/release/examples/startup_probe /out/"
