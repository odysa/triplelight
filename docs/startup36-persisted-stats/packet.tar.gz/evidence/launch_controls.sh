#!/bin/bash
# Stubbed launcher controls: no Raft, no engine, no real lock. A fake python records which subcommands ran.
set -u
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cat > "$T/fakepy" <<'PYEOF'
#!/bin/bash
# args: <supervisor> <subcommand> ...
echo "$2" >> "$CALLS"
[ "$2" = bind ] && exit "${BIND_RC:-0}"
[ "$2" = run ] && exit "${RUN_RC:-0}"
exit 0
PYEOF
chmod +x "$T/fakepy"
fail=0
check() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got [$2] want [$3]"; fail=1; fi; }
run_case() { # name lock_owner bind_rc [run_rc]
  rm -rf "$T/lock" "$T/calls" "$T/log"; : > "$T/calls"
  if [ -n "$2" ]; then mkdir "$T/lock"; echo "$2" > "$T/lock/owner"; fi
  LOCK="$T/lock" OWNER="me" PY="$T/fakepy" SUP=sup LOG="$T/log" CALLS="$T/calls" BIND_RC="$3" RUN_RC="${4:-0}" bash /tmp/s36/launch.sh R M; echo $?
}
rc=$(run_case lock-held-by-other "someone else" 0); check "lock-held-by-other: exit" "$rc" 2
check "lock-held-by-other: no commands" "$(cat "$T/calls")" ""
check "lock-held-by-other: lock untouched" "$(cat "$T/lock/owner")" "someone else"
rc=$(run_case lock-absent "" 0); check "lock-absent: exit" "$rc" 2
check "lock-absent: no commands" "$(cat "$T/calls")" ""
rc=$(run_case bind-fails "me" 1); check "bind-fails: exit" "$rc" 3
check "bind-fails: run not started" "$(tr '\n' ' ' < "$T/calls")" "bind "
check "bind-fails: own lock released" "$([ -d "$T/lock" ] && echo held || echo released)" released
rc=$(run_case success "me" 0); check "success: exit" "$rc" 0
check "success: bind then run" "$(tr '\n' ' ' < "$T/calls")" "bind run "
check "success: own lock released" "$([ -d "$T/lock" ] && echo held || echo released)" released
rc=$(run_case run-fails "me" 0 1); check "run-fails: exit" "$rc" 1
check "run-fails: bind then run" "$(tr '\n' ' ' < "$T/calls")" "bind run "
check "run-fails: own lock retained" "$([ -d "$T/lock" ] && cat "$T/lock/owner" || echo released)" me
# register.sh: a held lock means no command runs and the other owner's lock is untouched.
rm -rf "$T/lock" "$T/calls"; : > "$T/calls"; mkdir "$T/lock"; echo "someone else" > "$T/lock/owner"
LOCK="$T/lock" OWNER="me" PY="$T/fakepy" SUP=sup OUTFILE="$T/out" CALLS="$T/calls" bash /tmp/s36/register.sh > /dev/null; rc=$?
check "register-lock-held: exit" "$rc" 2
check "register-lock-held: no commands" "$(cat "$T/calls")" ""
check "register-lock-held: lock untouched" "$(cat "$T/lock/owner")" "someone else"
# register.sh: a failing registration releases only its own lock.
cat > "$T/failpy" <<'PYEOF'
#!/bin/bash
echo "$2" >> "$CALLS"; exit 1
PYEOF
chmod +x "$T/failpy"; rm -rf "$T/lock"; : > "$T/calls"
LOCK="$T/lock" OWNER="me" PY="$T/failpy" SUP=sup OUTFILE="$T/out" CALLS="$T/calls" bash /tmp/s36/register.sh > /dev/null; rc=$?
check "register-fails: exit" "$rc" 3
check "register-fails: own lock released" "$([ -d "$T/lock" ] && echo held || echo released)" released
[ $fail -eq 0 ] && echo "LAUNCH-CONTROLS PASS" || { echo "LAUNCH-CONTROLS FAIL"; exit 1; }
