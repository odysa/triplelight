# Independent audit: persisted-statistics startup comparison

**Pass for the registered 45-phase attempt.** The audit independently verified all 653 files listed in the published evidence manifest, current frozen source/qualification files and probe binaries/queries; registration/message/start ordering; all 45 saved answer, condition and resource gates; and 15 required q010 order checks. All 15 published metric rows matched independent medians, ranges and comparison calls. No engine, query, build or container was run by the audit.

Registration: `ffff5225b15cba91c458696a09288917d6ef4405ae7478d421e1c10c0a938c2c`.
Approved source freeze: `c160f830bb977ed0e55fcd2df17e1f8aae1e4e159e3ecfbbb3d2204c461f9b90`.
Evidence manifest: `e8ffed6b6d97c340b22bfdd106cc74735f46e22b71ff2ee8c69d4e6b381da9a0`.
Source A: `cc93aa0376c82ed6f7a7719835b73927b3162654`; B: `40af216a16dc3338ace1064614172510f71706dc`.

The registered endpoint is elapsed milliseconds from open start until statistics readiness is observed. B-scan includes the sidecar write before readiness publication; diagnostic scan/persistence components must not be added again.

| Cell | A-scan median ms | B-reuse median ms | B-scan median ms | A-scan / B-reuse |
|---|---:|---:|---:|---:|
| lubm1000-q2 | 25759.598 | 904.383 | 25412.603 | 28.48× |
| lubm1000-q9 | 25847.263 | 906.092 | 25457.385 | 28.53× |
| bsbm100-q010 | 20453.317 | 743.461 | 20110.614 | 27.51× |

B-reuse's readiness median is below the entire five-run A-scan range in every cell. Open and first-query medians remain within their A-scan ranges, except Q2 B-scan's first-query median is marginally lower. B-scan readiness medians are 1.35%, 1.51% and 1.68% lower for Q2, Q9 and q010 respectively; this does not establish a cause or a general scan-speed improvement.

The rule is descriptive: a B median outside the range of the five A observations is labelled lower/higher. It is not a confidence interval or evidence of equivalence when the median is inside that range. The q010 B-scan peak-memory “higher” result is preserved despite being only about 0.1 MiB beyond the baseline maximum. All raw observations, including actual rotated positions, remain in AUDIT.json. Three positions cannot be perfectly balanced over five repetitions.

Every phase has MemTotal 16,414,236 kB, matching 4 CPUs and a 12 GiB memory/no-extra-swap container configuration. Raw counters agree with receipts. Reported memory is whole-process container cgroup peak across open, scan, query and close, not process RSS or a phase-isolated peak. Residual memory.current is post-close cgroup charge. Eighteen of 45 phases have nonzero pgscan; there is no established reclaim-causality claim. The sidecar preparation probe records and file sizes are retained separately in PREPARATION.json, outside scored timings; the main report should disclose these costs.

The raw result canonicalization matches the registered round-13 bag hashes, normalizing explicit xsd:string as in the original harness. No blank nodes occur in these answers. This does not establish a general blank-node-isomorphism validator or full SPARQL conformance.

Scope limits: multi-GB original store trees were not independently rehashed in this replay. The frozen run records assert their pre/post identities and each clone's unchanged base tree; the audit checks those recorded gates and retained hashes. Saved receipts report all containers/helpers removed and clones deleted; this audit checks receipt consistency and clone-path absence without querying live Docker inventory. Image/platform checks include the saved inspector verdicts and one consistent image ID; no daemon image reinspection occurred. macOS host cache is uncontrolled, and B alone includes the post-timing origin diagnostic build flag. Compaction scanning is not measured. No prior failed registration or attempt is replaced by these results.

AUDIT.json and audit.py preserve the independently recomputed checks and table. The script reads the owner's frozen evidence paths; it does not copy raw databases, launch the harness, or execute archived code. The comparison of the published rounded summary rows was a separate offline arithmetic check recorded in AUDIT.json.
