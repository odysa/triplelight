#!/usr/bin/env python3
"""Read saved startup36 evidence; no engine, Docker, or original harness execution."""
from pathlib import Path
import hashlib,json,math,statistics
from collections import Counter
S=Path('/tmp/s36');ROOT=S/'scored-v2';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
def good(v):return type(v) in (int,float) and math.isfinite(v) and v>=0
def canon(answer):
    cols=answer['head']['vars'];seq=[]
    for row in answer['results']['bindings']:
        vals=[]
        for v in cols:
            t=row.get(v)
            if t is None:vals.append('-');continue
            assert t['type']!='bnode', 'fixture has unexpected bnode; do not apply label-erasing hash'
            kind='literal' if t['type']=='typed-literal' else t['type']
            dt=t.get('datatype','')
            if dt=='http://www.w3.org/2001/XMLSchema#string':dt=''
            vals.append('|'.join([kind,t['value'],dt,t.get('xml:lang','').lower()]))
        seq.append('\t'.join(vals))
    return len(seq),hashlib.sha1('\n'.join(sorted(seq)).encode()).hexdigest(),hashlib.sha1('\n'.join(seq).encode()).hexdigest()
def main():
    manifest=S/'scored-v2.SHA256';assert sha(manifest)=='e8ffed6b6d97c340b22bfdd106cc74735f46e22b71ff2ee8c69d4e6b381da9a0'
    entries={}
    for line in manifest.read_text().splitlines():
        h,n=line.split(None,1);assert n not in entries;assert not Path(n).is_absolute() and '..' not in Path(n).parts
        assert sha(S/n)==h,n;entries[n]=h
    actual={str(p.relative_to(S)) for p in ROOT.rglob('*') if p.is_file()}
    assert actual | {'scored-v2.run.log','summary-v2.txt'} == set(entries), {'missing':list(actual-set(entries))}
    reg=load(ROOT/'registration.json');rh=sha(ROOT/'registration.json')
    assert rh=='ffff5225b15cba91c458696a09288917d6ef4405ae7478d421e1c10c0a938c2c'
    ids=reg['identities'];assert ids['freeze_sha256']=='c160f830bb977ed0e55fcd2df17e1f8aae1e4e159e3ecfbbb3d2204c461f9b90'
    for name,digest in ids['freeze_files'].items():assert sha(S/name)==digest,name
    assert sha(S/'FREEZE.SHA256')==ids['freeze_sha256']
    for name,digest in ids['qualification_files'].items():assert sha(S/name)==digest,name
    assert sha(S/'QUAL.SHA256')==ids['qualification_sha256']
    assert sha(S/'score_startup36.py')==ids['supervisor_sha256']=='51838e3ac131a0cb1a7454d5484509a34c7cbec81d30484cb184207f56ffe7e5'
    for b,h in ids['binaries'].items():assert sha(S/('bin-'+b)/'startup_probe')==h
    assert reg['commits']=={'A':'cc93aa0376c82ed6f7a7719835b73927b3162654','B':'40af216a16dc3338ace1064614172510f71706dc'}
    receipt=load(ROOT/'raft_receipt.json');started=load(ROOT/'attempt/started.json');post=load(ROOT/'attempt/postcheck.json')
    assert receipt['registration_sha256']==rh and started['registration_sha256']==rh
    assert receipt['message_id']==started['raft_message_id']=='e7a49dbb-a9f9-4681-9c8a-6fdb7d025c66'
    assert sha(ROOT/'raft_message.txt')==receipt['read_sha256']
    assert reg['registered_unix']<receipt['bound_unix']<started['unix']<post['unix']
    assert post['identities_unchanged'] is True and post['stopped_early'] is False
    phases=reg['phases'];assert len(phases)==45
    cells=['lubm1000-q2','lubm1000-q9','bsbm100-q010'];conditions=['A-scan','B-reuse','B-scan']
    expected=[]
    for k,cell in enumerate(cells):
        for rep in range(1,6):
            rotation=(rep-1+k)%3;order=conditions[rotation:]+conditions[:rotation]
            for pos,c in enumerate(order,1):expected.append((cell,c,rep,pos))
    assert [(p['cell'],p['condition'],p['rep'],p['position']) for p in phases]==expected
    status=load(ROOT/'attempt/status.json');assert set(status)=={p['id'] for p in phases}
    assert {p.name for p in (ROOT/'attempt').iterdir() if p.is_dir()}==set(status)
    records=[];projections={};imageids=set()
    for ph in phases:
        d=ROOT/'attempt'/ph['id'];out=d/'out';r=load(d/'receipt.json');p=load(out/'probe.json');ins=load(d/'inspect.json');a=load(out/'result.json');raw=(out/'result.json').read_bytes()
        assert r['phase']==ph['id'] and r['exit_code']==0 and r['oom_killed'] is False and r['capped'] is False
        assert r['dropcache_helper_cleanup']=='removed' and r['container_cleanup']=='removed' and r['private_clone_removed'] is True and not r.get('cleanup_errors')
        assert r['inventory']['base_tree_unchanged'] is True
        assert r['result']==status[ph['id']] and r['result']['status']=='pass' and r['result']['problems']==[]
        assert r['result']['probe']==p
        assert p['mode']=='after-stats' and all(good(p[k]) for k in ['open_ms','stats_ready_ms','first_query_ms'])
        assert p['open_ms']<=p['stats_ready_ms']<=900000
        assert p['stats_ready_after_query'] is True and p['stats_ready_before_close'] is True and p['poll_interval_ms']==1
        assert type(p['result_bytes']) is int and p['result_bytes']==len(raw) and p['result_sha256']==hashlib.sha256(raw).hexdigest()
        assert 'disk build strategy' not in (out/'probe.stderr').read_text()
        rows,bag,order=canon(a);ref=reg['references'][ph['cell']]
        assert (rows,bag)==(ref['rows'],ref['bag_sha1'])
        assert (rows,bag,order)==(r['result']['rows'],r['result']['bag_sha1'],r['result']['order_sha1'])
        cols=a['head']['vars'];projections.setdefault(ph['cell'],cols);assert cols==projections[ph['cell']]
        if ph['cell']=='bsbm100-q010':
            terms=[row['productLabel'] for row in a['results']['bindings']]
            assert all(t['type'] in ['literal','typed-literal'] and not t.get('xml:lang') and t.get('datatype','http://www.w3.org/2001/XMLSchema#string')=='http://www.w3.org/2001/XMLSchema#string' for t in terms)
            vals=[t['value'] for t in terms];assert vals==sorted(vals)
        origin=p['origin'];sc=r['sidecar'];c=ph['condition'];pinned=ids['prepared_sidecars'][ph['store']]
        if c=='A-scan':assert origin=='unavailable' and sc['before'] is None and sc['after'] is None
        elif c=='B-reuse':
            assert set(origin)=={'kind','bytes','load_ms'} and origin['kind']=='Persisted' and type(origin['bytes']) is int and origin['bytes']==pinned['bytes'] and good(origin['load_ms'])
            assert sc['before']==sc['after']==pinned['sha256'] and sc['after_bytes']==pinned['bytes']
        else:
            assert set(origin)=={'kind','scan_ms','persist_ms'} and origin['kind']=='Scanned' and good(origin['scan_ms']) and good(origin['persist_ms'])
            assert sc['before'] is None and sha(d/'db-private/stats-0.v1')==sc['after']
            assert (d/'db-private/stats-0.v1').stat().st_size==sc['after_bytes']>0
        expectednew={'LOCK','wal.log'}|({'stats-0.v1'} if c=='B-scan' else set())
        assert set(r['inventory']['new_in_clone'])<=expectednew
        assert set(r['inventory']['out'])=={x.name for x in out.iterdir()}
        assert all(v is True for v in ins['checks'].values());imageids.add(ins['image_id'])
        hc=ins['HostConfig'];assert hc['NanoCpus']==4000000000 and hc['Memory']==hc['MemorySwap']==12884901888 and hc['NetworkMode']=='none' and hc['CgroupnsMode']=='private' and hc['ReadonlyRootfs'] is True and not hc['Tmpfs']
        assert 'RAYON_NUM_THREADS=4' in ins['env']
        assert set(ins['mounts'])=={'/bin/probe','/q.rq','/db','/out'}
        for m in ['/bin/probe','/q.rq']:assert ins['mounts'][m]['rw'] is False
        for m in ['/db','/out']:assert ins['mounts'][m]['rw'] is True
        assert sha(ins['mounts']['/bin/probe']['source'])==ids['binaries'][ph['binary']]
        assert sha(ins['mounts']['/q.rq']['source'])==ids['queries'][ph['cell']]
        assert ins['mounts']['/db']['source']==str(S/'clones'/ph['id']) and ins['mounts']['/out']['source']==str(out)
        assert not (S/'clones'/ph['id']).exists()
        memory=r['memory'];assert memory['MemTotal_kB']==int((out/'meminfo.start').read_text().split()[1])==post['cohort_MemTotal_kB']==16414236
        assert memory['memory_max']==(out/'memory.max').read_text().strip()=='12884901888'
        assert memory['memory_peak_bytes']==int((out/'memory.peak.after-close').read_text())==r['result']['memory_peak_bytes']
        assert memory['memory_current_after_close_bytes']==int((out/'memory.current.after-close').read_text())
        for field,name in [('memory_stat_after_close','memory.stat.after-close'),('memory_events_after_close','memory.events.after-close')]:
            assert memory[field]=={k:int(v) for k,v in (line.split() for line in (out/name).read_text().splitlines())}
        assert memory['memory_events_after_close']['oom']==memory['memory_events_after_close']['oom_kill']==0
        records.append({'id':ph['id'],'cell':ph['cell'],'condition':c,'rep':ph['rep'],'position':ph['position'],'ready':p['stats_ready_ms'],'open':p['open_ms'],'query':p['first_query_ms'],'peak_bytes':memory['memory_peak_bytes'],'residual_bytes':memory['memory_current_after_close_bytes'],'origin':origin,'pgscan':memory['memory_stat_after_close'].get('pgscan',0),'pgsteal':memory['memory_stat_after_close'].get('pgsteal',0)})
    assert len(imageids)==1
    table={}
    for cell in cells:
        table[cell]={}
        for metric in ['ready','open','query','peak_bytes','residual_bytes']:
            groups={c:[r[metric] for r in records if r['cell']==cell and r['condition']==c] for c in conditions}
            assert all(len(v)==5 for v in groups.values())
            table[cell][metric]={c:{'median':statistics.median(v),'min':min(v),'max':max(v)} for c,v in groups.items()}
            a=groups['A-scan']
            for c in ['B-reuse','B-scan']:
                med=statistics.median(groups[c]);table[cell][metric][c]['comparison']='lower' if med<min(a) else 'higher' if med>max(a) else 'no measurable change'
    result={'manifest_sha256':sha(manifest),'manifest_files_verified':len(entries),'freeze_files_verified':len(ids['freeze_files']),'qualification_files_verified':len(ids['qualification_files']),'registration_sha256':rh,'phases_replayed':45,'order_checks':15,'no_bnodes_observed':True,'projections':projections,'MemTotal_kB':16414236,'image_id':next(iter(imageids)),'current_binary_query_hashes_verified':True,'independent_full_base_tree_rehash':False,'base_tree_note':'Frozen run records assert pre/post identities and per-clone base trees unchanged; this replay does not reread multi-GB base stores.','container_cleanup':'45 saved receipts confirm removal; no live Docker inventory queried','table':table,'records':records}
    (OUT/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['records','table']},indent=2))
if __name__=='__main__':main()
