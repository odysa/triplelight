#!/bin/bash
# Launcher for one registered startup36 attempt: launch.sh <registration-sha256> <message-uuid>
# Requires the lock to be held already by OWNER (taken in the registration step); never acquires or removes a lock
# it does not own. Every step's exit code is captured explicitly (no pipes); a failed step stops the chain.
# LOCK / PY / SUP / LOG may be overridden for the stubbed controls in launch_controls.sh.
set -u
LOCK=${LOCK:-/tmp/rdf-bench.lock}
OWNER=${OWNER:-"Kaiming-He startup36-scored-v2"}
PY=${PY:-"python3 -I"}
SUP=${SUP:-/tmp/s36/score_startup36.py}
LOG=${LOG:-/tmp/s36/scored-v2.run.log}
REG=$1; MSG=$2
release() { if [ "$(cat "$LOCK/owner" 2>/dev/null)" = "$OWNER" ]; then rm -rf "$LOCK"; echo "released" >> "$LOG"; else echo "lock not ours; left untouched" >> "$LOG"; fi; }
if [ "$(cat "$LOCK/owner" 2>/dev/null)" != "$OWNER" ]; then echo "lock not held by $OWNER; nothing run" >> "$LOG"; exit 2; fi
$PY "$SUP" bind "$REG" "$MSG" >> "$LOG" 2>&1; rc=$?
echo "bind exit $rc" >> "$LOG"
if [ $rc -ne 0 ]; then release; exit 3; fi
$PY "$SUP" run "$REG" >> "$LOG" 2>&1; rc=$?
echo "run exit $rc" >> "$LOG"
# A successful run implies verified cleanup (its pass gates require it). A failed run may have left a container or
# kept a mounted clone (cleanup-unverified), so the lock is retained until cleanup is checked by hand.
if [ $rc -eq 0 ]; then release; else echo "run failed; lock retained until cleanup is verified" >> "$LOG"; fi
exit $rc
