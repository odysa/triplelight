#!/bin/bash
# Registration step: takes the lock (or does nothing at all), registers, and keeps the lock for launch.sh.
# On a failed registration it releases only its own lock. Exit codes are captured explicitly.
set -u
LOCK=${LOCK:-/tmp/rdf-bench.lock}
OWNER=${OWNER:-"Kaiming-He startup36-scored-v2"}
PY=${PY:-"python3 -I"}
SUP=${SUP:-/tmp/s36/score_startup36.py}
OUTFILE=${OUTFILE:-/tmp/s36/register-v2.out}
if ! mkdir "$LOCK" 2>/dev/null; then echo "lock held by: $(cat "$LOCK/owner" 2>/dev/null); nothing run"; exit 2; fi
echo "$OWNER" > "$LOCK/owner"
$PY "$SUP" register --owner="$OWNER" > "$OUTFILE" 2>&1; rc=$?
if [ $rc -ne 0 ]; then [ "$(cat "$LOCK/owner" 2>/dev/null)" = "$OWNER" ] && rm -rf "$LOCK"; echo "register failed ($rc); own lock released"; exit 3; fi
tail -n 1 "$OUTFILE"
