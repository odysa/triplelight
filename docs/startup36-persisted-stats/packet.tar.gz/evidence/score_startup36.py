"""Scored embedded startup comparison, task #34 step 2: persisted planner statistics (PR #36, 40af216a).
Three conditions per cell: A-scan (main before #36, always scans), B-reuse (B with the base's prepared statistics file),
B-scan (B without it: scans, then writes the file). Fresh process per observation; derived from the reviewed
startup34 supervisor (same container, cgroup, cache-drop, clone, inventory, cleanup and stop rules).

  score_startup36.py prepare --owner=<lock owner>       write the B-reuse statistics files once (untimed, receipts kept)
  score_startup36.py register --owner=<lock owner>      write /tmp/s36/scored-v2/registration.json once
  score_startup36.py bind <registration-sha256> <message-uuid>
  score_startup36.py run <registration-sha256>
  score_startup36.py selftest | selftest-cap | selftest-lifecycle
"""
import hashlib, json, math, os, re, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path

sys.dont_write_bytecode = True
S = Path("/tmp/s36")
OUT = S / "scored-v2"
LOCK = Path("/tmp/rdf-bench.lock")
TASK = "(internal discussion)"
ME = "@Kaiming-He"
REPO = Path("<agent-workspace>/rdfdb")
BENCH = REPO / "bench"
IMG = "debian@sha256:a72b4433de1cf7d6bae0c4cee74d0547f58601a643b3375f070c51600d63b6b2"
BUILD_IMG = "rust@sha256:0b0ea86881537b3f645aace7e8e39556289f8787db057317c8d4978548213b9e"
COMMITS = {"A": "cc93aa0376c82ed6f7a7719835b73927b3162654", "B": "40af216a16dc3338ace1064614172510f71706dc"}
WORKTREES = {"A": Path("/tmp/s36-A"), "B": Path("/tmp/s36-B")}
RUSTFLAGS = {"A": "", "B": "--cfg tl_origin"}  # B-only diagnostic read of stats_origin(), after all timed boundaries
CONDITIONS = {"A-scan": "A", "B-reuse": "B", "B-scan": "B"}
STORES = {"lubm1000": BENCH / "tools/rdfdb-diskvm-lubm1000", "bsbm100": BENCH / "tools/rdfdb-diskvm-bsbm100"}
# (cell id, store, query file, round-13 reference key). References: round 13 same-VM results, whose bags matched
# QLever and Virtuoso (bench/results/r13-*/rdfdb-disk-vm.json, run.py canonical bag hash).
QUERIES = [("lubm1000-q2", "lubm1000", BENCH / "lubm/q2.rq", "q2"), ("lubm1000-q9", "lubm1000", BENCH / "lubm/q9.rq", "q9"),
           ("bsbm100-q010", "bsbm100", BENCH / "bsbm100q/q010.rq", "q010")]
# Required ORDER BY keys (q010: ORDER BY ?productLabel LIMIT 5). Rows must be non-decreasing by the key; ties may
# appear in any order. LUBM Q2/Q9 have no ORDER BY and are gated on the result bag only.
ORDER_KEYS = {"bsbm100-q010": "productLabel"}
MODES = ["after-stats"]
ROTATION = ["A-scan", "B-reuse", "B-scan"]
REPS = 5  # per condition and cell; rep i of cell k runs ROTATION rotated by (i + k) % 3 (positions cannot balance exactly)
STATS_TIMEOUT = 900   # inside the probe: after-stats exits 3 if statistics are not ready by then (phase fails)
CAP = 1200            # outer wall cap per container (phase fails if hit)
CPUS, MEM = 4, 12 << 30
SIGNALS = (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)
WRAP = ('grep MemTotal /proc/meminfo > /out/meminfo.start; cat /sys/fs/cgroup/memory.max > /out/memory.max; '
        '/bin/probe "$@" > /out/probe.json 2> /out/probe.stderr; rc=$?; '
        'cat /sys/fs/cgroup/memory.peak > /out/memory.peak.after-close; cat /sys/fs/cgroup/memory.current > /out/memory.current.after-close; '
        'cat /sys/fs/cgroup/memory.stat > /out/memory.stat.after-close; cat /sys/fs/cgroup/memory.events > /out/memory.events.after-close; exit $rc')
ALLOWED_OUT = {"meminfo.start", "memory.max", "probe.json", "probe.stderr", "result.json", "memory.peak.after-close",
               "memory.current.after-close", "memory.stat.after-close", "memory.events.after-close"}
ALLOWED_NEW_DB = {"LOCK", "wal.log"}  # files an embedded open may create next to CURRENT and base-0/
SIDECAR = "stats-0.v1"
DESIGN = {
    "question": "Does PR #36 (persisted planner statistics) shorten the time from an embedded disk open until statistics are ready, "
                "and does the scan path (no file yet) regress?",
    "conditions": {"A-scan": "main before #36 on a fresh clone (always scans)",
                   "B-reuse": "#36 on a clone holding the prepared stats-0.v1 (loaded synchronously at open)",
                   "B-scan": "#36 on a fresh clone without the file (scans, then persists before publishing)"},
    "primary": "stats_ready_ms: open start to the first observed stats_ready() (includes polling and scheduler delay; nominal poll interval 1 ms). For B-scan it includes persisting the file before publication; scan_ms and persist_ms "
               "from stats_origin are explanatory components of that interval, not additional time",
    "secondary": ["open_ms", "first_query_ms (after stats are ready)", "whole-process container cgroup memory.peak after close",
                  "memory.current after close (residual charge), memory.stat (anon, file, pgscan, pgsteal), memory.events",
                  "B-reuse: load_ms and bytes from stats_origin; B-scan: scan_ms, persist_ms, written file size and hash"],
    "diagnostic_read": "B only (RUSTFLAGS=--cfg tl_origin): stats_origin() is read after the query and after stats_ready_before_close, "
                       "i.e. after every timed boundary; A prints origin=unavailable",
    "comparisons": "B-reuse vs A-scan and B-scan vs A-scan, reported separately; descriptive only: a difference is called only if "
                   "the B condition's median lies outside the range of the 5 A-scan observations of that cell, else 'no measurable "
                   "change'; no formal confidence claim. Compaction-time scanning is not measured",
    "preparation": "`prepare` runs binary B once per store on a fresh clone (untimed, after-stats), keeps its stats-0.v1 and records "
                   "hash, size, store tree and the run's receipts; preparation cost is reported separately and never in scored timings",
    "schedule": "45 phases; per cell 5 repetitions; repetition i of cell k runs [A-scan, B-reuse, B-scan] rotated by (i + k) % 3. "
                "Five repetitions cannot balance three positions exactly; every observation and its actual position are kept",
    "cache_control": "clone, sidecar copy and the pre-run inventory happen before the VM page-cache drop; nothing reads the clone "
                     "between the drop and the probe start; the macOS host cache behind virtiofs is not controlled",
    "gates": "exit 0; probe fields typed/finite; stats ready within the timeout; result bag equals round 13; q010 ORDER BY; base tree "
             "and CURRENT unchanged; A-scan: no stats file before or after, origin unavailable; B-reuse: file byte-identical to the "
             "prepared one before and after, origin Persisted; B-scan: no file before, file after, origin Scanned with persist_ms; "
             "only LOCK, wal.log (and stats-0.v1 for B-scan) may appear; no OOM; exact container inspection; one MemTotal",
    "stop_rule": "first failing gate, error, timeout, cap, OOM, lock mismatch, identity drift or failed cleanup stops the attempt; "
                 "no retries, no discarded observations",
}


class Abort(Exception):
    pass


def on_signal(signum, _frame): raise Abort(f"signal {signum}")


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def sha_big(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 24), b""): h.update(chunk)
    return h.hexdigest()


def tree(p):
    h = hashlib.sha256()
    for f in sorted(x for x in Path(p).rglob("*") if x.is_file()):
        h.update(str(f.relative_to(p)).encode() + b"\0" + sha_big(f).encode() + b"\n")
    return h.hexdigest()


def atomic(path, value):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(value, indent=1))
    os.replace(tmp, path)


def write_once(path, value):
    with open(path, "x") as f: f.write(json.dumps(value, indent=1))


def lock_owner():
    try: return (LOCK / "owner").read_text()
    except OSError: return None


def require_lock(owner):
    if lock_owner() != owner + "\n": raise Abort(f"lock owner is {lock_owner()!r}, registered {owner!r}")


def git(wt, *a): return subprocess.run(["git", "-C", str(wt), *a], capture_output=True, text=True, check=True).stdout


def source_identity(b):
    """Commit, and the only local change: the identical untracked probe file (same bytes in A and B)."""
    wt = WORKTREES[b]
    head = git(wt, "rev-parse", "HEAD").strip()
    status = git(wt, "status", "--porcelain", "--untracked-files=all").splitlines()
    return {"head": head, "status": status, "probe_sha256": sha(wt / "examples/startup_probe.rs")}


PREPARED = S / "prepared"


def prepared_identity():
    """The B-reuse statistics file per store, written once by `prepare` with binary B: hash, size, and the base it
    was bound to (store tree digest and generation 0)."""
    out = {}
    for d in STORES:
        f = PREPARED / d / SIDECAR
        receipt = json.loads((PREPARED / d / "receipt.json").read_text())
        if receipt["sha256"] != sha(f) or receipt["bytes"] != f.stat().st_size: raise SystemExit(f"prepared sidecar changed: {d}")
        # Content binding: the file's own header must name generation 0 and the exact MANIFEST bytes of the store
        # that every B-reuse clone copies (TLSIDE01 | generation | sha256(MANIFEST) | len | sha256(payload) | payload).
        head = f.read_bytes()[:88]
        manifest = hashlib.sha256((STORES[d] / "MANIFEST").read_bytes()).digest()
        if head[:8] != b"TLSIDE01" or int.from_bytes(head[8:16], "little") != 0 or head[16:48] != manifest:
            raise SystemExit(f"prepared sidecar for {d} is not bound to this store's base")
        out[d] = {"sha256": receipt["sha256"], "bytes": receipt["bytes"], "store_tree": receipt["store_tree"], "generation": 0}
    return out


def identities():
    ids = {
        "supervisor_sha256": sha(Path(__file__)),
        "probe_source_sha256": sha(S / "probe.rs"),
        "rustflags": RUSTFLAGS,
        "build_script_sha256": sha(S / "build.sh"),
        "build_image": BUILD_IMG,
        "sources": {b: source_identity(b) for b in COMMITS},
        "binaries": {b: sha(S / f"bin-{b}/startup_probe") for b in COMMITS},
        "queries": {c: sha(q) for c, _, q, _ in QUERIES},
        "references": {d: sha(BENCH / f"results/r13-{d}/rdfdb-disk-vm.json") for d in STORES},
        "stores": {d: tree(p) for d, p in STORES.items()},
        "qualification_sha256": sha(S / "QUAL.SHA256"),
        "qualification_files": qual_files(S / "QUAL.SHA256"),
        "prepared_sidecars": prepared_identity(),
        "freeze_sha256": sha(S / "FREEZE.SHA256"),
        "freeze_files": qual_files(S / "FREEZE.SHA256"),
    }
    for d, rec in ids["prepared_sidecars"].items():
        if rec["store_tree"] != ids["stores"][d]: raise SystemExit(f"prepared sidecar for {d} describes another store tree")
    for b, src in ids["sources"].items():
        if src["head"] != COMMITS[b] or src["status"] != ["?? examples/startup_probe.rs"] or src["probe_sha256"] != ids["probe_source_sha256"]:
            raise SystemExit(f"source {b} is not commit + the shared probe only: {src}")
    return ids


def qual_files(manifest):
    """Every entry of the qualification manifest must still hash to its listed digest."""
    files = {}
    for line in Path(manifest).read_text().splitlines():
        digest, rel = line.split(None, 1)
        if sha(manifest.parent / rel) != digest: raise SystemExit(f"qualification file changed: {rel}")
        files[rel] = digest
    if not files: raise SystemExit("empty qualification manifest")
    return files


def reference(d, key):
    r = json.loads((BENCH / f"results/r13-{d}/rdfdb-disk-vm.json").read_text())[key]["rdfdb-disk-vm"]
    return {"rows": r["rows"], "bag_sha1": r["hash"]}


def pre_reg(with_prepared):
    """The registration fields run_phase needs, for the untimed prepare/qualify steps."""
    ids = {"stores": {d: tree(p) for d, p in STORES.items()}}
    if with_prepared: ids["prepared_sidecars"] = prepared_identity()
    return {"references": {cell: reference(d, key) for cell, d, _, key in QUERIES}, "identities": ids}


def prepare(owner):
    """Untimed: binary B scans each store once on a fresh clone and writes stats-0.v1; that file becomes the
    B-reuse input. Its run receipts (including scan/persist time) are kept and reported as preparation cost."""
    require_lock(owner)
    PREPARED.mkdir(exist_ok=False)
    reg = pre_reg(False)
    for d in STORES:
        (PREPARED / d).mkdir()
        cell = next(c for c, store, _, _ in QUERIES if store == d)
        ph = {"id": f"prepare-{d}", "cell": cell, "store": d, "mode": "after-stats", "condition": "B-scan", "binary": "B",
              "keep_sidecar_to": str(PREPARED / d)}
        r = run_phase(ph, reg, PREPARED / d, owner)
        if r["status"] != "pass": raise SystemExit(f"prepare {d}: {r}")
        f = PREPARED / d / SIDECAR
        write_once(PREPARED / d / "receipt.json", {"sha256": sha(f), "bytes": f.stat().st_size, "store_tree": reg["identities"]["stores"][d],
                                                   "generation": 0, "probe": r.get("probe"), "phase_receipt": f"prepare-{d}/receipt.json"})
        print(d, sha(f), f.stat().st_size)


def qualify(owner):
    """Untimed: every condition once per cell (the schedule's first repetition), gated exactly like a scored phase."""
    require_lock(owner)
    q = S / "qual"; q.mkdir(exist_ok=False)
    reg = pre_reg(True)
    results = {}
    for ph in [ph for ph in schedule() if ph["rep"] == 1]:
        r = run_phase(ph, reg, q, owner); results[ph["id"]] = r
        print(ph["id"], r["status"], r.get("problems"))
        if r["status"] != "pass": break
    atomic(q / "QUAL.json", results)
    rels = ["qual/QUAL.json", "score_startup36.py", "probe.rs", "build.sh", "bin-A/startup_probe", "bin-B/startup_probe"]
    (S / "QUAL.SHA256").write_text("".join(f"{sha(S / r)}  {r}\n" for r in rels))


def schedule():
    """45 phases: per cell (in QUERIES order) 5 repetitions; repetition i of cell k runs ROTATION rotated by (i + k) % 3."""
    phases, n = [], 0
    for k, (cell, d, _, key) in enumerate(QUERIES):
        for i in range(REPS):
            r = (i + k) % len(ROTATION)
            for pos, cond in enumerate(ROTATION[r:] + ROTATION[:r]):
                n += 1
                phases.append({"id": f"{n:02d}-{cell}-{cond}-r{i + 1}", "cell": cell, "store": d, "mode": "after-stats",
                               "condition": cond, "binary": CONDITIONS[cond], "rep": i + 1, "position": pos + 1})
    return phases


def register(owner):
    require_lock(owner)
    if OUT.exists(): raise SystemExit(f"{OUT} exists; registration is prospective and never overwritten")
    OUT.mkdir(parents=True)
    phases = schedule()
    reg = {"schema": "startup36-scored-registration-v1", "attempt_label": "startup36-scored-v2", "lock_owner": owner,
           "commits": COMMITS, "image": IMG, "design": DESIGN, "identities": identities(),
           "references": {cell: reference(d, key) for cell, d, _, key in QUERIES},
           "container": {"cpus": CPUS, "memory": MEM, "memory_swap": MEM, "network": "none", "cgroupns": "private",
                         "read_only_root": True, "env": ["RAYON_NUM_THREADS=4"], "platform": "linux/arm64"},
           "stats_timeout_s": STATS_TIMEOUT, "cap_s": CAP, "phases": phases, "registered_unix": time.time()}
    write_once(OUT / "registration.json", reg)
    print(sha(OUT / "registration.json"))


def bind(expected_sha, message_id):
    if sha(OUT / "registration.json") != expected_sha: raise SystemExit("registration changed since review")
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", message_id):
        raise SystemExit("need the full message UUID returned by raft task reply")
    r = subprocess.run(["raft", "task", "read", TASK, "--around", message_id, "--limit", "1"], capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit(f"raft task read failed: {r.stderr.strip()}")
    head = next((l for l in r.stdout.splitlines() if f" msg={message_id} " in l), None)
    # The author handle is followed by a space (with profile) or a colon (without), e.g. "] @Kaiming-He: ...".
    if not head or not (f"] {ME} " in head or f"] {ME}:" in head) or expected_sha not in r.stdout:
        raise SystemExit("message not found, not mine, or does not quote the registration digest")
    (OUT / "raft_message.txt").write_text(r.stdout)
    write_once(OUT / "raft_receipt.json", {"registration_sha256": expected_sha, "task": TASK, "message_id": message_id,
                                           "header": head, "read_sha256": sha(OUT / "raft_message.txt"), "bound_unix": time.time()})
    print("bound", message_id)


def docker(*args, check=True, timeout=120):
    """Every docker call is bounded; a timeout raises (the phase then fails through the cleanup path)."""
    try: r = subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired: raise RuntimeError(f"docker {args[0]} timed out after {timeout}s")
    if check and r.returncode != 0: raise RuntimeError(f"docker {args[0]}: {r.stderr.strip()}")
    return r


def canon(res):
    """run.py canon(): (rows, bag sha1, returned-order sha1)."""
    vs = res["head"]["vars"]
    def val(b):
        if b is None: return "-"
        v = b["value"] if b["type"] != "bnode" else "_"
        t = "literal" if b["type"] == "typed-literal" else b["type"]
        dt = b.get("datatype", "")
        if dt == "http://www.w3.org/2001/XMLSchema#string": dt = ""
        return f'{t}|{v}|{dt}|{b.get("xml:lang","").lower()}'
    seq = ["\t".join(val(row.get(v)) for v in vs) for row in res["results"]["bindings"]]
    return len(seq), hashlib.sha1("\n".join(sorted(seq)).encode()).hexdigest(), hashlib.sha1("\n".join(seq).encode()).hexdigest()


def inspect_ok(info, mounts, pdir):
    hc, cfg = info["HostConfig"], info["Config"]
    got = {m["Destination"]: {"source": m["Source"], "rw": m["RW"]} for m in info["Mounts"]}
    want = {dst: {"source": src, "rw": rw} for src, dst, rw in mounts}
    img = json.loads(docker("image", "inspect", IMG).stdout)[0]
    checks = {
        "image_digest": cfg["Image"] == IMG and info["Image"] == img["Id"],
        "platform": info["Platform"] == "linux" and img["Os"] == "linux" and img["Architecture"] == "arm64",
        "cpus": hc["NanoCpus"] == CPUS * 1_000_000_000,
        "memory": hc["Memory"] == MEM and hc["MemorySwap"] == MEM,
        "network": hc["NetworkMode"] == "none",
        "cgroupns": hc["CgroupnsMode"] == "private",
        "read_only_root": hc["ReadonlyRootfs"] is True and not hc.get("Tmpfs"),
        "env": "RAYON_NUM_THREADS=4" in cfg["Env"],
        "mounts": got == want,
    }
    atomic(pdir / "inspect.json", {"checks": checks, "image_id": info["Image"], "mounts": got, "env": cfg["Env"], "cmd": cfg["Cmd"],
                                   "HostConfig": {k: hc.get(k) for k in ["NanoCpus", "Memory", "MemorySwap", "NetworkMode", "CgroupnsMode", "ReadonlyRootfs", "Tmpfs"]}})
    return all(checks.values())


def memory_evidence(out):
    try:
        stat = dict(l.split() for l in (out / "memory.stat.after-close").read_text().splitlines())
        events = dict(l.split() for l in (out / "memory.events.after-close").read_text().splitlines())
        return {"MemTotal_kB": int((out / "meminfo.start").read_text().split()[1]),
                "memory_max": (out / "memory.max").read_text().strip(),
                "memory_peak_bytes": int((out / "memory.peak.after-close").read_text()),
                "memory_current_after_close_bytes": int((out / "memory.current.after-close").read_text()),
                "memory_stat_after_close": {k: int(v) for k, v in stat.items()},
                "memory_events_after_close": {k: int(v) for k, v in events.items()},
                "scope": "container cgroup over the whole process (open, statistics scan, query, close), sampled after the probe exited"}
    except (OSError, ValueError, IndexError):
        return None


def gate(ph, out, ref, stderr):
    problems = []
    p = json.loads((out / "probe.json").read_text())
    num = lambda v: type(v) in (int, float) and math.isfinite(v) and v >= 0
    if p.get("mode") != ph["mode"] or not all(num(p.get(k)) for k in ("open_ms", "first_query_ms")) or type(p.get("result_bytes")) is not int:
        problems.append("probe-fields")
    if not all(type(p.get(k)) is bool for k in ("stats_ready_after_query", "stats_ready_before_close")): problems.append("stats-flags")
    if ph["mode"] == "after-stats" and not (num(p.get("stats_ready_ms")) and p.get("stats_ready_after_query") is True and p.get("stats_ready_before_close") is True):
        problems.append("stats-not-ready")
    # The registered readiness deadline is enforced here: open can block and the probe checks readiness before its
    # own timeout, so the probe alone does not bound the endpoint.
    if ph["mode"] == "after-stats" and num(p.get("stats_ready_ms")) and num(p.get("open_ms")) and not (p["open_ms"] <= p["stats_ready_ms"] <= STATS_TIMEOUT * 1000):
        problems.append("readiness-deadline")
    if ph["mode"] == "immediate" and p.get("stats_ready_ms") is not None: problems.append("immediate-waited")
    raw = (out / "result.json").read_bytes()
    if p.get("result_bytes") != len(raw) or p.get("result_sha256") != hashlib.sha256(raw).hexdigest(): problems.append("result-identity")
    if "disk build strategy" in stderr: problems.append("fresh-import")
    res = json.loads(raw)
    rows, bag, seq = canon(res)
    if (rows, bag) != (ref["rows"], ref["bag_sha1"]): problems.append(f"bag {rows}/{bag}")
    if ph["cell"] in ORDER_KEYS and not order_ok(res, ORDER_KEYS[ph["cell"]]): problems.append("order-by")
    return problems, {"probe": p, "rows": rows, "bag_sha1": bag, "order_sha1": seq}


def condition_problems(ph, probe, sidecar, reg):
    """Per-condition checks on structured diagnostics: which statistics path ran (typed, finite, nonnegative values;
    persisted byte count equal to the pinned file) and what happened to the statistics file."""
    origin, c = probe.get("origin"), ph["condition"]
    num = lambda v: type(v) in (int, float) and math.isfinite(v) and v >= 0
    if c == "A-scan":
        ok = origin == "unavailable" and sidecar["before"] is None and sidecar["after"] is None
    elif c == "B-reuse":
        pinned = reg["identities"]["prepared_sidecars"][ph["store"]]
        ok = (type(origin) is dict and set(origin) == {"kind", "bytes", "load_ms"} and origin["kind"] == "Persisted"
              and type(origin["bytes"]) is int and origin["bytes"] == pinned["bytes"] and num(origin["load_ms"])
              and sidecar["before"] == pinned["sha256"] and sidecar["after"] == pinned["sha256"])
    else:
        ok = (type(origin) is dict and set(origin) == {"kind", "scan_ms", "persist_ms"} and origin["kind"] == "Scanned"
              and num(origin["scan_ms"]) and num(origin["persist_ms"])
              and sidecar["before"] is None and sidecar["after"] is not None
              and type(sidecar.get("after_bytes")) is int and sidecar["after_bytes"] > 0)
    return [] if ok else [f"condition {c}: origin={origin!r} sidecar={sidecar}"]


def order_ok(res, var):
    """ORDER BY ?var over simple literals: lexical forms non-decreasing in code point order (SPARQL string order);
    any other term kind under the key fails the gate rather than being compared loosely."""
    keys = []
    for row in res["results"]["bindings"]:
        t = row.get(var)
        if t is None or t["type"] not in ("literal", "typed-literal") or t.get("xml:lang") or t.get("datatype", "http://www.w3.org/2001/XMLSchema#string") != "http://www.w3.org/2001/XMLSchema#string":
            return False
        keys.append(t["value"])
    return all(a <= b for a, b in zip(keys, keys[1:]))


def remove_named(name, receipt, key):
    """Bounded force-remove of an owned, exactly named container; records 'removed' only when absence is confirmed."""
    guarded(receipt, f"{key}-rm", lambda: docker("rm", "-f", name, check=False, timeout=60))
    probe = guarded(receipt, f"{key}-probe", lambda: docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}", check=False))
    receipt[key] = ("unverified" if probe is None or probe.returncode != 0 else "removed" if probe.stdout.strip() == "" else "still-present")
    return receipt[key] == "removed"


def drop_caches(hname, receipt):
    """Drops the VM page cache in a uniquely named helper; on every path the helper is force-removed and its
    absence confirmed, otherwise the phase fails."""
    if docker("ps", "-a", "--filter", f"name=^{hname}$", "--format", "{{.Names}}").stdout.strip():
        raise Abort(f"helper {hname} already exists; refusing to touch it")
    try:
        r = docker("run", "--name", hname, "--privileged", "--network", "none", IMG, "sh", "-c",
                   "sync; echo 3 > /proc/sys/vm/drop_caches", check=False, timeout=300)
        if r.returncode != 0: raise Abort(f"drop_caches failed: {r.stderr.strip()}")
    finally:
        if not remove_named(hname, receipt, "dropcache_helper_cleanup"): raise Abort(f"helper {hname} not confirmed removed")


def guarded(receipt, step, fn):
    try: return fn()
    except Exception as exc:
        receipt.setdefault("cleanup_errors", []).append(f"{step}: {exc!r}")
        return None


def cleanup(name, created, proc, clone, receipt):
    old = {s: signal.signal(s, signal.SIG_IGN) for s in SIGNALS}
    try:
        if created:
            guarded(receipt, "stop", lambda: docker("stop", "-t", "10", name, check=False, timeout=60))
            if proc is not None:
                def reap():
                    try: proc.wait(timeout=60)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
                guarded(receipt, "reap", reap)
            guarded(receipt, "rm", lambda: docker("rm", "-f", name, check=False, timeout=60))
            probe = guarded(receipt, "probe", lambda: docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}", check=False))
            receipt["container_cleanup"] = ("unverified" if probe is None or probe.returncode != 0 else
                                            "removed" if probe.stdout.strip() == "" else "still-present")
        else:
            receipt["container_cleanup"] = "not-created"
        if receipt.get("cleanup_errors"): receipt["container_cleanup"] = "unverified"
        if clone is not None:
            if receipt["container_cleanup"] in ("removed", "not-created"):
                guarded(receipt, "rm-clone", lambda: subprocess.run(["rm", "-rf", str(clone)], check=False, timeout=600))
                receipt["private_clone_removed"] = guarded(receipt, "probe-clone", lambda: not clone.exists()) is True
            else:
                # Never delete a directory a possibly live container still mounts; keep it and fail the phase.
                receipt["private_clone_removed"] = False
                receipt["clone_kept"] = str(clone)
    finally:
        for s, h in old.items(): signal.signal(s, h)


def run_phase(ph, reg, attempt, owner):
    pid = ph["id"]
    pdir = attempt / pid
    pdir.mkdir()
    name = f"s36-scored-v2-{pid}"
    receipt = {"phase": pid, "container": name}
    created, proc, clone, result = False, None, None, None
    try:
        require_lock(owner)
        if docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}").stdout.strip():
            raise Abort(f"container {name} already exists; refusing to touch it")
        out = pdir / "out"; out.mkdir()
        clone = S / "clones" / pid
        clone.parent.mkdir(exist_ok=True)
        clone.mkdir()
        subprocess.run(["cp", "-c", "-R", str(STORES[ph["store"]]), str(clone / "base-0")], check=True, timeout=600)
        (clone / "CURRENT").write_text("base-0\n")
        if ph["condition"] == "B-reuse":
            subprocess.run(["cp", "-c", str(PREPARED / ph["store"] / SIDECAR), str(clone / SIDECAR)], check=True, timeout=60)
        sidecar_before = sha(clone / SIDECAR) if (clone / SIDECAR).exists() else None
        before = sorted(str(p.relative_to(clone)) for p in clone.rglob("*"))
        drop_caches(f"{name}-dropcache", receipt)
        qf = next(q for c, _, q, _ in QUERIES if c == ph["cell"])
        mounts = [(str(S / f"bin-{ph['binary']}/startup_probe"), "/bin/probe", False), (str(qf), "/q.rq", False),
                  (str(clone), "/db", True), (str(out), "/out", True)]
        cmd = ["create", "--name", name, "--network", "none", "--cpus", str(CPUS), "--memory", "12g", "--memory-swap", "12g",
               "--cgroupns", "private", "--read-only", "-e", "RAYON_NUM_THREADS=4"]
        for src, dst, rw in mounts: cmd += ["-v", f"{src}:{dst}" + ("" if rw else ":ro")]
        cmd += [IMG, "sh", "-c", WRAP, "sh", "/db", "/q.rq", ph["mode"], str(STATS_TIMEOUT), "/out/result.json"]
        # From here the daemon may hold a container with this exact (pre-checked absent) name even if the CLI call
        # fails or times out, so cleanup must treat it as possibly created and confirm absence before touching the clone.
        created = True
        docker(*cmd)
        if not inspect_ok(json.loads(docker("inspect", name).stdout)[0], mounts, pdir):
            raise Abort("container inspection failed (see inspect.json)")
        start = time.time()
        t0 = time.monotonic()
        proc = subprocess.Popen(["docker", "start", "-a", name], stdout=open(pdir / "container.log", "w"), stderr=subprocess.STDOUT)
        capped = False
        while proc.poll() is None:
            require_lock(owner)
            if time.monotonic() - t0 >= CAP:
                # Bounded stop: stop, then kill, then give up on this phase (cleanup force-removes and verifies).
                capped = True
                docker("stop", "-t", "10", name, check=False, timeout=60)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    docker("kill", name, check=False, timeout=60)
                    try: proc.wait(timeout=30)
                    except subprocess.TimeoutExpired: raise Abort("container did not exit after stop and kill")
                break
            time.sleep(1)
        state = json.loads(docker("inspect", name).stdout)[0]["State"]
        receipt.update({"exit_code": state["ExitCode"], "oom_killed": state["OOMKilled"], "capped": capped,
                        "seconds": time.time() - start, "memory": memory_evidence(out)})
        found = sorted(str(p.relative_to(out)) for p in out.rglob("*"))
        new_db = sorted(set(str(p.relative_to(clone)) for p in clone.rglob("*")) - set(before))
        # Private mutations are kept for inspection; the cloned base must still equal the registered store tree.
        (pdir / "db-private").mkdir()
        for f in new_db:
            if (clone / f).is_file(): shutil.copy2(clone / f, pdir / "db-private" / f.replace("/", "__"))
        base_ok = tree(clone / "base-0") == reg["identities"]["stores"][ph["store"]] and (clone / "CURRENT").read_text() == "base-0\n"
        receipt["inventory"] = {"out": found, "new_in_clone": new_db, "base_tree_unchanged": base_ok}
        sidecar_after = sha(clone / SIDECAR) if (clone / SIDECAR).exists() else None
        receipt["sidecar"] = {"before": sidecar_before, "after": sidecar_after,
                              "after_bytes": (clone / SIDECAR).stat().st_size if sidecar_after else None}
        allowed = ALLOWED_NEW_DB | ({SIDECAR} if ph["condition"] == "B-scan" else set())
        unexpected = [f for f in found if f not in ALLOWED_OUT] + [f for f in new_db if f not in allowed] + ([] if base_ok else ["base-0 or CURRENT modified"])
        stderr = (out / "probe.stderr").read_text() if (out / "probe.stderr").exists() else ""
        receipt["probe_stderr"] = stderr[-2000:]
        if unexpected:
            result = {"status": "unexpected-files", "unexpected": unexpected}
        elif capped or state["OOMKilled"] or state["ExitCode"] != 0 or receipt["memory"] is None:
            result = {"status": "incomplete", "exit_code": state["ExitCode"]}
        elif receipt["memory"]["memory_events_after_close"].get("oom_kill", 0) or receipt["memory"]["memory_events_after_close"].get("oom", 0):
            result = {"status": "oom-event"}
        else:
            problems, obs = gate(ph, out, reg["references"][ph["cell"]], stderr)
            problems += condition_problems(ph, obs["probe"], receipt["sidecar"], reg)
            result = {"status": "pass" if not problems else "gate-failed", "problems": problems, **obs,
                      "memory_peak_bytes": receipt["memory"]["memory_peak_bytes"]}
            if ph.get("keep_sidecar_to") and result["status"] == "pass":
                shutil.copy2(clone / SIDECAR, Path(ph["keep_sidecar_to"]) / SIDECAR)
    except Abort as exc:
        result = {"status": "aborted", "error": str(exc)}
    except Exception as exc:
        result = {"status": "supervisor-error", "error": repr(exc)}
    finally:
        cleanup(name, created, proc, clone, receipt)
        if result is None: result = {"status": "aborted", "error": "interrupted"}
        if receipt["container_cleanup"] not in ("removed", "not-created") or receipt.get("private_clone_removed") is False:
            result = {**result, "status": "cleanup-unverified"}
        if receipt.get("memory"): result = {**result, "MemTotal_kB": receipt["memory"]["MemTotal_kB"]}
        receipt["result"] = result
        atomic(pdir / "receipt.json", receipt)
    return result


def run(expected_sha):
    reg_path = OUT / "registration.json"
    if sha(reg_path) != expected_sha: raise SystemExit("registration changed since review")
    receipt = json.loads((OUT / "raft_receipt.json").read_text())
    if receipt["registration_sha256"] != expected_sha: raise SystemExit("Raft receipt binds a different registration")
    reg = json.loads(reg_path.read_text())
    owner = reg["lock_owner"]
    require_lock(owner)
    attempt = OUT / "attempt"
    attempt.mkdir()
    status = {p["id"]: {"status": "not-run"} for p in reg["phases"]}
    atomic(attempt / "status.json", status)
    stopped, memtotal, post = True, None, {}
    for s in SIGNALS: signal.signal(s, on_signal)
    try:
        if identities() != reg["identities"]: raise Abort("identities differ from registration")
        write_once(attempt / "started.json", {"registration_sha256": expected_sha, "raft_message_id": receipt["message_id"], "unix": time.time()})
        stopped = False
        for ph in reg["phases"]:
            status[ph["id"]] = {"status": "running"}; atomic(attempt / "status.json", status)
            r = run_phase(ph, reg, attempt, owner)
            if r["status"] == "pass":
                memtotal = memtotal or r["MemTotal_kB"]
                if r["MemTotal_kB"] != memtotal: r = {**r, "status": "memtotal-mismatch", "cohort_MemTotal_kB": memtotal}
            status[ph["id"]] = r
            atomic(attempt / "status.json", status)
            if r["status"] != "pass": stopped = True; break
    except BaseException as exc:
        stopped = True
        status = {k: ({"status": "aborted", "error": repr(exc)} if v["status"] == "running" else v) for k, v in status.items()}
        post["error"] = repr(exc)
    finally:
        for s in SIGNALS: signal.signal(s, signal.SIG_IGN)
        try: post["identities_unchanged"] = identities() == reg["identities"]
        except BaseException as exc: post.update({"identities_unchanged": "unverified", "postcheck_error": repr(exc)})
        post.update({"stopped_early": stopped, "cohort_MemTotal_kB": memtotal, "unix": time.time()})
        atomic(attempt / "status.json", status)
        write_once(attempt / "postcheck.json", post)
    print(json.dumps({k: v["status"] for k, v in status.items()}, indent=1))
    return 0 if post["identities_unchanged"] is True and not stopped and all(v["status"] == "pass" for v in status.values()) else 1


def selftest_lifecycle():
    """Ambiguous-create controls with real containers (pinned image, no engine): (1) the daemon creates the container
    but the CLI call 'times out' -> cleanup must find and remove it, then delete the clone; (2) removal cannot be
    confirmed -> the clone must be kept; (3) the drop-cache helper is removed and confirmed absent."""
    global docker
    real = docker
    out = {}
    # (1) create succeeds in the daemon, client reports a timeout.
    name = "s36-selftest-create-timeout"; clone = S / "clones" / "selftest-create"; clone.mkdir(parents=True, exist_ok=False)
    def flaky(*a, **k):
        if a and a[0] == "create":
            real(*a, **k); raise RuntimeError("docker create timed out after 120s (simulated)")
        return real(*a, **k)
    docker = flaky
    receipt, created = {}, False
    try:
        try:
            created = True
            docker("create", "--name", name, "--network", "none", "-v", f"{clone}:/db", IMG, "sleep", "1000")
        except RuntimeError: pass
    finally:
        docker = real
        cleanup(name, created, None, clone, receipt)
    out["create-timeout"] = {**receipt, "ok": receipt.get("container_cleanup") == "removed" and receipt.get("private_clone_removed") is True}
    # (2) removal cannot be confirmed: the clone is kept.
    name = "s36-selftest-unconfirmed"; clone = S / "clones" / "selftest-unconfirmed"; clone.mkdir(parents=True, exist_ok=False)
    real("create", "--name", name, "--network", "none", "-v", f"{clone}:/db", IMG, "sleep", "1000")
    def no_rm(*a, **k):
        if a and a[0] == "rm": return subprocess.CompletedProcess(a, 1, "", "simulated rm failure")
        return real(*a, **k)
    docker = no_rm
    receipt = {}
    try: cleanup(name, True, None, clone, receipt)
    finally: docker = real
    kept = clone.exists()
    out["unconfirmed-removal"] = {**receipt, "clone_exists": kept, "ok": receipt.get("container_cleanup") == "still-present" and kept and receipt.get("private_clone_removed") is False}
    real("rm", "-f", name, check=False); subprocess.run(["rm", "-rf", str(clone)], check=False)
    # (3) helper removal confirmed.
    receipt = {}
    drop_caches("s36-selftest-dropcache", receipt)
    out["dropcache-helper"] = {**receipt, "ok": receipt.get("dropcache_helper_cleanup") == "removed"}
    ok = all(v["ok"] for v in out.values())
    print(json.dumps(out, indent=1)); print("SELFTEST-LIFECYCLE", "PASS" if ok else "FAIL")
    if not ok: sys.exit(1)


def selftest_cap():
    """Bounded-stop control with a real container that ignores SIGTERM: the cap must stop it, cleanup must confirm
    removal, and the clone directory must then be removed. Uses the pinned image; no engine, no measurement."""
    global CAP
    CAP = 3
    name = "s36-selftest-cap"
    clone = S / "clones" / "selftest-cap"; clone.mkdir(parents=True, exist_ok=False)
    receipt, created, proc = {}, False, None
    try:
        docker("create", "--name", name, "--network", "none", "-v", f"{clone}:/db", IMG, "sh", "-c", "trap '' TERM; sleep 1000")
        created = True
        proc = subprocess.Popen(["docker", "start", "-a", name], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
        t0 = time.monotonic(); capped = False
        while proc.poll() is None:
            if time.monotonic() - t0 >= CAP:
                capped = True
                docker("stop", "-t", "2", name, check=False, timeout=60)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    docker("kill", name, check=False, timeout=60); proc.wait(timeout=30)
                break
            time.sleep(0.5)
        elapsed = time.monotonic() - t0
    finally:
        cleanup(name, created, proc, clone, receipt)
    ok = capped and elapsed < CAP + 60 and receipt["container_cleanup"] == "removed" and receipt.get("private_clone_removed") is True
    print(json.dumps({"capped": capped, "elapsed_s": round(elapsed, 1), **receipt})); print("SELFTEST-CAP", "PASS" if ok else "FAIL")
    if not ok: sys.exit(1)


def selftest():
    """Negative controls for the gates (no containers): each tampered copy of a passing qualification output must fail."""
    good = next((S / "qual").glob("*-bsbm100-q010-B-scan-r1")) / "out"
    ph = {"cell": "bsbm100-q010", "mode": "after-stats"}
    ref = reference("bsbm100", "q010")
    results = {}
    def case(name, mutate, mode="after-stats"):
        with tempfile.TemporaryDirectory() as t:
            out = Path(t)
            for f in ("probe.json", "result.json"): shutil.copy(good / f, out / f)
            mutate(out)
            results[name] = gate({**ph, "mode": mode}, out, ref, "")[0]
    def edit_probe(fn):
        def m(out):
            p = json.loads((out / "probe.json").read_text()); fn(p); (out / "probe.json").write_text(json.dumps(p))
        return m
    case("pass", lambda out: None)
    case("infinite-time", lambda out: (out / "probe.json").write_text((out / "probe.json").read_text().replace('"first_query_ms":', '"first_query_ms":1e999,"x":')))
    case("missing-flag", edit_probe(lambda p: p.pop("stats_ready_before_close")))
    case("flag-not-bool", edit_probe(lambda p: p.update(stats_ready_after_query=1)))
    case("stats-unfinished", edit_probe(lambda p: p.update(stats_ready_ms=None)))
    case("ready-after-deadline", edit_probe(lambda p: p.update(stats_ready_ms=STATS_TIMEOUT * 1000 + 1)))
    case("ready-before-open", edit_probe(lambda p: p.update(stats_ready_ms=p["open_ms"] - 1)))
    case("immediate-waited", lambda out: None, mode="immediate")
    case("hash-mismatch", edit_probe(lambda p: p.update(result_sha256="0" * 64)))
    case("bytes-mismatch", edit_probe(lambda p: p.update(result_bytes=p["result_bytes"] + 1)))
    def reorder(out):
        r = json.loads((out / "result.json").read_text()); r["results"]["bindings"].reverse(); raw = json.dumps(r).encode()
        (out / "result.json").write_bytes(raw)
        p = json.loads((out / "probe.json").read_text()); p.update(result_bytes=len(raw), result_sha256=hashlib.sha256(raw).hexdigest())
        (out / "probe.json").write_text(json.dumps(p))
    case("order-violated", reorder)
    def drop_row(out):
        r = json.loads((out / "result.json").read_text()); r["results"]["bindings"].pop(); raw = json.dumps(r).encode()
        (out / "result.json").write_bytes(raw)
        p = json.loads((out / "probe.json").read_text()); p.update(result_bytes=len(raw), result_sha256=hashlib.sha256(raw).hexdigest())
        (out / "probe.json").write_text(json.dumps(p))
    case("bag-differs", drop_row)
    # Tree digest detects a modified existing file, not only added/removed names.
    with tempfile.TemporaryDirectory() as t:
        d = Path(t); (d / "spo").write_bytes(b"abc"); before = tree(d); (d / "spo").write_bytes(b"abd")
        results["tree-detects-modification"] = ["detected"] if tree(d) != before else []
    # Qualification manifest entries are verified, not only the manifest file.
    with tempfile.TemporaryDirectory() as t:
        d = Path(t); (d / "x").write_text("1"); (d / "M").write_text(f"{sha(d / 'x')}  x\n"); qual_files(d / "M"); (d / "x").write_text("2")
        try: qual_files(d / "M"); results["qual-entry-tamper"] = []
        except SystemExit: results["qual-entry-tamper"] = ["detected"]
    # Per-condition controls (condition_problems): positive cases must pass, each tampered variant must fail.
    reg = {"identities": {"prepared_sidecars": {"lubm1000": {"sha256": "a" * 64, "bytes": 100}}}}
    A, R, Sc = ({"condition": n, "store": "lubm1000"} for n in ("A-scan", "B-reuse", "B-scan"))
    none = {"before": None, "after": None, "after_bytes": None}
    kept = {"before": "a" * 64, "after": "a" * 64, "after_bytes": 100}
    new = {"before": None, "after": "b" * 64, "after_bytes": 80}
    persisted = {"kind": "Persisted", "bytes": 100, "load_ms": 0.7}
    scanned = {"kind": "Scanned", "scan_ms": 24000.0, "persist_ms": 10.0}
    cond = {
        "A-ok": (A, "unavailable", none, True),
        "A-with-sidecar": (A, "unavailable", kept, False),
        "A-sidecar-appears": (A, "unavailable", new, False),
        "A-origin-present": (A, persisted, none, False),
        "R-ok": (R, persisted, kept, True),
        "R-missing-origin": (R, None, kept, False),
        "R-wrong-origin": (R, scanned, kept, False),
        "R-bytes-mismatch": (R, {**persisted, "bytes": 99}, kept, False),
        "R-bytes-not-int": (R, {**persisted, "bytes": 100.0}, kept, False),
        "R-load-nonfinite": (R, {**persisted, "load_ms": float("inf")}, kept, False),
        "R-load-negative": (R, {**persisted, "load_ms": -1.0}, kept, False),
        "R-sidecar-missing": (R, persisted, {"before": None, "after": None, "after_bytes": None}, False),
        "R-sidecar-modified": (R, persisted, {**kept, "after": "c" * 64}, False),
        "R-extra-field": (R, {**persisted, "x": 1}, kept, False),
        "S-ok": (Sc, scanned, new, True),
        "S-no-new-file": (Sc, scanned, none, False),
        "S-preexisting-file": (Sc, scanned, kept, False),
        "S-persist-null": (Sc, {**scanned, "persist_ms": None}, new, False),
        "S-persist-nonfinite": (Sc, {**scanned, "persist_ms": float("nan")}, new, False),
        "S-wrong-origin": (Sc, persisted, new, False),
        "S-origin-string": (Sc, "unavailable", new, False),
    }
    for name, (ph, origin, side, want) in cond.items():
        got = condition_problems(ph, {"origin": origin}, side, reg) == []
        results["condition:" + name] = [] if got == want else [f"expected {'pass' if want else 'fail'}"]
    cond_ok = all(v == [] for k, v in results.items() if k.startswith("condition:"))
    ok = results["pass"] == [] and cond_ok and all(results[k] for k in results if k != "pass" and not k.startswith("condition:"))
    print(json.dumps(results, indent=1)); print("SELFTEST", "PASS" if ok else "FAIL")
    if not ok: sys.exit(1)


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    if cmd == "register" and len(sys.argv) == 3 and sys.argv[2].startswith("--owner="): register(sys.argv[2][len("--owner="):])
    elif cmd == "bind" and len(sys.argv) == 4: bind(sys.argv[2], sys.argv[3])
    elif cmd == "run" and len(sys.argv) == 3: sys.exit(run(sys.argv[2]))
    elif cmd == "prepare" and len(sys.argv) == 3 and sys.argv[2].startswith("--owner="): prepare(sys.argv[2][len("--owner="):])
    elif cmd == "qualify" and len(sys.argv) == 3 and sys.argv[2].startswith("--owner="): qualify(sys.argv[2][len("--owner="):])
    elif cmd == "schedule": print(json.dumps(schedule(), indent=1))
    elif cmd == "selftest": selftest()
    elif cmd == "selftest-cap": selftest_cap()
    elif cmd == "selftest-lifecycle": selftest_lifecycle()
    else: raise SystemExit("usage: score_startup36.py register --owner=<exact lock owner> | bind <reg-sha> <message-uuid> | run <reg-sha> | selftest")
