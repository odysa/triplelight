//! Embedded startup probe: one process, one open, one query.
//! usage: startup_probe <db-dir> <query.rq> immediate|after-stats <stats-timeout-s> <result-out.json>
//! immediate:   query right after open; never waits for statistics (the query may race the background stats scan).
//! after-stats: poll stats_ready() every 1 ms from the start of open; on timeout exit 3 without querying.
//! Prints one JSON line: open_ms, stats_ready_ms (after-stats only, measured from the start of open),
//! stats_ready_after_query, stats_ready_before_close, first_query_ms, result_bytes, result_sha256 (exact bytes).
//! The SPARQL JSON result is written to <result-out.json> for bag/order gating outside the process.
//! Peak memory is measured outside the process (container cgroup, whole process: open, stats, query, close).
use sha2::{Digest, Sha256};
use std::time::{Duration, Instant};
use triplelight::embedded::Database;

fn main() {
    let a: Vec<String> = std::env::args().collect();
    if a.len() != 6 { eprintln!("usage: startup_probe <db-dir> <query.rq> immediate|after-stats <timeout-s> <out.json>"); std::process::exit(2) }
    let query = std::fs::read_to_string(&a[2]).expect("query file");
    let wait = match a[3].as_str() { "immediate" => false, "after-stats" => true, m => { eprintln!("bad mode {m}"); std::process::exit(2) } };
    let timeout = Duration::from_secs(a[4].parse().expect("timeout"));
    let t0 = Instant::now();
    let db = Database::open(&a[1]).expect("open");
    let open_ms = t0.elapsed().as_secs_f64() * 1e3;
    let mut stats_ms = None;
    if wait {
        loop {
            if db.stats_ready() { stats_ms = Some(t0.elapsed().as_secs_f64() * 1e3); break }
            if t0.elapsed() >= timeout { eprintln!("statistics not ready after {timeout:?}"); std::process::exit(3) }
            std::thread::sleep(Duration::from_millis(1));
        }
    }
    let tq = Instant::now();
    let json = db.query_json(&query).expect("query");
    let first_query_ms = tq.elapsed().as_secs_f64() * 1e3;
    let after_query = db.stats_ready();
    std::fs::write(&a[5], json.as_bytes()).expect("write result");
    let sha = Sha256::digest(json.as_bytes()).iter().map(|b| format!("{b:02x}")).collect::<String>();
    let before_close = db.stats_ready();
    // Diagnostic only, read after every timed boundary above: where the statistics came from (B builds only; the
    // API does not exist before #36). Built with RUSTFLAGS="--cfg tl_origin".
    #[cfg(tl_origin)]
    let origin = match db.stats_origin() {
        Some(triplelight::embedded::StatsOrigin::Persisted { bytes, load_ms }) =>
            format!("{{\"kind\":\"Persisted\",\"bytes\":{bytes},\"load_ms\":{load_ms}}}"),
        Some(triplelight::embedded::StatsOrigin::Scanned { scan_ms, persist_ms }) =>
            format!("{{\"kind\":\"Scanned\",\"scan_ms\":{scan_ms},\"persist_ms\":{}}}", persist_ms.map_or("null".to_string(), |v| v.to_string())),
        None => String::from("null"),
    };
    #[cfg(not(tl_origin))]
    let origin = String::from("\"unavailable\"");
    drop(db);
    println!(
        "{{\"mode\":\"{}\",\"open_ms\":{open_ms:.3},\"stats_ready_ms\":{},\"stats_ready_after_query\":{after_query},\"stats_ready_before_close\":{before_close},\"first_query_ms\":{first_query_ms:.3},\"result_bytes\":{},\"result_sha256\":\"{sha}\",\"origin\":{origin},\"poll_interval_ms\":1}}",
        a[3], stats_ms.map_or("null".into(), |v: f64| format!("{v:.3}")), json.len()
    );
}
