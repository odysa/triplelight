"""Task #34 step-4 pre-work: split the instrumented conversion stage (control IdBatchReader vs ProfiledReader copy).
Derived from the reviewed a34 v2 supervisor (same container, cgroup, cache-drop, clone, inventory, cleanup, lock and
binding rules; strict types).

  score_a35.py qualify --owner=<lock owner>    untimed: per cell, probe `qualify` then one dry `phase` per order
  score_a35.py register                        write /tmp/a35/scored-v1/registration.json once
  score_a35.py bind <registration-sha256> <message-uuid>
  score_a35.py run <registration-sha256>       requires the lock held by the registered owner
"""
import hashlib, json, math, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path

sys.dont_write_bytecode = True
S = Path("/tmp/a35")
LOCK = Path("/tmp/rdf-bench.lock")
REPO = Path("<agent-workspace>/rdfdb")
BENCH = REPO / "bench"
WT = Path("/tmp/a34-wt")
IMG = "debian@sha256:a72b4433de1cf7d6bae0c4cee74d0547f58601a643b3375f070c51600d63b6b2"
STORES = {"lubm1000": BENCH / "tools/rdfdb-diskvm-lubm1000"}
PREPARED = {"lubm1000": Path("/tmp/s36/prepared/lubm1000/stats-0.v1")}
# Frozen per-cell answer values: the passed a34 qualification v3 (PR #45), instrumented-path canonical sums.
A34_QUAL = Path("/tmp/a34/qual/QUAL.json")
A34_QUAL_SHA256 = "043661d23c8484320f1f4754c9152cc403408cbc2e1aac221531c1421ab55bf9"
# (cell, store, query file, locality?)
CELLS = [("lubm1000-q9", "lubm1000", BENCH / "lubm/q9.rq", True),
         ("lubm1000-q14", "lubm1000", BENCH / "lubm/q14.rq", False)]
BATCH_ROWS = 8192
CAP = 1200
CPUS, MEM = 4, 12 << 30
SIGNALS = (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)
WRAP = ('grep MemTotal /proc/meminfo > /out/meminfo.start; cat /sys/fs/cgroup/memory.max > /out/memory.max; '
        '/bin/probe "$@" > /out/probe.json 2> /out/probe.stderr; rc=$?; '
        'cat /sys/fs/cgroup/memory.peak > /out/memory.peak.after-close; cat /sys/fs/cgroup/memory.events > /out/memory.events.after-close; exit $rc')
ALLOWED_OUT = {"meminfo.start", "memory.max", "probe.json", "probe.stderr", "memory.peak.after-close", "memory.events.after-close"}
ALLOWED_NEW_DB = {"LOCK", "wal.log"}
SIDECAR = "stats-0.v1"
OUT = S / "scored-v2"  # v1 (3208a1ee...) registered, never bound or run
OWNER = "Kaiming a35 scored v2"
TASK = "(internal discussion)"
ME = "@Kaiming-He"
REPS = 5
ORDERS = ["control-first", "profiled-first", "control-first", "profiled-first", "control-first"]
STAGES = ["collect_ms", "decode_ms", "scratch_ms", "build_ms", "consume_ms", "release_ms"]
DESIGN = {
    "question": "Within one IdBatchReader conversion pass with the PR #45 consumer work, how is wall time divided among "
                "collect, decode, scratch, build, consume and release? Descriptive; LUBM-1000 Q9 and Q14; one machine, one "
                "session; no optimization claim and no proven bottleneck.",
    "passes": {"control": "the unchanged library triplelight_c::arrow::IdBatchReader over a freshly recomputed query_ids "
                          "result; every batch consumed (PR #45 consumer), then dropped; total_ms = reader construction through "
                          "the explicit drop of the reader (its ID result and snapshot)",
               "profiled": "ProfiledReader, a probe-local copy generated from the frozen library IdBatchReader::batch source by "
                           "inserting clock lines only (batch-source-comparison.diff); collect/decode/scratch/build clocks inside "
                           "batch, consume/release at the call site; non-overlapping; its timings are those of a separate "
                           "instrumented copy, not of the library reader"},
    "id_result": "each pass recomputes query_ids on the same snapshot (separately recomputed); ids_ms is recorded per pass",
    "differences": "profiled minus control totals are observed instrumented-versus-control differences (they include position "
                   "and run-to-run variation), not isolated clock overhead; each profiled observation reports its stage sums and "
                   "a signed, unclamped remainder against its own total; stage medians are never added to explain a median total. "
                   "Both totals include the explicit reader destruction (ID result and snapshot); in the profiled pass it is "
                   "not a stage and falls in the remainder, as do the per-batch dictionary copies dropped after the build clock",
    "locality": "Q9 only; a separate untimed pass per phase: per batch over the sorted distinct stored IDs (unbound and computed "
                "IDs excluded): distinct count, cells, gaps=max(distinct-1,0) bucketed 1|2-15|16-255|256-65535|>=65536, maximal "
                "contiguous runs (zero when distinct=0) bucketed 1|2-15|16-255|>=256; per-batch counts retained; may suggest a "
                "hypothesis, cannot establish a cause",
    "order": "per phase: open, stats wait, untimed warm-up (control), then two passes in the frozen order per repetition r1..r5: "
             "control-first, profiled-first, control-first, profiled-first, control-first; positions retained",
    "reported": "per cell: medians and ranges of each stage, of the stage sum and remainder, of both pass totals and of ids_ms; "
                "a stage is dominant only descriptively (largest median share); no cross-cell pooling",
    "gates": "exit 0; every pass and the warm-up equal the frozen a34 qualification values (rows, cells, batches, checksum; "
             "strict types); totals and ids_ms finite and positive; stage times finite, non-negative, not bool, may be 0; "
             "stage_sum and remainder finite, remainder may be negative; distinct_ids_decoded an exact int equal to the "
             "locality distinct_ids_sum when locality runs; locality histogram totals consistent with its per-batch counts; "
             "base tree, CURRENT and stats file unchanged; only LOCK and wal.log appear; no OOM; exact container inspection; "
             "one MemTotal across the cohort; lock held by the registered owner throughout",
    "stop_rule": "first failing gate, error, timeout, cap, OOM, lock mismatch, identity drift or failed cleanup stops the attempt; "
                 "no retries, no discarded observations",
    "limitations": "macOS host cache behind virtiofs not controlled; probe-only worktree diff disclosed; per-batch clocks perturb "
                   "the profiled copy; equal outputs detect answer divergence only, not changed allocation or lookup strategy",
}


class Abort(Exception):
    pass


def on_signal(signum, _frame): raise Abort(f"signal {signum}")


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def sha_big(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 24), b""): h.update(chunk)
    return h.hexdigest()


def tree(p):
    h = hashlib.sha256()
    for f in sorted(x for x in Path(p).rglob("*") if x.is_file()):
        h.update(str(f.relative_to(p)).encode() + b"\0" + sha_big(f).encode() + b"\n")
    return h.hexdigest()


def atomic(path, value):
    tmp = Path(str(path) + ".tmp"); tmp.write_text(json.dumps(value, indent=1)); os.replace(tmp, path)


def lock_owner():
    try: return (LOCK / "owner").read_text()
    except OSError: return None


def require_lock(owner):
    if lock_owner() != owner + "\n": raise Abort(f"lock owner is {lock_owner()!r}, expected {owner!r}")


def docker(*args, check=True, timeout=120):
    try: r = subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired: raise RuntimeError(f"docker {args[0]} timed out after {timeout}s")
    if check and r.returncode != 0: raise RuntimeError(f"docker {args[0]}: {r.stderr.strip()}")
    return r


def inspect_ok(info, mounts, pdir):
    hc, cfg = info["HostConfig"], info["Config"]
    got = {m["Destination"]: {"source": m["Source"], "rw": m["RW"]} for m in info["Mounts"]}
    want = {dst: {"source": src, "rw": rw} for src, dst, rw in mounts}
    img = json.loads(docker("image", "inspect", IMG).stdout)[0]
    checks = {"image_digest": cfg["Image"] == IMG and info["Image"] == img["Id"],
              "platform": info["Platform"] == "linux" and img["Os"] == "linux" and img["Architecture"] == "arm64",
              "cpus": hc["NanoCpus"] == CPUS * 1_000_000_000, "memory": hc["Memory"] == MEM and hc["MemorySwap"] == MEM,
              "network": hc["NetworkMode"] == "none", "cgroupns": hc["CgroupnsMode"] == "private",
              "read_only_root": hc["ReadonlyRootfs"] is True and not hc.get("Tmpfs"),
              "env": "RAYON_NUM_THREADS=4" in cfg["Env"], "mounts": got == want}
    atomic(pdir / "inspect.json", {"checks": checks, "image_id": info["Image"], "mounts": got, "env": cfg["Env"], "cmd": cfg["Cmd"]})
    return all(checks.values())


def guarded(receipt, step, fn):
    try: return fn()
    except Exception as exc:
        receipt.setdefault("cleanup_errors", []).append(f"{step}: {exc!r}"); return None


def remove_named(name, receipt, key):
    guarded(receipt, f"{key}-rm", lambda: docker("rm", "-f", name, check=False, timeout=60))
    probe = guarded(receipt, f"{key}-probe", lambda: docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}", check=False))
    receipt[key] = ("unverified" if probe is None or probe.returncode != 0 else "removed" if probe.stdout.strip() == "" else "still-present")
    return receipt[key] == "removed"


def drop_caches(hname, receipt):
    if docker("ps", "-a", "--filter", f"name=^{hname}$", "--format", "{{.Names}}").stdout.strip():
        raise Abort(f"helper {hname} already exists; refusing to touch it")
    try:
        r = docker("run", "--name", hname, "--privileged", "--network", "none", IMG, "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches", check=False, timeout=300)
        if r.returncode != 0: raise Abort(f"drop_caches failed: {r.stderr.strip()}")
    finally:
        if not remove_named(hname, receipt, "dropcache_helper_cleanup"): raise Abort(f"helper {hname} not confirmed removed")


def cleanup(name, created, proc, clone, receipt):
    old = {s: signal.signal(s, signal.SIG_IGN) for s in SIGNALS}
    try:
        if created:
            guarded(receipt, "stop", lambda: docker("stop", "-t", "10", name, check=False, timeout=60))
            if proc is not None:
                def reap():
                    try: proc.wait(timeout=60)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
                guarded(receipt, "reap", reap)
            remove_named(name, receipt, "container_cleanup")
        else:
            receipt["container_cleanup"] = "not-created"
        if receipt.get("cleanup_errors"): receipt["container_cleanup"] = "unverified"
        if clone is not None:
            if receipt["container_cleanup"] in ("removed", "not-created"):
                guarded(receipt, "rm-clone", lambda: subprocess.run(["rm", "-rf", str(clone)], check=False, timeout=600))
                receipt["private_clone_removed"] = guarded(receipt, "probe-clone", lambda: not clone.exists()) is True
            else:
                receipt["private_clone_removed"] = False; receipt["clone_kept"] = str(clone)
    finally:
        for s, h in old.items(): signal.signal(s, h)


def write_once(path, value):
    with open(path, "x") as f: f.write(json.dumps(value, indent=1))


def finite_pos(x): return type(x) in (int, float) and math.isfinite(x) and x > 0  # bool excluded


def exact(got, want):
    """Equality with identical JSON types (True is not 1, 1.0 is not 1)."""
    return type(got) is type(want) and got == want


def run_phase(pid, cell, store, qf, args, outdir, owner, base_tree):
    pdir = outdir / pid; pdir.mkdir()
    name = f"a35-{outdir.name}-{pid}"
    receipt = {"phase": pid, "container": name, "args": args}
    created, proc, clone, result = False, None, None, None
    try:
        require_lock(owner)
        if docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}").stdout.strip():
            raise Abort(f"container {name} already exists; refusing to touch it")
        out = pdir / "out"; out.mkdir()
        clone = S / "clones" / f"{outdir.name}-{pid}"; clone.parent.mkdir(exist_ok=True); clone.mkdir()
        subprocess.run(["cp", "-c", "-R", str(STORES[store]), str(clone / "base-0")], check=True, timeout=600)
        (clone / "CURRENT").write_text("base-0\n")
        subprocess.run(["cp", "-c", str(PREPARED[store]), str(clone / SIDECAR)], check=True, timeout=60)
        sidecar_before = sha(clone / SIDECAR)
        before = sorted(str(p.relative_to(clone)) for p in clone.rglob("*"))
        drop_caches(f"{name}-dropcache", receipt)
        mounts = [(str(S / "bin/arrow_profile"), "/bin/probe", False), (str(qf), "/q.rq", False), (str(clone), "/db", True), (str(out), "/out", True)]
        cmd = ["create", "--name", name, "--network", "none", "--cpus", str(CPUS), "--memory", "12g", "--memory-swap", "12g",
               "--cgroupns", "private", "--read-only", "-e", "RAYON_NUM_THREADS=4"]
        for src, dst, rw in mounts: cmd += ["-v", f"{src}:{dst}" + ("" if rw else ":ro")]
        cmd += [IMG, "sh", "-c", WRAP, "sh", "/db", "/q.rq", *args]
        created = True
        docker(*cmd)
        if not inspect_ok(json.loads(docker("inspect", name).stdout)[0], mounts, pdir): raise Abort("container inspection failed")
        t0 = time.monotonic()
        proc = subprocess.Popen(["docker", "start", "-a", name], stdout=open(pdir / "container.log", "w"), stderr=subprocess.STDOUT)
        capped = False
        while proc.poll() is None:
            require_lock(owner)
            if time.monotonic() - t0 >= CAP:
                capped = True
                docker("stop", "-t", "10", name, check=False, timeout=60)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    docker("kill", name, check=False, timeout=60)
                    try: proc.wait(timeout=30)
                    except subprocess.TimeoutExpired: raise Abort("container did not exit after stop and kill")
                break
            time.sleep(1)
        state = json.loads(docker("inspect", name).stdout)[0]["State"]
        receipt.update({"exit_code": state["ExitCode"], "oom_killed": state["OOMKilled"], "capped": capped, "seconds": time.monotonic() - t0})
        found = sorted(str(p.relative_to(out)) for p in out.rglob("*"))
        new_db = sorted(set(str(p.relative_to(clone)) for p in clone.rglob("*")) - set(before))
        base_ok = tree(clone / "base-0") == base_tree and (clone / "CURRENT").read_text() == "base-0\n"
        side_ok = (clone / SIDECAR).exists() and sha(clone / SIDECAR) == sidecar_before
        receipt["inventory"] = {"out": found, "new_in_clone": new_db, "base_tree_unchanged": base_ok, "sidecar_unchanged": side_ok}
        try: events = dict(l.split() for l in (out / "memory.events.after-close").read_text().splitlines())
        except (OSError, ValueError): events = None
        receipt["memory_events"] = events
        receipt["memory_peak_bytes"] = int((out / "memory.peak.after-close").read_text()) if (out / "memory.peak.after-close").exists() else None
        try: receipt["memtotal_kB"] = int((out / "meminfo.start").read_text().split()[1])
        except (OSError, ValueError, IndexError): receipt["memtotal_kB"] = None
        receipt["probe_stderr"] = (out / "probe.stderr").read_text()[-2000:] if (out / "probe.stderr").exists() else ""
        unexpected = [f for f in found if f not in ALLOWED_OUT] + [f for f in new_db if f not in ALLOWED_NEW_DB] + ([] if base_ok and side_ok else ["base-0, CURRENT or stats file modified"])
        if unexpected: result = {"status": "unexpected-files", "unexpected": unexpected}
        elif capped or state["OOMKilled"] or state["ExitCode"] != 0 or events is None: result = {"status": "incomplete", "exit_code": state["ExitCode"]}
        elif int(events.get("oom_kill", 0)) or int(events.get("oom", 0)): result = {"status": "oom-event"}
        else: result = {"status": "ran", "probe": json.loads((out / "probe.json").read_text())}
    except Abort as exc:
        result = {"status": "aborted", "error": str(exc)}
    except Exception as exc:
        result = {"status": "supervisor-error", "error": repr(exc)}
    finally:
        cleanup(name, created, proc, clone, receipt)
        if result is None: result = {"status": "aborted", "error": "interrupted"}
        if receipt["container_cleanup"] not in ("removed", "not-created") or receipt.get("private_clone_removed") is False:
            result = {**result, "status": "cleanup-unverified"}
        receipt["result"] = result
        atomic(pdir / "receipt.json", receipt)
    return result


def bind(expected_sha, message_id):
    if sha(OUT / "registration.json") != expected_sha: raise SystemExit("registration changed since review")
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", message_id):
        raise SystemExit("need the full message UUID returned by raft task reply")
    r = subprocess.run(["raft", "task", "read", TASK, "--around", message_id, "--limit", "1"], capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit(f"raft task read failed: {r.stderr.strip()}")
    head = next((l for l in r.stdout.splitlines() if f" msg={message_id} " in l), None)
    if not head or not (f"] {ME} " in head or f"] {ME}:" in head) or expected_sha not in r.stdout:
        raise SystemExit("message not found, not mine, or does not quote the registration digest")
    (OUT / "raft_message.txt").write_text(r.stdout)
    write_once(OUT / "raft_receipt.json", {"registration_sha256": expected_sha, "task": TASK, "message_id": message_id,
                                           "header": head, "read_sha256": sha(OUT / "raft_message.txt"), "bound_unix": time.time()})
    print("bound", message_id)


def verify_qualification(expected):
    if sha(S / "QUAL.SHA256") != expected: raise Abort("qualification manifest changed")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise Abort(f"qualification file {f} changed")


def frozen_values():
    q = json.loads(A34_QUAL.read_text())
    return {c: q[c]["probe"]["canonical"]["instr"]["sum"] for c, *_ in CELLS}


def nonneg(x): return type(x) in (int, float) and math.isfinite(x) and x >= 0
def finite(x): return type(x) in (int, float) and math.isfinite(x)


def same_sum(label, got, want, problems):
    for f in ("rows", "cells", "batches", "checksum"):
        if not exact(got.get(f), want[f]): problems.append(f"{label}: {f} {got.get(f)!r} != {want[f]!r}")


def locality_problems(loc, want, problems):
    same_sum("locality", loc.get("sum", {}), want, problems)
    pb = loc.get("per_batch_distinct_cells_gaps_runs")
    if not isinstance(pb, list) or not exact(loc.get("batches"), len(pb)) or len(pb) != want["batches"]:
        problems.append("locality: batch list"); return
    for i, row in enumerate(pb):
        if not (isinstance(row, list) and len(row) == 4 and all(type(x) is int and x >= 0 for x in row)):
            problems.append(f"locality: batch {i} malformed"); return
        d, c, g, r = row
        if g != max(d - 1, 0) or (r == 0) != (d == 0) or r > d: problems.append(f"locality: batch {i} gaps/runs inconsistent")
        width = want["cells"] // want["rows"]
        expect_cells = min(BATCH_ROWS, want["rows"] - i * BATCH_ROWS) * width
        if c != expect_cells or not 0 <= d <= c: problems.append(f"locality: batch {i} cells {c} != {expect_cells} or distinct out of range")
    gb, rb = loc.get("gap_buckets"), loc.get("run_buckets")
    if not (isinstance(gb, list) and len(gb) == 5 and all(type(x) is int and x >= 0 for x in gb)): problems.append("locality: gap buckets"); return
    if not (isinstance(rb, list) and len(rb) == 4 and all(type(x) is int and x >= 0 for x in rb)): problems.append("locality: run buckets"); return
    if sum(gb) != sum(x[2] for x in pb): problems.append("locality: gap bucket total")
    if sum(rb) != sum(x[3] for x in pb) or not exact(loc.get("runs"), sum(rb)): problems.append("locality: run bucket total")
    if not exact(loc.get("distinct_ids_sum"), sum(x[0] for x in pb)): problems.append("locality: distinct sum")
    # Gap-1 pairs per batch are exactly distinct - runs (each maximal run of length L has L - 1 unit gaps).
    if gb[0] != sum(x[0] - x[3] for x in pb): problems.append("locality: gap-1 count != sum(distinct - runs)")
    # Run lengths sum to the distinct IDs; bucket bounds 1 | 2-15 | 16-255 | >=256 must admit that total.
    total_d = sum(x[0] for x in pb)
    lo = rb[0] * 1 + rb[1] * 2 + rb[2] * 16 + rb[3] * 256
    hi = None if rb[3] else rb[0] * 1 + rb[1] * 15 + rb[2] * 255
    if lo > total_d or (hi is not None and hi < total_d): problems.append("locality: run buckets infeasible for the distinct total")
    if not exact(loc.get("cells"), sum(x[1] for x in pb)) or loc["cells"] != want["cells"]: problems.append("locality: cells")


def pass_problems(p, want, problems, label):
    same_sum(label, p.get("sum", {}), want, problems)
    if not (finite(p.get("ids_ms")) and p["ids_ms"] > 0 and finite(p.get("total_ms")) and p["total_ms"] > 0): problems.append(f"{label}: times")
    st = p.get("stages")
    if p.get("pass") == "control":
        if st is not None or "stage_sum_ms" in p or "remainder_ms" in p: problems.append(f"{label}: control has stages")
        return
    if not isinstance(st, dict): problems.append(f"{label}: stages missing"); return
    for k in STAGES:
        if not nonneg(st.get(k)): problems.append(f"{label}: {k} {st.get(k)!r}")
    if type(st.get("distinct_ids_decoded")) is not int or st["distinct_ids_decoded"] < 0: problems.append(f"{label}: distinct_ids_decoded")
    # The probe writes stage_sum_ms and remainder_ms beside `stages`, at the pass level.
    if not (finite(p.get("stage_sum_ms")) and finite(p.get("remainder_ms"))): problems.append(f"{label}: sum/remainder")
    elif all(nonneg(st.get(k)) for k in STAGES) and finite(p.get("total_ms")):
        s = sum(st[k] for k in STAGES)
        if abs(s - p["stage_sum_ms"]) > 1e-3 or abs(p["total_ms"] - s - p["remainder_ms"]) > 2e-3: problems.append(f"{label}: sum/remainder arithmetic")


def phase_gate(ph, p, reg):
    problems = []
    want = reg["frozen_values"][ph["cell"]]
    loc_cell = next(c for c in CELLS if c[0] == ph["cell"])[3]
    if p.get("mode") != "phase" or p.get("order") != ph["order"]: problems.append("probe mode/order mismatch")
    same_sum("warmup", p.get("warmup", {}), want, problems)
    passes = p.get("passes", [])
    want_kinds = ["control", "profiled"] if ph["order"] == "control-first" else ["profiled", "control"]
    if [x.get("pass") for x in passes] != want_kinds or not all(exact(x.get("position"), i + 1) for i, x in enumerate(passes)): problems.append("pass order mismatch")
    for x in passes: pass_problems(x, want, problems, f"pass {x.get('pass')}")
    if not (finite(p.get("stats_ready_ms")) and p["stats_ready_ms"] > 0): problems.append("stats_ready_ms")
    if loc_cell:
        loc = p.get("locality")
        if not isinstance(loc, dict): problems.append("locality missing")
        else:
            locality_problems(loc, want, problems)
            prof = next((x for x in passes if x.get("pass") == "profiled"), None)
            if prof and isinstance(prof.get("stages"), dict) and not exact(prof["stages"].get("distinct_ids_decoded"), loc.get("distinct_ids_sum")):
                problems.append("profiled distinct_ids_decoded != locality distinct_ids_sum")
    elif "locality" in p: problems.append("unexpected locality")
    return problems


def qual_gate(cell, p, want, loc_cell):
    problems = []
    if p.get("mode") != "qualify": problems.append("mode")
    passes = p.get("passes", [])
    if [x.get("pass") for x in passes] != ["control", "profiled"]: problems.append("qualify passes")
    for x in passes: pass_problems(x, want, problems, f"qualify {x.get('pass')}")
    if loc_cell:
        if not isinstance(p.get("locality"), dict): problems.append("locality missing")
        else:
            locality_problems(p["locality"], want, problems)
            if passes and isinstance(passes[-1].get("stages"), dict) and not exact(passes[-1]["stages"].get("distinct_ids_decoded"), p["locality"].get("distinct_ids_sum")):
                problems.append("distinct mismatch")
    return problems


def schedule():
    phases, n = [], 0
    for cell, store, _, _ in CELLS:
        for i in range(REPS):
            n += 1
            phases.append({"id": f"{n:02d}-{cell}-r{i + 1}", "cell": cell, "store": store, "rep": i + 1, "order": ORDERS[i]})
    return phases


def args_for(cell, mode):
    loc = next(c for c in CELLS if c[0] == cell)[3]
    return [*mode, *(["--locality"] if loc else [])]


def extract_batch(path):
    """The exact text of `fn batch(&mut self)` in a Rust source file, by brace matching."""
    src = Path(path).read_text(); i = src.index("    fn batch(&mut self)"); j = src.index("{", i); d = 0
    for k in range(j, len(src)):
        if src[k] == "{": d += 1
        elif src[k] == "}":
            d -= 1
            if d == 0: return src[i:k + 1] + "\n"
    raise ValueError("unbalanced")


def comparison_verified():
    """Regenerates both function extracts from the actual frozen library and probe sources and the unified diff, and
    requires byte equality with the published comparison files."""
    lib, prof = extract_batch(WT / "bindings/c/src/arrow.rs"), extract_batch(WT / "bindings/c/examples/arrow_profile.rs")
    if (S / "lib_batch.rs").read_text() != lib or (S / "profiled_batch.rs").read_text() != prof: return False
    d = subprocess.run(["/usr/bin/diff", "-u", "--label", "lib_batch.rs", "--label", "profiled_batch.rs", str(S / "lib_batch.rs"), str(S / "profiled_batch.rs")],
                       capture_output=True, text=True)
    return d.returncode == 1 and d.stdout == (S / "batch-source-comparison.diff").read_text()


def identities():
    return {"supervisor_sha256": sha(Path(__file__)), "probe_source_sha256": sha(WT / "bindings/c/examples/arrow_profile.rs"),
            "library_arrow_source_sha256": sha(WT / "bindings/c/src/arrow.rs"),
            "batch_source_comparison_sha256": sha(S / "batch-source-comparison.diff"),
            "batch_source_comparison_verified": comparison_verified(),
            "build_script_sha256": sha(S / "build.sh"), "binary_sha256": sha(S / "bin/arrow_profile"),
            "launcher_sha256": sha(S / "launch.sh"), "launch_controls_sha256": sha(S / "launch_controls.sh"),
            "launch_controls_output_sha256": sha(S / "launch_controls.txt"),
            "worktree_head": subprocess.run(["/usr/bin/git", "-C", str(WT), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip(),
            "worktree_diff_sha256": hashlib.sha256(subprocess.run(["/usr/bin/git", "-C", str(WT), "diff", "HEAD"], capture_output=True, check=True).stdout).hexdigest(),
            "queries": {c: sha(q) for c, _, q, _ in CELLS}, "a34_qualification_sha256": sha(A34_QUAL),
            "prepared_sidecars": {s: sha(p) for s, p in PREPARED.items()}}


def gate_controls():
    """Offline negative controls on the frozen dry-run probes; no engine runs."""
    import copy
    q = S / "qual"
    reg = {"frozen_values": frozen_values()}
    out = {"cases": [], "all_pass": True}
    def record(name, ok): out["cases"].append({"case": name, "ok": ok}); out["all_pass"] &= ok
    for cell, _, _, loc_cell in CELLS:
        for order in ("control-first", "profiled-first"):
            base = json.loads((q / f"{cell}-dry-{order}" / "out/probe.json").read_text())
            ph = {"cell": cell, "order": order}
            record(f"{cell}/{order}: unmutated passes", phase_gate(ph, base, reg) == [])
            pi = [x["pass"] for x in base["passes"]].index("profiled"); ci = 1 - pi
            muts = {
                "stage = true": lambda p: p["passes"][pi]["stages"].__setitem__("decode_ms", True),
                "stage negative": lambda p: p["passes"][pi]["stages"].__setitem__("build_ms", -0.5),
                "stage inf": lambda p: p["passes"][pi]["stages"].__setitem__("collect_ms", float("inf")),
                "stage missing": lambda p: p["passes"][pi]["stages"].pop("release_ms"),
                "remainder inconsistent": lambda p: p["passes"][pi].__setitem__("remainder_ms", p["passes"][pi]["remainder_ms"] + 5),
                "remainder missing": lambda p: p["passes"][pi].pop("remainder_ms"),
                "stage_sum = true": lambda p: p["passes"][pi].__setitem__("stage_sum_ms", True),
                "distinct as float": lambda p: p["passes"][pi]["stages"].__setitem__("distinct_ids_decoded", float(p["passes"][pi]["stages"]["distinct_ids_decoded"])),
                "control has stages": lambda p: p["passes"][ci].__setitem__("stages", p["passes"][pi]["stages"]),
                "total = true": lambda p: p["passes"][ci].__setitem__("total_ms", True),
                "ids_ms = 0": lambda p: p["passes"][pi].__setitem__("ids_ms", 0),
                "checksum changed": lambda p: p["passes"][pi]["sum"].__setitem__("checksum", "0" * 16),
                "batches as float": lambda p: p["passes"][ci]["sum"].__setitem__("batches", float(p["passes"][ci]["sum"]["batches"])),
                "warmup rows changed": lambda p: p["warmup"].__setitem__("rows", p["warmup"]["rows"] + 1),
                "order swapped": lambda p: p["passes"].reverse(),
                "position = 1.0": lambda p: p["passes"][0].__setitem__("position", 1.0),
                "mode changed": lambda p: p.__setitem__("mode", "qualify"),
            }
            if loc_cell:
                muts.update({
                    "locality missing": lambda p: p.pop("locality"),
                    "locality gap total": lambda p: p["locality"]["gap_buckets"].__setitem__(0, p["locality"]["gap_buckets"][0] + 1),
                    "locality batch gaps": lambda p: p["locality"]["per_batch_distinct_cells_gaps_runs"][0].__setitem__(2, p["locality"]["per_batch_distinct_cells_gaps_runs"][0][2] + 1),
                    "locality distinct != profiled": lambda p: p["passes"][pi]["stages"].__setitem__("distinct_ids_decoded", p["passes"][pi]["stages"]["distinct_ids_decoded"] + 1),
                    "locality checksum": lambda p: p["locality"]["sum"].__setitem__("checksum", "0" * 16),
                    "gap-1 moved to 2-15": lambda p: (p["locality"]["gap_buckets"].__setitem__(0, p["locality"]["gap_buckets"][0] - 1),
                                                       p["locality"]["gap_buckets"].__setitem__(1, p["locality"]["gap_buckets"][1] + 1)),
                    "all runs in 2-15": lambda p: p["locality"].__setitem__("run_buckets", [0, sum(p["locality"]["run_buckets"]), 0, 0]),
                    "cell shifted between batches": lambda p: (p["locality"]["per_batch_distinct_cells_gaps_runs"][0].__setitem__(1, p["locality"]["per_batch_distinct_cells_gaps_runs"][0][1] - 1),
                                                                p["locality"]["per_batch_distinct_cells_gaps_runs"][1].__setitem__(1, p["locality"]["per_batch_distinct_cells_gaps_runs"][1][1] + 1)),
                    "distinct > cells": lambda p: (lambda b: (b.__setitem__(0, b[1] + 1)))(p["locality"]["per_batch_distinct_cells_gaps_runs"][0]),
                })
            else:
                muts["unexpected locality"] = lambda p: p.__setitem__("locality", {})
            for name, m in muts.items():
                p = copy.deepcopy(base); m(p)
                record(f"{cell}/{order}: {name} fails", phase_gate(ph, p, reg) != [])
    return out


def qualify(owner):
    """Untimed. Per cell: probe `qualify`, then one dry `phase` per order gated exactly like a scored phase. Dry timings are
    discarded and never reported."""
    require_lock(owner)
    if sha(A34_QUAL) != A34_QUAL_SHA256: raise SystemExit("a34 qualification changed")
    q = S / "qual"; q.mkdir(exist_ok=False)
    ids = identities(); base_trees = {s: tree(p) for s, p in STORES.items()}; ids["stores"] = base_trees
    if ids["batch_source_comparison_verified"] is not True: raise SystemExit("source comparison does not match the frozen sources")
    atomic(q / "identities.json", ids)
    want = frozen_values(); reg = {"frozen_values": want}
    results, ok = {}, True
    for cell, store, qf, loc_cell in CELLS:
        r = run_phase(cell, cell, store, qf, args_for(cell, ["qualify"]), q, owner, base_trees[store])
        if r["status"] == "ran":
            problems = qual_gate(cell, r["probe"], want[cell], loc_cell)
            r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
        results[cell] = r; print(cell, r["status"], r.get("problems") or r.get("error") or "", flush=True)
        if r["status"] != "pass": ok = False; break
        for order in ("control-first", "profiled-first"):
            pid = f"{cell}-dry-{order}"
            d = run_phase(pid, cell, store, qf, args_for(cell, ["phase", order]), q, owner, base_trees[store])
            if d["status"] == "ran":
                problems = phase_gate({"cell": cell, "order": order}, d["probe"], reg)
                d = {"status": "pass" if not problems else "gate-failed", "problems": problems, "timings": "discarded"}
            else: d = {k: v for k, v in d.items() if k != "probe"}
            results[pid] = d; print(pid, d["status"], d.get("problems") or d.get("error") or "", flush=True)
            if d["status"] != "pass": ok = False; break
        if not ok: break
    atomic(q / "QUAL.json", results)
    after = identities(); after["stores"] = {s: tree(p) for s, p in STORES.items()}
    if after != ids: print("IDENTITY DRIFT during qualification", flush=True); raise SystemExit(1)
    if not ok or len(results) != 3 * len(CELLS): raise SystemExit(1)
    controls = gate_controls(); atomic(q / "gate_controls.json", controls)
    if not controls["all_pass"]: print("GATE CONTROLS FAILED", flush=True); raise SystemExit(1)
    rels = sorted(str(f.relative_to(S)) for f in q.rglob("*") if f.is_file()) + [
        "score_a35.py", "build.sh", "bin/arrow_profile", "probe.rs", "batch-source-comparison.diff", "lib_batch.rs", "profiled_batch.rs", "probe-worktree.raw.diff",
        "launch.sh", "launch_controls.sh", "launch_controls.txt"]
    (S / "QUAL.SHA256").write_text("".join(f"{sha(S / r)}  {r}\n" for r in rels))
    print("frozen", sha(S / "QUAL.SHA256"), f"controls {sum(c['ok'] for c in controls['cases'])}/{len(controls['cases'])}", flush=True)


def register():
    if OUT.exists(): raise SystemExit(f"{OUT} exists; registration is prospective and never overwritten")
    if (S / "launch_controls.txt").read_text().splitlines()[-1] != "LAUNCH-CONTROLS PASS": raise SystemExit("launcher controls did not pass")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise SystemExit(f"qualification file {f} changed")
    OUT.mkdir(parents=True)
    ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
    reg = {"schema": "a35-scored-registration-v2", "attempt_label": "a35-scored-v2", "lock_owner": OWNER, "image": IMG,
           "design": DESIGN, "identities": ids, "qualification_sha256": sha(S / "QUAL.SHA256"), "frozen_values": frozen_values(),
           "batch_rows": BATCH_ROWS, "container": {"cpus": CPUS, "memory": MEM, "memory_swap": MEM, "network": "none", "cgroupns": "private",
           "read_only_root": True, "env": ["RAYON_NUM_THREADS=4"], "platform": "linux/arm64"}, "cap_s": CAP, "phases": schedule(),
           "registered_unix": time.time()}
    write_once(OUT / "registration.json", reg)
    print(sha(OUT / "registration.json"))


def run(expected_sha):
    reg_path = OUT / "registration.json"
    if sha(reg_path) != expected_sha: raise SystemExit("registration changed since review")
    receipt = json.loads((OUT / "raft_receipt.json").read_text())
    if receipt["registration_sha256"] != expected_sha: raise SystemExit("Raft receipt binds a different registration")
    reg = json.loads(reg_path.read_text())
    owner = reg["lock_owner"]; require_lock(owner)
    attempt = OUT / "attempt"; attempt.mkdir()
    status = {p["id"]: {"status": "not-run"} for p in reg["phases"]}; atomic(attempt / "status.json", status)
    stopped, memtotal, post = True, None, {}
    try:
        ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
        if ids != reg["identities"]: raise Abort("identities differ from registration")
        verify_qualification(reg["qualification_sha256"])
        write_once(attempt / "started.json", {"registration_sha256": expected_sha, "raft_message_id": receipt["message_id"], "unix": time.time()})
        stopped = False
        for ph in reg["phases"]:
            status[ph["id"]] = {"status": "running"}; atomic(attempt / "status.json", status)
            qf = next(c for c in CELLS if c[0] == ph["cell"])[2]
            r = run_phase(ph["id"], ph["cell"], ph["store"], qf, args_for(ph["cell"], ["phase", ph["order"]]), attempt, owner, reg["identities"]["stores"][ph["store"]])
            if r["status"] == "ran":
                problems = phase_gate(ph, r["probe"], reg)
                mt = json.loads((attempt / ph["id"] / "receipt.json").read_text()).get("memtotal_kB")
                memtotal = memtotal or mt
                if mt is None or mt != memtotal: problems.append(f"MemTotal {mt} != cohort {memtotal}")
                r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
            status[ph["id"]] = r; atomic(attempt / "status.json", status)
            if r["status"] != "pass": stopped = True; break
    except BaseException as exc:
        stopped = True
        status = {k: ({"status": "aborted", "error": repr(exc)} if v["status"] == "running" else v) for k, v in status.items()}
        post["error"] = repr(exc)
    finally:
        for sg in SIGNALS: signal.signal(sg, signal.SIG_IGN)
        try:
            ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
            post["identities_unchanged"] = ids == reg["identities"]
            try: verify_qualification(reg["qualification_sha256"]); post["qualification_unchanged"] = True
            except Abort as exc: post["qualification_unchanged"] = False; post["qualification_error"] = str(exc)
        except BaseException as exc: post.update({"identities_unchanged": "unverified", "postcheck_error": repr(exc)})
        post.update({"stopped_early": stopped, "cohort_MemTotal_kB": memtotal, "unix": time.time()})
        atomic(attempt / "status.json", status); write_once(attempt / "postcheck.json", post)
    print(json.dumps({k: v["status"] for k, v in status.items()}, indent=1))
    return 0 if post["identities_unchanged"] is True and post.get("qualification_unchanged") is True and not stopped and all(v["status"] == "pass" for v in status.values()) else 1


if __name__ == "__main__":
    for s in SIGNALS: signal.signal(s, on_signal)
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "qualify" and a[1].startswith("--owner="): qualify(a[1][8:])
    elif a == ["register"]: register()
    elif len(a) == 3 and a[0] == "bind": bind(a[1], a[2])
    elif len(a) == 2 and a[0] == "run": sys.exit(run(a[1]))
    elif a == ["schedule"]: print(json.dumps(schedule(), indent=1))
    elif a == ["gate-controls"]: print(json.dumps(gate_controls(), indent=1))
    else: raise SystemExit(__doc__)
