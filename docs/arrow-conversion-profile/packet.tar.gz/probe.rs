//! Task #34 step-4 pre-work probe: split the instrumented conversion stage. Not part of the library.
//!
//! usage: arrow_profile <db-dir> <query.rq> qualify [--locality]
//!        arrow_profile <db-dir> <query.rq> phase control-first|profiled-first [--locality]
//!
//! control:  the unchanged library `triplelight_c::arrow::IdBatchReader`, every batch consumed, then dropped.
//! profiled: `ProfiledReader`, a copy of the library batch logic with clocks (collect, decode, scratch, build) inside
//!           `batch`; `consume` and `release` are timed at the call site. Intervals do not overlap. Each pass
//!           recomputes `query_ids` on the same snapshot ("separately recomputed"); `ids_ms` is recorded per pass.
//! locality: untimed; per batch over the sorted distinct stored IDs (unbound and computed IDs excluded): distinct
//!           count, cells, gap buckets and maximal contiguous run-length buckets.
//! Consumer work and the order-independent checksum are identical to arrow_probe (PR #45). Prints one JSON line.
use std::ffi::c_char;
use std::ptr;
use std::sync::Arc;
use std::time::{Duration, Instant};

use arrow_array::builder::{LargeStringBuilder, StringBuilder};
use arrow_array::{Array, ArrayRef, LargeStringArray, RecordBatch, RecordBatchOptions, StringArray, StructArray};
use arrow_schema::ArrowError;
use triplelight::embedded::ReadSnapshot;
use triplelight::exec::{IdSolutions, QueryResult, UNBOUND};
use triplelight::model::TermId;
use triplelight::rdf::TermRef;
use triplelight_c::arrow::{schema_for, term_fields, IdBatchReader};
use triplelight_c::*;

type CellRef<'a> = Option<(&'a str, &'a str, Option<&'a str>, Option<&'a str>)>;

#[derive(Default, Clone)]
struct Sum { rows: u64, cells: u64, batches: u64, checksum: u64 }

const FNV: u64 = 0xcbf29ce484222325;
fn fnv(mut h: u64, bytes: &[u8]) -> u64 { for b in bytes { h ^= *b as u64; h = h.wrapping_mul(0x100000001b3) } h }
fn fold_cell(h: u64, c: CellRef) -> u64 {
    match c {
        None => fnv(h, &[0]),
        Some((k, v, d, l)) => {
            let mut h = fnv(h, &[1]);
            for part in [Some(k), Some(v), d, l] {
                h = match part { None => fnv(h, &[0]), Some(s) => fnv(fnv(fnv(h, &[1]), &(s.len() as u64).to_le_bytes()), s.as_bytes()) };
            }
            h
        }
    }
}

/// Identical to arrow_probe's consumer (PR #45): every cell's validity and field bytes folded into the checksum.
fn consume_batch(b: &RecordBatch, s: &mut Sum) {
    s.batches += 1;
    let cols: Vec<(&StructArray, &StringArray, &LargeStringArray, &StringArray, &StringArray)> = b.columns().iter().map(|c| {
        let st = c.as_any().downcast_ref::<StructArray>().expect("struct column");
        (st, st.column(0).as_any().downcast_ref::<StringArray>().unwrap(), st.column(1).as_any().downcast_ref::<LargeStringArray>().unwrap(),
         st.column(2).as_any().downcast_ref::<StringArray>().unwrap(), st.column(3).as_any().downcast_ref::<StringArray>().unwrap())
    }).collect();
    for r in 0..b.num_rows() {
        let mut h = FNV;
        for (st, k, v, d, l) in &cols {
            let cell = st.is_valid(r).then(|| (k.value(r), v.value(r), d.is_valid(r).then(|| d.value(r)), l.is_valid(r).then(|| l.value(r))));
            h = fold_cell(h, cell);
        }
        s.rows += 1; s.cells += cols.len() as u64; s.checksum = s.checksum.wrapping_add(h);
    }
}

// ---- ProfiledReader: copy of triplelight_c::arrow::IdBatchReader::batch (PR #42 head) with stage clocks ----

#[derive(Clone)]
struct Owned { kind: &'static str, value: String, datatype: Option<String>, language: Option<String> }

fn owned(t: TermRef<'_>) -> Result<Owned, ArrowError> {
    Ok(match t {
        TermRef::NamedNode(n) => Owned { kind: "iri", value: n.as_str().to_string(), datatype: None, language: None },
        TermRef::BlankNode(n) => Owned { kind: "bnode", value: n.as_str().to_string(), datatype: None, language: None },
        TermRef::Literal(l) => Owned { kind: "literal", value: l.value().to_string(), datatype: Some(l.datatype().as_str().to_string()), language: l.language().map(str::to_string) },
        #[allow(unreachable_patterns)]
        _ => return Err(ArrowError::NotYetImplemented("RDF-star terms are not supported".into())),
    })
}

#[derive(Default, Clone, Copy)]
struct Stages { collect: f64, decode: f64, scratch: f64, build: f64, consume: f64, release: f64, distinct: u64 }

struct ProfiledReader { snap: ReadSnapshot, sol: IdSolutions, schema: arrow_schema::SchemaRef, next_row: usize, scratch_converted: usize, st: Stages }

fn ms(t: Instant) -> f64 { t.elapsed().as_secs_f64() * 1e3 }

impl ProfiledReader {
    fn new(snap: ReadSnapshot, sol: IdSolutions) -> Self {
        let names: Vec<String> = sol.vars.iter().map(|v| v.as_str().to_string()).collect();
        Self { schema: schema_for(&names), snap, sol, next_row: 0, scratch_converted: 0, st: Stages::default() }
    }
    fn batch(&mut self) -> Result<Option<RecordBatch>, ArrowError> {
        let clk = Instant::now(); // PROFILE: collect
        let rows = self.sol.rows;
        if self.next_row >= rows { self.st.collect += ms(clk); return Ok(None) } // PROFILE: + clock
        let start = self.next_row;
        let n = (rows - start).min(BATCH_ROWS);
        self.next_row += n;
        let width = self.sol.vars.len();
        let options = RecordBatchOptions::new().with_row_count(Some(n));
        if width == 0 {
            self.st.collect += ms(clk); // PROFILE
            // A zero-column SELECT keeps its cardinality: n solutions, no columns.
            return RecordBatch::try_new_with_options(Arc::clone(&self.schema), vec![], &options).map(Some);
        }
        let cells = &self.sol.ids[start * width..(start + n) * width];
        let mut distinct: Vec<TermId> = cells.iter().copied().filter(|id| *id != UNBOUND && !self.sol.scratch.contains_key(id)).collect();
        distinct.sort_unstable();
        distinct.dedup();
        self.st.distinct += distinct.len() as u64; // PROFILE
        self.st.collect += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: decode
        let mut decoded: Vec<Option<Owned>> = vec![None; distinct.len()];
        let mut failure = None;
        self.snap.with_terms(&distinct, &mut |i, t| match owned(t) {
            Ok(o) => decoded[i] = Some(o),
            Err(e) => failure = Some(e),
        }).map_err(|e| ArrowError::ExternalError(Box::new(e)))?;
        if let Some(e) = failure { return Err(e) }
        self.st.decode += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: scratch
        // Computed (scratch) terms: convert only those present in this batch.
        let mut scratch: std::collections::HashMap<TermId, Owned> = std::collections::HashMap::new();
        for id in cells {
            if scratch.contains_key(id) { continue }
            if let Some(t) = self.sol.scratch.get(id) {
                scratch.insert(*id, owned(t.as_ref())?);
            }
        }
        self.scratch_converted += scratch.len();
        self.st.scratch += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: build
        let mut columns: Vec<ArrayRef> = Vec::with_capacity(width);
        for col in 0..width {
            let mut kind = StringBuilder::new();
            let mut value = LargeStringBuilder::new();
            let mut datatype = StringBuilder::new();
            let mut language = StringBuilder::new();
            let mut nulls = Vec::with_capacity(n);
            // i32-offset columns must not overflow: check their byte totals before appending.
            let (mut dt_bytes, mut lang_bytes) = (0usize, 0usize);
            for r in 0..n {
                let id = cells[r * width + col];
                let term = if id == UNBOUND {
                    None
                } else if let Some(t) = scratch.get(&id) {
                    Some(t)
                } else {
                    let i = distinct.binary_search(&id).map_err(|_| ArrowError::ComputeError("undecoded term ID".into()))?;
                    Some(decoded[i].as_ref().ok_or_else(|| ArrowError::ComputeError("dictionary omitted a requested term".into()))?)
                };
                nulls.push(term.is_some());
                match term {
                    None => { kind.append_value(""); value.append_value(""); datatype.append_null(); language.append_null(); }
                    Some(t) => {
                        dt_bytes += t.datatype.as_ref().map_or(0, String::len);
                        lang_bytes += t.language.as_ref().map_or(0, String::len);
                        if dt_bytes > i32::MAX as usize || lang_bytes > i32::MAX as usize {
                            return Err(ArrowError::ComputeError("batch string data exceeds Utf8 offset range".into()));
                        }
                        kind.append_value(t.kind);
                        value.append_value(&t.value);
                        datatype.append_option(t.datatype.as_deref());
                        language.append_option(t.language.as_deref());
                    }
                }
            }
            let children: Vec<ArrayRef> = vec![Arc::new(kind.finish()), Arc::new(value.finish()), Arc::new(datatype.finish()), Arc::new(language.finish())];
            let array = StructArray::try_new(term_fields(), children, Some(nulls.into()))?;
            columns.push(Arc::new(array));
        }
        let out = RecordBatch::try_new_with_options(Arc::clone(&self.schema), columns, &options).map(Some); // PROFILE: bind
        self.st.build += ms(clk); // PROFILE
        out // PROFILE: `decoded`, `scratch`, `distinct` drop at return, after the build clock (remainder)
    }
}

fn query(snap: &ReadSnapshot, q: &str) -> (f64, IdSolutions) {
    let t = Instant::now();
    let QueryResult::Ids(ids) = snap.query_ids(q).expect("query_ids") else { panic!("SELECT expected") };
    (ms(t), ids)
}

/// Control: the unchanged library reader. Returns (ids_ms, total_ms, sum).
fn control(db: &triplelight::embedded::Database, q: &str) -> (f64, f64, Sum) {
    let snap = db.read();
    let (ids_ms, ids) = query(&snap, q);
    let t = Instant::now();
    let mut s = Sum::default();
    let mut r = IdBatchReader::new(snap, ids);
    for b in r.by_ref() { let b = b.expect("batch"); consume_batch(&b, &mut s); drop(b) }
    // Reader destruction (its ID result and snapshot) is inside the total on both passes: explicit, before the clock stops.
    drop(r);
    (ids_ms, ms(t), s)
}

/// Profiled: copy with stage clocks. Returns (ids_ms, total_ms, stages, sum).
fn profiled(db: &triplelight::embedded::Database, q: &str) -> (f64, f64, Stages, Sum) {
    let snap = db.read();
    let (ids_ms, ids) = query(&snap, q);
    let t = Instant::now();
    let mut s = Sum::default();
    let mut r = ProfiledReader::new(snap, ids);
    while let Some(b) = r.batch().expect("batch") {
        let tc = Instant::now(); consume_batch(&b, &mut s); r.st.consume += ms(tc);
        let tr = Instant::now(); drop(b); r.st.release += ms(tr);
    }
    // Capture the counters, then drop the reader (its ID result and snapshot) before stopping the total clock, as
    // the control pass's `for` loop does; that destruction falls in the signed remainder.
    let st = r.st;
    drop(r);
    let total = ms(t);
    (ids_ms, total, st, s)
}

/// Untimed locality aggregates over each batch's sorted distinct stored IDs.
fn locality(db: &triplelight::embedded::Database, q: &str) -> String {
    let snap = db.read();
    let (_, sol) = query(&snap, q);
    let width = sol.vars.len();
    let gap_edges: [u64; 4] = [2, 16, 256, 65536]; // buckets: 1 | 2-15 | 16-255 | 256-65535 | >=65536
    let run_edges: [u64; 3] = [2, 16, 256];        // buckets: 1 | 2-15 | 16-255 | >=256
    let bucket = |x: u64, edges: &[u64]| edges.iter().position(|e| x < *e).unwrap_or(edges.len());
    let (mut gaps, mut runs) = (vec![0u64; 5], vec![0u64; 4]);
    let (mut batches, mut distinct_total, mut cells_total, mut runs_total) = (0u64, 0u64, 0u64, 0u64);
    let mut per_batch = Vec::new();
    let mut s = Sum::default();
    let mut start = 0;
    while start < sol.rows {
        let n = (sol.rows - start).min(BATCH_ROWS);
        let cells = &sol.ids[start * width..(start + n) * width];
        let mut d: Vec<TermId> = cells.iter().copied().filter(|id| *id != UNBOUND && !sol.scratch.contains_key(id)).collect();
        d.sort_unstable(); d.dedup();
        let (mut bg, mut br) = (0u64, 0u64);
        let mut run = if d.is_empty() { 0 } else { 1u64 };
        for w in d.windows(2) {
            let g = w[1].0 - w[0].0;
            gaps[bucket(g, &gap_edges)] += 1; bg += 1;
            if g == 1 { run += 1 } else { runs[bucket(run, &run_edges)] += 1; br += 1; run = 1 }
        }
        if run > 0 { runs[bucket(run, &run_edges)] += 1; br += 1 }
        per_batch.push(format!("[{},{},{},{}]", d.len(), cells.len(), bg, br));
        batches += 1; distinct_total += d.len() as u64; cells_total += cells.len() as u64; runs_total += br;
        start += n;
    }
    // gate the locality pass's own consumption like every other pass
    for b in IdBatchReader::new(snap, sol) { consume_batch(&b.expect("batch"), &mut s) }
    format!("{{\"batches\":{batches},\"distinct_ids_sum\":{distinct_total},\"cells\":{cells_total},\"gap_buckets\":{:?},\"run_buckets\":{:?},\"runs\":{runs_total},\"per_batch_distinct_cells_gaps_runs\":[{}],\"sum\":{}}}",
        gaps, runs, per_batch.join(","), sum_json(&s))
}

fn sum_json(s: &Sum) -> String { format!("{{\"rows\":{},\"cells\":{},\"batches\":{},\"checksum\":\"{:016x}\"}}", s.rows, s.cells, s.batches, s.checksum) }
fn stages_json(st: &Stages) -> String {
    format!("{{\"collect_ms\":{:.6},\"decode_ms\":{:.6},\"scratch_ms\":{:.6},\"build_ms\":{:.6},\"consume_ms\":{:.6},\"release_ms\":{:.6},\"distinct_ids_decoded\":{}}}",
        st.collect, st.decode, st.scratch, st.build, st.consume, st.release, st.distinct)
}

fn main() {
    let mut a: Vec<String> = std::env::args().collect();
    let usage = || -> ! { eprintln!("usage: arrow_profile <db> <query.rq> qualify | phase control-first|profiled-first [--locality]"); std::process::exit(2) };
    let loc = a.last().map(String::as_str) == Some("--locality");
    if loc { a.pop(); }
    if a.len() < 4 { usage() }
    let q = std::fs::read_to_string(&a[2]).expect("query file");
    let order = match (a[3].as_str(), a.get(4).map(String::as_str), a.len()) {
        ("qualify", None, 4) => None,
        ("phase", Some(o @ ("control-first" | "profiled-first")), 5) => Some(o.to_string()),
        _ => usage(),
    };
    let mut h = ptr::null_mut();
    let t0 = Instant::now();
    unsafe { assert_eq!(tl_open(a[1].as_ptr() as *const c_char, a[1].len(), &mut h, ptr::null_mut()), TL_OK, "tl_open") };
    while unsafe { tl_stats_ready(h) } != 1 {
        if t0.elapsed() > Duration::from_secs(120) { eprintln!("statistics not ready after 120 s"); std::process::exit(3) }
        std::thread::sleep(Duration::from_millis(1));
    }
    let stats_ready_ms = ms(t0);
    let db = unsafe { tl_db_database(&*h) };
    let mut out = format!("{{\"mode\":\"{}\",\"stats_ready_ms\":{stats_ready_ms:.3},\"batch_rows\":{BATCH_ROWS}", a[3]);
    let pass_json = |kind: &str, pos: usize, r: (f64, f64, Option<Stages>, Sum)| -> String {
        let (ids_ms, total, st, s) = r;
        let stages = st.map_or("null".to_string(), |x| {
            let sum = x.collect + x.decode + x.scratch + x.build + x.consume + x.release;
            format!("{},\"stage_sum_ms\":{sum:.6},\"remainder_ms\":{:.6}", stages_json(&x), total - sum)
        });
        format!("{{\"pass\":\"{kind}\",\"position\":{pos},\"ids_ms\":{ids_ms:.3},\"total_ms\":{total:.3},\"stages\":{stages},\"sum\":{}}}", sum_json(&s))
    };
    let run = |kind: &str| -> (f64, f64, Option<Stages>, Sum) {
        if kind == "control" { let (i, t, s) = control(db, &q); (i, t, None, s) } else { let (i, t, st, s) = profiled(db, &q); (i, t, Some(st), s) }
    };
    match order {
        None => {
            // Untimed qualification: one control and one profiled pass (gated), recorded but not reported.
            out += &format!(",\"passes\":[{},{}]", pass_json("control", 1, run("control")), pass_json("profiled", 2, run("profiled")));
        }
        Some(order) => {
            let (_, _, ws) = control(db, &q); // untimed warm-up, control path
            out += &format!(",\"warmup\":{}", sum_json(&ws));
            let kinds: [&str; 2] = if order == "control-first" { ["control", "profiled"] } else { ["profiled", "control"] };
            out += &format!(",\"order\":\"{order}\",\"passes\":[{},{}]", pass_json(kinds[0], 1, run(kinds[0])), pass_json(kinds[1], 2, run(kinds[1])));
        }
    }
    if loc { out += &format!(",\"locality\":{}", locality(db, &q)) }
    out += "}";
    unsafe { tl_close(h) };
    println!("{out}");
}
