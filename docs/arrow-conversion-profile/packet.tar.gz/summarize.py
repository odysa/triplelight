import json, statistics
from pathlib import Path
A = Path("/tmp/a35/scored-v2/attempt")
st = json.loads((A / "status.json").read_text()); reg = json.loads(Path("/tmp/a35/scored-v2/registration.json").read_text())
STAGES = ["collect_ms", "decode_ms", "scratch_ms", "build_ms", "consume_ms", "release_ms"]
out = {}
for ph in reg["phases"]:
    p = st[ph["id"]]["probe"]; c = out.setdefault(ph["cell"], {"obs": []})
    ps = {x["pass"]: x for x in p["passes"]}
    pr, co = ps["profiled"], ps["control"]
    c["obs"].append({"rep": ph["rep"], "order": ph["order"], "control_total_ms": co["total_ms"], "control_pos": co["position"],
                     "profiled_total_ms": pr["total_ms"], "profiled_pos": pr["position"], "control_ids_ms": co["ids_ms"],
                     "profiled_ids_ms": pr["ids_ms"], **{k: pr["stages"][k] for k in STAGES}, "stage_sum_ms": pr["stage_sum_ms"],
                     "remainder_ms": pr["remainder_ms"], "distinct_ids_decoded": pr["stages"]["distinct_ids_decoded"],
                     "rows": pr["sum"]["rows"], "cells": pr["sum"]["cells"]})
    if "locality" in p: c["locality"] = {k: v for k, v in p["locality"].items() if k != "per_batch_distinct_cells_gaps_runs"}
fields = ["control_total_ms", "profiled_total_ms", "control_ids_ms", "profiled_ids_ms", *STAGES, "stage_sum_ms", "remainder_ms"]
for cell, c in out.items():
    c["summary"] = {f: {"median": statistics.median(o[f] for o in c["obs"]), "min": min(o[f] for o in c["obs"]), "max": max(o[f] for o in c["obs"])} for f in fields}
    med = c["summary"]; tot = med["profiled_total_ms"]["median"]
    c["share_of_profiled_total_median"] = {k: med[k]["median"] / tot for k in STAGES}
    c["decode_us_per_distinct_id_median"] = statistics.median(1e3 * o["decode_ms"] / o["distinct_ids_decoded"] for o in c["obs"])
Path("/tmp/a35/SUMMARY.json").write_text(json.dumps(out, indent=1))
for cell, c in out.items():
    s = c["summary"]; print(cell, "rows", c["obs"][0]["rows"], "distinct", c["obs"][0]["distinct_ids_decoded"])
    for f in fields: print(f"  {f:18s} {s[f]['median']:11.3f} [{s[f]['min']:.3f}-{s[f]['max']:.3f}]")
    print("  decode us/distinct id", round(c["decode_us_per_distinct_id_median"], 2), " shares", {k: round(v, 4) for k, v in c["share_of_profiled_total_median"].items()})
    if "locality" in c: print("  locality", c["locality"])
