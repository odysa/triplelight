"""Recheck the RDFLib-HDT fixture bags from retained data, without importing an RDF engine."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

XSD = 'http://www.w3.org/2001/XMLSchema#'
RDF_LANG = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
PREFIX = '<urn:s> <urn:v> '


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def key(term):
    kind = term['type']
    value = term['value']
    if kind != 'literal':
        return kind, value, '', ''
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype') or (RDF_LANG if language else XSD + 'string')
    return kind, value, datatype, language


def parse_fixture_token(token):
    if not token.startswith('"'):
        if token.startswith('_:'):
            return 'bnode', token[2:], '', ''
        value = token[1:-1] if token.startswith('<') and token.endswith('>') else token
        return 'uri', value, '', ''
    value, end = json.JSONDecoder().raw_decode(token)
    suffix = token[end:]
    if not suffix:
        return 'literal', value, XSD + 'string', ''
    if suffix.startswith('@'):
        return 'literal', value, RDF_LANG, suffix[1:].lower()
    if suffix.startswith('^^<') and suffix.endswith('>'):
        return 'literal', value, suffix[3:-1], ''
    raise ValueError(token)


def differences(left, right):
    return [{'row': row, 'count': count} for row, count in sorted((left - right).items())]


def replay(root):
    frozen = root / 'frozen'
    manifest = frozen / 'FREEZE.json'
    freeze_digest = digest(manifest)
    for name, expected_sha in load(manifest).items():
        assert digest(frozen / name) == expected_sha, name
    pins = load(frozen / 'PINS.json')
    hdt_sha = pins['fixture_hdt_sha256']
    assert digest(frozen / 'fixture.hdt') == hdt_sha

    setup_file = root / 'run' / 'SETUP.json'
    setup = load(setup_file)
    assert setup['state'] == 'ready' and setup['rdf_data_opened'] is False
    assert setup['source_sha256'] == freeze_digest
    runtime_path = root / 'run' / 'adjacent-import.stdout'
    assert digest(runtime_path) == setup['runtime_sha256']
    runtime = load(runtime_path)
    assert runtime['python_sha256'] == pins['interpreter_sha256']
    assert runtime['versions'] == {wheel['name']: wheel['version'] for wheel in pins['wheels']}

    reference = Counter()
    subject, predicate = (parse_fixture_token(token) for token in PREFIX.split())
    for line in (frozen / 'consumer-fixture.nt').read_text().splitlines():
        assert line.startswith(PREFIX) and line.endswith(' .')
        reference[subject, predicate, parse_fixture_token(line[len(PREFIX):-2])] += 1
    jena = load(frozen / 'consumer-fixture-jena.json')['results']['bindings']
    assert len(reference) == sum(reference.values()) == 9
    assert reference == Counter((subject, predicate, key(binding['o'])) for binding in jena)

    supervisor = load(root / 'run' / 'SUPERVISOR.json')
    assert supervisor['identity_postcheck'] is True
    assert supervisor['source_sha256'] == freeze_digest
    assert supervisor['setup_sha256'] == digest(setup_file)
    assert supervisor['full_workload_qualified'] is False
    observations = {}
    for stage in supervisor['stages']:
        mode = stage['mode']
        assert mode not in observations and mode in ('default', 'preserve')
        inventory = stage['private_file_inventory']
        assert inventory['fixture.hdt'] == {'sha256': hdt_sha, 'bytes': 2035}
        for name, recorded in inventory.items():
            file = root / 'run' / (mode + '-private') / name
            assert file.is_file() and digest(file) == recorded['sha256']
            assert file.stat().st_size == recorded['bytes']

        summary = {'state': stage['state'], 'exit': stage['exit']}
        observations[mode] = summary
        if stage['state'] == 'worker-error':
            assert stage['exit'] != 0 and 'record' not in stage
            continue
        record = load(root / 'run' / stage['record'])
        assert record['mode'] == mode
        assert record['hdt_before_sha256'] == record['hdt_after_sha256'] == hdt_sha
        if stage['state'] == 'stage-error':
            assert record['step'] == stage['failed_step'] and 'error' in record
            summary.update(step=record['step'], error=record['error'])
            continue
        assert stage['state'] == 'observed' and stage['exit'] == 0
        assert record['step'] == 'complete' and record['close_returned'] is True
        assert record['normalize_literals'] is (mode == 'default')
        assert record['mapped'] is True and record['indexed'] is True
        assert record['safe_mode'] is False and record['global_bgp_optimizer_enabled'] is False
        raw = Counter(tuple(parse_fixture_token(token) for token in row) for row in record['raw_strings'])
        typed = Counter(tuple(map(key, row)) for row in record['typed'])
        gates = {
            'native_total': type(record['native_total']) is int and record['native_total'] == 11,
            'store_count': type(record['store_count']) is int and record['store_count'] == 11,
            'raw_exact': raw == reference,
            'typed_exact': typed == reference,
        }
        assert stage['checks'] == record['checks'] == gates
        diagnostic = record['shared_evaluator']
        assert diagnostic['passes'] is (diagnostic.get('columns') == ['o'] and diagnostic.get('rows') == [])
        summary.update(gates=gates, raw_rows=sum(raw.values()), typed_rows=sum(typed.values()),
                       native_total=record['native_total'], graph_length=record['store_count'],
                       raw_missing=differences(reference, raw), raw_extra=differences(raw, reference),
                       typed_missing=differences(reference, typed), typed_extra=differences(typed, reference),
                       shared_evaluator_rows=len(diagnostic['rows']) if 'rows' in diagnostic else None,
                       shared_evaluator_passes=diagnostic['passes'])
    assert set(observations) == {'default', 'preserve'}
    return {'freeze_sha256': freeze_digest, 'runtime_sha256': setup['runtime_sha256'],
            'reference_terms': sum(reference.values()), 'observations': observations}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('packet_root', type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.packet_root), indent=2, sort_keys=True))
