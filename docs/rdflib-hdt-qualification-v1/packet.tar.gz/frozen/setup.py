"""Install the frozen wheel set and verify imports, without opening the HDT fixture."""
import argparse
import base64
from importlib.metadata import distribution
import json
from pathlib import Path
import platform
import sys
import time
from urllib.request import urlopen

from common import HERE, PINS, ROOT, guard, lock, run, sha, source_identity, write


def runtime():
    import hdt
    import rdflib_hdt

    entry_paths={'hdt':hdt.__file__,'rdflib_hdt':rdflib_hdt.__file__}
    root = Path(sys.prefix).resolve()
    installed = {}
    for wheel in PINS['wheels']:
        dist = distribution(wheel['name'])
        if dist.version != wheel['version'] or not dist.files:
            raise RuntimeError(f'unexpected distribution {wheel["name"]}')
        for member in dist.files:
            path = Path(dist.locate_file(member)).resolve(strict=True)
            if not path.is_relative_to(root):
                raise RuntimeError(f'RECORD entry escaped the environment {member}')
            digest = sha(path)
            if member.hash:
                encoded = base64.urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip('=')
                if member.hash.mode != 'sha256' or encoded != member.hash.value or path.stat().st_size != member.size:
                    raise RuntimeError(f'RECORD mismatch {member}')
            elif not str(member).endswith('.dist-info/RECORD'):
                raise RuntimeError(f'out-of-scope unsigned RECORD entry {member}')
            installed[str(path.relative_to(root))] = digest
    site=Path(hdt.__file__).resolve().parent
    if any(sha(site/name)!=digest for name,digest in PINS['hdt_module_files'].items()):
        raise RuntimeError('installed HDT module changed')
    return {'python':sys.version, 'python_sha256':sha(Path(sys.executable)),
            'python_base_prefix':sys.base_prefix,'python_base_executable':sys._base_executable,
            'installed':installed, 'entry_paths':entry_paths,
            'versions':{w['name']:distribution(w['name']).version for w in PINS['wheels']}}


def setup(digest):
    lock('setup')
    source_identity(digest)
    if (sys.version_info[:3] != (3, 9, 6) or platform.system() != 'Darwin' or platform.machine() != 'arm64'
            or sha(Path(sys.executable)) != PINS['interpreter_sha256']):
        raise RuntimeError('wrong setup interpreter')
    ROOT.mkdir()
    (ROOT/'tmp').mkdir()
    directory=ROOT/'wheels'
    directory.mkdir()
    deadline=time.monotonic()+300
    receipt={'state':'download', 'source_sha256':digest, 'rdf_data_opened':False}
    try:
        for wheel in PINS['wheels']:
            path=directory/wheel['filename']
            length=0
            with urlopen(wheel['url'],timeout=15) as response, path.open('xb') as output:
                while data:=response.read(2**16):
                    guard('setup',deadline)
                    length+=len(data)
                    if length>wheel['bytes']:
                        raise RuntimeError(f'wheel exceeds declared size {path.name}')
                    output.write(data)
            if length!=wheel['bytes'] or sha(path)!=wheel['sha256']:
                raise RuntimeError(f'wheel identity mismatch {path.name}')
        python=str(ROOT/'venv/bin/python')
        pip=[python,'-I','-B','-m','pip','--isolated','--disable-pip-version-check','--no-cache-dir']
        steps=[
            ('venv',[sys.executable,'-I','-B','-m','venv',str(ROOT/'venv')]),
            ('install',pip+['install','--no-index','--no-deps','--no-compile','--only-binary=:all:',
                             *[str(directory/w['filename']) for w in PINS['wheels']]]),
            ('pip-check',pip+['check']),
            ('adjacent-import',[python,'-E','-s','-B',str(HERE/'setup.py'),'--probe']),
        ]
        for label,command in steps:
            receipt['state']=label
            code=run('setup',deadline,command,ROOT,label)
            receipt['exit']=code
            if code:
                receipt['state']=label+'-failed'
                return
        source_identity(digest)
        receipt.update(state='ready',runtime_sha256=sha(ROOT/'adjacent-import.stdout'))
    except Exception as exc:
        receipt['error']=repr(exc)
        raise
    finally:
        write(ROOT/'SETUP.json',receipt)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--source-sha256')
    mode.add_argument('--probe',action='store_true')
    args=parser.parse_args()
    if args.probe:
        lock('setup')
        print(json.dumps(runtime(),indent=2,sort_keys=True))
    else:
        setup(args.source_sha256)
