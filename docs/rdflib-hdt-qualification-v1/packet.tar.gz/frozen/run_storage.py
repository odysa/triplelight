"""Run the two independent RDFLib-HDT readers with frozen identities."""
import argparse
import json
import shutil
from pathlib import Path
import sys
import time

from common import HERE, PINS, ROOT, lock, run, sha, source_identity, write
from worker import checks


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-sha256',required=True)
    parser.add_argument('--setup-sha256',required=True)
    args=parser.parse_args()
    lock('storage')
    setup=ROOT/'SETUP.json'
    runtime_path=ROOT/'adjacent-import.stdout'
    python=ROOT/'venv/bin/python'

    def identity():
        source_identity(args.source_sha256)
        if sha(setup)!=args.setup_sha256:
            raise RuntimeError('wrong setup receipt digest')
        receipt=json.loads(setup.read_bytes())
        if (receipt['source_sha256']!=args.source_sha256 or receipt['rdf_data_opened'] is not False
                or receipt['state']!='ready' or sha(runtime_path)!=receipt['runtime_sha256']):
            raise RuntimeError('setup did not produce the announced runtime')
        runtime=json.loads(runtime_path.read_bytes())
        if sha(python)!=runtime['python_sha256'] or sha(Path(sys.executable))!=runtime['python_sha256']:
            raise RuntimeError('Python executable changed')
        if any(sha(ROOT/'venv'/name)!=digest for name,digest in runtime['installed'].items()):
            raise RuntimeError('installed runtime changed')

    identity()
    out=ROOT/'attempt-1'
    out.mkdir()
    (out/'tmp').mkdir()
    deadline=time.monotonic()+120
    result={'stages':[], 'source_sha256':args.source_sha256,'setup_sha256':args.setup_sha256,
            'identity_postcheck':False,'full_workload_qualified':False}
    try:
        for mode in ('default','preserve'):
            stage={'mode':mode}
            result['stages'].append(stage)
            db=out/(mode+'-private')
            db.mkdir()
            file=db/'fixture.hdt'
            shutil.copyfile(HERE/'fixture.hdt',file)
            if sha(file)!=PINS['fixture_hdt_sha256']:
                raise RuntimeError('private HDT copy differs from the pinned source')
            file.chmod(0o444)
            name=f'{mode}.json'
            command=[str(python),'-E','-s','-B',str(HERE/'worker.py'),'--mode',mode,
                     '--hdt',str(file),'--out',str(out/name)]
            stage['exit']=run('storage',deadline,command,out,mode)
            if sha(file)!=PINS['fixture_hdt_sha256']:
                raise RuntimeError('private HDT file changed')
            inventory={}
            for path in sorted(db.iterdir()):
                if path.is_symlink() or not path.is_file():
                    raise RuntimeError(f'unexpected HDT store entry {path.name}')
                if path!=file and not path.name.startswith('fixture.hdt.index'):
                    raise RuntimeError(f'unexpected HDT sidecar {path.name}')
                inventory[path.name]={'bytes':path.stat().st_size,'sha256':sha(path)}
            stage['private_file_inventory']=inventory
            if stage['exit']:
                stage['state']='worker-error'
                continue
            record=json.loads((out/name).read_bytes())
            stage['record']=name
            if record['mode']!=mode or record['hdt_before_sha256']!=record['hdt_after_sha256'] or record['hdt_after_sha256']!=PINS['fixture_hdt_sha256']:
                raise RuntimeError('wrong worker record identity')
            if record['step']!='complete' or 'error' in record:
                stage.update(state='stage-error',failed_step=record['step'])
                continue
            if record['checks']!=checks(record):
                raise RuntimeError('typed answer reducer disagreement')
            stage['checks']=record['checks']
            stage['state']='observed'
        identity()
        lock('storage')
        result['identity_postcheck']=True
    finally:
        write(out/'SUPERVISOR.json',result)


if __name__=='__main__':
    main()
