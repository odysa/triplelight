"""Observe a fresh HDT copy through raw native strings and the RDFLib adapter."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys

from common import HERE, PINS, lock, sha, write

XSD='http://www.w3.org/2001/XMLSchema#'
LANGSTRING='http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
SUBJECT='urn:s'
PREDICATE='urn:v'
FILTER_FALSE='SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }'


def literal(text):
    value,end=json.JSONDecoder().raw_decode(text)
    if not isinstance(value,str):
        raise ValueError('expected a quoted literal')
    suffix=text[end:]
    result={'type':'literal','value':value}
    if suffix.startswith('@'):
        result['language']=suffix[1:]
    elif suffix.startswith('^^<') and suffix.endswith('>'):
        result['datatype']=suffix[3:-1]
    elif suffix:
        raise ValueError(f'outside the frozen fixture N3 subset {suffix!r}')
    return result


def raw_term(text):
    if text.startswith('"'):
        return literal(text)
    if text.startswith('_:'):
        return {'type':'bnode','value':text[2:]}
    return {'type':'uri','value':text[1:-1] if text.startswith('<') and text.endswith('>') else text}


def rdf_key(term):
    if term['type']!='literal':
        return term['type'],term['value'],'',''
    lang=term.get('language',term.get('xml:lang','')).lower()
    datatype=term.get('datatype') or (LANGSTRING if lang else XSD+'string')
    return 'literal',term['value'],datatype,lang


def checks(record):
    ref=json.loads((HERE/'consumer-fixture-jena.json').read_bytes())
    expected=Counter((('uri',SUBJECT,'',''),('uri',PREDICATE,'',''),rdf_key(row['o']))
                     for row in ref['results']['bindings'])
    raw=Counter(tuple(rdf_key(raw_term(t)) for t in row) for row in record['raw_strings'])
    typed=Counter(tuple(rdf_key(t) for t in row) for row in record['typed'])
    return {'store_count':type(record['store_count']) is int and record['store_count']==11,
            'native_total':type(record['native_total']) is int and record['native_total']==11,
            'raw_exact':raw==expected,'typed_exact':typed==expected}


def observe(args,record):
    import hdt
    import rdflib
    from rdflib_hdt import HDTStore

    default=rdflib.NORMALIZE_LITERALS
    rdflib.NORMALIZE_LITERALS=default if args.mode=='default' else False
    record.update(literal_default=default,normalize_literals=rdflib.NORMALIZE_LITERALS,
                  mapped=True,indexed=True,safe_mode=False,global_bgp_optimizer_enabled=False)
    record['step']='open'
    store=HDTStore(str(args.hdt),mapped=True,indexed=True,safe_mode=False)
    if store.is_safe() is not False:
        raise RuntimeError('HDT iterator unexpectedly suppresses decoding errors')
    graph=rdflib.Graph(store=store)

    def term(value):
        if isinstance(value,rdflib.URIRef):
            return {'type':'uri','value':str(value)}
        if isinstance(value,rdflib.BNode):
            return {'type':'bnode','value':str(value)}
        if isinstance(value,rdflib.Literal):
            result={'type':'literal','value':str(value)}
            if value.datatype:
                result['datatype']=str(value.datatype)
            if value.language:
                result['language']=value.language
            return result
        raise TypeError(f'unexpected RDF term {type(value).__name__}')

    try:
        record['step']='native-read'
        native=store.hdt_document
        record['native_total']=native.total_triples
        iterator,estimate=hdt.HDTDocument.search_triples(native,SUBJECT,PREDICATE,'',limit=0,offset=0)
        record['raw_strings']=list(iterator)
        record['native_cardinality_estimate']=estimate

        record['step']='typed-read'
        record['store_count']=len(graph)
        pattern=(rdflib.URIRef(SUBJECT),rdflib.URIRef(PREDICATE),None)
        record['typed']=[[term(t) for t in row] for row in graph.triples(pattern)]
        record['checks']=checks(record)

        record['step']='shared-evaluator'
        try:
            result=graph.query(FILTER_FALSE,use_store_provided=False)
            columns=[str(variable) for variable in result.vars]
            rows=[[None if value is None else term(value) for value in row] for row in result]
            record['shared_evaluator']={'columns':columns,'rows':rows,'passes':columns==['o'] and not rows}
        except Exception as exc:
            record['shared_evaluator']={'error':repr(exc),'passes':False}
    finally:
        graph.close()
        record['close_returned']=True
    record['step']='complete'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('default','preserve'),required=True)
    parser.add_argument('--hdt',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    lock('storage')
    if (not args.hdt.is_absolute() or not args.out.is_absolute() or args.hdt.is_symlink()
            or sha(args.hdt)!=PINS['fixture_hdt_sha256'] or sha(Path(sys.executable))!=PINS['interpreter_sha256']
            or list(args.hdt.parent.iterdir())!=[args.hdt]):
        raise RuntimeError('fresh HDT copy or runtime identity mismatch')
    record={'mode':args.mode,'step':'import','hdt_before_sha256':sha(args.hdt)}
    try:
        observe(args,record)
    except Exception as exc:
        record['error']=repr(exc)
    lock('storage')
    record['hdt_after_sha256']=sha(args.hdt)
    write(args.out,record)


if __name__=='__main__':
    main()
