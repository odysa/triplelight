# RDFLib-HDT adapter qualification plan

Test the released RDFLib-HDT 3.3 wheel as a separate Python read-only adapter. PyPI publishes a CPython 3.9 universal2 wheel. The current repository README describes a different Python build baseline. Use the published wheel with the installed Xcode CPython 3.9.6 running natively on ARM64. Pin the interpreter and all five wheels, verify actual dependency compatibility and installed module identities, and keep the environment private. No native engine installation or import has run.

Use the retained 2,035-byte HDT file produced by the earlier standalone Jena/HDT qualification. It has eleven triples and its known digest is recorded. The test scope is the nine-term subgraph selected by the frozen fixture, plus a store-wide length check for eleven. Copy only the file itself into the new run root. The retained Jena source tree and its Java index sidecar stay untouched. Record any private index sidecar produced by the Python native reader separately. Keep the earlier Jena cohort separate.

## Observations

- Read the selected subgraph through the shipped native HDT string iterator. Retain the exact encoded objects and count. Then read it through `Graph(store=HDTStore(...))` in separate fresh default and preserve-normalization processes. Compare the direct typed bags to the same frozen Jena term reference. Record exact file bytes before and after each child.
- Use the published memory-mapped, indexed read path with safe mode disabled so decoding errors surface. Each fresh child begins with only its own byte-identical HDT file. Record any index written separately for each process. The fixture's encoded typed terms are the raw observation. If terms differ, compare exact strings and say where the first observed difference appears. The earlier Jena typed-read records describe the prior boundary. A discrepancy first observed in the native Python iterator would not by itself isolate the Jena writer from the new decoder. A single successful read is a fixture interoperability result for the already written Jena HDT artifact.
- Keep the shared RDFLib `FILTER(false)` diagnostic separate. Leave the opt-in `optimize_sparql()` global BGP replacement disabled in these profiles. Measuring the optional native BGP adapter would require its own route checks. The two readers use no graph modification API. No workload timing, write or broader SPARQL admission is planned.

- [RDFLib-HDT release wheel](https://pypi.org/project/rdflib-hdt/3.3/)
- [RDFLib-HDT source and API](https://github.com/RDFLib/rdflib-hdt)

## Harness revision 2

The v1 attempt exited at the first allocation check before any wheel was installed or RDF data opened. CPython 3.9 does not accept the `follow_symlinks` keyword on `Path.stat`. Use `Path.lstat()` to retain the link-local allocation check. Use a new run root and lock owner names, preserving the v1 failure receipts. The interpreter, wheel pins, fixture, and storage gates are identical.
