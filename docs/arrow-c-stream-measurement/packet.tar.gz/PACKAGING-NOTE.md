# Packaging note (packet v2)

- `probe-worktree.diff` (sha256 2c7a2deb…) was produced by `git diff HEAD` through the RTK shell hook, which rewrites
  git output into a compact summary. It is the file frozen in QUAL.SHA256 and is retained unchanged.
- `probe-worktree.raw.diff` is the exact raw `/usr/bin/git -C /tmp/a34-wt diff HEAD` output. Its sha256 equals the
  registered `identities.worktree_diff_sha256` (b676484a…), which the supervisor computed from raw `git diff HEAD`
  bytes at qualification, registration, preflight and postflight. Added after the run; not part of the frozen manifest.
- `probe-worktree.status` was likewise written through the RTK hook and is not byte-identical to raw `git status --short`;
  it is retained unchanged (frozen in QUAL.SHA256). `probe-worktree.raw.status` is the exact raw `/usr/bin/git status --short`
  output, added after the run. Status was never part of the registered identities.
- The untracked probe source is `probe.rs` (= worktree `bindings/c/examples/arrow_probe.rs`, hashed in identities).
