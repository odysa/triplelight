//! Task #34 step-3 descriptive probe (warm-query experiment). Not part of the library.
//!
//! usage: arrow_probe <db-dir> <query.rq> qualify
//!        arrow_probe <db-dir> <query.rq> phase arrow-first|view-first     (either may end with --order-col N)
//!
//! Paths (each consumes every cell with identical work: bound flag + bytes of kind, value, datatype?, language?):
//!   arrow: tl_query_arrow -> C stream callbacks -> arrow-rs import -> every batch -> release   (public API)
//!   view:  tl_query -> tl_result_get_view -> every cell -> tl_result_free                    (public API)
//!   instr: ReadSnapshot::query_ids (ids_ms), then IdBatchReader batches (convert_ms), no C stream (instrumented)
//! Cheap checksum: per row FNV-1a 64 over its cells, rows combined by wrapping add (order-independent), plus counts.
//! Canonical hash (untimed only): bench/run.py `canon` bag hash (sha1 of sorted rows) and its in-order sequence hash.
//! Prints one JSON line.
use std::ffi::c_char;
use std::ptr;
use std::time::{Duration, Instant};

use arrow_array::ffi_stream::{FFI_ArrowArrayStream, RecordBatchStreamReader};
use arrow_array::{Array, LargeStringArray, RecordBatch, StringArray, StructArray};
use sha1::{Digest, Sha1};
use triplelight::exec::QueryResult;
use triplelight_c::arrow::IdBatchReader;
use triplelight_c::*;

const XSD_STRING: &str = "http://www.w3.org/2001/XMLSchema#string";
const LANG_STRING: &str = "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString";

/// One cell as the consumer sees it: None = unbound.
type CellRef<'a> = Option<(&'a str, &'a str, Option<&'a str>, Option<&'a str>)>;

/// `ordered`: with `--order-col N`, whether column N held simple literals in non-decreasing code-point order while the
/// rows were consumed (checked during this observation, one comparison per row); None without `--order-col`.
#[derive(Default, Clone, PartialEq, Debug)]
struct Sum { rows: u64, cells: u64, batches: u64, checksum: u64, ordered: Option<bool>, last_key: Option<String> }

static ORDER_COL: std::sync::OnceLock<Option<usize>> = std::sync::OnceLock::new();
fn order_col() -> Option<usize> { *ORDER_COL.get().unwrap_or(&None) }

impl Sum {
    fn new() -> Self { Sum { ordered: order_col().map(|_| true), ..Default::default() } }
    fn key(&mut self, c: CellRef) {
        let ok = match c {
            Some(("literal", v, Some(XSD_STRING), None)) => {
                let fine = self.last_key.as_deref().is_none_or(|prev| prev <= v);
                self.last_key = Some(v.to_string());
                fine
            }
            _ => false,
        };
        if !ok { self.ordered = Some(false) }
    }
}

const FNV: u64 = 0xcbf29ce484222325;
fn fnv(mut h: u64, bytes: &[u8]) -> u64 { for b in bytes { h ^= *b as u64; h = h.wrapping_mul(0x100000001b3) } h }
fn fold_cell(h: u64, c: CellRef) -> u64 {
    match c {
        None => fnv(h, &[0]),
        Some((k, v, d, l)) => {
            let mut h = fnv(h, &[1]);
            for part in [Some(k), Some(v), d, l] {
                h = match part { None => fnv(h, &[0]), Some(s) => fnv(fnv(fnv(h, &[1]), &(s.len() as u64).to_le_bytes()), s.as_bytes()) };
            }
            h
        }
    }
}

/// Optional canonical collector (untimed passes only).
struct Canon { rows: Vec<String> }
fn canon_cell(c: CellRef) -> String {
    match c {
        None => "-".into(),
        Some((k, v, d, l)) => {
            let t = match k { "iri" => "uri", other => other };
            let v = if k == "bnode" { "_" } else { v };
            let dt = match d { Some(XSD_STRING) | Some(LANG_STRING) | None => "", Some(x) => x };
            format!("{t}|{v}|{dt}|{}", l.unwrap_or("").to_lowercase())
        }
    }
}
impl Canon {
    /// (bag sha1, in-order sha1, the in-order canonical rows when there are at most 16).
    fn hashes(mut self) -> (String, String, Option<Vec<String>>) {
        let sample = (self.rows.len() <= 16).then(|| self.rows.clone());
        let seq = Sha1::digest(self.rows.join("\n").as_bytes());
        self.rows.sort();
        let bag = Sha1::digest(self.rows.join("\n").as_bytes());
        (hex(&bag), hex(&seq), sample)
    }
}
fn json_str(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c { '"' => o += "\\\"", '\\' => o += "\\\\", c if (c as u32) < 0x20 => o += &format!("\\u{:04x}", c as u32), c => o.push(c) }
    }
    o + "\""
}
fn hex(b: &[u8]) -> String { b.iter().map(|x| format!("{x:02x}")).collect() }

fn consume_batch(b: &RecordBatch, s: &mut Sum, canon: &mut Option<Canon>) {
    s.batches += 1;
    let cols: Vec<(&StructArray, &StringArray, &LargeStringArray, &StringArray, &StringArray)> = b.columns().iter().map(|c| {
        let st = c.as_any().downcast_ref::<StructArray>().expect("struct column");
        (st, st.column(0).as_any().downcast_ref::<StringArray>().unwrap(), st.column(1).as_any().downcast_ref::<LargeStringArray>().unwrap(),
         st.column(2).as_any().downcast_ref::<StringArray>().unwrap(), st.column(3).as_any().downcast_ref::<StringArray>().unwrap())
    }).collect();
    for r in 0..b.num_rows() {
        let mut h = FNV;
        let mut line: Vec<String> = Vec::new();
        for (ci, (st, k, v, d, l)) in cols.iter().enumerate() {
            let cell = st.is_valid(r).then(|| (k.value(r), v.value(r), d.is_valid(r).then(|| d.value(r)), l.is_valid(r).then(|| l.value(r))));
            h = fold_cell(h, cell);
            if order_col() == Some(ci) { s.key(cell) }
            if canon.is_some() { line.push(canon_cell(cell)) }
        }
        s.rows += 1; s.cells += cols.len() as u64; s.checksum = s.checksum.wrapping_add(h);
        if let Some(c) = canon { c.rows.push(line.join("\t")) }
    }
}

fn run_arrow(db: *mut TlDb, q: &str, canon: &mut Option<Canon>) -> Sum {
    let mut s = Sum::new();
    unsafe {
        let mut stream = FFI_ArrowArrayStream::empty();
        let rc = tl_query_arrow(db, q.as_ptr() as *const c_char, q.len(), &mut stream, ptr::null_mut());
        assert_eq!(rc, TL_OK, "tl_query_arrow");
        let reader = RecordBatchStreamReader::try_new(stream).expect("import");
        for b in reader { consume_batch(&b.expect("batch"), &mut s, canon) } // each batch released after use; stream on drop
    }
    s
}

fn run_view(db: *mut TlDb, q: &str, canon: &mut Option<Canon>) -> Sum {
    let mut s = Sum::new();
    unsafe {
        let mut r = ptr::null_mut();
        assert_eq!(tl_query(db, q.as_ptr() as *const c_char, q.len(), &mut r, ptr::null_mut()), TL_OK, "tl_query");
        let v = &*tl_result_get_view(r);
        let bytes = std::slice::from_raw_parts(v.bytes, v.n_bytes as usize);
        let st = |x: TlStr| std::str::from_utf8_unchecked(&bytes[x.off as usize..(x.off + x.len) as usize]);
        let terms = std::slice::from_raw_parts(v.terms, v.n_terms as usize);
        let w = v.n_vars as usize;
        let cells = std::slice::from_raw_parts(v.cells, v.n_rows as usize * w);
        for r in 0..v.n_rows as usize {
            let mut h = FNV;
            let mut line: Vec<String> = Vec::new();
            for c in 0..w {
                let i = cells[r * w + c];
                let cell = (i != 0).then(|| {
                    let t = &terms[i as usize - 1];
                    let (kind, lit) = match t.kind { TL_TERM_IRI => ("iri", false), TL_TERM_BLANK => ("bnode", false), _ => ("literal", true) };
                    (kind, st(t.value), lit.then(|| st(t.datatype)), (t.language.len > 0).then(|| st(t.language)))
                });
                h = fold_cell(h, cell);
                if order_col() == Some(c) { s.key(cell) }
                if canon.is_some() { line.push(canon_cell(cell)) }
            }
            s.rows += 1; s.cells += w as u64; s.checksum = s.checksum.wrapping_add(h);
            if let Some(cn) = canon { cn.rows.push(line.join("\t")) }
        }
        s.batches = 1;
        tl_result_free(r);
    }
    s
}

/// Instrumented decomposition on the same open handle: (ids_ms, convert_ms, sum).
fn run_instr(db: *mut TlDb, q: &str, canon: &mut Option<Canon>) -> (f64, f64, Sum) {
    let d = unsafe { tl_db_database(&*db) };
    let t = Instant::now();
    let snap = d.read();
    let QueryResult::Ids(ids) = snap.query_ids(q).expect("query_ids") else { panic!("SELECT expected") };
    let ids_ms = t.elapsed().as_secs_f64() * 1e3;
    let t = Instant::now();
    let mut s = Sum::new();
    for b in IdBatchReader::new(snap, ids) { consume_batch(&b.expect("batch"), &mut s, canon) }
    (ids_ms, t.elapsed().as_secs_f64() * 1e3, s)
}

fn sum_json(s: Sum) -> String {
    let ordered = s.ordered.map_or("null".to_string(), |b| b.to_string());
    format!("{{\"rows\":{},\"cells\":{},\"batches\":{},\"checksum\":\"{:016x}\",\"ordered\":{ordered}}}", s.rows, s.cells, s.batches, s.checksum)
}

fn canonical(db: *mut TlDb, q: &str, path: &str) -> (Sum, String, String, Option<Vec<String>>) {
    let mut c = Some(Canon { rows: Vec::new() });
    let s = match path { "arrow" => run_arrow(db, q, &mut c), "view" => run_view(db, q, &mut c), _ => run_instr(db, q, &mut c).2 };
    let (bag, seq, sample) = c.unwrap().hashes();
    (s, bag, seq, sample)
}

fn main() {
    let a: Vec<String> = std::env::args().collect();
    let usage = || -> ! { eprintln!("usage: arrow_probe <db> <query.rq> qualify | phase arrow-first|view-first [--order-col N]"); std::process::exit(2) };
    let mut a = a;
    if a.len() >= 2 && a[a.len() - 2] == "--order-col" {
        let n: usize = a[a.len() - 1].parse().unwrap_or_else(|_| usage());
        ORDER_COL.set(Some(n)).unwrap();
        a.truncate(a.len() - 2);
    } else { ORDER_COL.set(None).unwrap() }
    if a.len() < 4 { usage() }
    let q = std::fs::read_to_string(&a[2]).expect("query file");
    let order = match (a[3].as_str(), a.get(4).map(String::as_str)) {
        ("qualify", None) => None,
        ("phase", Some(o @ ("arrow-first" | "view-first"))) => Some(o.to_string()),
        _ => usage(),
    };
    let mut db = ptr::null_mut();
    let t0 = Instant::now();
    unsafe { assert_eq!(tl_open(a[1].as_ptr() as *const c_char, a[1].len(), &mut db, ptr::null_mut()), TL_OK, "tl_open") };
    while unsafe { tl_stats_ready(db) } != 1 {
        if t0.elapsed() > Duration::from_secs(120) { eprintln!("statistics not ready after 120 s"); std::process::exit(3) }
        std::thread::sleep(Duration::from_millis(1));
    }
    let stats_ready_ms = t0.elapsed().as_secs_f64() * 1e3;
    let mut out = format!("{{\"mode\":\"{}\",\"stats_ready_ms\":{stats_ready_ms:.3},\"batch_rows\":{BATCH_ROWS}", a[3]);
    if let Some(order) = order {
        // Warm-up, frozen order: arrow, then view (discarded except for gating values).
        let wa = run_arrow(db, &q, &mut None);
        let wv = run_view(db, &q, &mut None);
        out += &format!(",\"warmup\":{{\"arrow\":{},\"view\":{}}}", sum_json(wa), sum_json(wv));
        let paths: [&str; 2] = if order == "arrow-first" { ["arrow", "view"] } else { ["view", "arrow"] };
        out += &format!(",\"order\":\"{order}\",\"timed\":[");
        for (pos, p) in paths.iter().enumerate() {
            let t = Instant::now();
            let s = if *p == "arrow" { run_arrow(db, &q, &mut None) } else { run_view(db, &q, &mut None) };
            let ms = t.elapsed().as_secs_f64() * 1e3;
            out += &format!("{}{{\"path\":\"{p}\",\"position\":{},\"ms\":{ms:.3},\"sum\":{}}}", if pos > 0 { "," } else { "" }, pos + 1, sum_json(s));
        }
        let (ids_ms, convert_ms, s) = run_instr(db, &q, &mut None);
        out += &format!("],\"instrumented\":{{\"ids_ms\":{ids_ms:.3},\"convert_ms\":{convert_ms:.3},\"sum\":{}}}", sum_json(s));
    }
    // Untimed canonical pass on every path (validates another execution, not the timed outputs).
    out += ",\"canonical\":{";
    for (i, p) in ["arrow", "view", "instr"].iter().enumerate() {
        let (s, bag, seq, sample) = canonical(db, &q, p);
        let sample = sample.map_or("null".to_string(), |r| format!("[{}]", r.iter().map(|x| json_str(x)).collect::<Vec<_>>().join(",")));
        out += &format!("{}\"{p}\":{{\"sum\":{},\"bag_sha1\":\"{bag}\",\"seq_sha1\":\"{seq}\",\"rows_in_order\":{sample}}}", if i > 0 { "," } else { "" }, sum_json(s));
    }
    out += "}}";
    unsafe { tl_close(db) };
    println!("{out}");
}
