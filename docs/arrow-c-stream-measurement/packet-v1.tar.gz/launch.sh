#!/bin/bash
# launch.sh <registration-sha256> <message-uuid>: takes the lock (or does nothing), binds, runs.
# Every exit code is captured explicitly (no pipes). A failed run keeps the lock until cleanup is verified by hand.
# LOCK / OWNER / PY / SUP / LOG may be overridden only by the stubbed controls in launch_controls.sh.
set -u
LOCK=${LOCK:-/tmp/rdf-bench.lock}
OWNER=${OWNER:-"Kaiming a34 scored v2"}
PY=${PY:-"python3 -I"}
SUP=${SUP:-/tmp/a34/score_a34.py}
LOG=${LOG:-/tmp/a34/scored-v2.run.log}
REG=$1; MSG=$2
release() { if [ "$(cat "$LOCK/owner" 2>/dev/null)" = "$OWNER" ]; then rm -rf "$LOCK"; echo "released" >> "$LOG"; else echo "lock not ours; left untouched" >> "$LOG"; fi; }
if ! mkdir "$LOCK" 2>/dev/null; then echo "lock held by: $(cat "$LOCK/owner" 2>/dev/null); nothing run" >> "$LOG"; exit 2; fi
echo "$OWNER" > "$LOCK/owner"
$PY "$SUP" bind "$REG" "$MSG" >> "$LOG" 2>&1; rc=$?
echo "bind exit $rc" >> "$LOG"
if [ $rc -ne 0 ]; then release; exit 3; fi
$PY "$SUP" run "$REG" >> "$LOG" 2>&1; rc=$?
echo "run exit $rc" >> "$LOG"
if [ $rc -eq 0 ]; then release; else echo "run failed; lock retained until cleanup is verified" >> "$LOG"; fi
exit $rc
