#!/bin/bash
# Builds arrow_probe for linux/arm64 from the probe worktree into /tmp/a34/bin. Sources are copied in first.
set -eu
IMG=rust@sha256:0b0ea86881537b3f645aace7e8e39556289f8787db057317c8d4978548213b9e
WT=/tmp/a34-wt
mkdir -p /tmp/a34/bin /tmp/a34/target
docker run --rm --platform linux/arm64 -v $WT:/src:ro -v /tmp/a34/target:/t -v /tmp/a34/bin:/out -e CARGO_TARGET_DIR=/t $IMG \
  sh -c "mkdir -p /b/bindings && cp -r /src/src /src/crates /src/Cargo.toml /src/Cargo.lock /src/rust-toolchain.toml /b/ && cp -r /src/examples /src/tests /b/ && mkdir /b/bindings/c && cd /src/bindings/c && cp -r src examples tests include Cargo.toml Cargo.lock rust-toolchain.toml /b/bindings/c/ && cd /b/bindings/c && cargo build --locked --release --example arrow_probe && cp /t/release/examples/arrow_probe /out/"
