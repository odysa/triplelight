#!/bin/bash
# Stubbed launcher controls: no Raft, no engine, no real lock. A fake python records which subcommands ran.
set -u
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
cat > "$T/fakepy" <<'PYEOF'
#!/bin/bash
echo "$2" >> "$CALLS"
[ "$2" = bind ] && exit "${BIND_RC:-0}"
[ "$2" = run ] && exit "${RUN_RC:-0}"
exit 0
PYEOF
chmod +x "$T/fakepy"
fail=0
check() { if [ "$2" = "$3" ]; then echo "PASS $1"; else echo "FAIL $1: got [$2] want [$3]"; fail=1; fi; }
run_case() { # lock_owner bind_rc [run_rc]; empty owner = lock absent
  rm -rf "$T/lock" "$T/calls" "$T/log"; : > "$T/calls"
  if [ -n "$1" ]; then mkdir "$T/lock"; echo "$1" > "$T/lock/owner"; fi
  LOCK="$T/lock" OWNER="me" PY="$T/fakepy" SUP=sup LOG="$T/log" CALLS="$T/calls" BIND_RC="$2" RUN_RC="${3:-0}" bash /tmp/a34/launch.sh R M; echo $?
}
rc=$(run_case "someone else" 0); check "lock-held-by-other: exit" "$rc" 2
check "lock-held-by-other: no commands" "$(cat "$T/calls")" ""
check "lock-held-by-other: lock untouched" "$(cat "$T/lock/owner")" "someone else"
rc=$(run_case "me" 0); check "lock-already-held-by-same-name: exit" "$rc" 2
check "lock-already-held-by-same-name: no commands" "$(cat "$T/calls")" ""
check "lock-already-held-by-same-name: lock untouched" "$(cat "$T/lock/owner")" "me"
rc=$(run_case "" 1); check "bind-fails: exit" "$rc" 3
check "bind-fails: run not started" "$(tr '\n' ' ' < "$T/calls")" "bind "
check "bind-fails: own lock released" "$([ -d "$T/lock" ] && echo held || echo released)" released
rc=$(run_case "" 0); check "success: exit" "$rc" 0
check "success: bind then run" "$(tr '\n' ' ' < "$T/calls")" "bind run "
check "success: own lock released" "$([ -d "$T/lock" ] && echo held || echo released)" released
rc=$(run_case "" 0 1); check "run-fails: exit" "$rc" 1
check "run-fails: bind then run" "$(tr '\n' ' ' < "$T/calls")" "bind run "
check "run-fails: own lock retained" "$([ -d "$T/lock" ] && cat "$T/lock/owner" || echo released)" me
[ $fail -eq 0 ] && echo "LAUNCH-CONTROLS PASS" || { echo "LAUNCH-CONTROLS FAIL"; exit 1; }
