import json, statistics, sys
from pathlib import Path
A = Path("/tmp/a34/scored-v2/attempt")
st = json.loads((A / "status.json").read_text())
reg = json.loads(Path("/tmp/a34/scored-v2/registration.json").read_text())
cells = {}
for ph in reg["phases"]:
    p = st[ph["id"]]["probe"]
    t = {x["path"]: x for x in p["timed"]}
    c = cells.setdefault(ph["cell"], {"arrow": [], "view": [], "ids": [], "convert": [], "rows": t["arrow"]["sum"]["rows"],
                                      "arrow_pos": [], "view_pos": []})
    c["arrow"].append(t["arrow"]["ms"]); c["view"].append(t["view"]["ms"])
    c["arrow_pos"].append(t["arrow"]["position"]); c["view_pos"].append(t["view"]["position"])
    c["ids"].append(p["instrumented"]["ids_ms"]); c["convert"].append(p["instrumented"]["convert_ms"])
out = []
for cell, c in cells.items():
    row = {"cell": cell, "rows": c["rows"]}
    for k in ("arrow", "view", "ids", "convert"):
        v = c[k]; row[k] = {"median_ms": statistics.median(v), "min_ms": min(v), "max_ms": max(v), "obs_ms": v}
    row["convert_us_per_row_median"] = 1e3 * row["convert"]["median_ms"] / c["rows"]
    row["arrow_us_per_row_median"] = 1e3 * row["arrow"]["median_ms"] / c["rows"]
    row["view_us_per_row_median"] = 1e3 * row["view"]["median_ms"] / c["rows"]
    a, v = c["arrow"], c["view"]
    row["arrow_vs_view_ranges"] = "arrow below view" if max(a) < min(v) else "arrow above view" if min(a) > max(v) else "ranges overlap"
    row["positions"] = {"arrow": c["arrow_pos"], "view": c["view_pos"]}
    out.append(row)
Path("/tmp/a34/SUMMARY.json").write_text(json.dumps(out, indent=1))
f = lambda x: f"{x:,.1f}" if x < 100 else f"{x:,.0f}"
for r in out:
    print(f"{r['cell']} rows={r['rows']:,}")
    for k in ("arrow", "view", "ids", "convert"):
        print(f"  {k:8s} median {f(r[k]['median_ms'])} ms  range {f(r[k]['min_ms'])}-{f(r[k]['max_ms'])}")
    print(f"  per-row us: arrow {r['arrow_us_per_row_median']:.3f} view {r['view_us_per_row_median']:.3f} convert {r['convert_us_per_row_median']:.3f}; {r['arrow_vs_view_ranges']}")
