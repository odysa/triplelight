"""Task #34 step 3 descriptive measurement (warm-query experiment): ID materialization vs Arrow conversion.
Derived from the reviewed startup36 supervisor (same container, cgroup, cache-drop, clone, inventory, cleanup rules).

  score_a34.py qualify --owner=<lock owner>    untimed: one phase per cell (probe mode `qualify`), writes /tmp/a34/qual
  score_a34.py register                        write /tmp/a34/scored-v1/registration.json once (no lock needed)
  score_a34.py bind <registration-sha256> <message-uuid>
  score_a34.py run <registration-sha256>       requires the lock held by the registered owner
"""
import hashlib, json, math, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path

sys.dont_write_bytecode = True
S = Path("/tmp/a34")
LOCK = Path("/tmp/rdf-bench.lock")
REPO = Path("/Users/odysa/.slock/agents/b438313f-6338-4d86-ab3e-5995a1bde6c3/rdfdb")
BENCH = REPO / "bench"
WT = Path("/tmp/a34-wt")
IMG = "debian@sha256:a72b4433de1cf7d6bae0c4cee74d0547f58601a643b3375f070c51600d63b6b2"
STORES = {"lubm1000": BENCH / "tools/rdfdb-diskvm-lubm1000", "bsbm100": BENCH / "tools/rdfdb-diskvm-bsbm100"}
PREPARED = {"lubm1000": Path("/tmp/s36/prepared/lubm1000/stats-0.v1"), "bsbm100": Path("/tmp/s36/prepared/bsbm100/stats-0.v1")}
# (cell, store, query file, round-13 reference file, key, ORDER BY var or None)
CELLS = [("lubm1000-q9", "lubm1000", BENCH / "lubm/q9.rq", "r13-lubm1000/qlever.json", "q9", None),
         ("lubm1000-q14", "lubm1000", BENCH / "lubm/q14.rq", "r13-lubm1000/qlever.json", "q14", None),
         ("bsbm100-q010", "bsbm100", BENCH / "bsbm100q/q010.rq", "r13-bsbm100/qlever.json", "q010", 1)]
BATCH_ROWS = 8192
CAP = 1200
CPUS, MEM = 4, 12 << 30
SIGNALS = (signal.SIGTERM, signal.SIGINT, signal.SIGHUP)
WRAP = ('grep MemTotal /proc/meminfo > /out/meminfo.start; cat /sys/fs/cgroup/memory.max > /out/memory.max; '
        '/bin/probe "$@" > /out/probe.json 2> /out/probe.stderr; rc=$?; '
        'cat /sys/fs/cgroup/memory.peak > /out/memory.peak.after-close; cat /sys/fs/cgroup/memory.events > /out/memory.events.after-close; exit $rc')
ALLOWED_OUT = {"meminfo.start", "memory.max", "probe.json", "probe.stderr", "memory.peak.after-close", "memory.events.after-close"}
ALLOWED_NEW_DB = {"LOCK", "wal.log"}
SIDECAR = "stats-0.v1"
OUT = S / "scored-v2"  # v1 (0a08f39e...) registered, never bound or run
OWNER = "Kaiming a34 scored v2"
TASK = "#sota-rdf-db:#34"
ME = "@Kaiming-He"
REPS = 5
ORDERS = ["arrow-first", "view-first", "arrow-first", "view-first", "arrow-first"]  # repetition r1..r5, every cell
DESIGN = {
    "question": "For the merged tl_query_arrow (PR #42), how does a warm SELECT's elapsed time through the Arrow C stream "
                "compare with the existing tl_query view path, and how does an instrumented run split between building the "
                "ID result and converting it to Arrow batches? Descriptive; one machine, one session; no speed-up, zero-copy "
                "or memory claim.",
    "experiment": "warm-query: the VM page cache is dropped before each phase, before the in-process warm-up; timed "
                  "observations are therefore warm-query, not cold-cache, measurements",
    "endpoints": {
        "arrow_api_ms": "tl_query_arrow -> every batch pulled through the crate's C stream callbacks and imported with arrow-rs "
                        "RecordBatchStreamReader -> every cell's validity and kind/value/datatype/language bytes folded into the "
                        "cheap checksum -> each batch and the stream released",
        "view_api_ms": "tl_query -> tl_result_get_view -> every cell's unbound flag and kind/value/datatype/language bytes folded "
                       "into the same cheap checksum -> tl_result_free",
        "instrumented": "after both timed public paths, same process and handle: ids_ms = ReadSnapshot::query_ids; convert_ms = "
                        "IdBatchReader batches with the same consumer work and no C stream. A later instrumented observation, "
                        "reported on its own and never subtracted from either public-API total",
    },
    "checksum": "per row FNV-1a 64 over its cells (bound flag; per present field a presence byte, u64 length, bytes; absent "
                "fields a zero byte), rows combined by wrapping addition (order-independent), with row and cell counts",
    "canonical": "untimed pass after the instrumented observation on all three paths: bench/run.py canon bag sha1 (sorted rows) "
                 "and in-order sha1; validates another execution, not the timed outputs",
    "warmup": "one untimed execution per public path in the frozen order arrow, then view, every phase",
    "timed_order": "per repetition r1..r5: arrow-first, view-first, arrow-first, view-first, arrow-first (same for every cell); "
                   "five repetitions cannot balance two orders; every observation keeps its position",
    "reported": "per cell: medians and the five-observation ranges of arrow_api_ms, view_api_ms, ids_ms, convert_ms, and per-row "
                "microseconds; no pooled cross-cell number; ranges are descriptive: non-overlap is reported as such and overlap "
                "is not treated as evidence of no difference; not a throughput benchmark of Arrow consumers",
    "gates": "exit 0; all times finite and positive; every warm-up, timed and instrumented observation's rows, cells, batches and "
             "checksum equal the frozen qualification values; canonical bag hashes on all paths equal the QLever round-13 "
             "reference; q010 ORDER BY non-decreasing on all paths; base tree, CURRENT and the stats file unchanged; only LOCK and "
             "wal.log appear in the clone; no OOM; exact container inspection; one MemTotal across the cohort; lock held by the "
             "registered owner throughout",
    "stop_rule": "first failing gate, error, timeout, cap, OOM, lock mismatch, identity drift or failed cleanup stops the attempt; "
                 "no retries, no discarded observations",
    "limitations": "macOS host cache behind virtiofs not controlled; probe-only worktree diff (example, hidden accessor, sha1 "
                   "dev-dependency) disclosed; Q14 is a large-output candidate, not presumed conversion-dominated",
}


class Abort(Exception):
    pass


def on_signal(signum, _frame): raise Abort(f"signal {signum}")
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def sha_big(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 24), b""): h.update(chunk)
    return h.hexdigest()


def tree(p):
    h = hashlib.sha256()
    for f in sorted(x for x in Path(p).rglob("*") if x.is_file()):
        h.update(str(f.relative_to(p)).encode() + b"\0" + sha_big(f).encode() + b"\n")
    return h.hexdigest()


def atomic(path, value):
    tmp = Path(str(path) + ".tmp"); tmp.write_text(json.dumps(value, indent=1)); os.replace(tmp, path)


def lock_owner():
    try: return (LOCK / "owner").read_text()
    except OSError: return None


def require_lock(owner):
    if lock_owner() != owner + "\n": raise Abort(f"lock owner is {lock_owner()!r}, expected {owner!r}")


def docker(*args, check=True, timeout=120):
    try: r = subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired: raise RuntimeError(f"docker {args[0]} timed out after {timeout}s")
    if check and r.returncode != 0: raise RuntimeError(f"docker {args[0]}: {r.stderr.strip()}")
    return r


def reference(cell):
    _, _, _, f, key, _ = next(c for c in CELLS if c[0] == cell)
    v = json.loads((BENCH / "results" / f).read_text())[key]["qlever"]
    return {"rows": v["rows"], "bag_sha1": v["hash"], "source": f"bench/results/{f} [{key}][qlever]"}


def inspect_ok(info, mounts, pdir):
    hc, cfg = info["HostConfig"], info["Config"]
    got = {m["Destination"]: {"source": m["Source"], "rw": m["RW"]} for m in info["Mounts"]}
    want = {dst: {"source": src, "rw": rw} for src, dst, rw in mounts}
    img = json.loads(docker("image", "inspect", IMG).stdout)[0]
    checks = {"image_digest": cfg["Image"] == IMG and info["Image"] == img["Id"],
              "platform": info["Platform"] == "linux" and img["Os"] == "linux" and img["Architecture"] == "arm64",
              "cpus": hc["NanoCpus"] == CPUS * 1_000_000_000, "memory": hc["Memory"] == MEM and hc["MemorySwap"] == MEM,
              "network": hc["NetworkMode"] == "none", "cgroupns": hc["CgroupnsMode"] == "private",
              "read_only_root": hc["ReadonlyRootfs"] is True and not hc.get("Tmpfs"),
              "env": "RAYON_NUM_THREADS=4" in cfg["Env"], "mounts": got == want}
    atomic(pdir / "inspect.json", {"checks": checks, "image_id": info["Image"], "mounts": got, "env": cfg["Env"], "cmd": cfg["Cmd"]})
    return all(checks.values())


def guarded(receipt, step, fn):
    try: return fn()
    except Exception as exc:
        receipt.setdefault("cleanup_errors", []).append(f"{step}: {exc!r}"); return None


def remove_named(name, receipt, key):
    guarded(receipt, f"{key}-rm", lambda: docker("rm", "-f", name, check=False, timeout=60))
    probe = guarded(receipt, f"{key}-probe", lambda: docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}", check=False))
    receipt[key] = ("unverified" if probe is None or probe.returncode != 0 else "removed" if probe.stdout.strip() == "" else "still-present")
    return receipt[key] == "removed"


def drop_caches(hname, receipt):
    if docker("ps", "-a", "--filter", f"name=^{hname}$", "--format", "{{.Names}}").stdout.strip():
        raise Abort(f"helper {hname} already exists; refusing to touch it")
    try:
        r = docker("run", "--name", hname, "--privileged", "--network", "none", IMG, "sh", "-c", "sync; echo 3 > /proc/sys/vm/drop_caches", check=False, timeout=300)
        if r.returncode != 0: raise Abort(f"drop_caches failed: {r.stderr.strip()}")
    finally:
        if not remove_named(hname, receipt, "dropcache_helper_cleanup"): raise Abort(f"helper {hname} not confirmed removed")


def cleanup(name, created, proc, clone, receipt):
    old = {s: signal.signal(s, signal.SIG_IGN) for s in SIGNALS}
    try:
        if created:
            guarded(receipt, "stop", lambda: docker("stop", "-t", "10", name, check=False, timeout=60))
            if proc is not None:
                def reap():
                    try: proc.wait(timeout=60)
                    except subprocess.TimeoutExpired: proc.kill(); proc.wait()
                guarded(receipt, "reap", reap)
            remove_named(name, receipt, "container_cleanup")
        else:
            receipt["container_cleanup"] = "not-created"
        if receipt.get("cleanup_errors"): receipt["container_cleanup"] = "unverified"
        if clone is not None:
            if receipt["container_cleanup"] in ("removed", "not-created"):
                guarded(receipt, "rm-clone", lambda: subprocess.run(["rm", "-rf", str(clone)], check=False, timeout=600))
                receipt["private_clone_removed"] = guarded(receipt, "probe-clone", lambda: not clone.exists()) is True
            else:
                receipt["private_clone_removed"] = False; receipt["clone_kept"] = str(clone)
    finally:
        for s, h in old.items(): signal.signal(s, h)


def order_ok(rows, col):
    """ORDER BY over simple literals: canonical cells `literal|v||` non-decreasing in code-point order."""
    keys = []
    for r in rows:
        cell = r.split("\t")[col]
        if not cell.startswith("literal|"): return False
        v, dt, lang = cell[len("literal|"):].rsplit("|", 2)
        if dt or lang: return False
        keys.append(v)
    return all(a <= b for a, b in zip(keys, keys[1:]))


def sums_equal_expected(s, rows, width):
    return s["rows"] == rows and s["cells"] == rows * width


def qual_gate(cell, p, ref, order_col):
    problems = []
    c = p["canonical"]
    paths = ["arrow", "view", "instr"]
    for k in paths:
        if c[k]["bag_sha1"] != ref["bag_sha1"]: problems.append(f"{k}: bag hash differs from reference")
        if c[k]["sum"]["rows"] != ref["rows"]: problems.append(f"{k}: rows {c[k]['sum']['rows']} != {ref['rows']}")
    for f in ("rows", "cells", "checksum"):
        if len({(type(c[k]["sum"][f]).__name__, c[k]["sum"][f]) for k in paths}) != 1: problems.append(f"paths disagree on {f}")
    for k in paths:
        if c[k]["sum"].get("ordered", "missing") is not (True if order_col is not None else None): problems.append(f"{k}: ordered verdict")
    want_batches = -(-ref["rows"] // BATCH_ROWS)
    for k in ("arrow", "instr"):
        if c[k]["sum"]["batches"] != want_batches: problems.append(f"{k}: batches {c[k]['sum']['batches']} != {want_batches}")
    if order_col is not None:
        for k in paths:
            if c[k]["rows_in_order"] is None or not order_ok(c[k]["rows_in_order"], order_col): problems.append(f"{k}: ORDER BY check failed")
    return problems


def run_phase(pid, cell, store, qf, args, outdir, owner, base_tree):
    pdir = outdir / pid; pdir.mkdir()
    name = f"a34-{outdir.name}-{pid}"
    receipt = {"phase": pid, "container": name, "args": args}
    created, proc, clone, result = False, None, None, None
    try:
        require_lock(owner)
        if docker("ps", "-a", "--filter", f"name=^{name}$", "--format", "{{.Names}}").stdout.strip():
            raise Abort(f"container {name} already exists; refusing to touch it")
        out = pdir / "out"; out.mkdir()
        clone = S / "clones" / f"{outdir.name}-{pid}"; clone.parent.mkdir(exist_ok=True); clone.mkdir()
        subprocess.run(["cp", "-c", "-R", str(STORES[store]), str(clone / "base-0")], check=True, timeout=600)
        (clone / "CURRENT").write_text("base-0\n")
        subprocess.run(["cp", "-c", str(PREPARED[store]), str(clone / SIDECAR)], check=True, timeout=60)
        sidecar_before = sha(clone / SIDECAR)
        before = sorted(str(p.relative_to(clone)) for p in clone.rglob("*"))
        drop_caches(f"{name}-dropcache", receipt)
        mounts = [(str(S / "bin/arrow_probe"), "/bin/probe", False), (str(qf), "/q.rq", False), (str(clone), "/db", True), (str(out), "/out", True)]
        cmd = ["create", "--name", name, "--network", "none", "--cpus", str(CPUS), "--memory", "12g", "--memory-swap", "12g",
               "--cgroupns", "private", "--read-only", "-e", "RAYON_NUM_THREADS=4"]
        for src, dst, rw in mounts: cmd += ["-v", f"{src}:{dst}" + ("" if rw else ":ro")]
        cmd += [IMG, "sh", "-c", WRAP, "sh", "/db", "/q.rq", *args]
        created = True
        docker(*cmd)
        if not inspect_ok(json.loads(docker("inspect", name).stdout)[0], mounts, pdir): raise Abort("container inspection failed")
        t0 = time.monotonic()
        proc = subprocess.Popen(["docker", "start", "-a", name], stdout=open(pdir / "container.log", "w"), stderr=subprocess.STDOUT)
        capped = False
        while proc.poll() is None:
            require_lock(owner)
            if time.monotonic() - t0 >= CAP:
                capped = True
                docker("stop", "-t", "10", name, check=False, timeout=60)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    docker("kill", name, check=False, timeout=60)
                    try: proc.wait(timeout=30)
                    except subprocess.TimeoutExpired: raise Abort("container did not exit after stop and kill")
                break
            time.sleep(1)
        state = json.loads(docker("inspect", name).stdout)[0]["State"]
        receipt.update({"exit_code": state["ExitCode"], "oom_killed": state["OOMKilled"], "capped": capped, "seconds": time.monotonic() - t0})
        found = sorted(str(p.relative_to(out)) for p in out.rglob("*"))
        new_db = sorted(set(str(p.relative_to(clone)) for p in clone.rglob("*")) - set(before))
        base_ok = tree(clone / "base-0") == base_tree and (clone / "CURRENT").read_text() == "base-0\n"
        side_ok = (clone / SIDECAR).exists() and sha(clone / SIDECAR) == sidecar_before
        receipt["inventory"] = {"out": found, "new_in_clone": new_db, "base_tree_unchanged": base_ok, "sidecar_unchanged": side_ok}
        try: events = dict(l.split() for l in (out / "memory.events.after-close").read_text().splitlines())
        except (OSError, ValueError): events = None
        receipt["memory_events"] = events
        receipt["memory_peak_bytes"] = int((out / "memory.peak.after-close").read_text()) if (out / "memory.peak.after-close").exists() else None
        try: receipt["memtotal_kB"] = int((out / "meminfo.start").read_text().split()[1])
        except (OSError, ValueError, IndexError): receipt["memtotal_kB"] = None
        receipt["probe_stderr"] = (out / "probe.stderr").read_text()[-2000:] if (out / "probe.stderr").exists() else ""
        unexpected = [f for f in found if f not in ALLOWED_OUT] + [f for f in new_db if f not in ALLOWED_NEW_DB] + ([] if base_ok and side_ok else ["base-0, CURRENT or stats file modified"])
        if unexpected: result = {"status": "unexpected-files", "unexpected": unexpected}
        elif capped or state["OOMKilled"] or state["ExitCode"] != 0 or events is None: result = {"status": "incomplete", "exit_code": state["ExitCode"]}
        elif int(events.get("oom_kill", 0)) or int(events.get("oom", 0)): result = {"status": "oom-event"}
        else: result = {"status": "ran", "probe": json.loads((out / "probe.json").read_text())}
    except Abort as exc:
        result = {"status": "aborted", "error": str(exc)}
    except Exception as exc:
        result = {"status": "supervisor-error", "error": repr(exc)}
    finally:
        cleanup(name, created, proc, clone, receipt)
        if result is None: result = {"status": "aborted", "error": "interrupted"}
        if receipt["container_cleanup"] not in ("removed", "not-created") or receipt.get("private_clone_removed") is False:
            result = {**result, "status": "cleanup-unverified"}
        receipt["result"] = result
        atomic(pdir / "receipt.json", receipt)
    return result


def write_once(path, value):
    with open(path, "x") as f: f.write(json.dumps(value, indent=1))


def qual_values():
    """Frozen per-cell values from the passed qualification (canonical sums per path)."""
    q = json.loads((S / "qual/QUAL.json").read_text())
    return {c: {k: q[c]["probe"]["canonical"][k]["sum"] for k in ("arrow", "view", "instr")} for c, *_ in CELLS}  # qualify runs only


def schedule():
    phases, n = [], 0
    for cell, store, *_ in CELLS:
        for i in range(REPS):
            n += 1
            phases.append({"id": f"{n:02d}-{cell}-r{i + 1}", "cell": cell, "store": store, "rep": i + 1, "order": ORDERS[i]})
    return phases


def finite_pos(x): return type(x) in (int, float) and math.isfinite(x) and x > 0  # bool excluded


def exact(got, want):
    """Equality with identical JSON types (True is not 1, 1.0 is not 1)."""
    return type(got) is type(want) and got == want


def scored_gate(ph, p, reg, order_col):
    problems = []
    qv, ref = reg["qualification_values"][ph["cell"]], reg["identities"]["references"][ph["cell"]]
    want_ordered = True if order_col is not None else None
    def same(label, got, want):
        for f in ("rows", "cells", "batches", "checksum"):
            if not exact(got.get(f), want[f]): problems.append(f"{label}: {f} {got.get(f)!r} != {want[f]!r}")
        if got.get("ordered", "missing") is not want_ordered: problems.append(f"{label}: ordered {got.get('ordered', 'missing')!r} != {want_ordered!r}")
    if p.get("mode") != "phase" or p.get("order") != ph["order"]: problems.append("probe mode/order mismatch")
    same("warmup arrow", p["warmup"]["arrow"], qv["arrow"]); same("warmup view", p["warmup"]["view"], qv["view"])
    want_paths = ["arrow", "view"] if ph["order"] == "arrow-first" else ["view", "arrow"]
    timed = p.get("timed", [])
    if [t.get("path") for t in timed] != want_paths or not all(exact(t.get("position"), i + 1) for i, t in enumerate(timed)): problems.append("timed order mismatch")
    for t in timed:
        if not finite_pos(t["ms"]): problems.append(f"timed {t['path']}: non-finite time")
        same(f"timed {t['path']}", t["sum"], qv[t["path"]])
    ins = p["instrumented"]
    if not (finite_pos(ins["ids_ms"]) and finite_pos(ins["convert_ms"])): problems.append("instrumented: non-finite time")
    same("instrumented", ins["sum"], qv["instr"])
    for k in ("arrow", "view", "instr"):
        c = p["canonical"][k]
        same(f"canonical {k}", c["sum"], qv[k])
        if c["bag_sha1"] != ref["bag_sha1"]: problems.append(f"canonical {k}: bag hash differs from reference")
        if order_col is not None and (c["rows_in_order"] is None or not order_ok(c["rows_in_order"], order_col)): problems.append(f"canonical {k}: ORDER BY")
    if not finite_pos(p.get("stats_ready_ms")): problems.append("stats_ready_ms not finite")
    return problems


def register():
    if OUT.exists(): raise SystemExit(f"{OUT} exists; registration is prospective and never overwritten")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise SystemExit(f"qualification file {f} changed")
    if (S / "launch_controls.txt").read_text().splitlines()[-1] != "LAUNCH-CONTROLS PASS": raise SystemExit("launcher controls did not pass")
    OUT.mkdir(parents=True)
    ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
    reg = {"schema": "a34-scored-registration-v2", "attempt_label": "a34-scored-v2", "lock_owner": OWNER, "image": IMG,
           "design": DESIGN, "identities": ids, "qualification_sha256": sha(S / "QUAL.SHA256"),
           "qualification_values": qual_values(), "batch_rows": BATCH_ROWS,
           "container": {"cpus": CPUS, "memory": MEM, "memory_swap": MEM, "network": "none", "cgroupns": "private",
                         "read_only_root": True, "env": ["RAYON_NUM_THREADS=4"], "platform": "linux/arm64"},
           "cap_s": CAP, "phases": schedule(), "registered_unix": time.time()}
    write_once(OUT / "registration.json", reg)
    print(sha(OUT / "registration.json"))


def bind(expected_sha, message_id):
    if sha(OUT / "registration.json") != expected_sha: raise SystemExit("registration changed since review")
    if not re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", message_id):
        raise SystemExit("need the full message UUID returned by raft task reply")
    r = subprocess.run(["raft", "task", "read", TASK, "--around", message_id, "--limit", "1"], capture_output=True, text=True)
    if r.returncode != 0: raise SystemExit(f"raft task read failed: {r.stderr.strip()}")
    head = next((l for l in r.stdout.splitlines() if f" msg={message_id} " in l), None)
    if not head or not (f"] {ME} " in head or f"] {ME}:" in head) or expected_sha not in r.stdout:
        raise SystemExit("message not found, not mine, or does not quote the registration digest")
    (OUT / "raft_message.txt").write_text(r.stdout)
    write_once(OUT / "raft_receipt.json", {"registration_sha256": expected_sha, "task": TASK, "message_id": message_id,
                                           "header": head, "read_sha256": sha(OUT / "raft_message.txt"), "bound_unix": time.time()})
    print("bound", message_id)


def run(expected_sha):
    reg_path = OUT / "registration.json"
    if sha(reg_path) != expected_sha: raise SystemExit("registration changed since review")
    receipt = json.loads((OUT / "raft_receipt.json").read_text())
    if receipt["registration_sha256"] != expected_sha: raise SystemExit("Raft receipt binds a different registration")
    reg = json.loads(reg_path.read_text())
    owner = reg["lock_owner"]
    require_lock(owner)
    attempt = OUT / "attempt"; attempt.mkdir()
    status = {p["id"]: {"status": "not-run"} for p in reg["phases"]}
    atomic(attempt / "status.json", status)
    stopped, memtotal, post = True, None, {}
    try:
        ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
        if ids != reg["identities"]: raise Abort("identities differ from registration")
        verify_qualification(reg["qualification_sha256"])
        write_once(attempt / "started.json", {"registration_sha256": expected_sha, "raft_message_id": receipt["message_id"], "unix": time.time()})
        stopped = False
        for ph in reg["phases"]:
            status[ph["id"]] = {"status": "running"}; atomic(attempt / "status.json", status)
            cell = next(c for c in CELLS if c[0] == ph["cell"])
            oc = ["--order-col", str(cell[5])] if cell[5] is not None else []
            r = run_phase(ph["id"], ph["cell"], ph["store"], cell[2], ["phase", ph["order"], *oc], attempt, owner, reg["identities"]["stores"][ph["store"]])
            if r["status"] == "ran":
                problems = scored_gate(ph, r["probe"], reg, cell[5])
                rc = json.loads((attempt / ph["id"] / "receipt.json").read_text())
                mt = rc.get("memtotal_kB")
                memtotal = memtotal or mt
                if mt is None or mt != memtotal: problems.append(f"MemTotal {mt} != cohort {memtotal}")
                r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
            status[ph["id"]] = r; atomic(attempt / "status.json", status)
            if r["status"] != "pass": stopped = True; break
    except BaseException as exc:
        stopped = True
        status = {k: ({"status": "aborted", "error": repr(exc)} if v["status"] == "running" else v) for k, v in status.items()}
        post["error"] = repr(exc)
    finally:
        for sg in SIGNALS: signal.signal(sg, signal.SIG_IGN)
        try:
            ids = identities(); ids["stores"] = {st: tree(p) for st, p in STORES.items()}
            post["identities_unchanged"] = ids == reg["identities"]
            try: verify_qualification(reg["qualification_sha256"]); post["qualification_unchanged"] = True
            except Abort as exc: post["qualification_unchanged"] = False; post["qualification_error"] = str(exc)
        except BaseException as exc: post.update({"identities_unchanged": "unverified", "postcheck_error": repr(exc)})
        post.update({"stopped_early": stopped, "cohort_MemTotal_kB": memtotal, "unix": time.time()})
        atomic(attempt / "status.json", status)
        write_once(attempt / "postcheck.json", post)
    print(json.dumps({k: v["status"] for k, v in status.items()}, indent=1))
    return 0 if post["identities_unchanged"] is True and post.get("qualification_unchanged") is True and not stopped and all(v["status"] == "pass" for v in status.values()) else 1


def identities():
    return {"supervisor_sha256": sha(Path(__file__)), "probe_source_sha256": sha(WT / "bindings/c/examples/arrow_probe.rs"),
            "build_script_sha256": sha(S / "build.sh"), "binary_sha256": sha(S / "bin/arrow_probe"),
            "launcher_sha256": sha(S / "launch.sh"), "launch_controls_sha256": sha(S / "launch_controls.sh"),
            "launch_controls_output_sha256": sha(S / "launch_controls.txt"),
            "worktree_head": subprocess.run(["git", "-C", str(WT), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip(),
            "worktree_diff_sha256": hashlib.sha256(subprocess.run(["git", "-C", str(WT), "diff", "HEAD"], capture_output=True, check=True).stdout).hexdigest(),
            "queries": {c: sha(q) for c, _, q, _, _, _ in CELLS},
            "references": {c: reference(c) for c, *_ in CELLS},
            "prepared_sidecars": {s: sha(p) for s, p in PREPARED.items()}}


def gate_controls():
    """Offline negative controls on the frozen dry-run probes: each unmutated probe must pass the scored gate, and every
    mutation must fail it. No engine runs."""
    import copy
    q = S / "qual"
    qres = json.loads((q / "QUAL.json").read_text())
    ids = json.loads((q / "identities.json").read_text())
    out = {"cases": [], "all_pass": True}
    def record(name, ok):
        out["cases"].append({"case": name, "ok": ok}); out["all_pass"] &= ok
    for cell, *_rest in CELLS:
        order_col = _rest[-1]
        values = {k: qres[cell]["probe"]["canonical"][k]["sum"] for k in ("arrow", "view", "instr")}
        reg = {"qualification_values": {cell: values}, "identities": ids}
        for order in ("arrow-first", "view-first"):
            base = json.loads((q / f"{cell}-dry-{order}" / "out/probe.json").read_text())
            ph = {"cell": cell, "order": order}
            record(f"{cell}/{order}: unmutated passes", scored_gate(ph, base, reg, order_col) == [])
            vi = [t["path"] for t in base["timed"]].index("view")
            muts = {
                "timed ms = true": lambda p: p["timed"][0].__setitem__("ms", True),
                "timed ms = inf": lambda p: p["timed"][0].__setitem__("ms", float("inf")),
                "timed ms = 0": lambda p: p["timed"][1].__setitem__("ms", 0),
                "ids_ms = true": lambda p: p["instrumented"].__setitem__("ids_ms", True),
                "convert_ms = true": lambda p: p["instrumented"].__setitem__("convert_ms", True),
                "stats_ready_ms = true": lambda p: p.__setitem__("stats_ready_ms", True),
                "view batches = true": lambda p: p["timed"][vi]["sum"].__setitem__("batches", True),
                "position = 1.0": lambda p: p["timed"][0].__setitem__("position", 1.0),
                "rows as float": lambda p: p["warmup"]["arrow"].__setitem__("rows", float(p["warmup"]["arrow"]["rows"])),
                "checksum changed": lambda p: p["instrumented"]["sum"].__setitem__("checksum", "0" * 16),
                "timed order swapped": lambda p: p["timed"].reverse(),
                "ordered missing": lambda p: p["warmup"]["view"].pop("ordered"),
                "ordered flipped": lambda p: p["timed"][0]["sum"].__setitem__("ordered", False if order_col is not None else True),
                "canonical bag changed": lambda p: p["canonical"]["view"].__setitem__("bag_sha1", "0" * 40),
                "mode changed": lambda p: p.__setitem__("mode", "qualify"),
            }
            for name, m in muts.items():
                p = copy.deepcopy(base); m(p)
                record(f"{cell}/{order}: {name} fails", scored_gate(ph, p, reg, order_col) != [])
    return out


def verify_qualification(expected):
    if sha(S / "QUAL.SHA256") != expected: raise Abort("qualification manifest changed")
    for line in (S / "QUAL.SHA256").read_text().splitlines():
        h, f = line.split("  ", 1)
        if sha(S / f) != h: raise Abort(f"qualification file {f} changed")


def qualify(owner):
    """Untimed. Per cell: probe `qualify` (establishes the frozen values), then one dry `phase` run per order, gated exactly
    like a scored phase against those values. Dry-run timings are discarded and never reported."""
    require_lock(owner)
    q = S / "qual"; q.mkdir(exist_ok=False)
    ids = identities()
    base_trees = {s: tree(p) for s, p in STORES.items()}
    ids["stores"] = base_trees
    atomic(q / "identities.json", ids)
    results, ok = {}, True
    for cell, store, qf, _, _, order_col in CELLS:
        oc = ["--order-col", str(order_col)] if order_col is not None else []
        r = run_phase(cell, cell, store, qf, ["qualify", *oc], q, owner, base_trees[store])
        if r["status"] == "ran":
            problems = qual_gate(cell, r["probe"], ids["references"][cell], order_col)
            r = {**r, "status": "pass" if not problems else "gate-failed", "problems": problems}
        results[cell] = r
        print(cell, r["status"], r.get("problems") or r.get("error") or "", flush=True)
        if r["status"] != "pass": ok = False; break
        values = {k: r["probe"]["canonical"][k]["sum"] for k in ("arrow", "view", "instr")}
        fake_reg = {"qualification_values": {cell: values}, "identities": ids}
        for order in ("arrow-first", "view-first"):
            pid = f"{cell}-dry-{order}"
            d = run_phase(pid, cell, store, qf, ["phase", order, *oc], q, owner, base_trees[store])
            if d["status"] == "ran":
                problems = scored_gate({"cell": cell, "order": order}, d["probe"], fake_reg, order_col)
                d = {"status": "pass" if not problems else "gate-failed", "problems": problems, "timings": "discarded"}
            else:
                d = {k: v for k, v in d.items() if k != "probe"}
            results[pid] = d
            print(pid, d["status"], d.get("problems") or d.get("error") or "", flush=True)
            if d["status"] != "pass": ok = False; break
        if not ok: break
    atomic(q / "QUAL.json", results)
    after = identities(); after["stores"] = {s: tree(p) for s, p in STORES.items()}
    if after != ids: print("IDENTITY DRIFT during qualification", flush=True); raise SystemExit(1)
    if not ok or len(results) != 3 * len(CELLS): raise SystemExit(1)
    controls = gate_controls()
    atomic(q / "gate_controls.json", controls)
    if not controls["all_pass"]: print("GATE CONTROLS FAILED", flush=True); raise SystemExit(1)
    rels = sorted(str(f.relative_to(S)) for f in q.rglob("*") if f.is_file()) + [
        "score_a34.py", "build.sh", "bin/arrow_probe", "probe.rs", "probe-worktree.diff", "probe-worktree.status",
        "launch.sh", "launch_controls.sh", "launch_controls.txt"]
    (S / "QUAL.SHA256").write_text("".join(f"{sha(S / r)}  {r}\n" for r in rels))
    print("frozen", sha(S / "QUAL.SHA256"), flush=True)


if __name__ == "__main__":
    for s in SIGNALS: signal.signal(s, on_signal)
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "qualify" and a[1].startswith("--owner="): qualify(a[1][8:])
    elif a == ["register"]: register()
    elif len(a) == 3 and a[0] == "bind": bind(a[1], a[2])
    elif len(a) == 2 and a[0] == "run": sys.exit(run(a[1]))
    elif a == ["schedule"]: print(json.dumps(schedule(), indent=1))
    else: raise SystemExit(__doc__)
