import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.*;
import it.unibz.inf.ontop.injection.OntopSQLOWLAPIConfiguration;
import it.unibz.inf.ontop.rdf4j.repository.OntopRepository;
import org.eclipse.rdf4j.query.*;
import org.eclipse.rdf4j.model.*;

/** Untimed source draft. Compile/run only after the exact classpath and Java25 runtime are pinned. */
public final class TinyOntop {
    static final String OWNER = "Jianlin task46 Ontop tiny qualification v1";
    static final List<String> CASES = List.of("group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false", "same_iri", "same_string", "same_lang", "datatype_int", "is_iri");
    static void lock() throws Exception {
        if (!Files.readString(Path.of("/tmp/rdf-bench.lock/owner")).trim().equals(OWNER)) throw new IllegalStateException("exact own lock required");
    }
    static String quote(String v) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                default -> { if (c < 32 || Character.isSurrogate(c)) b.append(String.format("\\u%04x", (int)c)); else b.append(c); }
            }
        }
        return b.append('"').toString();
    }
    static String json(Object v) {
        if (v == null) return "null";
        if (v instanceof String s) return quote(s);
        if (v instanceof Boolean || v instanceof Integer || v instanceof Long) return v.toString();
        if (v instanceof Map<?,?> m) {
            List<String> fields = new ArrayList<>();
            for (var e : m.entrySet()) fields.add(quote((String)e.getKey()) + ":" + json(e.getValue()));
            return "{" + String.join(",", fields) + "}";
        }
        if (v instanceof List<?> l) return "[" + String.join(",", l.stream().map(TinyOntop::json).toList()) + "]";
        throw new IllegalArgumentException("unsupported JSON value " + v.getClass());
    }
    static Map<String,Object> term(Value v) {
        Map<String,Object> t = new LinkedHashMap<>();
        if (v instanceof IRI iri) { t.put("type", "uri"); t.put("value", iri.stringValue()); }
        else if (v instanceof BNode b) { t.put("type", "bnode"); t.put("value", b.getID()); }
        else if (v instanceof Literal l) {
            t.put("type", "literal"); t.put("value", l.getLabel());
            t.put("datatype", l.getDatatype().stringValue());
            l.getLanguage().ifPresent(lang -> t.put("xml:lang", lang));
        } else throw new IllegalArgumentException("unknown RDF term class " + v.getClass());
        return t;
    }
    static void save(Path p, Object value) throws Exception { Files.writeString(p, json(value) + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW); }
    public static void main(String[] args) throws Exception {
        if (Runtime.version().feature() != 25) throw new IllegalStateException("Java25 only");
        if (args.length != 2) throw new IllegalArgumentException("source-root fresh-output-root");
        lock();
        Path source = Path.of(args[0]).toAbsolutePath(), out = Path.of(args[1]).toAbsolutePath();
        Files.createDirectory(out);
        Path db = out.resolve("tiny.duckdb");
        Class.forName("org.duckdb.DuckDBDriver");
        String url = "jdbc:duckdb:" + db;
        try (Connection connection = DriverManager.getConnection(url); java.sql.Statement statement = connection.createStatement()) {
            for (String line : Files.readAllLines(source.resolve("source.sql"))) if (!line.isBlank()) statement.execute(line);
            try (ResultSet result = statement.executeQuery("SELECT version(), count(*) FROM source_terms")) {
                if (!result.next() || result.getLong(2) != 11) throw new IllegalStateException("SQL source must have all eleven frozen rows");
                save(out.resolve("jdbc-source.json"), Map.of("duckdb_version", result.getString(1), "source_rows", result.getLong(2), "java", Runtime.version().toString()));
            }
        }
        lock();
        var config = OntopSQLOWLAPIConfiguration.defaultBuilder().r2rmlMappingFile(source.resolve("mapping.ttl").toFile()).jdbcUrl(url).jdbcDriver("org.duckdb.DuckDBDriver").build();
        try (OntopRepository repository = OntopRepository.defaultRepository(config)) {
            repository.init();
            try (var connection = repository.getConnection()) {
                for (String name : CASES) {
                    lock();
                    String sparql = Files.readString(source.resolve("queries").resolve(name + ".rq"));
                    Map<String,Object> record = new LinkedHashMap<>(); record.put("query", sparql);
                    try {
                        if (name.equals("ask_false")) record.put("answer", Map.of("boolean", connection.prepareBooleanQuery(QueryLanguage.SPARQL, sparql).evaluate()));
                        else try (TupleQueryResult result = connection.prepareTupleQuery(QueryLanguage.SPARQL, sparql).evaluate()) {
                            List<String> variables = List.copyOf(result.getBindingNames());
                            List<Object> rows = new ArrayList<>();
                            while (result.hasNext()) {
                                BindingSet row = result.next(); Map<String,Object> values = new LinkedHashMap<>();
                                for (String variable : variables) { Value v = row.getValue(variable); if (v != null) values.put(variable, term(v)); }
                                rows.add(values);
                            }
                            record.put("answer", Map.of("head", Map.of("vars", variables), "results", Map.of("bindings", rows)));
                        }
                    } catch (Exception error) { record.put("error_class", error.getClass().getName()); record.put("error", String.valueOf(error.getMessage())); }
                    save(out.resolve(name + ".json"), record);
                }
            }
        }
        lock();
        save(out.resolve("completed.json"), Map.of("cases_attempted", CASES.size(), "scored", false, "full_workload_qualified", false));
    }
}
