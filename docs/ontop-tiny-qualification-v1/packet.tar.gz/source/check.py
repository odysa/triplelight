#!/usr/bin/env python3
"""Strict typed-result checks, no engine import and no expected metadata given to the producer."""
import json
from collections import Counter
from pathlib import Path
CASES=['group','plain','distinct','count','distinct_count','empty','unbound','ask_false','same_iri','same_string','same_lang','datatype_int','is_iri']
def key(t):
    if t is None:return None
    if t['type']=='literal':
        lang=t.get('xml:lang','').lower();dt=t.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if lang else 'http://www.w3.org/2001/XMLSchema#string')
        return ('literal',t['value'],dt,lang)
    return (t['type'],t['value'])
def bag(a):return Counter(tuple(key(r.get(v)) for v in a['head']['vars']) for r in a['results']['bindings'])
def expected(source):
    ref=json.loads((source/'consumer-fixture-jena.json').read_text());objects=[r['o'] for r in ref['results']['bindings']]
    def select(terms):return {'head':{'vars':['o']},'results':{'bindings':[{'o':t} for t in terms]}}
    plain=select(objects)
    count={'head':{'vars':['n']},'results':{'bindings':[{'n':{'type':'literal','value':'9','datatype':'http://www.w3.org/2001/XMLSchema#integer'}}]}}
    return {'group':ref,'plain':plain,'distinct':plain,'count':count,'distinct_count':count,'empty':select([]),
       'unbound':{'head':{'vars':['o','missing']},'results':plain['results']},'ask_false':{'boolean':False},
       'same_iri':select([t for t in objects if t['type']=='uri' and t['value']=='urn:iri']),
       'is_iri':select([t for t in objects if t['type']=='uri']),
       'same_string':select([t for t in objects if key(t)==('literal','urn:iri','http://www.w3.org/2001/XMLSchema#string','')]),
       'same_lang':select([t for t in objects if t.get('xml:lang','').lower()=='en']),
       'datatype_int':select([t for t in objects if t.get('datatype')=='http://www.w3.org/2001/XMLSchema#int'])}
def evaluate(source,out):
    exp=expected(source);verdicts={};details={}
    for name in CASES:
        try:
            record=json.loads((out/(name+'.json')).read_text());a=record['answer'];e=exp[name]
            checks={'no_query_error':'error' not in record and 'error_class' not in record}
            if name=='ask_false':checks['false_boolean']=(type(a.get('boolean')) is bool and a['boolean'] is False and set(a)=={'boolean'})
            else:checks.update(projection=a['head']['vars']==e['head']['vars'],strict_bag=bag(a)==bag(e))
            if name=='unbound':checks['every_missing_unbound']=all('missing' not in row for row in a['results']['bindings'])
            verdicts[name]=all(v is True for v in checks.values());details[name]=checks
        except (OSError,ValueError,KeyError,TypeError) as error:
            verdicts[name]=False;details[name]={'driver_or_shape_error':repr(error)}
    return {'case_verdicts':verdicts,'checks':details,'tiny_answer_admitted':all(v is True for v in verdicts.values()),'full_workload_qualified':False,'scored':False}
