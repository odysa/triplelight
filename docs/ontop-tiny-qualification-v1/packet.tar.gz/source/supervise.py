#!/usr/bin/env python3
import argparse,hashlib,json,os,signal,subprocess
from pathlib import Path
from check import evaluate
ROOT=Path(__file__).resolve().parent
OWNER='Jianlin task46 Ontop tiny qualification v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def lock():
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip()!=OWNER:raise RuntimeError('exact own lock required')
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--freeze-sha256',required=True);p.add_argument('--runtime',type=Path,required=True);p.add_argument('--runtime-sha256',required=True);a=p.parse_args()
    lock()
    if not a.out.is_absolute():raise RuntimeError('fresh absolute output required')
    if sha(ROOT/'FREEZE.json')!=a.freeze_sha256 or sha(a.runtime)!=a.runtime_sha256:raise RuntimeError('freeze/runtime mismatch')
    freeze=json.loads((ROOT/'FREEZE.json').read_text());runtime=json.loads(a.runtime.read_text())
    def intact():return all(sha(ROOT/n)==h for n,h in freeze['files'].items()) and all(sha(f['path'])==f['sha256'] for f in runtime['files'])
    if not intact():raise RuntimeError('source/runtime file changed')
    files=runtime['files']
    paths=[f['path'] for f in files]
    if not files or len(paths)!=len(set(paths)) or not all(Path(n).is_absolute() for n in paths):raise RuntimeError('runtime manifest must enumerate unique absolute files')
    roles={f['role'] for f in files}
    if not {'java','jdk_release','jdk_libjvm','jdk_modules','jar','class'}.issubset(roles):raise RuntimeError('incomplete runtime coverage')
    indexed={f['path']:f for f in files}
    if runtime['java_path'] not in indexed or indexed[runtime['java_path']]['role']!='java':raise RuntimeError('unhashed Java executable')
    if str(Path(runtime['java_path']).resolve())!=runtime['java_real_path']:raise RuntimeError('Java real path mismatch')
    entries=runtime['classpath_entries']
    if not entries or not all(Path(e).is_absolute() for e in entries) or any('*' in e for e in entries):raise RuntimeError('classpath must be explicit and absolute')
    jars={f['path'] for f in files if f['role']=='jar'}
    if jars!={e for e in entries if e.endswith('.jar')}:raise RuntimeError('classpath jar set is not fully hashed')
    classes=[f for f in files if f['role']=='class']
    if not any(Path(f['path']).name=='TinyOntop.class' and str(Path(f['path']).parent) in entries for f in classes):raise RuntimeError('main class is not hashed on classpath')
    if runtime['java_feature']!=25:raise RuntimeError('Java25 only')
    a.out.mkdir(exist_ok=False)
    (a.out/'tmp').mkdir()
    result={'scored':False,'timeout':False,'full_workload_qualified':False}
    try:
        with (a.out/'child.stdout').open('wb') as stdout,(a.out/'child.stderr').open('wb') as stderr:
            child=subprocess.Popen([runtime['java_path'],'-Xmx2g','-Djava.io.tmpdir='+str(a.out/'tmp'),'--enable-native-access=ALL-UNNAMED','-cp',os.pathsep.join(runtime['classpath_entries']),'TinyOntop',str(ROOT),str(a.out/'child')],stdout=stdout,stderr=stderr,start_new_session=True)
            try:result['exit_code']=child.wait(timeout=120)
            except subprocess.TimeoutExpired:
                result['timeout']=True;os.killpg(child.pid,signal.SIGKILL);result['exit_code']=child.wait()
        result['query_checks']=evaluate(ROOT,a.out/'child')
        completed=json.loads((a.out/'child/completed.json').read_text()) if (a.out/'child/completed.json').is_file() else {}
        result['driver_completed']=completed.get('cases_attempted')==13 and completed.get('full_workload_qualified') is False
    finally:
        result['source_runtime_unchanged']=intact()
        result['tiny_answer_admitted']=(result.get('exit_code')==0 and not result['timeout'] and result['source_runtime_unchanged'] and result.get('driver_completed') is True and result.get('query_checks',{}).get('tiny_answer_admitted') is True)
        (a.out/'supervisor.json').write_text(json.dumps(result,indent=2)+'\n')
    lock()
    if result.get('exit_code')!=0 or result['timeout'] or not result['source_runtime_unchanged']:raise SystemExit(1)
if __name__=='__main__':main()
