import java.util.*;
public class JsonControls {
 public static void main(String[] args) {
  if (Runtime.version().feature()!=25) throw new IllegalStateException("Java25 only");
  List<String> values=List.of("plain", "a\"b\\c", "line\n\t\r\u0000", new String(Character.toChars(0x1F600)), "a|b ^c @d - e");
  Map<String,Object> out=new LinkedHashMap<>();out.put("java_feature", Runtime.version().feature());out.put("values",values);out.put("false",false);out.put("absent",null);
  System.out.println(TinyOntop.json(out));
 }
}
