# COTTAS Python adapter tiny qualification plan

COTTAS stores RDF as a compressed Parquet triple table and uses DuckDB for triple-pattern scans. `pycottas.COTTASStore` exposes those scans to RDFLib's SPARQL evaluator. Qualify the packaged Python adapter and its read-only file format. This profile is a separate storage path from the earlier typed-triples SQL and DuckDB RDF mapping runs.

Use the pinned pycottas 1.1.0 release wheel and its PyOxigraph 0.3.18 requirement, DuckDB 1.5.0, RDFLib 7.6.0 and a complete wheel-only dependency set on the pinned macOS ARM64 CPython 3.12.12. Install into private scratch, resolve no packages during the setup and run pip check. Record hashes and installed-file identities, including the PyOxigraph and DuckDB modules. Only PyPI metadata and the small pycottas wheel have been inspected.

## Boundaries

1. In an isolated producer process, call the released `rdf2cottas` on the frozen nine-term fixture with the public `spo` setting and in-memory DuckDB staging. It parses the N-Triples via PyOxigraph, writes an immutable COTTAS file and exits. The wheel source streams pyoxigraph.parse and does not create a PyOxigraph Store. The DuckDB export applies DISTINCT and SPO sort before writing Parquet. Capture separate parser diagnostics using the public PyOxigraph parse iterator, and never use those diagnostics to alter the file. Record the exact output file hash. No mutation or query workload timing is planned.
2. In two fresh reader processes, open the exact same COTTAS file with RDFLib's installed normalization default and with normalization disabled. Read `COTTASDocument.search` with raw N3 strings, then read direct typed triples and length through `Graph(store=COTTASStore(...))`. Compare distinct fixture triples and exact typed bags against the frozen reference. Record Parquet row order and index metadata as diagnostics. Save all the raw N3 and typed results, and the pre/post artifact hash. No named-graph or write claims follow from this fixture.
3. Run the same `FILTER(false)` control through the shared RDFLib evaluator and report it independently. It failed in earlier RDFLib profiles, so the same behavior is expected here. This is not a standalone SPARQL-to-SQL engine admission.

If count, encoded term strings and typed readers disagree, report the earliest observed boundary at which the term changes. Do not transfer an observed behavior of a different PyOxigraph release onto the streaming parser. Keep any failure, use separate stage caps and fresh output directories, and hold the shared machine lock only for setup and the small run.

- [COTTAS Python package](https://pypi.org/project/pycottas/1.1.0/)
- [COTTAS Python repository](https://github.com/cottas-rdf/pycottas)
- [COTTAS Python documentation](https://pycottas.readthedocs.io/en/latest/)
