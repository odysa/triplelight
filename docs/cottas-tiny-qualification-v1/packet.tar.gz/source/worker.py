"""Produce the tiny COTTAS file, or observe it under one RDFLib read profile."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys

from common import HERE, PINS, lock, sha, write

XSD = 'http://www.w3.org/2001/XMLSchema#'
LANGSTRING = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
FILTER_FALSE = 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }'


def n3_term(text):
    """Decode only the lexical forms used in this frozen fixture, without RDFLib."""
    if text.startswith('<') and text.endswith('>'):
        return {'type':'uri','value':text[1:-1]}
    value,end = json.JSONDecoder().raw_decode(text)
    if not isinstance(value,str):
        raise ValueError("expected a quoted RDF literal")
    extra=text[end:]
    term={'type':'literal','value':value}
    if extra.startswith('@'):
        term['language']=extra[1:]
    elif extra.startswith('^^<') and extra.endswith('>'):
        term['datatype']=extra[3:-1]
    elif extra:
        raise ValueError(f'unexpected fixture N3 suffix {extra!r}')
    return term


def rdf_key(term):
    if term['type']=='uri':
        return 'uri',term['value'],'',''
    language=term.get('language',term.get('xml:lang','')).lower()
    return 'literal',term['value'],term.get('datatype') or (LANGSTRING if language else XSD+'string'),language


def coverage(record):
    ref=json.loads((HERE/'consumer-fixture-jena.json').read_bytes())
    expected=Counter((('uri','urn:s','',''),('uri','urn:v','',''),rdf_key(row['o']))
                     for row in ref['results']['bindings'])
    stored=Counter(tuple(rdf_key(n3_term(t)) for t in row) for row in record['raw_n3'])
    typed=Counter(tuple(rdf_key(t) for t in row) for row in record['typed'])
    return {'count_nine':type(record['count']) is int and record['count']==9,
            'triple_layout':record['quad_table'] is False,
            'raw_exact':stored==expected,'typed_exact':typed==expected,
            'raw_matches_ordered_file':Counter(tuple(r) for r in record['raw_n3'])==
                                        Counter(tuple(r) for r in record['ordered_file_n3'])}


def produce(args,record):
    import pycottas
    import pyoxigraph
    fixture=HERE/'consumer-fixture.nt'
    if args.file.exists() or args.file.is_symlink():
        raise RuntimeError('producer must use a fresh file path')
    expected_mime=pycottas.file_ext_2_mime_type[pycottas.get_file_extension(file_path=str(fixture))]
    record['step']='parser-diagnostic'
    record['parser_n3']=[[str(term) for term in triple] for triple in
                         pyoxigraph.parse(str(fixture),base_iri=None,mime_type=expected_mime)]
    record['parser_mime_type']=expected_mime
    record['step']='convert'
    pycottas.rdf2cottas(str(fixture),str(args.file),index='spo',disk=False)
    with args.file.open('rb') as stream:
        first=stream.read(4)
        stream.seek(-4,2)
        last=stream.read()
    if first!=b'PAR1' or last!=b'PAR1':
        raise RuntimeError('expected Parquet file boundaries')
    record.update(step='complete',file_sha256=sha(args.file),file_bytes=args.file.stat().st_size)


def read(args,record):
    import duckdb
    import pycottas
    import rdflib

    if args.file.is_symlink() or not args.file.is_file() or sha(args.file)!=args.file_sha256:
        raise RuntimeError('COTTAS file identity mismatch')
    default=rdflib.NORMALIZE_LITERALS
    rdflib.NORMALIZE_LITERALS=default if args.mode=='default' else False
    record.update(literal_default=default,normalize_literals=rdflib.NORMALIZE_LITERALS)

    def term(value):
        if isinstance(value,rdflib.URIRef):
            return {'type':'uri','value':str(value)}
        if isinstance(value,rdflib.Literal):
            result={'type':'literal','value':str(value)}
            if value.language:
                result['language']=value.language
            if value.datatype:
                result['datatype']=str(value.datatype)
            return result
        raise TypeError(f'unexpected fixture term {type(value).__name__}')

    record['step']='raw-reader'
    document=pycottas.COTTASDocument(str(args.file))
    record['raw_n3']=document.search((None,None,None),results_in_n3=True)
    record['quad_table']=document.is_quad_table
    record['step']='typed-reader'
    graph=rdflib.Graph(store=pycottas.COTTASStore(str(args.file)))
    try:
        record['count']=len(graph)
        record['typed']=[[term(t) for t in row] for row in graph.triples((None,None,None))]
        record['step']='shared-evaluator'
        try:
            answer=graph.query(FILTER_FALSE,use_store_provided=False)
            columns=[str(v) for v in answer.vars]
            rows=[[None if value is None else term(value) for value in row] for row in answer]
            record['shared_evaluator']={'columns':columns,'rows':rows,'passes':columns==['o'] and not rows}
        except Exception as exc:
            record['shared_evaluator']={'error':repr(exc),'passes':False}
    finally:
        graph.close()
    record['step']='parquet-metadata'
    try:
        with duckdb.connect(':memory:') as connection:
            record['ordered_file_n3']=connection.execute(
                'SELECT s, p, o FROM read_parquet(?, file_row_number=true) ORDER BY file_row_number',
                [str(args.file)]).fetchall()
            record['parquet_kv']={key.decode():value.decode() for key,value in connection.execute(
                'SELECT key, value FROM parquet_kv_metadata(?)',[str(args.file)]).fetchall()}
        record['sort_diagnostic']=record['ordered_file_n3']==sorted(record['ordered_file_n3'])
    except Exception as exc:
        record['metadata_error']=repr(exc)
        record['ordered_file_n3']=[]
    record['checks']=coverage(record)
    record['file_sha256']=sha(args.file)
    if record['file_sha256']!=args.file_sha256:
        raise RuntimeError('reader changed the Parquet file')
    record['step']='complete'


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('produce','default','preserve'),required=True)
    parser.add_argument('--file',type=Path,required=True)
    parser.add_argument('--file-sha256')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    lock('storage')
    if not args.file.is_absolute() or not args.out.is_absolute() or sha(Path(sys.executable))!=PINS['interpreter_sha256']:
        raise RuntimeError('worker runtime or paths do not match the plan')
    record={'mode':args.mode,'step':'import'}
    try:
        if args.mode=='produce':
            produce(args,record)
        else:
            read(args,record)
    except Exception as exc:
        record['error']=repr(exc)
    lock('storage')
    write(args.out,record)


if __name__=='__main__':
    main()
