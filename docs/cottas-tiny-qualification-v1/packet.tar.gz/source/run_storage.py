"""Run producer then the two separate reader processes, with frozen identities."""
import argparse
import json
from pathlib import Path
import sys
import time

from common import HERE, ROOT, lock, run, sha, source_identity, write
from worker import coverage


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-sha256',required=True)
    parser.add_argument('--setup-sha256',required=True)
    args=parser.parse_args()
    lock('storage')
    setup=ROOT/'SETUP.json'
    runtime_path=ROOT/'adjacent-import.stdout'
    python=ROOT/'venv/bin/python'

    def identity():
        source_identity(args.source_sha256)
        if sha(setup)!=args.setup_sha256:
            raise RuntimeError('wrong setup receipt digest')
        receipt=json.loads(setup.read_bytes())
        if (receipt['source_sha256']!=args.source_sha256 or receipt['rdf_data_opened'] is not False
                or receipt['state']!='ready' or sha(runtime_path)!=receipt['runtime_sha256']):
            raise RuntimeError('setup did not produce the announced runtime')
        runtime=json.loads(runtime_path.read_bytes())
        if sha(python)!=runtime['python_sha256'] or sha(Path(sys.executable))!=runtime['python_sha256']:
            raise RuntimeError('Python executable changed')
        if any(sha(ROOT/'venv'/name)!=digest for name,digest in runtime['installed'].items()):
            raise RuntimeError('installed runtime changed')

    identity()
    out=ROOT/'attempt-1'
    out.mkdir()
    (out/'tmp').mkdir()
    file=out/'fixture.cottas'
    hash_record=None
    deadline=time.monotonic()+120
    result={'stages':[], 'source_sha256':args.source_sha256,'setup_sha256':args.setup_sha256,
            'identity_postcheck':False,'full_workload_qualified':False}
    try:
        for mode in ('produce','default','preserve'):
            stage={'mode':mode}
            result['stages'].append(stage)
            if mode!='produce' and hash_record is None:
                stage['state']='skipped-producer'
                continue
            name=f'{mode}.json'
            command=[str(python),'-E','-s','-B',str(HERE/'worker.py'),'--mode',mode,
                     '--file',str(file),'--out',str(out/name)]
            if hash_record is not None:
                command+=['--file-sha256',hash_record]
            stage['exit']=run('storage',deadline,command,out,mode)
            if stage['exit']:
                stage['state']='worker-error'
                continue
            record=json.loads((out/name).read_bytes())
            stage['record']=name
            if record['mode']!=mode:
                raise RuntimeError('worker record mode mismatch')
            if record['step']!='complete' or 'error' in record:
                stage.update(state='stage-error',failed_step=record['step'])
                continue
            if mode=='produce':
                hash_record=record['file_sha256']
                if sha(file)!=hash_record or file.stat().st_size!=record['file_bytes']:
                    raise RuntimeError('producer artifact identity mismatch')
                file.chmod(0o444)
            else:
                if sha(file)!=hash_record or record['checks']!=coverage(record):
                    raise RuntimeError('reader identity or answer reducer disagreement')
                stage['checks']=record['checks']
            stage['state']='observed'
        identity()
        lock('storage')
        result['identity_postcheck']=True
    finally:
        write(out/'SUPERVISOR.json',result)


if __name__=='__main__':
    main()
