"""Recompute COTTAS fixture observations from an extracted evidence packet."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

XSD = 'http://www.w3.org/2001/XMLSchema#'
LANGSTRING = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
FIXTURE_LITERAL = re.compile(r'(?P<text>"(?:[^"\\]|\\.)*")(?:(?:@(?P<lang>[A-Za-z-]+))|(?:\^\^<(?P<type>[^>]+)>))?\Z')


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def native_key(value):
    if value['type']=='uri':
        return 'uri',value['value'],'',''
    lang=value.get('language',value.get('xml:lang','')).lower()
    dtype=value.get('datatype') or (LANGSTRING if lang else XSD+'string')
    return 'literal',value['value'],dtype,lang


def encoded_key(text):
    if text.startswith('<') and text.endswith('>'):
        return 'uri',text[1:-1],'',''
    matched=FIXTURE_LITERAL.fullmatch(text)
    if matched is None:
        raise ValueError('outside the frozen fixture N3 subset')
    lang=(matched['lang'] or '').lower()
    dtype=matched['type'] or (LANGSTRING if lang else XSD+'string')
    return 'literal',json.loads(matched['text']),dtype,lang


def main():
    args=argparse.ArgumentParser()
    args.add_argument('packet',type=Path)
    root=args.parse_args().packet
    run=root/'attempt'
    setup=read(root/'SETUP.json')
    runtime=read(root/'RUNTIME.json')
    assert setup['state']=='ready' and setup['rdf_data_opened'] is False
    assert setup['runtime_sha256']==sha(root/'RUNTIME.json') and len(runtime['installed'])==3943
    source=root/'source'
    assert sha(source/'FREEZE.json')==setup['source_sha256']
    assert all(sha(source/n)==digest for n,digest in read(source/'FREEZE.json').items())
    summary=read(run/'SUPERVISOR.json')
    assert summary['identity_postcheck'] is True and summary['full_workload_qualified'] is False
    assert summary['source_sha256']==setup['source_sha256'] and summary['setup_sha256']==sha(root/'SETUP.json')
    ref=read(source/'consumer-fixture-jena.json')
    expected=Counter((('uri','urn:s','',''),('uri','urn:v','',''),native_key(row['o']))
                     for row in ref['results']['bindings'])
    assert len(expected)==sum(expected.values())==9
    artifact=run/'fixture.cottas'
    content=artifact.read_bytes()
    assert content[:4]==content[-4:]==b'PAR1'
    assert [s['mode'] for s in summary['stages']]==['produce','default','preserve']
    assert all(s['state']=='observed' and s['exit']==0 for s in summary['stages'])
    raw_producer=read(run/'produce.json')
    assert raw_producer['file_bytes']==len(content) and raw_producer['file_sha256']==sha(artifact)
    canonical=lambda records:Counter(tuple(encoded_key(x) for x in row) for row in records)
    assert canonical(raw_producer['parser_n3'])==expected
    encoded_producer=Counter(tuple(row) for row in raw_producer['parser_n3'])
    audit=[]
    for stage in summary['stages'][1:]:
        record=read(run/stage['record'])
        assert record['mode']==stage['mode'] and record['step']=='complete'
        assert record['normalize_literals'] is (stage['mode']=='default')
        assert record['file_sha256']==sha(artifact)
        in_file=Counter(tuple(row) for row in record['ordered_file_n3'])
        document=Counter(tuple(row) for row in record['raw_n3'])
        assert in_file==encoded_producer==document
        assert record['ordered_file_n3']==sorted(record['ordered_file_n3'])
        assert record['parquet_kv']=={'index':'spo'}
        observed=Counter(tuple(native_key(t) for t in row) for row in record['typed'])
        assert sum(observed.values())==9
        checks={'count_nine':type(record['count']) is int and record['count']==9,
                'triple_layout':record['quad_table'] is False,'raw_exact':canonical(record['raw_n3'])==expected,
                'typed_exact':observed==expected,'raw_matches_ordered_file':in_file==document}
        assert checks==record['checks']==stage['checks']
        evaluator=record['shared_evaluator']
        assert evaluator['columns']==['o'] and len(evaluator['rows'])==9 and evaluator['passes'] is False
        audit.append({'normalization':stage['mode'],'checks':checks,'graph_count':record['count'],
                      'raw_object_n3':[row[2] for row in record['ordered_file_n3']],
                      'typed_missing':sorted((expected-observed).elements()),
                      'typed_additional':sorted((observed-expected).elements()),
                      'shared_filter_false_rows':len(evaluator['rows'])})
    print(json.dumps({'parquet_bytes':len(content),'parquet_sha256':sha(artifact),
                      'parser_rows':len(encoded_producer),'storage_checks':audit},indent=2))


if __name__=='__main__':
    main()
