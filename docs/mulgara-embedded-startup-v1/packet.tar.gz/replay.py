"""Reconcile the saved Mulgara build and startup evidence without Java."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_freeze(name, expected):
    source = ROOT / name
    freeze = source / "FREEZE.json"
    require(digest(freeze) == expected, "source freeze digest mismatch")
    files = json.loads(freeze.read_text())["files"]
    require(set(files) | {"FREEZE.json"} == {p.name for p in source.iterdir()}, "freeze membership mismatch")
    for filename, sha in files.items():
        require(digest(source / filename) == sha, f"source member drift: {filename}")
    return len(files)


def read(path):
    return json.loads((ROOT / path).read_text())


def replay():
    build = read("build-v3/BUILD.json")
    fixture = read("fixture-v1/FIXTURE.json")
    n_build = verify_freeze("build-source", build["freeze_sha256"])
    n_fixture = verify_freeze("fixture-source", fixture["freeze_sha256"])
    require(fixture["build_receipt_sha256"] == digest(ROOT / "build-v3/BUILD.json")
            and fixture["artifact_sha256"] == build["artifact"]["sha256"], "fixture used another build")
    for filename, key in (("ANT-CLOSURE.json", "target_closure_sha256"), ("VENDORED-JARS.json", "vendored_jars_sha256")):
        require(digest(ROOT / "build-v3/setup" / filename) == build[key], f"{filename} digest mismatch")
    java = (ROOT / "build-v3/setup/java.stderr").read_text()
    compiler = (ROOT / "build-v3/setup/javac.stdout").read_text() + (ROOT / "build-v3/setup/javac.stderr").read_text()
    require("1.8.0_514" in java and "1.8.0_514" in compiler and "os.arch = aarch64" in java, "JDK identity mismatch")
    archive = read("build-v3/setup/JDK-ARCHIVE.json")
    require(archive["sha256"] == build["jdk_archive_sha256"] == read("AZUL.json")["sha256"],
            "JDK archive digest chain mismatch")
    require(build["pass"] is True and build["server_started"] is False and build["rdf_fixture_executed"] is False,
            "unexpected build scope or outcome")
    require("BUILD SUCCESSFUL" in (ROOT / "build-v3/setup/embedded-dist.stdout").read_text(), "build log missing")
    for name in ("build-v3/setup", "fixture-v1/diagnostics"):
        require((ROOT / name / "network-denial.stdout").read_text().strip() == "loopback bind denied",
                "network-denial control missing")

    require(fixture["completed"] is False and fixture["phase"] == "load-and-check"
            and fixture["exit_codes"] == {"compile": 0, "load": 1, "network-denial": 0},
            "unexpected startup gate")
    trace = (ROOT / "fixture-v1/diagnostics/load.stdout").read_text().splitlines()
    require([line for line in trace if line.startswith("FIXTURE\t")] == ["FIXTURE\tstage\tload"],
            "fixture operation advanced past construction")
    failure = (ROOT / "fixture-v1/diagnostics/load.stderr").read_text()
    for event in ("java.rmi.server.ExportException", "Operation not permitted (Bind failed)",
                  "JotmTransactionManagerFactory.<init>", "Failed to bootstrap system-model",
                  "Host name aliases for this server are: [redacted]"):
        require(event in failure, f"missing startup evidence: {event}")
    return {
        "build_pass": True,
        "source_commit": build["source_commit"],
        "jar": build["artifact"],
        "java": "Zulu 8u514 macOS ARM64",
        "jdk_archive_bytes": archive["bytes"],
        "jdk_metadata_bytes": read("AZUL.json")["metadata_bytes"],
        "jdk_archive_sha256": archive["sha256"],
        "svnversion": read("build-v3/setup/LOCAL-TOOLS.json")["svnversion"],
        "frozen_members": {"build": n_build, "fixture": n_fixture},
        "earlier_build_stops": [read(f"build-v{n}/BUILD.json")["phase"] for n in (1, 2)],
        "network_denial_controls": 2,
        "fixture_compiled": True,
        "network_free_bootstrap": "RMI bind denied during JOTM initialization and system-model bootstrap",
        "rdf_loaded": False,
        "query_labels_run": 0,
        "reopen_run": False,
        "workload_timing": False,
    }


if __name__ == "__main__":
    with Path(sys.argv[1]).open("x") as handle:
        json.dump(replay(), handle, indent=2, sort_keys=True)
        handle.write("\n")
