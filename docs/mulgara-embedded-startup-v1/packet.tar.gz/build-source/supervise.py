"""Build the pinned Mulgara embedded distribution without starting it."""

import argparse
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import time
import tarfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/rdf-jianlin-mulgara39-build-v3")
LOCK = Path("/private/tmp/rdf-bench.lock/owner")
OWNER = "Jianlin task39 Mulgara build v3\n"
REPO = "https://github.com/quoll/mulgara.git"
COMMIT = "a84257dae77b6c14a20b9013062bb469675f10b5"
TREE = "a1b7102c6accd68d06c03dfef372d263b6641aa5"
JDK_URL = "https://cdn.azul.com/zulu/bin/zulu8.98.0.201-ca-jdk8.0.514-macosx_aarch64.tar.gz"
JDK_SHA = "792935f732653f5c4fd4cdc68e3ade65cb1fa1fda6b6769fc5dd8098b330b298"
JDK_DOWNLOAD_CAP = 104 * 1024 * 1024
GIB = 1 << 30


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write("\n")


def source_check(expected):
    path = HERE / "FREEZE.json"
    require(sha(path) == expected, "freeze digest drift")
    files = load(path)["files"]
    current = {p.name for p in HERE.iterdir()}
    require(current == set(files) | {"FREEZE.json"}, "source file inventory drift")
    for name, digest in files.items():
        p = HERE / name
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, f"source drift: {name}")


def check_lock():
    require(LOCK.read_text() == OWNER, "exact own lock required")


def bytes_used():
    allocated = 0
    logical = 0
    for path in ROOT.rglob("*"):
        try:
            item = path.lstat()
        except FileNotFoundError:
            continue
        allocated += item.st_blocks * 512
        if stat.S_ISREG(item.st_mode):
            logical += item.st_size
    return allocated, logical


def guard(deadline):
    check_lock()
    require(time.monotonic() < deadline, "phase deadline")
    require(shutil.disk_usage(ROOT).free >= 42 * GIB, "42 GiB free-space guard")
    allocated, logical = bytes_used()
    require(allocated < 4 * GIB and logical < 8 * GIB, "owned root size guard")


def command(args, env, cwd, out, label, deadline):
    stdout_path = out / (label + ".stdout")
    limit = min(deadline, time.monotonic() + 300)
    guard(limit)
    with stdout_path.open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(args, stdout=stdout, stderr=stderr, cwd=cwd, env=env, start_new_session=True)
        try:
            while child.poll() is None:
                guard(limit)
                require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                        "diagnostic output limit")
                time.sleep(0.25)
            require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                    "diagnostic output limit")
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    guard(limit)
    return child.returncode, stdout_path


def environment(java_home=None):
    env = {
        "PATH": "/usr/bin:/bin:/usr/sbin",
        "HOME": str(ROOT / "home"),
        "TMPDIR": str(ROOT / "tmp"),
        "LANG": "C",
        "LC_ALL": "C",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_TERMINAL_PROMPT": "0",
    }
    if java_home is not None:
        env.update({
            "JAVA_HOME": str(java_home),
            "JAVA_TOOL_OPTIONS": f"-Djava.io.tmpdir={ROOT / 'tmp'} -Duser.home={ROOT / 'home'}",
        })
    return env


def ant_closure(source):
    import xml.etree.ElementTree as ET

    root_build = ET.parse(source / "build.xml").getroot()
    imports = [
        source / item.attrib["file"].replace("${jar.src.dir}", "src/jar")
        for item in root_build.findall("import")
    ]
    targets = {}
    for file, root in [(source / "build.xml", root_build), *[(p, ET.parse(p).getroot()) for p in imports]]:
        for item in root.findall("target"):
            name = item.attrib["name"]
            # Ant gives main-file targets priority over imported ones.
            targets.setdefault(name, (file, item))
    closure = {}
    forbidden = {"get", "junit", "junitlauncher", "scp", "sshexec", "ant", "subant"}
    pending = ["embedded-dist"]
    while pending:
        name = pending.pop()
        if name in closure:
            continue
        require(name in targets, f"unresolved Ant target: {name}")
        file, item = targets[name]
        direct = [target.strip() for target in item.attrib.get("depends", "").split(",") if target.strip()]
        calls = [child.attrib["target"] for child in item.iter("antcall") if "target" in child.attrib]
        tasks = sorted({child.tag for child in item.iter() if child is not item})
        require(not forbidden.intersection(tasks), f"non-build task under {name}")
        version_probe = name == "run-svnversion" and file == source / "common.xml"
        require(version_probe or (not name.startswith(("start", "run-", "stop")) and not name.endswith("-test")),
                f"launch or test target in build closure: {name}")
        closure[name] = {"file": str(file.relative_to(source)), "depends": direct, "antcalls": calls, "tasks": tasks}
        pending.extend(direct + calls)
    require(closure["embedded-dist"]["depends"] == load(HERE / "EMBEDDED_DIRECT.json"),
            "direct embedded-dist dependencies drifted")
    return closure


def execute(freeze):
    import sys

    check_lock()
    require(shutil.disk_usage(ROOT.parent).free >= 48 * GIB, "48 GiB launch floor")
    ROOT.mkdir()
    deadline = time.monotonic() + 540
    for name in ("home", "tmp", "setup", "source", "jdk"):
        (ROOT / name).mkdir()
    out = ROOT / "setup"
    source = ROOT / "source"
    env = environment()
    save(out / "LOCAL-TOOLS.json", {"svnversion": shutil.which("svnversion", path=env["PATH"])})
    phase = "acquire-source"

    def step(args, label, cwd=source, local_env=env):
        rc, stdout = command(args, local_env, cwd, out, label, deadline)
        require(rc == 0, f"{label} exited {rc}")
        return stdout

    try:
        git = ["/usr/bin/git", "-c", "core.hooksPath=/dev/null"]
        step(git + ["init", "--quiet"], "git-init")
        step(git + ["fetch", "--no-tags", "--depth=1", REPO, COMMIT], "git-fetch")
        step(git + ["checkout", "--detach", "--quiet", "FETCH_HEAD"], "git-checkout")
        require(step(git + ["rev-parse", "HEAD"], "git-commit").read_text().strip() == COMMIT, "commit drift")
        require(step(git + ["rev-parse", "HEAD^{tree}"], "git-tree").read_text().strip() == TREE, "tree drift")
        require(step(git + ["status", "--porcelain"], "git-status").read_bytes() == b"", "source tree dirty")
        for filename in ("LICENCE.txt", "LEGAL.txt"):
            shutil.copyfile(source / filename, out / filename)
        libraries = {p.relative_to(source).as_posix(): sha(p) for p in sorted((source / "lib").rglob("*.jar"))}
        require("lib/ant-1.9.7.jar" in libraries and "lib/ant-launcher-1.9.7.jar" in libraries, "bundled Ant missing")
        save(out / "VENDORED-JARS.json", libraries)

        phase = "inspect-build-target"
        closure = ant_closure(source)
        save(out / "ANT-CLOSURE.json", closure)

        phase = "acquire-jdk"
        archive = ROOT / "jdk.tar.gz"
        step(
            ["/usr/bin/curl", "-q", "--fail", "--silent", "--show-error", "--proto", "=https",
             "--max-filesize", str(JDK_DOWNLOAD_CAP), "--max-time", "120", "--output", str(archive), JDK_URL],
            "download-jdk", cwd=ROOT,
        )
        archive_size = archive.stat().st_size
        archive_digest = sha(archive)
        save(out / "JDK-ARCHIVE.json", {"bytes": archive_size, "sha256": archive_digest})
        require(0 < archive_size <= JDK_DOWNLOAD_CAP, "JDK archive exceeds download cap")
        require(archive_digest == JDK_SHA, "JDK archive identity drift")
        jdk = ROOT / "jdk"
        with tarfile.open(archive, "r:gz") as tar:
            expanded = 0
            for entry in tar:
                require(entry.isfile() or entry.isdir() or entry.issym() or entry.islnk(), "unexpected JDK archive item")
                expanded += entry.size
                require(expanded < 2 * GIB, "JDK expansion cap")
                tar.extract(entry, jdk, filter="data")
        guard(deadline)
        homes = [p.parent.parent.resolve() for p in jdk.rglob("java")
                 if p.parent.name == "bin" and p.is_file() and (p.parent / "javac").is_file()]
        require(len(set(homes)) == 1, "JDK home not unique")
        java_home = homes[0]
        require(java_home.is_relative_to(jdk), "JDK executable outside owned root")

        phase = "verify-network-denial"
        sandbox = ["/usr/bin/sandbox-exec", "-f", str(HERE / "build-only.sb")]
        probe = (
            "import errno, socket\n"
            "with socket.socket() as s:\n"
            "    try: s.bind(('127.0.0.1', 0))\n"
            "    except OSError as e: assert e.errno in (errno.EACCES, errno.EPERM)\n"
            "    else: raise RuntimeError('network bind unexpectedly allowed')\n"
            "print('loopback bind denied')\n"
        )
        step(sandbox + [sys.executable, "-I", "-B", "-c", probe], "network-denial")

        phase = "verify-jdk"
        java_env = environment(java_home)
        java = java_home / "bin/java"
        javac = java_home / "bin/javac"
        step(sandbox + [str(java), "-XshowSettings:properties", "-version"], "java", local_env=java_env)
        step(sandbox + [str(javac), "-version"], "javac", local_env=java_env)
        java_log = (out / "java.stderr").read_text()
        compiler_log = (out / "javac.stdout").read_text() + (out / "javac.stderr").read_text()
        require("1.8.0_514" in java_log and "1.8.0_514" in compiler_log, "unexpected Java version")
        require("os.arch = aarch64" in java_log, "non-ARM64 Java")

        phase = "compile-and-package"
        step(sandbox + ["/bin/sh", "build.sh", "embedded-dist"], "embedded-dist", local_env=java_env)
        logs = (out / "embedded-dist.stdout").read_text(errors="replace") + (out / "embedded-dist.stderr").read_text(errors="replace")
        network_errors = ("UnknownHostException", "ConnectException", "SocketException", "[get]")
        require(not any(error in logs for error in network_errors), "network attempt reported during build")
        jar = source / "dist/mulgara-2.1.13.jar"
        require(jar.is_file(), "embedded JAR missing")
        with zipfile.ZipFile(jar) as z:
            classes = {
                "org/mulgara/server/SessionFactoryFactory.class",
                "org/mulgara/sparql/SparqlInterpreter.class",
                "org/mulgara/server/Session.class",
            }
            require(classes <= set(z.namelist()), "embedded JAR classes missing")
        guard(deadline)
        source_check(freeze)
        receipt = {
            "pass": True, "source_commit": COMMIT, "source_tree": TREE, "freeze_sha256": freeze,
            "jdk_archive_sha256": JDK_SHA, "java_sha256": sha(java), "javac_sha256": sha(javac),
            "vendored_jars_sha256": sha(out / "VENDORED-JARS.json"),
            "target_closure_sha256": sha(out / "ANT-CLOSURE.json"),
            "artifact": {"path": str(jar.relative_to(ROOT)), "bytes": jar.stat().st_size, "sha256": sha(jar)},
            "server_started": False, "rdf_fixture_executed": False,
        }
    except Exception as error:
        receipt = {"pass": False, "phase": phase, "error": repr(error),
                   "source_commit": COMMIT, "source_tree": TREE, "freeze_sha256": freeze,
                   "server_started": False, "rdf_fixture_executed": False}
        save(ROOT / "BUILD.json", receipt)
        raise
    save(ROOT / "BUILD.json", receipt)
    print(sha(ROOT / "BUILD.json"))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", required=True)
    options = parser.parse_args()
    source_check(options.freeze)
    execute(options.freeze)
