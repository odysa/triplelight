# Mulgara 2.1.13 source build check

Run after a named handoff and source review. Verify at least 48 GiB free and that `/private/tmp/rdf-jianlin-mulgara39-build-v3` is absent. Claim the lock with owner `Jianlin task39 Mulgara build v3`. The sampled guard requires 42 GiB free and caps owned scratch at 4 GiB allocated and 8 GiB logical. Stop after one registered JDK 8 profile. Total deadline is 540 seconds, and an individual command has a 300-second deadline.

```sh
rtk proxy python3 -E -s -B supervise.py --freeze FREEZE_SHA256
```

The supervisor acquires an exact source commit and verifies its Git tree. It records the OSL licence, upstream third-party notices, and hashes of every vendored JAR under `lib`. The bundled Ant is 1.9.7. The 56 direct dependencies of `embedded-dist` are fixed in `EMBEDDED_DIRECT.json`. The checkout supplies the transitive target graph, which the supervisor records and checks for test runners, startup targets and literal fetch and nested Ant-build tasks before building. The server and test resolver entries in the direct list package JARs. They are neither server startups nor test executions.

Download the pinned JDK under a 104 MiB transfer cap. Record its exact received length and SHA-256. Extract only if the received SHA-256 matches Azul's package metadata. Extraction uses a safe tar filter and a separate 2 GiB expansion cap. Compilation and JDK identification run in the macOS network-deny sandbox, with a local bind-denial control. No JAR entry point or RDF fixture runs during this phase. Legacy libraries remain in the private build. Any failed compatibility or harness stage is retained with the stage name and logs.

The build receipt identifies the resulting JAR and native session API classes when compilation succeeds. A separate registration is required for the RDF fixture. Verify that owned workers exited, then release the exact own lock and hand off to the named next owner.

The first attempt stopped at the closure check before JDK acquisition. This revision permits the exact source tree's local `common.xml:run-svnversion` probe, which supplies build metadata. The checker passed all 322 reachable targets in the preserved checkout. The v1 root remains intact.

The v2 attempt stopped before JDK extraction or compilation. Azul's package metadata lists 103,757,000 bytes and its CDN reports 103,757,046 bytes for the same URL. The v2 curl ceiling used the metadata value. V3 gives the transfer its own bounded allowance and retains the exact digest gate. It also records whether svnversion is available in the supervisor's restricted PATH. Both earlier roots remain intact.
