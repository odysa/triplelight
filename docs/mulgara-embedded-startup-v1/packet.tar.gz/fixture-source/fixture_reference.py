"""Compare typed engine records to the frozen typed reference."""

import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
XSD = "http://www.w3.org/2001/XMLSchema#"
RDF = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
LABELS = ("group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false")


def term_key(term):
    if term is None:
        return None
    kind, value = term["type"], term["value"]
    if type(value) is not str or kind not in {"uri", "bnode", "literal"}:
        raise ValueError("non-native RDF value")
    if kind != "literal":
        if set(term) != {"type", "value"}:
            raise ValueError("unexpected RDF term fields")
        return kind, value
    if set(term) - {"type", "value", "datatype", "xml:lang"}:
        raise ValueError("unexpected RDF literal fields")
    language = term.get("xml:lang", "").lower()
    datatype = term.get("datatype") or (RDF + "langString" if language else XSD + "string")
    return kind, value, datatype, language


def bag(answer, columns):
    actual = answer["head"]["vars"]
    rows = answer["results"]["bindings"]
    if actual != columns or any(set(row) - set(columns) for row in rows):
        raise ValueError("query projection or binding names differ")
    return Counter(tuple(term_key(row.get(name)) for name in columns) for row in rows)


def check_queries(record):
    if set(record.get("queries", {})) != set(LABELS):
        raise ValueError("missing or extra labels")
    grouped = json.loads((HERE / "consumer-fixture-jena.json").read_text())
    objects = [row["o"] for row in grouped["results"]["bindings"]]
    object_bag = Counter((term_key(term),) for term in objects)
    expected_count = Counter({(("literal", "9", XSD + "integer", ""),): 1})
    results = {}
    for label in LABELS:
        entry = record["queries"][label]
        if set(entry) == {"error"}:
            results[label] = {"pass": False, "query_error": entry["error"]}
            continue
        if set(entry) != {"answer"}:
            raise ValueError("invalid observation")
        answer = entry["answer"]
        try:
            if label == "group":
                wanted = bag(grouped, ["o", "n"])
                observed = bag(answer, ["o", "n"])
            elif label in {"plain", "distinct"}:
                wanted, observed = object_bag, bag(answer, ["o"])
            elif label in {"count", "distinct_count"}:
                wanted, observed = expected_count, bag(answer, ["n"])
            elif label == "empty":
                wanted, observed = Counter(), bag(answer, ["o"])
            elif label == "unbound":
                wanted = Counter({(row[0], None): count for row, count in object_bag.items()})
                observed = bag(answer, ["o", "missing"])
            else:
                results[label] = {"pass": set(answer) == {"boolean"} and answer["boolean"] is False}
                continue
            results[label] = {"pass": wanted == observed, "rows": sum(observed.values())}
            if label == "plain":
                distinct_kinds = {term[0] for (term,) in observed if term is not None and term[1] == "urn:iri"}
                results[label]["same_text_iri_and_literal"] = distinct_kinds == {"uri", "literal"}
                results[label]["pass"] &= results[label]["same_text_iri_and_literal"]
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            results[label] = {"pass": False, "answer_error": repr(error)}
    return results


def check_native(record):
    grouped = json.loads((HERE / "consumer-fixture-jena.json").read_text())
    subject = ("uri", "urn:s")
    predicate = ("uri", "urn:v")
    expected = Counter((subject, predicate, term_key(binding["o"]))
                       for binding in grouped["results"]["bindings"])
    native = Counter(tuple(term_key(t[key]) for key in ("s", "p", "o"))
                     for t in record["native"])
    status = {"exact": native == expected, "rows": sum(native.values())}
    if record["stage"] != "parser":
        length = record["length"]
        status["length_pass"] = type(length) is int and length == 9
    return status
