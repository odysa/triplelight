# Mulgara 2.1.13 embedded fixture

Use the exact 33,239,922-byte JAR from the completed source build, SHA-256 `fad67f830a3cbd2a69d865a0c377b448d9217d45d04b2718a8097c7298d5e57b`. Reuse the verified Zulu 8u514 ARM64 java and javac with their hashes from the v3 build receipt. Keep build and fixture roots separate. Compile only the fixture adapter. Use the macOS network-deny profile with a bind-denial control for compilation and all Java processes. No downloads or server entry points.

Construct a local session factory with an explicit directory and stable local graph URI. Create the native store graph. Load the unchanged nine-triple N-Triples file through Session.setModel with a local stream and retain its returned insertion count. Run a native Query with a GraphResource and three variables across that graph to enumerate and compare typed triples and native row count. Run the eight frozen SPARQL labels against the same graph using SparqlInterpreter and Session. Close each Answer in its own scope and close the session and factory. Open the same directory with the same graph URI from a second Java process and repeat the native scan and the eight labels. Record lengths, datatypes, language tags, blank nodes, unbound values and ASK booleans through native interfaces. Preserve lexical text as received from the engine.

An individual SPARQL failure or mismatch is recorded and later labels still run. A failed load, native scan, close or reopen retains the exact stage and output. Compare native inventories from both processes and classify row ordering as immaterial. Retain separate first-session and reopen observations and per-label results. The result covers clean reopen and the specified fixture on this artifact. No scored timing. No alternate JDK, external provider, legacy JAR publication or large workload in this registration.

Use fresh `/private/tmp/rdf-jianlin-mulgara39-fixture-v1`, a 48 GiB launch floor and 42 GiB sampled floor. Limit fixture scratch to 1 GiB allocated and 2 GiB logical and include the retained Mulgara build roots in preflight accounting. Bound total attempt time at five minutes, with process group and output limits. Require named machine handoff, reviewed source freeze and exact lock ownership. Preserve every attempted phase. Release the lock after owned children exit.

Frozen reference inputs from the reviewed dotNetRDF fixture.

- `consumer-fixture.nt` `419291c55eb34af3bdc59a43ddcda019436ade3e1075ca034c3505247d8e9266`
- `consumer-fixture.rq` `c09c8b5bb1b2deca899383d71e89963908536cb231b0494a56e3664be528756d`
- `consumer-fixture-jena.json` `b8b6e0bf2ae822a6b354d2846a440ae572516a73cc08d6432df93b8008cab5bd`
- `queries.json` `8b8ad2fd1015d7ddfea503de81e7dd90102ef013ad78589f97a4644cf0e7b9c0`
