"""Decode a local Mulgara fixture trace and compare its typed results."""

import base64
import json
import sys
from collections import Counter
from pathlib import Path

from fixture_reference import LABELS, check_native, check_queries, term_key

GRAPH = "local:database#fixture"
FACTORY = "org.mulgara.resolver.Database"
SESSION = "org.mulgara.resolver.DatabaseSession"


def decode(value):
    return None if value == "-" else base64.b64decode(value, validate=True).decode("utf-8")


def term(token):
    if token == "null":
        return None
    kind, *fields = token.split(":")
    if kind in {"bnode", "uri"} and len(fields) == 1:
        return {"type": kind, "value": decode(fields[0])}
    if kind == "literal" and len(fields) == 3:
        lexical, datatype, language = map(decode, fields)
        result = {"type": kind, "value": lexical}
        if datatype is not None:
            result["datatype"] = datatype
        if language is not None:
            result["xml:lang"] = language
        return result
    raise ValueError("invalid RDF term in worker trace")


def parse(trace, stage):
    fields = {}
    queries = {}
    phases = []
    current = None
    observed = None
    for line in trace.splitlines():
        if not line.startswith("FIXTURE\t"):
            continue
        _, kind, *values = line.split("\t")
        if current is not None and kind not in {"row", "answer-end"}:
            raise ValueError("interleaved answers")
        if kind == "head":
            label, names = values
            columns = names.split(",") if names else []
            if len(set(columns)) != len(columns) or label in queries or (label == "native" and observed is not None):
                raise ValueError("duplicate projection or answer")
            current = (label, columns, [])
        elif kind == "row":
            label, raw = values
            if current is None or label != current[0]:
                raise ValueError("row outside its answer")
            columns, rows = current[1:]
            cells = [term(cell) for cell in raw.split(",")] if raw else []
            if len(cells) != len(columns):
                raise ValueError("row/projection length mismatch")
            rows.append({name: value for name, value in zip(columns, cells) if value is not None})
        elif kind == "answer-end":
            label, = values
            if current is None or label != current[0]:
                raise ValueError("answer end outside its answer")
            columns, rows = current[1:]
            if label == "native":
                if columns != ["s", "p", "o"]:
                    raise ValueError("invalid native projection")
                observed = rows
            else:
                queries[label] = {"answer": {"head": {"vars": columns}, "results": {"bindings": rows}}}
            current = None
        elif kind in {"boolean", "error"}:
            label, value = values
            if label in queries:
                raise ValueError("duplicate query result")
            if kind == "boolean":
                if value not in {"true", "false"} or label != "ask_false":
                    raise ValueError("invalid ASK result")
                queries[label] = {"answer": {"boolean": value == "true"}}
            else:
                queries[label] = {"error": decode(value)}
        elif kind == "phase":
            phase, = values
            phases.append(phase)
        elif kind in {"stage", "complete", "factory", "session", "default-graph", "load-count", "length"}:
            value, = values
            if kind in fields:
                raise ValueError("duplicate receipt field")
            fields[kind] = value
        else:
            raise ValueError("unknown fixture event")

    expected = {"stage": stage, "complete": stage, "factory": FACTORY, "session": SESSION, "default-graph": GRAPH}
    if any(fields.get(name) != value for name, value in expected.items()):
        raise ValueError("incomplete stage or wrong local implementation/default graph")
    expected_phases = (["load"] if stage == "load" else []) + ["inventory", "queries", "close"]
    if phases != expected_phases or observed is None or current is not None or list(queries) != list(LABELS):
        raise ValueError("incomplete stage or unexpected phase/label order")
    if ("load-count" in fields) != (stage == "load"):
        raise ValueError("load count must occur exactly in the load process")
    result = {"stage": stage, "length": int(fields["length"]), "native": observed,
              "queries": queries, "factory": FACTORY, "session": SESSION, "default_graph": GRAPH}
    if stage == "load":
        result["load_count"] = int(fields["load-count"])
    return result


def inventory(record):
    return Counter(tuple(term_key(row[name]) for name in ("s", "p", "o")) for row in record["native"])


def audit(load, reopen):
    reference = json.loads(Path(__file__).with_name("consumer-fixture-jena.json").read_text())
    expected = Counter((("uri", "urn:s"), ("uri", "urn:v"), term_key(row["o"]))
                       for row in reference["results"]["bindings"])
    stages = {}
    for record in (load, reopen):
        actual = inventory(record)
        stages[record["stage"]] = {
            "native": check_native(record),
            "missing_typed_triples": list((expected - actual).elements()),
            "extra_typed_triples": list((actual - expected).elements()),
            "queries": check_queries(record),
        }
    stable = inventory(load) == inventory(reopen)
    count_pass = load["load_count"] == 9
    passed = stable and count_pass and all(
        item["native"]["exact"] and item["native"]["length_pass"]
        and all(entry["pass"] for entry in item["queries"].values())
        for item in stages.values()
    )
    return {"pass": passed, "load_count": load["load_count"], "load_count_pass": count_pass,
            "native_reopen_bag_equal": stable, "stages": stages}


if __name__ == "__main__":
    load = parse(Path(sys.argv[1]).read_text(), "load")
    reopen = parse(Path(sys.argv[2]).read_text(), "reopen")
    result = audit(load, reopen)
    with Path(sys.argv[3]).open("x") as handle:
        json.dump({"observations": [load, reopen], "audit": result}, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
