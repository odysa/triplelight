"""Qualify the pinned Mulgara embedded JAR in two separate JVMs."""

import argparse
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import time
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/rdf-jianlin-mulgara39-fixture-v1")
LOCK = Path("/private/tmp/rdf-bench.lock/owner")
OWNER = "Jianlin task39 Mulgara fixture v1\n"
BUILDS = tuple(Path(f"/private/tmp/rdf-jianlin-mulgara39-build-v{n}") for n in (1, 2, 3))
BUILD = BUILDS[-1]
BUILD_SHA = "7205c1767e8105678b9efa2a518467fe389bfba3dabd7ca3dc15d9461c367dcc"
JAR = BUILD / "source/dist/mulgara-2.1.13.jar"
JAVA_HOME = BUILD / "jdk/zulu8.98.0.201-ca-jdk8.0.514-macosx_aarch64/Contents/Home"
LABELS = ("group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false")
GIB = 1 << 30


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def sha(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, sort_keys=True, indent=2)
        handle.write("\n")


def source_check(expected):
    path = HERE / "FREEZE.json"
    require(sha(path) == expected, "freeze digest drift")
    files = load(path)["files"]
    current = {p.name for p in HERE.iterdir()}
    require(current == set(files) | {"FREEZE.json"}, "source file inventory drift")
    for name, digest in files.items():
        p = HERE / name
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, f"source drift: {name}")


def check_lock():
    require(LOCK.read_text() == OWNER, "exact own lock required")


def bytes_used(root):
    allocated = 0
    logical = 0
    for path in root.rglob("*"):
        try:
            item = path.lstat()
        except FileNotFoundError:
            continue
        allocated += item.st_blocks * 512
        if stat.S_ISREG(item.st_mode):
            logical += item.st_size
    return allocated, logical


def guard(deadline):
    check_lock()
    require(time.monotonic() < deadline, "phase deadline")
    require(shutil.disk_usage(ROOT).free >= 42 * GIB, "42 GiB free-space guard")
    allocated, logical = bytes_used(ROOT)
    require(allocated < GIB and logical < 2 * GIB, "owned root size guard")


def command(args, env, cwd, out, label, deadline, sample):
    stdout_path = out / (label + ".stdout")
    limit = min(deadline, time.monotonic() + 90)
    guard(limit)
    sample()
    with stdout_path.open("xb") as stdout, (out / (label + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(args, stdout=stdout, stderr=stderr, cwd=cwd, env=env, start_new_session=True)
        try:
            while child.poll() is None:
                guard(limit)
                sample()
                require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                        "diagnostic output limit")
                time.sleep(0.25)
            require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 4 << 20,
                    "diagnostic output limit")
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    guard(limit)
    sample()
    return child.returncode, stdout_path


def environment():
    return {
        "PATH": "/usr/bin:/bin:/usr/sbin",
        "HOME": str(ROOT / "home"),
        "TMPDIR": str(ROOT / "tmp"),
        "LANG": "C",
        "LC_ALL": "C",
    }

def inventory(paths):
    result = {}
    for top in paths:
        for path in sorted(top.rglob("*")):
            info = path.lstat()
            key = str(path.relative_to(ROOT))
            if stat.S_ISDIR(info.st_mode):
                result[key] = {"type": "directory"}
            else:
                require(stat.S_ISREG(info.st_mode), f"unexpected fixture file type: {key}")
                result[key] = {"type": "file", "bytes": info.st_size, "sha256": sha(path)}
    return result


def execute(freeze):
    source_check(freeze)
    check_lock()
    require(shutil.disk_usage(ROOT.parent).free >= 48 * GIB, "48 GiB launch floor")
    deadline = time.monotonic() + 300
    ROOT.mkdir()
    for name in ("home", "tmp", "store", "work", "inputs", "classes", "diagnostics"):
        (ROOT / name).mkdir()
    output = ROOT / "diagnostics"
    inputs = ROOT / "inputs"
    classes = ROOT / "classes"
    state_dirs = tuple(ROOT / name for name in ("home", "tmp", "store", "work"))
    env = environment()
    receipt = {"freeze_sha256": freeze, "build_receipt_sha256": BUILD_SHA, "completed": False}
    phase = "preflight"
    sampled_paths = set()

    def sample():
        for directory in state_dirs:
            sampled_paths.update(str(path.relative_to(ROOT)) for path in directory.rglob("*"))
        require(len(sampled_paths) <= 4096, "observed file inventory limit")

    def run(args, label):
        rc, stdout = command(args, env, ROOT / "work", output, label, deadline, sample)
        receipt.setdefault("exit_codes", {})[label] = rc
        require(rc == 0, f"{label} exited {rc}")
        return stdout

    try:
        receipt["retained_build_roots"] = {
            root.name: dict(zip(("allocated", "logical"), bytes_used(root))) for root in BUILDS
        }
        guard(deadline)
        receipt_path = BUILD / "BUILD.json"
        require(sha(receipt_path) == BUILD_SHA, "build receipt drift")
        build = load(receipt_path)
        require(build["pass"] is True, "build did not pass")
        require(JAR.stat().st_size == build["artifact"]["bytes"]
                and sha(JAR) == build["artifact"]["sha256"], "JAR drift")
        java, javac = (JAVA_HOME / "bin" / name for name in ("java", "javac"))
        require(sha(java) == build["java_sha256"] and sha(javac) == build["javac_sha256"],
                "JDK executable drift")
        receipt["artifact_sha256"] = build["artifact"]["sha256"]
        queries = load(HERE / "queries.json")
        require(set(queries) == set(LABELS), "query label drift")
        for label in LABELS:
            (inputs / (label + ".rq")).write_bytes(queries[label].encode("utf-8"))
        shutil.copyfile(HERE / "consumer-fixture.nt", inputs / "consumer-fixture.nt")
        sandbox = ["/usr/bin/sandbox-exec", "-f", str(HERE / "network-deny.sb")]

        phase = "verify-network-denial"
        probe = (
            "import errno, socket\n"
            "with socket.socket() as s:\n"
            "    try: s.bind(('127.0.0.1', 0))\n"
            "    except OSError as e: assert e.errno in (errno.EACCES, errno.EPERM)\n"
            "    else: raise RuntimeError('network bind unexpectedly allowed')\n"
            "print('loopback bind denied')\n"
        )
        run(sandbox + [sys.executable, "-I", "-B", "-c", probe], "network-denial")

        phase = "compile-adapter"
        env["JAVA_TOOL_OPTIONS"] = (f"-Duser.home={ROOT / 'home'} -Djava.io.tmpdir={ROOT / 'tmp'} "
                                    "-XX:+PerfDisableSharedMem")
        run(sandbox + [str(javac), "-proc:none", "-encoding", "UTF-8", "-classpath", str(JAR),
                       "-d", str(classes), str(HERE / "Fixture.java")], "compile")
        worker = sandbox + [str(java), "-Xmx512m", "-Dfile.encoding=UTF-8",
                            "-classpath", f"{classes}:{JAR}", "Fixture"]

        phase = "load-and-check"
        run(worker + ["load", str(ROOT / "store"), str(inputs)], "load")
        save(output / "LOAD-FILES.json", inventory(state_dirs))
        phase = "reopen-and-check"
        run(worker + ["reopen", str(ROOT / "store"), str(inputs)], "reopen")
        save(output / "REOPEN-FILES.json", inventory(state_dirs))

        phase = "validate"
        audit_path = output / "AUDIT.json"
        run([sys.executable, "-E", "-s", "-B", str(HERE / "check_answers.py"),
             str(output / "load.stdout"), str(output / "reopen.stdout"), str(audit_path)], "validate")
        source_check(freeze)
        require(sha(JAR) == receipt["artifact_sha256"], "JAR drift during qualification")
        receipt.update(completed=True, exact_fixture_pass=load(audit_path)["audit"]["pass"],
                       audit_sha256=sha(audit_path))
    except Exception as error:
        receipt.update(phase=phase, error=repr(error))
        raise
    finally:
        receipt["sampled_state_paths"] = sorted(sampled_paths)
        save(ROOT / "FIXTURE.json", receipt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--freeze", required=True)
    options = parser.parse_args()
    execute(options.freeze)
