# Mulgara 2.1.13 fixture execution

After the named handoff, verify 48 GiB free and an absent `/private/tmp/rdf-jianlin-mulgara39-fixture-v1`. Take the exact lock as `Jianlin task39 Mulgara fixture v1` and run the frozen supervisor once.

```sh
rtk proxy python3 -E -s -B supervise.py --freeze FREEZE_SHA256
```

The supervisor verifies the build receipt digest and the JAR and executable identities. Compile only Fixture.java with the verified javac. All Java processes run with network denial, checked by the loopback bind probe. The adapter requests the local Database factory and records the exact factory and session classes. Use the same local graph URI for the native inventory and the SPARQL interpreter default graph. The query file bytes are unchanged. Collect the native lexical values, datatypes, language tags and exact projection and ASK results.

Close the load JVM before starting the reopen JVM. Record owned work, home, temporary and store files after both JVMs close. Sample their path names during subprocess execution. Paths created and removed between samples can escape that inventory. Record the retained build roots in preflight. The fixture supervisor bounds each worker at 90 seconds, the full attempt at 300 seconds, worker output at 4 MiB, and owned fixture disk at 1 GiB allocated and 2 GiB logical with 42 GiB minimum free space.

A completed result can contain typed mismatches or errors. The audit retains missing and extra typed native triples to localize observed changes. Separate load counts, native query row counts and typed SPARQL labels. Stage failures retain logs and a phase receipt. Preserve raw outputs and verify owned processes have exited before releasing the lock. No workload timing is collected.
