import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import org.jrdf.graph.Literal;
import org.jrdf.graph.URIReference;
import org.mulgara.query.Answer;
import org.mulgara.query.AskQuery;
import org.mulgara.query.ConstraintImpl;
import org.mulgara.query.GraphResource;
import org.mulgara.query.Query;
import org.mulgara.query.UnconstrainedAnswer;
import org.mulgara.query.Variable;
import org.mulgara.query.rdf.BlankNodeImpl;
import org.mulgara.server.Session;
import org.mulgara.server.SessionFactory;
import org.mulgara.server.SessionFactoryFactory;
import org.mulgara.sparql.SparqlInterpreter;

public final class Fixture {
    private static final URI STORE = URI.create("local:database");
    private static final URI GRAPH = URI.create("local:database#fixture");
    private static final String LOCAL_FACTORY = "org.mulgara.resolver.Database";
    private static final String[] LABELS = {
        "group", "plain", "distinct", "count", "distinct_count", "empty", "unbound", "ask_false"
    };

    private static String encode(String value) {
        if (value == null) {
            return "-";
        }
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String term(Object node) {
        if (node == null) {
            return "null";
        }
        if (node instanceof URIReference) {
            return "uri:" + encode(((URIReference) node).getURI().toString());
        }
        if (node instanceof BlankNodeImpl) {
            return "bnode:" + encode(((BlankNodeImpl) node).getID());
        }
        if (node instanceof Literal) {
            Literal literal = (Literal) node;
            URI datatype = literal.getDatatypeURI();
            return "literal:" + encode(literal.getLexicalForm()) + ":"
                + encode(datatype == null ? null : datatype.toString()) + ":" + encode(literal.getLanguage());
        }
        throw new IllegalArgumentException("Unexpected native RDF term class " + node.getClass());
    }

    private static void event(String kind, String... fields) {
        System.out.println("FIXTURE\t" + kind + "\t" + String.join("\t", fields));
    }

    private static void readAnswer(Session session, String label, Query query) throws Exception {
        List<String[]> rows = new ArrayList<>();
        String[] columns;
        Long count = null;
        Answer answer = session.query(query);
        try {
            columns = Arrays.stream(answer.getVariables()).map(Variable::getName).toArray(String[]::new);
            if (label.equals("native")) {
                count = answer.getRowCount();
            }
            answer.beforeFirst();
            while (answer.next()) {
                if (rows.size() == 128) {
                    throw new IllegalStateException("Fixture row cap exceeded");
                }
                String[] row = new String[columns.length];
                for (int column = 0; column < row.length; column++) {
                    row[column] = term(answer.getObject(column));
                }
                rows.add(row);
            }
        } finally {
            answer.close();
        }
        if (count != null) {
            event("length", Long.toString(count));
        }
        event("head", label, String.join(",", columns));
        for (String[] row : rows) {
            event("row", label, String.join(",", row));
        }
        event("answer-end", label);
    }

    private static Query inventory() {
        Variable s = new Variable("s");
        Variable p = new Variable("p");
        Variable o = new Variable("o");
        return new Query(Arrays.asList(s, p, o), new GraphResource(GRAPH), new ConstraintImpl(s, p, o),
            null, Collections.emptyList(), null, 0, false, new UnconstrainedAnswer());
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3 || !(args[0].equals("load") || args[0].equals("reopen"))) {
            throw new IllegalArgumentException("Expected load|reopen, store path, input directory");
        }
        event("stage", args[0]);
        Path inputs = Paths.get(args[2]);
        SessionFactory factory = new SessionFactoryFactory(LOCAL_FACTORY)
            .newSessionFactory(STORE, Paths.get(args[1]).toFile());
        try {
            String factoryClass = factory.getClass().getName();
            event("factory", factoryClass);
            if (!LOCAL_FACTORY.equals(factoryClass)) {
                throw new IllegalStateException("Unexpected session factory " + factoryClass);
            }
            Session session = factory.newSession();
            try {
                event("session", session.getClass().getName());
                if (args[0].equals("load")) {
                    event("phase", "load");
                    session.createModel(GRAPH, null);
                    Path fixture = inputs.resolve("consumer-fixture.nt");
                    try (InputStream input = Files.newInputStream(fixture)) {
                        event("load-count", Long.toString(session.setModel(input, GRAPH, fixture.toUri(), null)));
                    }
                }
                event("phase", "inventory");
                if (!session.modelExists(GRAPH)) {
                    throw new IllegalStateException("Missing fixture graph");
                }
                readAnswer(session, "native", inventory());

                event("phase", "queries");
                SparqlInterpreter interpreter = new SparqlInterpreter().setDefaultGraphUri(GRAPH);
                List<URI> defaults = interpreter.getDefaultGraphUris();
                if (!defaults.equals(Collections.singletonList(GRAPH))) {
                    throw new IllegalStateException("Unexpected default graph " + defaults);
                }
                event("default-graph", GRAPH.toString());
                for (String label : LABELS) {
                    try {
                        Path queryFile = inputs.resolve(label + ".rq");
                        String sparql = new String(Files.readAllBytes(queryFile), StandardCharsets.UTF_8);
                        Query query = interpreter.parseQuery(sparql);
                        if (query instanceof AskQuery) {
                            if (!label.equals("ask_false")) {
                                throw new IllegalStateException("Unexpected ASK for " + label);
                            }
                            event("boolean", label, Boolean.toString(session.query((AskQuery) query)));
                        } else {
                            if (label.equals("ask_false")) {
                                throw new IllegalStateException("Expected ASK");
                            }
                            readAnswer(session, label, query);
                        }
                    } catch (Exception error) {
                        event("error", label, encode(error.getClass().getName() + ": " + error.getMessage()));
                        error.printStackTrace(System.err);
                    }
                }
                event("phase", "close");
            } finally {
                session.close();
            }
        } finally {
            factory.close();
        }
        event("complete", args[0]);
    }
}
