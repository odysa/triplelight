"""Inspect files after each matched fixture JVM has exited."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import stat

ALL_ORDERS = {"spo", "sop", "pso", "pos", "osp", "ops"}
KEPT_ORDERS = {"spo", "pso", "pos", "osp"}


def regular(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError(f"expected a regular file at {path}")
    return {"apparent_bytes": info.st_size, "allocated_bytes": info.st_blocks * 512}


def inspect(engine, store):
    if engine == "blazegraph":
        return {"engine": engine, "format": "Blazegraph DiskRW",
                "files": {store.name: regular(store)}}

    if store.is_symlink() or not store.is_dir():
        raise ValueError("expected a real store directory")
    current = store / "CURRENT"
    regular(current)
    name = current.read_text(encoding="ascii").strip()
    if not re.fullmatch(r"base-[0-9]+", name):
        raise ValueError("expected an unfenced CURRENT generation for this default-graph fixture")
    base = store / name
    if base.is_symlink() or not base.is_dir():
        raise ValueError("expected a real current base directory")
    manifest = base / "MANIFEST"
    regular(manifest)
    data = manifest.read_bytes()
    if data[:10] != b"RDFSNAP6\x1d\x00":
        raise ValueError("expected RDFSNAP6 and the registered four-order mask")
    observed = {path.name for path in base.iterdir()} & ALL_ORDERS
    if observed != KEPT_ORDERS:
        raise ValueError(f"unexpected index order files: {sorted(observed)}")
    files = {}
    for path in store.rglob("*"):
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode):
            files[str(path.relative_to(store))] = regular(path)
    return {"engine": engine, "format": "RDFSNAP6", "kept_orders": sorted(observed),
            "generation": name, "manifest_sha256": hashlib.sha256(data).hexdigest(),
            "files": files}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("engine", choices=("triplelight", "blazegraph"))
    parser.add_argument("store", type=Path)
    args = parser.parse_args()
    receipt = inspect(args.engine, args.store)
    for key in ("apparent_bytes", "allocated_bytes"):
        receipt[key] = sum(info[key] for info in receipt["files"].values())
    print(json.dumps(receipt, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
