"""Run the registered six-stage Java 25 qualification. No scored timing."""
import argparse
from hashlib import file_digest
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import time

from check_fixture import ENGINES, STAGES, verify, verify_stage
from report_store import inspect

HERE = Path(__file__).resolve().parent
LOCK = Path("/tmp/rdf-bench.lock")
LABEL = "org.triplelight.matched-java-fixture"
JAVA_FLAGS = ["-Xmx1g", "-XX:ActiveProcessorCount=4", "-Djava.io.tmpdir=/tmp"]
NATIVE_FLAGS = ["--enable-native-access=ALL-UNNAMED", "-Dtriplelight.library=/native.so"]


def digest(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"expected a regular input: {path}")
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def write_json(path, data):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, sort_keys=True)
        stream.write("\n")


def verify_inputs(reg):
    build = Path(reg["build_root"])
    receipt = build / "BUILD.json"
    pinned = {HERE / name: value for name, value in reg["harness"].items()}
    pinned[receipt] = reg["build_receipt_sha256"]
    pinned[Path(reg["jar"]["path"])] = reg["jar"]["sha256"]
    pinned.update({build / name: value for name, value in reg["artifacts"].items()})
    for path, value in pinned.items():
        if digest(path) != value:
            raise ValueError(f"input differs from registration: {path}")
    built = json.loads(receipt.read_text())
    expected_image = f"linux/arm64 {reg['image']['config']}"
    if not built["complete"] or built["images"]["java"] != expected_image:
        raise ValueError("build receipt does not qualify the registered Java image")
    if built["outputs"] != reg["artifacts"]:
        raise ValueError("registered artifact inventory differs from build receipt")
    smoke = HERE / "smoke"
    observed = {str(p.relative_to(HERE)) for p in smoke.rglob("*") if not p.is_dir() or p.is_symlink()}
    if observed != {name for name in reg["harness"] if name.startswith("smoke/")}:
        raise ValueError("unexpected smoke fixture content")
    for engine in ENGINES:
        classes = build / "classes" / engine
        observed = {str(p.relative_to(build)) for p in classes.rglob("*") if not p.is_dir() or p.is_symlink()}
        expected = {p for p in reg["artifacts"] if p.startswith(f"classes/{engine}/")}
        if classes.is_symlink() or not expected or observed != expected:
            raise ValueError(f"unexpected classpath content: {engine}")
    return build


def docker(*args):
    return subprocess.check_output(["rtk", "proxy", "docker", *args], text=True, timeout=15).strip()


def command(reg, build, root, engine, stage):
    name = f"{reg['container_prefix']}-{engine}-{stage}"
    args = ["run", "--rm", "--name", name, "--label", f"{LABEL}={reg['owner']}",
            "--pull", "never", "--platform", "linux/arm64", "--network", "none",
            "--cpus", "4", "--memory", "4g", "--memory-swap", "4g", "--read-only",
            "--tmpfs", "/tmp:rw,nosuid,nodev,size=64m", "--log-driver", "none",
            "--entrypoint", "/bin/sh"]
    stage_home = root / engine / stage
    is_blazegraph = engine == "blazegraph"
    mounts = [(LOCK, "/guard", True), (HERE / "run_java.sh", "/run-java.sh", True),
              (HERE / "smoke", "/smoke", True), (build / "classes" / engine, "/classes", True),
              (stage_home, "/stage", False), (root / engine / "data", "/data", False)]
    archive = Path(reg["jar"]["path"]) if is_blazegraph else build / "native/artifacts/libtriplelight_c.so"
    mounts.append((archive, "/engine.jar" if is_blazegraph else "/native.so", True))
    for source, target, read_only in mounts:
        args += ["--mount", f"type=bind,src={source},dst={target}" + (",readonly" if read_only else "")]
    args += [reg["image"]["reference"], "/run-java.sh", reg["owner"]]
    if is_blazegraph:
        args += ["-cp", "/classes:/engine.jar", "BlazegraphWorkload", stage, "/data/store.jnl"]
    else:
        args += [*NATIVE_FLAGS, "-cp", "/classes", "TripleLightFixture", stage, "/data/store"]
    if stage == "load":
        args += ["/smoke/fixture.nt"]
    if stage == "query":
        args += ["/smoke/queries", "/stage/answers"]
    return name, args


def guard(root, reg, deadline):
    if (LOCK / "owner").read_text().strip() != reg["owner"]:
        raise RuntimeError("lock owner differs from registration")
    if time.monotonic() >= deadline:
        raise TimeoutError("fixture wall limit reached")
    if shutil.disk_usage(root.parent).free < reg["free_floor_bytes"]:
        raise RuntimeError("shared disk floor reached")
    allocated = 0
    for path in root.rglob("*"):
        try:
            allocated += path.lstat().st_blocks * 512
        except FileNotFoundError:
            continue
    if allocated >= reg["sample_limit_bytes"]:
        raise RuntimeError("fixture root allocation reached the sample ceiling")


def run_stage(reg, build, root, engine, stage, deadline):
    guard(root, reg, deadline)
    folder = root / engine / stage
    folder.mkdir()
    if stage == "query":
        (folder / "answers").mkdir()
    name, args = command(reg, build, root, engine, stage)

    def owned_ids():
        rows = docker("ps", "-a", "--filter", f"label={LABEL}={reg['owner']}",
                      "--filter", f"name=^/{name}$", "--format", "{{.ID}} {{.Names}}")
        return [identifier for identifier, actual in (line.split() for line in rows.splitlines()) if actual == name]

    def output_limit():
        cap = reg["per_log_limit_bytes"]
        resource.setrlimit(resource.RLIMIT_FSIZE, (cap, cap))

    result = {"exit_code": None, "stop": None}
    proc = None
    try:
        if owned_ids():
            raise RuntimeError("registered container name already exists")
        with (folder / "stdout.txt").open("xb") as out, (folder / "stderr.txt").open("xb") as err:
            proc = subprocess.Popen(["rtk", "proxy", "docker", *args], stdout=out, stderr=err,
                                    start_new_session=True, preexec_fn=output_limit)
            stage_deadline = min(deadline, time.monotonic() + reg["stage_seconds"])
            while proc.poll() is None:
                guard(root, reg, stage_deadline)
                time.sleep(0.25)
            result["exit_code"] = proc.returncode
        guard(root, reg, deadline)
    except BaseException as error:
        result["stop"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        if proc is not None:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait(timeout=5)
            result["exit_code"] = proc.returncode
        try:
            if proc is not None:
                for identifier in owned_ids():
                    docker("rm", "-f", identifier)
                if owned_ids():
                    raise RuntimeError("owned fixture container survived cleanup")
        except BaseException as error:
            result["stop"] = f"{type(error).__name__}: {error}"
            raise
        finally:
            write_json(folder / "status.json", result)
    verify_stage(folder, engine, stage, reg["java_version"], 4)
    flags = [line.split("=", 1)[1] for line in (folder / "stdout.txt").read_text().splitlines()
             if line.startswith("java_argument=")]
    if flags != JAVA_FLAGS + (NATIVE_FLAGS if engine == "triplelight" else []):
        raise ValueError("actual JVM arguments differ from registration")
    events = [dict(line.split() for line in (folder / f"{when}.memory.events").read_text().splitlines())
              for when in ("before", "after")]
    if any(events[0].get(key) != "0" or events[1].get(key) != "0" for key in ("oom", "oom_kill")):
        raise ValueError("missing or nonzero OOM counters")
    store = root / engine / "data" / ("store.jnl" if engine == "blazegraph" else "store")
    receipt = inspect(engine, store)
    for key in ("apparent_bytes", "allocated_bytes"):
        receipt[key] = sum(info[key] for info in receipt["files"].values())
    write_json(folder / "store.json", receipt)


def run(reg, registration_sha256):
    root = Path(reg["root"])
    deadline = time.monotonic() + reg["total_seconds"]
    guard(root, reg, deadline)
    build = verify_inputs(reg)
    actual = docker("image", "inspect", "--format", "{{.Os}}/{{.Architecture}} {{.Id}}", reg["image"]["reference"])
    if actual != f"linux/arm64 {reg['image']['config']}":
        raise ValueError("local Java image differs from registration")
    root.mkdir(mode=0o700)
    status = {"registration_sha256": registration_sha256, "qualified": False, "stop": None}
    try:
        for engine in ENGINES:
            (root / engine / "data").mkdir(parents=True)
            for stage in STAGES:
                run_stage(reg, build, root, engine, stage, deadline)
            report = verify(root, HERE / "smoke", reg["java_version"], 4)
            if not all(report["engines"][engine]["queries"].values()):
                raise ValueError(f"{engine} typed reference replay failed")
        write_json(root / "AUDIT.json", report)
        verify_inputs(reg)
        guard(root, reg, deadline)
        if not report["qualified"]:
            raise ValueError("typed reference replay failed")
        status["qualified"] = True
        return 0
    except BaseException as error:
        status["stop"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        write_json(root / "FINAL.json", status)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registration-sha256", required=True)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    path = HERE / "REGISTRATION.json"
    if digest(path) != args.registration_sha256:
        parser.error("registration digest differs")
    reg = json.loads(path.read_text())
    if args.verify_only:
        verify_inputs(reg)
        print("Frozen source, JAR, build receipt and artifact hashes match")
    else:
        raise SystemExit(run(reg, args.registration_sha256))
