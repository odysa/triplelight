#!/bin/sh
set -eu

owner=$1
shift
test "$(cat /guard/owner)" = "$owner"
test "$(uname -m)" = aarch64
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS CLASSPATH
export HOME=/tmp RAYON_NUM_THREADS=4

cgroup=/sys/fs/cgroup
for name in cpu.max memory.max memory.swap.max memory.events; do
    cat "$cgroup/$name" > "/stage/before.$name"
done
read -r quota period < /stage/before.cpu.max
test "$quota" -eq "$((4 * period))"
test "$(cat /stage/before.memory.max)" -eq 4294967296
test "$(cat /stage/before.memory.swap.max)" -eq 0

rc=0
/opt/java/openjdk/bin/java -Xmx1g -XX:ActiveProcessorCount=4 -Djava.io.tmpdir=/tmp "$@" || rc=$?

for name in memory.events memory.peak; do
    cat "$cgroup/$name" > "/stage/after.$name"
done
test "$(cat /guard/owner)" = "$owner"
exit "$rc"
