"""Check separate load, reopen, and query receipts for both Java 25 workers."""
import argparse
from collections import Counter
import json
from pathlib import Path

from check_answers import read_answer

STAGES = ("load", "reopen", "query")
ENGINES = ("blazegraph", "triplelight")
CASES = ("terms.rq", "count.rq", "empty.rq")
XSD = "http://www.w3.org/2001/XMLSchema#"
RDF_LANG = "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString"
COMMON = ("stage_complete", "java_version", "java_arch", "available_processors")
CLOSE = {
    "blazegraph": {"connection_closed": "true", "shutdown_returned": "true"},
    "triplelight": {"database_closed": "true"},
}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def get_markers(lines, keys):
    markers = {}
    for line in lines:
        key, separator, value = line.partition("=")
        if not separator or key not in keys:
            continue
        if key in markers:
            raise ValueError(f"duplicate stage marker: {key}")
        markers[key] = value
    return markers


def key(term):
    if term is None:
        return None
    lang = term.get("xml:lang")
    kind, value = term["type"], term["value"]
    if kind == "uri":
        return kind, value
    if kind != "literal":
        raise ValueError("fixture expected IRIs and literals only")
    dt = term.get("datatype", RDF_LANG if lang else XSD + "string")
    return kind, value, dt, lang.lower() if lang else None


def answer_key(answer):
    columns = answer["head"]["vars"]
    return columns, Counter(tuple(key(row.get(col)) for col in columns)
                            for row in answer["results"]["bindings"])


def expected(source):
    reference = read_json(source / "jena.json")
    if reference["head"]["vars"] != ["o", "n"] or len(reference["results"]["bindings"]) != 9:
        raise ValueError("wrong Jena fixture reference")
    # Jena's grouped reference contains each object with its exact multiplicity.
    groups = reference["results"]["bindings"]
    unit = ("literal", "1", XSD + "integer", None)
    if any(key(row.get("n")) != unit or "o" not in row for row in groups):
        raise ValueError("expected one occurrence of each Jena object")
    terms = {"head": {"vars": ["o"]}, "results": {"bindings": [{"o": row["o"]} for row in groups]}}
    if len(answer_key(terms)[1]) != 9:
        raise ValueError("Jena object groups are not distinct")
    count = {"head": {"vars": ["count_result"]}, "results": {"bindings": [
        {"count_result": {"type": "literal", "value": str(len(groups)), "datatype": XSD + "integer"}}
    ]}}
    empty = {"head": {"vars": ["o"]}, "results": {"bindings": []}}
    return {name: answer_key(answer) for name, answer in zip(CASES, (terms, count, empty), strict=True)}


def verify_stage(root, engine, stage, version, workers):
    if read_json(root / "status.json") != {"exit_code": 0, "stop": None}:
        raise ValueError("stage did not exit successfully")
    required = {"stage_complete": stage, "java_version": version, "java_arch": "aarch64",
                "available_processors": str(workers), **CLOSE[engine]}
    if stage == "query":
        required["invalid_query_kind"] = ("SYNTAX" if engine == "triplelight"
                                         else "org.openrdf.query.MalformedQueryException")
    else:
        required["exact_triples"] = "9"
        if engine == "blazegraph":
            required["exact_explicit_triples"] = "9"
            if stage == "load":
                required.update(parse_returned="true", commit_returned="true",
                                normalize_datatype_values="false")
        elif stage == "load":
            required["native_load_added"] = "9"
    lines = (root / "stdout.txt").read_text(encoding="utf-8").splitlines()
    inference = [line.partition("=")[2] for line in lines if line.startswith("include_inferred=")]
    expected_inference = ["true"] * len(CASES) if engine == "blazegraph" and stage == "query" else []
    if inference != expected_inference:
        raise ValueError(f"per-query inference markers differ: {inference}")
    markers = get_markers(lines, set(COMMON) | required.keys())
    if markers != required:
        raise ValueError(f"stage markers differ: expected {required}, observed {markers}")
    if expected_inference:
        markers["include_inferred"] = inference
    return markers


def verify(root, source, version, workers):
    references = expected(source)
    if (source / "queries/ORDER.txt").read_text(encoding="utf-8").splitlines() != list(CASES):
        raise ValueError("fixture query order differs")
    report = {"engines": {}, "qualified": False, "scored": False}
    for engine in ENGINES:
        result = report["engines"][engine] = {"stages": {}, "queries": {}}
        for stage in STAGES:
            folder = root / engine / stage
            try:
                result["stages"][stage] = {"ok": True, "observed": verify_stage(folder, engine, stage, version, workers)}
            except (OSError, ValueError, KeyError, TypeError) as error:
                result["stages"][stage] = {"ok": False, "error": str(error)}
        for index, (name, reference) in enumerate(references.items(), 1):
            try:
                record = read_answer(root / engine / "query/answers" / f"{index:02d}.tsv", name)
                result["queries"][name] = record["status"] == "complete" and answer_key(record["answer"]) == reference
            except (OSError, ValueError, KeyError, TypeError):
                result["queries"][name] = False
    report["qualified"] = all(
        all(stage["ok"] for stage in result["stages"].values()) and all(result["queries"].values())
        for result in report["engines"].values()
    )
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--java-version", required=True)
    parser.add_argument("--processors", type=int, required=True)
    args = parser.parse_args()
    if not args.java_version.startswith("25.") or args.processors <= 0:
        parser.error("register a Java 25 runtime release and a positive processor count")
    result = verify(args.root, Path(__file__).resolve().parent / "smoke", args.java_version, args.processors)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["qualified"] else 1)
