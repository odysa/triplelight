# Matched Java 25 fixture registration

Qualify both embedded drivers on the nine-triple default-graph fixture. Run Blazegraph 2.1.5 and TripleLight from the successful 08835fa5 build in six fresh Linux ARM64 containers. Each engine loads, reopens, then runs three typed answer checks and one malformed-query control. Freeze the build receipt, all class files, native artifacts, comparator JAR, checker and fixture bytes. There is no scored timing.

Both engines receive four CPUs, a 4 GiB cgroup, no swap, a 1 GiB Java heap, four active JVM processors, a 64 MiB private temporary filesystem and no network. TripleLight also receives a four-thread Rayon configuration and the documented Java native-access flag. The script checks the actual Java version, architecture, flags, processor count and cgroup limits. Compare typed answer bags with the frozen Jena references. Check the TripleLight four-order RDFSNAP6 base after every stage and record both stores' apparent and allocated sizes. The TripleLight Java load uses a durable write atop the initialized base, so the size receipt covers the whole store, including its WAL.

Use a new root and the registered exclusive machine lock. The 45-second stage limit and five-minute overall limit stop a failed run without a retry. The one-GiB allocation budget has a 768 MiB sample stop, two MiB caps on each host log and a 42 GiB shared free-space floor. The sample stop provides room for cleanup and receipts. Remove only a container with the registered label and exact stage name. Stage receipts and partial artifacts stay in the root for review.

Run `python3.12 -B run_fixture.py --registration-sha256 <reviewed SHA> --verify-only` to check identity without Docker. Drop `--verify-only` for the approved machine window.

This retry changes only host log capture and attempt identity. The original launcher inherited a file-size limit and exited on SIGXFSZ even though its two captured logs were below that limit. The retry caps the two captured files directly and stops on overflow. Engine commands, images, mounts and input bytes are unchanged.
