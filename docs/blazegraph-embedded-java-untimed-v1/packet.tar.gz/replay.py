"""Verify the archived typed answers without either Java engine."""
from pathlib import Path
import importlib.util
import json

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "check_pass", root / "java/timed-worker-draft/check_pass.py",
)
checker = importlib.util.module_from_spec(spec)
spec.loader.exec_module(checker)

for attempt, engines in (("untimed-v1", ("blazegraph",)), ("untimed-v2", ("blazegraph", "triplelight"))):
    receipt = json.loads((root / f"{attempt}.json").read_bytes())
    if receipt["scored"] or [entry["process"]["engine"] for entry in receipt["runs"]] != list(engines):
        raise ValueError(f"incorrect receipt scope for {attempt}")
    for engine, entry in zip(engines, receipt["runs"], strict=True):
        checked = checker.audit_pass(root / attempt / engine / "discard", "discard")
        if entry["passes"] != [checked] or checked["durations_ns"]:
            raise ValueError(f"incorrect pass receipt for {attempt} {engine}")
        print(f"{attempt} {engine}: {checked['exact_typed_answers']} exact typed answers, 0 durations")
