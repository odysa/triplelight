"""Replay Blazegraph's native tuple stream against independently frozen answers."""

import base64
import hashlib
import json
import re
import sys
from pathlib import Path

RECORD_LIMIT = 64 << 20
ANSWER_LIMIT = (256 << 20) - (1 << 20)
ENCODED = re.compile(r"[A-Za-z0-9_-]*\Z")
POSITIVE = re.compile(r"(?:0|[1-9][0-9]*)\Z")


def decode(value):
    if not ENCODED.fullmatch(value):
        raise ValueError("invalid base64 alphabet")
    with_padding = value + "=" * (-len(value) % 4)
    decoded = base64.b64decode(with_padding, altchars=b"-_", validate=True)
    if base64.urlsafe_b64encode(decoded).decode("ascii").rstrip("=") != value:
        raise ValueError("non-canonical base64")
    return decoded.decode("utf-8")


def rdf_term(token):
    if token == "unbound":
        return None
    parts = token.split(":")
    if len(parts) == 2 and parts[0] in {"iri", "bnode"}:
        value = decode(parts[1])
        if not value:
            raise ValueError("empty IRI or blank-node label")
        return {"type": "uri" if parts[0] == "iri" else "bnode", "value": value}
    if len(parts) != 4 or parts[0] != "literal":
        raise ValueError("unknown RDF term token")
    value, datatype, language = map(decode, parts[1:])
    if language and datatype not in {"", "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString"}:
        raise ValueError("language tag with unrelated datatype")
    term = {"type": "literal", "value": value}
    if language:
        term["xml:lang"] = language
    if datatype:
        term["datatype"] = datatype
    return term


def fields(raw):
    if not raw.endswith(b"\n") or b"\r" in raw:
        raise ValueError("unterminated or malformed TSV")
    return raw[:-1].decode("ascii").split("\t")


def read_answer(path, label):
    if path.is_symlink() or path.stat().st_size > RECORD_LIMIT:
        raise ValueError("result path or byte cap")
    with path.open("rb") as source:
        if fields(source.readline()) != ["label", encoded_label(label)]:
            raise ValueError("query label drift")
        variables = None
        bindings = []
        for raw in source:
            kind, *values = fields(raw)
            if kind == "vars" and variables is None:
                variables = list(map(decode, values))
                if not variables or not all(variables) or len(variables) != len(set(variables)):
                    raise ValueError("invalid native projection")
            elif kind == "row" and variables is not None and len(values) == len(variables):
                terms = [rdf_term(value) for value in values]
                bindings.append({key: value for key, value in zip(variables, terms) if value is not None})
            elif kind == "query-error" and len(values) == 1:
                name = decode(values[0])
                if not name or source.read(1):
                    raise ValueError("malformed terminal query error")
                return {"status": "query-error", "class": name, "partial_rows": len(bindings)}
            elif kind == "complete" and variables is not None and len(values) == 1:
                if not POSITIVE.fullmatch(values[0]) or int(values[0]) != len(bindings) or source.read(1):
                    raise ValueError("wrong final row count or trailing data")
                return {
                    "status": "complete",
                    "answer": {"head": {"vars": variables}, "results": {"bindings": bindings}},
                }
            else:
                raise ValueError("unexpected TSV record")
    raise ValueError("missing terminal record")


def encoded_label(label):
    return base64.urlsafe_b64encode(label.encode("ascii")).decode("ascii").rstrip("=")


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bound_json(path, digest):
    if file_hash(path) != digest:
        raise ValueError(f"identity drift in {path.name}")
    return json.loads(path.read_text())


def replay(workload, results, binding_file, binding_digest):
    bindings = bound_json(binding_file, binding_digest)
    rules = bound_json(workload / "rules-freeze.json", bindings["workload_files"]["rules-freeze.json"])
    sys.path.insert(0, str(workload / "validators"))
    from aggregate_count_policy import compare

    query_rows = bindings["queries"]
    expected = {f"{index:02d}.tsv" for index in range(1, len(query_rows) + 1)}
    present = {path.name for path in results.iterdir()}
    if present - expected or sum((results / name).stat().st_size for name in present) > ANSWER_LIMIT:
        raise ValueError("extra files or answer stream exceeds byte cap")
    reports = []
    for index, query in enumerate(query_rows, 1):
        label = query["label"]
        if file_hash(workload / "queries" / label) != query["query_sha256"]:
            raise ValueError(f"changed query: {label}")
        ref = query["reference"]
        reference = bound_json(workload / "reference" / ref["path"], ref["sha256"])
        path = results / f"{index:02d}.tsv"
        outcome = {"label": label, "primary_pass": False, "count_compatible_pass": False}
        if not path.exists():
            outcome["status"] = "not-run"
        else:
            try:
                parsed = read_answer(path, label)
            except (OSError, ValueError) as error:
                outcome.update(status="incomplete", error=str(error))
            else:
                if parsed["status"] == "complete":
                    outcome["status"] = "complete"
                    try:
                        outcome.update(compare(parsed["answer"], reference, rules["queries"][label]["columns"]))
                    except ValueError as error:
                        outcome["answer_error"] = str(error)
                else:
                    outcome.update(parsed)
        reports.append(outcome)

    seen_gap = False
    for outcome in reports:
        if seen_gap and outcome["status"] != "not-run":
            raise ValueError("query stream resumed after a missing or incomplete record")
        seen_gap |= outcome["status"] in {"not-run", "incomplete"}
    complete = len(reports) == 30 and not seen_gap
    return {
        "labels": reports,
        "stream_complete": complete,
        "all_primary_pass": complete and all(item["primary_pass"] for item in reports),
        "all_count_compatible_pass": complete and all(item["count_compatible_pass"] for item in reports),
        "scored": False,
    }
