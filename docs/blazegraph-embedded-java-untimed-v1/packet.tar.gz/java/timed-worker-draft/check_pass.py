"""Offline gate for the timed worker's per-pass journals and preserved typed answers."""

from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
FROZEN = HERE.parents[1] / "blazegraph39-workload-plan-v1"
BINDINGS = FROZEN / "BINDINGS.json"
BINDINGS_SHA256 = "629f2e63e3528ec7f864cdfbd7ee30943520d313424c8db810b5e738c285aa63"
HEADER = "index\tlabel\trows\tnanoseconds"
ENGINE_PAIRS = (
    ("blazegraph", "triplelight"), ("triplelight", "blazegraph"),
    ("blazegraph", "triplelight"), ("triplelight", "blazegraph"),
    ("blazegraph", "triplelight"), ("triplelight", "blazegraph"),
)


def check(condition, reason):
    if not condition:
        raise ValueError(reason)


def bindings():
    raw = BINDINGS.read_bytes()
    check(sha256(raw).hexdigest() == BINDINGS_SHA256, "query binding identity differs")
    rows = json.loads(raw)["queries"]
    check(len(rows) == len({q["label"] for q in rows}) == 30, "scheduled label set differs")
    return rows


def order_text(rows):
    return "".join(f'{row["label"]}\t{row["query_sha256"]}\n' for row in rows)


def audit_journal(journal, assessed, scored):
    lines = journal.splitlines()
    check(len(lines) == len(assessed) + 1 and lines[0] == HEADER, "journal header or count differs")
    times = []
    for i, (line, reference) in enumerate(zip(lines[1:], assessed, strict=True), 1):
        fields = line.split("\t")
        check(len(fields) == 4, "journal record shape differs")
        index, label, rows, duration = fields
        check(index == str(i) and label == reference["label"] and rows == str(reference["rows"]),
              f"journal and answer identity differ: {label}")
        if scored:
            check(re.fullmatch(r"[1-9][0-9]{0,18}", duration) and int(duration) <= (1 << 63) - 1,
                  f"invalid elapsed duration: {label}")
            times.append(int(duration))
        else:
            check(duration == "", f"unscored phase contains an elapsed duration: {label}")
    return times


def audit_pass(folder, phase):
    check(phase in ("discard", "warmup", "scored"), "invalid pass role")
    expected = bindings()
    spec = importlib.util.spec_from_file_location("matched_java_answers", FROZEN / "check_answers.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    answer = module.replay(FROZEN / "workload", folder / "answers", BINDINGS, BINDINGS_SHA256)
    labels = answer["labels"]
    check(answer["stream_complete"] and answer["all_primary_pass"]
          and [x["label"] for x in labels] == [q["label"] for q in expected], "typed answer check failed")
    times = audit_journal((folder / "samples.tsv").read_text(encoding="ascii"), labels, phase == "scored")
    return {"phase": phase, "exact_typed_answers": len(labels), "durations_ns": times}
