#!/usr/bin/env python3
"""One untimed 120s whole-child window; never removes or acquires the lock."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parent
OWNER = 'Jianlin task39 Oxilite tiny feasibility v1'
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check():
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != OWNER:
        raise RuntimeError('exact own lock required')
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--freeze-sha256', required=True)
    a = ap.parse_args()
    check()
    if sha(ROOT / 'FREEZE.json') != a.freeze_sha256:
        raise RuntimeError('freeze mismatch')
    freeze = json.loads((ROOT / 'FREEZE.json').read_text())
    def unchanged():
        return all(sha(ROOT / n) == h for n, h in freeze['files'].items())
    if not unchanged():
        raise RuntimeError('preflight identity mismatch')
    a.out.mkdir(exist_ok=False)
    records = []
    deadline = time.monotonic() + 120
    try:
        for mode in ['memory', 'disk-load', 'disk-reopen']:
            check()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('whole window exceeded')
            with (a.out / (mode + '.stdout')).open('wb') as stdout, (a.out / (mode + '.stderr')).open('wb') as stderr:
                p = subprocess.Popen([sys.executable, '-B', str(ROOT / 'run.py'), '--mode', mode, '--out', str(a.out / mode)], stdout=stdout, stderr=stderr, start_new_session=True)
                try:
                    code = p.wait(timeout=remaining)
                except subprocess.TimeoutExpired:
                    os.killpg(p.pid, signal.SIGKILL)
                    code = p.wait()
                    records.append({'mode': mode, 'exit_code': code, 'timeout': True})
                    raise TimeoutError('whole child cap exceeded')
            records.append({'mode': mode, 'exit_code': code, 'timeout': False})
            if code != 0:
                raise RuntimeError('setup/driver failure; no retries')
    finally:
        verdicts = {}
        for mode in ['memory', 'disk-load', 'disk-reopen']:
            try:
                summary = json.loads((a.out / mode / 'summary.json').read_text())
                verdicts[mode] = (summary.get('mode') == mode
                                  and summary.get('tiny_answers_pass') is True
                                  and summary.get('full_workload_qualified') is False)
            except (OSError, ValueError, TypeError, AttributeError):
                verdicts[mode] = False
        identities_ok = unchanged()
        admitted = (len(records) == 3 and all(r['exit_code'] == 0 and not r['timeout'] for r in records)
                    and identities_ok and all(verdicts.values()))
        result = {'scored': False, 'children': records, 'identities_unchanged': identities_ok,
                  'admitted': admitted, 'admission_scope': 'tiny_answer_feasibility_only',
                  'full_workload_qualified': False, 'profile_verdicts': verdicts,
                  'lock_release': 'caller only after all children exited'}
        (a.out / 'supervisor.json').write_text(json.dumps(result, indent=2) + '\n')
    check()
    if not unchanged():
        raise RuntimeError('postflight identity mismatch')
if __name__ == '__main__':
    main()
