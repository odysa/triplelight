#!/usr/bin/env python3
"""Untimed Oxilite feasibility; each mode runs in a separate child process."""
import argparse
from collections import Counter
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import sys

OWNER = 'Jianlin task39 Oxilite tiny feasibility v1'
ROOT = Path(__file__).resolve().parent

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def lock():
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != OWNER:
        raise RuntimeError('exact own lock required')

def key(t):
    if t is None:
        return None
    if t['type'] == 'literal':
        lang = t.get('xml:lang', '').lower()
        dt = t.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if lang else 'http://www.w3.org/2001/XMLSchema#string')
        return ('literal', t['value'], dt, lang)
    return (t['type'], t['value'])

def bag(a):
    cols = a['head']['vars']
    return Counter(tuple(key(r.get(v)) for v in cols) for r in a['results']['bindings'])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--mode', choices=['memory', 'disk-load', 'disk-reopen'], required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    lock()
    freeze = json.loads((ROOT / 'FREEZE.json').read_text())
    for n, h in freeze['files'].items():
        if sha(ROOT / n) != h:
            raise RuntimeError('source/input mismatch: ' + n)
    args.out.mkdir(exist_ok=False)
    dist = metadata.distribution('oxilite')
    if dist.version != '0.10.0':
        raise RuntimeError('unexpected Oxilite version')
    installed = {}
    for item in dist.files or []:
        p = Path(dist.locate_file(item))
        if p.is_file() and not str(item).endswith('.pyc'):
            installed[str(item)] = sha(p)
    import oxilite as ox
    identity = {'python': sys.version, 'executable_sha256': sha(sys.executable),
                'platform': platform.platform(), 'version': dist.version,
                'module_file': str(ox.__file__), 'module_sha256': sha(ox.__file__),
                'distribution_files': installed, 'sqlite_backend_version': None,
                'sqlite_version_note': 'bundled backend version unobserved; Python sqlite3 is not used',
                'mode': args.mode, 'scored': False}
    (args.out / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    db = args.out.parent / 'tiny.sqlite'
    if args.mode == 'disk-load' and db.exists():
        raise RuntimeError('disk database must be fresh')
    if args.mode == 'disk-reopen' and not db.is_file():
        raise RuntimeError('reopen requires previous disk-load database')
    store = ox.Store() if args.mode == 'memory' else ox.Store(str(db))
    if args.mode != 'disk-reopen':
        store.load(path=str(ROOT / 'consumer-fixture.nt'), format=ox.RdfFormat.N_TRIPLES)
    reference = json.loads((ROOT / 'consumer-fixture-jena.json').read_text())
    objects = {'head': {'vars': ['o']}, 'results': {'bindings': [{'o': r['o']} for r in reference['results']['bindings']]}}
    queries = {
        'group': (ROOT / 'consumer-fixture.rq').read_text(),
        'plain': 'SELECT ?o WHERE { <urn:s> <urn:v> ?o }',
        'distinct': 'SELECT DISTINCT ?o WHERE { <urn:s> <urn:v> ?o }',
        'count': 'SELECT (COUNT(*) AS ?n) WHERE { <urn:s> <urn:v> ?o }',
        'distinct_count': 'SELECT (COUNT(DISTINCT ?o) AS ?n) WHERE { <urn:s> <urn:v> ?o }',
        'empty': 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }',
        'unbound': 'SELECT ?o ?missing WHERE { <urn:s> <urn:v> ?o OPTIONAL { <urn:s> <urn:absent> ?missing } }',
        'ask_false': 'ASK { <urn:absent> <urn:v> ?o }'}
    def term(t):
        if isinstance(t, ox.NamedNode):
            return {'type': 'uri', 'value': t.value}
        if isinstance(t, ox.BlankNode):
            return {'type': 'bnode', 'value': t.value}
        if isinstance(t, ox.Literal):
            r = {'type': 'literal', 'value': t.value, 'datatype': t.datatype.value}
            if t.language:
                r['xml:lang'] = t.language
            return r
        raise TypeError('unrecognized native RDF term: ' + type(t).__name__)
    records = {}
    for label, query in queries.items():
        lock()
        r = {'query': query, 'execution_route': 'unclassified', 'checks': {}}
        try:
            # Human-readable compiler diagnostic is retained verbatim; never infer
            # SQL-only execution from a successful answer or a substring heuristic.
            r['explain'] = store.explain(query)
        except Exception as e:
            r['explain_error'] = repr(e)
        try:
            result = store.query(query)
            if label == 'ask_false':
                if not isinstance(result, ox.QueryBoolean):
                    raise TypeError('expected native QueryBoolean')
                answer = {'boolean': bool(result)}
                r['checks'] = {'false_boolean': answer == {'boolean': False}}
            else:
                if not isinstance(result, ox.QuerySolutions):
                    raise TypeError('expected native QuerySolutions')
                cols = [v.value for v in result.variables]
                bindings = [{v: term(row[i]) for i, v in enumerate(cols) if row[i] is not None} for row in result]
                answer = {'head': {'vars': cols}, 'results': {'bindings': bindings}}
                if label == 'group':
                    r['checks'] = {'projection': cols == reference['head']['vars'], 'strict_bag': bag(answer) == bag(reference)}
                elif label in ['plain', 'distinct']:
                    r['checks'] = {'projection': cols == ['o'], 'strict_bag': bag(answer) == bag(objects)}
                elif label in ['count', 'distinct_count']:
                    expected = {'head': {'vars': ['n']}, 'results': {'bindings': [{'n': {'type': 'literal', 'value': '9', 'datatype': 'http://www.w3.org/2001/XMLSchema#integer'}}]}}
                    r['checks'] = {'projection': cols == ['n'], 'typed_count': bag(answer) == bag(expected)}
                elif label == 'empty':
                    r['checks'] = {'empty_with_projection': answer == {'head': {'vars': ['o']}, 'results': {'bindings': []}}}
                else:
                    projected = {'head': {'vars': ['o']}, 'results': {'bindings': [{'o': b['o']} for b in bindings if 'o' in b]}}
                    r['checks'] = {'projection': cols == ['o', 'missing'], 'strict_object_bag': bag(projected) == bag(objects), 'all_unbound': all('missing' not in b for b in bindings)}
            r['answer'] = answer
        except Exception as e:
            r['error'] = repr(e)
        r['pass'] = 'error' not in r and bool(r['checks']) and all(r['checks'].values())
        (args.out / (label + '.json')).write_text(json.dumps(r, indent=2) + '\n')
        records[label] = r
    lock()
    summary = {'mode': args.mode, 'scored': False, 'stored_quads': len(store),
               'tiny_answers_pass': len(store) == 9 and all(r['pass'] for r in records.values()),
               'execution_route': 'unclassified_pending_manual_explain_review',
               'full_workload_qualified': False, 'connection_boundary': 'child process exit; no documented close method'}
    (args.out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')

if __name__ == '__main__':
    main()
