# Packaging note (packet v2)

Packet v2 = packet v1 (`packet-v1.tar.gz`, unchanged, the audited input) plus `summarize-v2.py`, `SUMMARY-v2.json`
and this note, with a regenerated `PACKET_FILES.json`.

- v1's `summarize.py` reconstructed each phase interval as the phase directory's birth time plus the receipt's
  container duration. Preparation (clone, cache drop, create, inspect) precedes that duration, and directory birth
  times are not preserved in the packet.
- v2 uses a portable, preserved proxy: the mtime of the phase's empty `container.log`, created at the
  `docker start -a` call, plus the receipt's container duration. It is a reconstructed host timestamp proxy.
- Every counter and timing field in `SUMMARY-v2.json` equals `SUMMARY.json`; the overlap flags are identical
  (phases 13, 14, 15 against the enclosing window 11:36:56–11:38:29Z).
