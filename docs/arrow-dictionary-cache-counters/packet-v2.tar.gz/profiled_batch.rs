    fn batch(&mut self) -> Result<Option<RecordBatch>, ArrowError> {
        let clk = Instant::now(); // PROFILE: collect
        let rows = self.sol.rows;
        if self.next_row >= rows { self.st.collect += ms(clk); return Ok(None) } // PROFILE: + clock
        let start = self.next_row;
        let n = (rows - start).min(BATCH_ROWS);
        self.next_row += n;
        let width = self.sol.vars.len();
        let options = RecordBatchOptions::new().with_row_count(Some(n));
        if width == 0 {
            self.st.collect += ms(clk); // PROFILE
            // A zero-column SELECT keeps its cardinality: n solutions, no columns.
            return RecordBatch::try_new_with_options(Arc::clone(&self.schema), vec![], &options).map(Some);
        }
        let cells = &self.sol.ids[start * width..(start + n) * width];
        let mut distinct: Vec<TermId> = cells.iter().copied().filter(|id| *id != UNBOUND && !self.sol.scratch.contains_key(id)).collect();
        distinct.sort_unstable();
        distinct.dedup();
        self.st.distinct += distinct.len() as u64; // PROFILE
        self.st.collect += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: decode
        let mut decoded: Vec<Option<Owned>> = vec![None; distinct.len()];
        let mut failure = None;
        self.snap.with_terms(&distinct, &mut |i, t| match owned(t) {
            Ok(o) => decoded[i] = Some(o),
            Err(e) => failure = Some(e),
        }).map_err(|e| ArrowError::ExternalError(Box::new(e)))?;
        if let Some(e) = failure { return Err(e) }
        self.st.decode += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: scratch
        // Computed (scratch) terms: convert only those present in this batch.
        let mut scratch: std::collections::HashMap<TermId, Owned> = std::collections::HashMap::new();
        for id in cells {
            if scratch.contains_key(id) { continue }
            if let Some(t) = self.sol.scratch.get(id) {
                scratch.insert(*id, owned(t.as_ref())?);
            }
        }
        self.scratch_converted += scratch.len();
        self.st.scratch += ms(clk); // PROFILE
        let clk = Instant::now(); // PROFILE: build
        let mut columns: Vec<ArrayRef> = Vec::with_capacity(width);
        for col in 0..width {
            let mut kind = StringBuilder::new();
            let mut value = LargeStringBuilder::new();
            let mut datatype = StringBuilder::new();
            let mut language = StringBuilder::new();
            let mut nulls = Vec::with_capacity(n);
            // i32-offset columns must not overflow: check their byte totals before appending.
            let (mut dt_bytes, mut lang_bytes) = (0usize, 0usize);
            for r in 0..n {
                let id = cells[r * width + col];
                let term = if id == UNBOUND {
                    None
                } else if let Some(t) = scratch.get(&id) {
                    Some(t)
                } else {
                    let i = distinct.binary_search(&id).map_err(|_| ArrowError::ComputeError("undecoded term ID".into()))?;
                    Some(decoded[i].as_ref().ok_or_else(|| ArrowError::ComputeError("dictionary omitted a requested term".into()))?)
                };
                nulls.push(term.is_some());
                match term {
                    None => { kind.append_value(""); value.append_value(""); datatype.append_null(); language.append_null(); }
                    Some(t) => {
                        dt_bytes += t.datatype.as_ref().map_or(0, String::len);
                        lang_bytes += t.language.as_ref().map_or(0, String::len);
                        if dt_bytes > i32::MAX as usize || lang_bytes > i32::MAX as usize {
                            return Err(ArrowError::ComputeError("batch string data exceeds Utf8 offset range".into()));
                        }
                        kind.append_value(t.kind);
                        value.append_value(&t.value);
                        datatype.append_option(t.datatype.as_deref());
                        language.append_option(t.language.as_deref());
                    }
                }
            }
            let children: Vec<ArrayRef> = vec![Arc::new(kind.finish()), Arc::new(value.finish()), Arc::new(datatype.finish()), Arc::new(language.finish())];
            let array = StructArray::try_new(term_fields(), children, Some(nulls.into()))?;
            columns.push(Arc::new(array));
        }
        let out = RecordBatch::try_new_with_options(Arc::clone(&self.schema), columns, &options).map(Some); // PROFILE: bind
        self.st.build += ms(clk); // PROFILE
        out // PROFILE: `decoded`, `scratch`, `distinct` drop at return, after the build clock (remainder)
    }
