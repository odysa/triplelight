import json, os, statistics
from pathlib import Path
A = Path("/tmp/a36/scored-v3/attempt")
st = json.loads((A / "status.json").read_text()); reg = json.loads(Path("/tmp/a36/scored-v3/registration.json").read_text())
SLOTS = range(8); NAMES = ["hits", "misses", "reads", "bytes", "evictions"]
OV = (1795174616, 1795174709)  # 11:36:56Z-11:38:29Z enclosing overlap window (Jianlin a62a55f1)
def delta(w): return [[w["after"][i][j] - w["before"][i][j] for j in range(5)] for i in SLOTS]
rows = []
for ph in reg["phases"]:
    d = A / ph["id"]; rc = json.loads((d / "receipt.json").read_text()); p = st[ph["id"]]["probe"]
    start = d.stat().st_birthtime; end = start + rc["seconds"]
    overlap = start <= OV[1] and end >= OV[0]
    for x in p["passes"]:
        q, c = delta(x["query_window"]), delta(x["convert_window"])
        rows.append({"phase": ph["id"], "cell": ph["cell"], "trace": ph["trace"], "pass": x["pass"], "position": x["position"],
                     "overlap": overlap, "start_unix": start, "end_unix": end, "total_ms": x["total_ms"], "ids_ms": x["ids_ms"],
                     "decode_ms": (x["stages"] or {}).get("decode_ms"), "query_delta": q, "convert_delta": c,
                     "slot7_convert": dict(zip(NAMES, c[7])), "nonzero_slots_convert": [i for i in SLOTS if any(c[i])],
                     "nonzero_slots_query": [i for i in SLOTS if any(q[i])]})
Path("/tmp/a36/SUMMARY.json").write_text(json.dumps(rows, indent=1))
for cell in ("lubm1000-q9", "lubm1000-q14"):
    on = [r for r in rows if r["cell"] == cell and r["trace"]]
    print(cell, "trace-on obs", len(on), "overlap-flagged phases", sorted({r["phase"] for r in rows if r["cell"] == cell and r["overlap"]}))
    for k in NAMES:
        v = [r["slot7_convert"][k] for r in on]; print(f"  slot7 convert {k:9s} median {statistics.median(v):>12,.0f} range {min(v):,}-{max(v):,}")
    print("  nonzero convert slots", sorted({s for r in on for s in r["nonzero_slots_convert"]}), "nonzero query slots", sorted({s for r in on for s in r["nonzero_slots_query"]}))
    for tr in (True, False):
        tot = [r["total_ms"] for r in rows if r["cell"] == cell and r["trace"] is tr]
        print(f"  trace {'on ' if tr else 'off'} pass total_ms median {statistics.median(tot):,.0f} [{min(tot):,.0f}-{max(tot):,.0f}]")
