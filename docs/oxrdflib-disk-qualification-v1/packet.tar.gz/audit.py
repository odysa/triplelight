"""Audit retained Oxrdflib group/object deltas and between-process inventories."""
from collections import Counter
import json
from pathlib import Path
import sys

XSD = 'http://www.w3.org/2001/XMLSchema#'


def identity(term):
    return (term['type'], term['value'],
            term.get('datatype', XSD + 'string') if term['type'] == 'literal' and not term.get('xml:lang') else None,
            term.get('xml:lang'))


def object_bag(answer):
    return Counter(identity(row['o']) for row in answer['results']['bindings'])


def main():
    packet = Path(sys.argv[1])
    attempt = packet / 'attempt-1'
    reference = json.loads((packet / 'source/consumer-fixture-jena.json').read_text())
    expected = object_bag(reference)
    assert sum(expected.values()) == len(expected) == 9
    summary = json.loads((attempt / 'SUPERVISOR.json').read_text())
    audited = []
    for observation in summary['observations']:
        path = attempt / observation['record']
        raw = json.loads(path.read_text())
        results = raw['answers']
        matching = object_bag(results['group'])
        assert matching == object_bag(results['unbound'])
        assert all(row['n']['value'] == '1' and row['n']['datatype'] == XSD + 'integer'
                   for row in results['group']['results']['bindings'])
        assert sum(matching.values()) == len(matching) == raw['count'] == 8
        inventory = observation.get('before_reopen_files')
        if observation['boundary'] == 'reopen':
            assert inventory['CURRENT'] > 0
            assert any(name.startswith('MANIFEST-') and size > 0 for name, size in inventory.items())
        audited.append({
            'profile': observation['profile'], 'boundary': observation['boundary'],
            'graph_len': raw['count'], 'group_count': len(matching),
            'missing': sorted((expected - matching).elements()),
            'additional': sorted((matching - expected).elements()),
            'store_inventory_verified': inventory is not None,
        })
    assert len(audited) == 8
    print(json.dumps(audited, indent=2) + '\n', end='')


if __name__ == '__main__':
    main()
