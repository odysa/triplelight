"""Capture the isolated interpreter and installed RECORD files without importing engines."""
import base64
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

from qualification import HERE


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def runtime_identity():
    if sys.prefix == sys.base_prefix:
        raise RuntimeError('isolated environment required')
    root = Path(sys.prefix).resolve()
    wheels = json.loads((HERE / 'DEPENDENCIES.json').read_text())['wheels']
    distributions = {}
    for wheel in wheels:
        name = wheel['name']
        dist = importlib.metadata.distribution(name)
        if dist.version != wheel['version'] or not dist.files:
            raise RuntimeError(f'invalid installed distribution {name}')
        files = {}
        for item in dist.files:
            path = Path(dist.locate_file(item)).resolve(strict=True)
            if not path.is_relative_to(root) or not path.is_file():
                raise RuntimeError(f'invalid RECORD path {item}')
            digest = sha(path)
            if item.hash:
                expected = base64.urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip('=')
                if item.hash.mode != 'sha256' or expected != item.hash.value or path.stat().st_size != item.size:
                    raise RuntimeError(f'RECORD mismatch {item}')
            elif not str(item).endswith('.dist-info/RECORD'):
                raise RuntimeError(f'out-of-scope unsigned RECORD entry {item}')
            files[str(path.relative_to(root))] = digest
        distributions[name] = {'version': dist.version, 'files': files}
    return {'python': sys.version, 'executable': sys.executable,
            'executable_sha256': sha(Path(sys.executable)), 'distributions': distributions}


if __name__ == '__main__':
    print(json.dumps(runtime_identity(), indent=2, sort_keys=True))
