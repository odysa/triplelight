"""One declared Oxrdflib profile and one disk boundary per process."""
import argparse
import importlib.metadata
import inspect
import json
from pathlib import Path
import platform
import resource
import sys
import sysconfig
from unittest.mock import patch

from qualification import GRAPH, HERE, PROFILES, QUERIES, evaluate, routes_pass

OWNER = 'Jianlin task39 Oxrdflib tiny feasibility v1'
LOCK = Path('/tmp/rdf-bench.lock/owner')


def require_lock():
    if LOCK.read_text().strip() != OWNER:
        raise RuntimeError('exact owned lock required')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=PROFILES, required=True)
    parser.add_argument('--boundary', choices=('load', 'reopen'), required=True)
    parser.add_argument('--database', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    opts = parser.parse_args()
    require_lock()
    resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024 * 1024,) * 2)
    if (sys.version_info[:3] != (3, 14, 3) or platform.system() != 'Darwin'
            or platform.machine() != 'arm64' or sysconfig.get_config_var('Py_GIL_DISABLED')):
        raise RuntimeError('unexpected runtime')
    dependencies = json.loads((HERE / 'DEPENDENCIES.json').read_text())['wheels']
    versions = {entry['name']: importlib.metadata.version(entry['name']) for entry in dependencies}
    if versions != {entry['name']: entry['version'] for entry in dependencies}:
        raise RuntimeError('unexpected dependency version')

    import rdflib
    from oxrdflib.store import OxigraphStore
    from rdflib.store import VALID_STORE

    def term(value):
        if isinstance(value, rdflib.URIRef):
            return {'type': 'uri', 'value': str(value)}
        if isinstance(value, rdflib.Literal):
            info = {'type': 'literal', 'value': str(value)}
            if value.language:
                info['xml:lang'] = value.language
            if value.datatype:
                info['datatype'] = str(value.datatype)
            return info
        raise TypeError(f'unexpected term type {type(value).__name__}')

    input_parser, normalize = PROFILES[opts.profile]
    literal_default = rdflib.NORMALIZE_LITERALS
    rdflib.NORMALIZE_LITERALS = literal_default if normalize == 'default' else False
    record = {
        'profile': opts.profile, 'boundary': opts.boundary, 'parser': input_parser,
        'literal_default': literal_default, 'normalize_literals': rdflib.NORMALIZE_LITERALS,
        'versions': versions, 'answers': {}, 'errors': {},
        'query_calls': [], 'length_contexts': [],
    }
    original_query = OxigraphStore.query
    original_length = OxigraphStore.__len__
    query_signature = inspect.signature(original_query)
    query_labels = {query: label for label, query in QUERIES.items()}
    returned = {}

    def traced_query(*args, **kwargs):
        bound = query_signature.bind(*args, **kwargs).arguments
        query = bound['query']
        graph = bound['queryGraph']
        call = {'label': query_labels.get(query), 'graph': str(graph),
                'graph_type': type(graph).__name__}
        record['query_calls'].append(call)
        try:
            result = original_query(*args, **kwargs)
        except Exception as exc:
            call['error'] = repr(exc)
            raise
        call['result_type'] = result.type
        returned[query] = result
        return result

    def traced_length(store, context=None):
        record['length_contexts'].append(str(context.identifier) if context is not None else None)
        return original_length(store, context)

    graph = rdflib.Graph(store='Oxigraph', identifier=rdflib.URIRef(GRAPH))
    if type(graph.store) is not OxigraphStore or graph.default_union:
        raise RuntimeError('unexpected Graph store or default graph policy')
    loading = opts.boundary == 'load'
    if not opts.database.is_absolute() or opts.database.is_symlink():
        raise RuntimeError('database must use its dedicated absolute path')
    if loading and opts.database.exists():
        raise RuntimeError('loader requires fresh store path')
    if not loading and not (opts.database / 'CURRENT').is_file():
        raise RuntimeError('reopen requires existing RocksDB CURRENT')
    record['open_status'] = graph.open(str(opts.database), create=loading)
    if record['open_status'] != VALID_STORE or not (opts.database / 'CURRENT').is_file():
        raise RuntimeError('store did not open as a persistent RocksDB store')
    try:
        if loading:
            graph.parse(source=HERE / 'consumer-fixture.nt', format=input_parser)
        with patch.object(OxigraphStore, '__len__', traced_length):
            try:
                record['count'] = len(graph)
            except Exception as exc:
                record['errors']['count'] = repr(exc)
        with patch.object(OxigraphStore, 'query', traced_query):
            for label, query in QUERIES.items():
                try:
                    result = graph.query(query, use_store_provided=True)
                    if returned.get(query) is result:
                        record['query_calls'][-1]['original_result_returned'] = True
                    if result.type == 'ASK' and type(result.askAnswer) is bool:
                        record['answers'][label] = {'boolean': result.askAnswer}
                    elif result.type == 'SELECT':
                        columns = [str(variable) for variable in result.vars]
                        rows = [{column: term(value) for column, value in zip(columns, row, strict=True)
                                 if value is not None} for row in result]
                        record['answers'][label] = {'head': {'vars': columns}, 'results': {'bindings': rows}}
                    else:
                        raise TypeError(f'unexpected query result {result.type}')
                except Exception as exc:
                    record['errors'][label] = repr(exc)
    finally:
        graph.close()

    require_lock()
    record['checks'] = evaluate(record)
    record['routes_pass'] = routes_pass(record)
    record['tiny_pass'] = not record['errors'] and record['routes_pass'] and all(record['checks'].values())
    with opts.out.open('x') as output:
        json.dump(record, output, indent=2)
        output.write('\n')


if __name__ == '__main__':
    main()
