"""Run and retain eight untimed observations under one bounded window."""
import argparse
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

from qualification import HERE, PROFILES, evaluate, routes_pass
from runtime import runtime_identity, sha
from worker import require_lock

STAGE_CAP = 120
FILE_CAP = 8 * 1024 * 1024
TOTAL_CAP = 64 * 1024 * 1024


def inventory(directory, *, active=False):
    files = {}
    for path in sorted(directory.rglob('*')):
        try:
            info = path.lstat()
        except FileNotFoundError:
            if not active:
                raise
            continue
        if stat.S_ISREG(info.st_mode):
            files[str(path.relative_to(directory))] = info.st_size
        elif not stat.S_ISDIR(info.st_mode):
            raise RuntimeError(f'unexpected filesystem entry {path.name}')
    if any(size >= FILE_CAP for size in files.values()) or sum(files.values()) >= TOTAL_CAP:
        raise RuntimeError('scratch output limit reached')
    return files


def store_inventory(database):
    files = inventory(database)
    manifest = (database / 'CURRENT').read_text().strip()
    if not manifest.startswith('MANIFEST-') or files.get(manifest, 0) <= 0:
        raise RuntimeError('RocksDB manifest missing after load')
    return files


def child(out, profile, boundary, database, deadline):
    name = f'{profile}-{boundary}'
    args = [sys.executable, '-E', '-s', '-B', str(HERE / 'worker.py'),
            '--profile', profile, '--boundary', boundary, '--database', str(database),
            '--out', str(out / f'{name}.json')]
    require_lock()
    with (out / f'{name}.stdout').open('xb') as stdout, (out / f'{name}.stderr').open('xb') as stderr:
        process = subprocess.Popen(args, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while process.poll() is None:
                require_lock()
                inventory(out, active=True)
                if time.monotonic() >= deadline:
                    raise TimeoutError('query stage deadline reached')
                time.sleep(0.1)
        finally:
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
    inventory(out)
    require_lock()
    return process.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--runtime', type=Path, required=True)
    parser.add_argument('--runtime-sha256', required=True)
    opts = parser.parse_args()
    require_lock()
    if not opts.out.is_absolute():
        raise RuntimeError('fresh absolute output path required')
    manifest = HERE / 'FREEZE.json'
    if sha(manifest) != opts.source_sha256 or sha(opts.runtime) != opts.runtime_sha256:
        raise RuntimeError('announced receipt digest mismatch')
    sources = json.loads(manifest.read_text())
    runtime = json.loads(opts.runtime.read_text())

    def check_identity():
        if sha(manifest) != opts.source_sha256 or sha(opts.runtime) != opts.runtime_sha256:
            raise RuntimeError('source/runtime receipt changed')
        if any(sha(HERE / name) != digest for name, digest in sources.items()):
            raise RuntimeError('frozen input changed')
        if runtime_identity() != runtime:
            raise RuntimeError('runtime changed')

    check_identity()
    opts.out.mkdir()
    report = {'scored': False, 'full_workload_qualified': False, 'observations': [],
              'source_sha256': opts.source_sha256, 'runtime_sha256': opts.runtime_sha256}
    deadline = time.monotonic() + STAGE_CAP
    try:
        for profile in PROFILES:
            database = opts.out / f'{profile}.db'
            for boundary in ('load', 'reopen'):
                observation = {'profile': profile, 'boundary': boundary, 'tiny_pass': False}
                report['observations'].append(observation)
                if boundary == 'reopen':
                    if previous['exit_code'] != 0:
                        observation['state'] = 'skipped-after-loader-error'
                        continue
                    observation['before_reopen_files'] = store_inventory(database)
                if time.monotonic() >= deadline:
                    raise TimeoutError('query stage deadline reached')
                observation['exit_code'] = child(opts.out, profile, boundary, database, deadline)
                if observation['exit_code'] == 0:
                    name = f'{profile}-{boundary}.json'
                    record = json.loads((opts.out / name).read_text())
                    if (record['profile'], record['boundary']) != (profile, boundary):
                        raise RuntimeError('observation identity mismatch')
                    checks = evaluate(record)
                    route = routes_pass(record)
                    verdict = not record['errors'] and route and all(checks.values())
                    if record['checks'] != checks or record['routes_pass'] != route or record['tiny_pass'] != verdict:
                        raise RuntimeError('worker and supervisor checks disagree')
                    observation.update({'state': 'observed', 'record': name, 'checks': checks,
                                        'routes_pass': route, 'tiny_pass': verdict})
                else:
                    observation['state'] = 'worker-error'
                previous = observation
    finally:
        try:
            require_lock()
            check_identity()
            report['identity_postcheck'] = True
        finally:
            (opts.out / 'SUPERVISOR.json').write_text(json.dumps(report, indent=2) + '\n')

    if any(item['state'] != 'observed' for item in report['observations']):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
