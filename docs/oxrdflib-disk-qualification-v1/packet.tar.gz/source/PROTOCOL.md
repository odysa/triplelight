# Oxrdflib disk qualification plan

Test the Oxrdflib Graph API on macOS ARM64 against the existing nine-term Jena reference. Oxrdflib routes the selected string queries through PyOxigraph. This is an adapter and persistence check for the Oxigraph engine family. The fixture is small enough to isolate result semantics. Use these checks for admission only.

## Frozen comparison

- Target GIL-enabled CPython 3.14.3, Oxrdflib 0.5.0, PyOxigraph 0.5.13, RDFLib 7.6.0 and pyparsing 3.3.3. The dependency manifest records the four selected wheels and their published sizes and SHA-256 digests. PyOxigraph's cp39-abi3 wheel is the intended match for standard CPython 3.14 on macOS ARM64. Verify compatibility and the actual interpreter and module identities at setup.
- Use four independent disk stores at fresh paths. Cross the RDFLib nt and Oxrdflib ox-nt parser entry points with RDFLib's installed literal-normalization default and normalization explicitly disabled. The default must match the imported RDFLib setting and be captured separately from the requested profile.
- Use the same explicit IRI graph identifier for all profiles and both processes. Obtain the plugin via Graph(store="Oxigraph", identifier=...). Confirm the concrete OxigraphStore class. Call open(create=True) before loading, record the store-open result and verify that a persistent store materialized before leaving the loader. Start a fresh process to reopen only after the loader exited and the persistent store has been observed at the registered path. Require existing database files before open(create=False), and test reopen without re-parsing the fixture. Use the existing on-disk store type returned from the declared Graph API.
- Read from Graph.query with the store-provided route enabled. Wrap and record calls to the installed OxigraphStore.query for the exact scheduled strings, delegating to the original method and recording a successfully returned result. A call that raises NotImplementedError or falls back is a failed route check even if RDFLib returns rows. Source and runtime evidence are both needed because RDFLib can fall back.
- Run the four queries used by the RDFLib Memory report at both boundaries of each profile and preserve exact lexical terms, datatype, language, column order, unbound cells and ASK boolean. Compare grouped columns and typed bag, empty projected columns and zero rows, unbound projected columns and typed object bag, truly absent unbound cells and false ASK. Verify count nine with the public Graph length API. Seven answer checks plus one count check per boundary, for 64 checks across eight observations paired by store. Record exact answers even for expected semantic failures. A missing observation, path/route error or run failure cannot pass.
- Literal normalization may happen while loading through the nt parser or while converting results back to RDFLib terms. At the pinned adapter revision ox-nt delegates a load directly into PyOxigraph for this store, and the result converter calls RDFLib Literal without normalize= explicitly. Differences between profiles can narrow down where to investigate. Report the failing observation and parser/runtime settings with any causal attribution supported by a separate probe.
- Preserve raw native API responses and exceptions, plus a replay that checks results against the frozen reference outside either engine. No blank nodes are present in this fixture. The load/reopen pair qualifies persistence for the nine tested terms and four queries. This plan uses explicit disk stores, excludes the implicit temporary store and collects no performance measurements.

## Graph scope

RDFLib 7.6.0 passes the explicit Graph identifier to Store.query for a non-union Graph and calls the store length method with that Graph as context. The pinned Oxrdflib store maps the URIRef query argument to PyOxigraph's default_graph and supplies use_default_graph_as_union=False. The length method also uses that Graph as its default graph. The worker verifies the URIRef and context seen by the two wrappers. The supervisor records the RocksDB CURRENT and manifest inventory after loader exit and before reopen.

## Execution boundary

Setup, query source review and execution are pending. Use fresh dedicated scratch outside existing run roots and a bounded, announced machine window when available. Require exact wheel hashes before installation, an isolated wheel-only environment, a complete installed-file manifest with RECORD verification, source and fixture checksums, and a single supervisor owning only the child processes it started. Use a 120 s overall query-stage deadline and a 5 min setup deadline. Record setup failures, capped output, child exits, pre/post input identity and exact lock release. Keep independent profiles running after ordinary answer failures. Stop on a lost lock, identity change or a resource/containment failure. Retain every attempt and leave the existing measured cohorts untouched.

## Sources

- [Oxrdflib v0.5.0 on PyPI](https://pypi.org/project/oxrdflib/0.5.0/)
- [Pinned store implementation](https://github.com/oxigraph/oxrdflib/blob/8313a019242264f52767301dcb6f2ea5dfd5738f/src/oxrdflib/store.py)
- [Pinned parser implementation](https://github.com/oxigraph/oxrdflib/blob/8313a019242264f52767301dcb6f2ea5dfd5738f/src/oxrdflib/parser.py)
- [Pinned result converter](https://github.com/oxigraph/oxrdflib/blob/8313a019242264f52767301dcb6f2ea5dfd5738f/src/oxrdflib/_converter.py)
- [Prior fixture and RDFLib Memory qualification](https://github.com/odysa/triplelight/tree/main/docs/rdflib-tiny-qualification-v1)
- [Pinned RDFLib Graph implementation](https://github.com/RDFLib/rdflib/blob/7.6.0/rdflib/graph.py)
