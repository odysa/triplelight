"""Prepare the exact wheel-only environment, without loading the candidate engine."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import sysconfig
import time
from urllib.request import urlopen

from qualification import HERE
from runtime import sha
from worker import require_lock

BASE_PYTHON_SHA256 = 'fe027e1504df20b6b93b1c9dbc2695a3dc592cd0dc7916b1a3349c97d9104527'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--source-sha256', required=True)
    opts = parser.parse_args()
    require_lock()
    if (not opts.out.is_absolute() or sys.version_info[:3] != (3, 14, 3)
            or platform.system() != 'Darwin' or platform.machine() != 'arm64'
            or sysconfig.get_config_var('Py_GIL_DISABLED')
            or sha(Path(sys.executable)) != BASE_PYTHON_SHA256):
        raise RuntimeError('unexpected setup path or interpreter')

    def source_check():
        manifest = HERE / 'FREEZE.json'
        if sha(manifest) != opts.source_sha256:
            raise RuntimeError('source receipt digest mismatch')
        if any(sha(HERE / name) != digest for name, digest in json.loads(manifest.read_text()).items()):
            raise RuntimeError('source files changed')

    source_check()
    opts.out.mkdir()
    deadline = time.monotonic() + 300

    def remaining_seconds():
        require_lock()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError('setup deadline reached')
        return remaining

    def run(label, args, output=None):
        remaining_seconds()
        with (output or opts.out / f'{label}.stdout').open('xb') as stdout, \
                (opts.out / f'{label}.stderr').open('xb') as stderr:
            child = subprocess.Popen(args, stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                while child.poll() is None:
                    remaining_seconds()
                    if os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size > 8 * 2**20:
                        raise RuntimeError('setup output cap reached')
                    time.sleep(0.1)
            finally:
                if child.poll() is None:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    child.wait()
            if child.returncode:
                raise subprocess.CalledProcessError(child.returncode, args)

    wheels = json.loads((HERE / 'DEPENDENCIES.json').read_text())['wheels']
    wheel_paths = []
    for wheel in wheels:
        target = opts.out / wheel['filename']
        with urlopen(wheel['url'], timeout=min(15, remaining_seconds())) as response, target.open('xb') as output:
            digest = hashlib.sha256()
            size = 0
            while block := response.read(2**16):
                remaining_seconds()
                size += len(block)
                if size > wheel['bytes']:
                    raise RuntimeError(f'wheel exceeds declared size {target.name}')
                digest.update(block)
                output.write(block)
        if size != wheel['bytes'] or digest.hexdigest() != wheel['sha256']:
            raise RuntimeError(f'wheel identity mismatch {target.name}')
        wheel_paths.append(str(target))

    venv = opts.out / 'venv'
    run('venv', [sys.executable, '-I', '-B', '-m', 'venv', str(venv)])
    python = str(venv / 'bin/python')
    run('install', [python, '-I', '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check',
                    'install', '--no-index', '--no-deps', '--only-binary=:all:', '--no-compile',
                    *wheel_paths])
    run('runtime', [python, '-E', '-s', '-B', str(HERE / 'runtime.py')], opts.out / 'RUNTIME.json')
    source_check()
    remaining_seconds()


if __name__ == '__main__':
    main()
