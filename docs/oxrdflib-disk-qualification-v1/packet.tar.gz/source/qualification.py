"""Engine-independent schedule and answer checks for the Oxrdflib disk profile."""
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
GRAPH = 'urn:triplelight:qualification:oxrdflib39'
PROFILES = {
    'nt-default': ('nt', 'default'),
    'nt-preserve': ('nt', 'preserve'),
    'ox-nt-default': ('ox-nt', 'default'),
    'ox-nt-preserve': ('ox-nt', 'preserve'),
}
QUERIES = {
    'group': (HERE / 'consumer-fixture.rq').read_text(),
    'empty': 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }',
    'unbound': 'SELECT ?o ?missing WHERE { <urn:s> <urn:v> ?o OPTIONAL { <urn:s> <urn:absent> ?missing } }',
    'ask_false': 'ASK { <urn:absent> <urn:v> ?o }',
}
REFERENCE = json.loads((HERE / 'consumer-fixture-jena.json').read_text())


def term_key(term):
    if term is None:
        return None
    if term['type'] == 'literal':
        language = term.get('xml:lang', '').lower()
        implicit_datatype = ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
                             if language else 'http://www.w3.org/2001/XMLSchema#string')
        return 'literal', term['value'], term.get('datatype', implicit_datatype), language
    return term['type'], term['value']


def columns(answer):
    return answer.get('head', {}).get('vars')


def rows(answer):
    return answer.get('results', {}).get('bindings', [])


def bag(answer, variables):
    return Counter(tuple(term_key(row.get(v)) for v in variables) for row in rows(answer))


def evaluate(record):
    answers = record['answers']
    group = answers.get('group', {})
    unbound = answers.get('unbound', {})
    return {
        'count': type(record.get('count')) is int and record['count'] == 9,
        'group_columns': columns(group) == columns(REFERENCE),
        'group_typed_bag': bag(group, columns(REFERENCE)) == bag(REFERENCE, columns(REFERENCE)),
        'empty_projection': answers.get('empty') == {'head': {'vars': ['o']}, 'results': {'bindings': []}},
        'unbound_columns': columns(unbound) == ['o', 'missing'],
        'unbound_typed_bag': bag(unbound, ['o']) == bag(REFERENCE, ['o']),
        'unbound_cells': bool(rows(unbound)) and all(set(row) == {'o'} for row in rows(unbound)),
        'false_ask': answers.get('ask_false', {}).get('boolean') is False,
    }


def routes_pass(record):
    calls = record['query_calls']
    return (
        record['length_contexts'] == [GRAPH]
        and [call['label'] for call in calls] == list(QUERIES)
        and all(call['graph'] == GRAPH and call['graph_type'] == 'URIRef'
                and call.get('original_result_returned') is True
                and call.get('result_type') == ('ASK' if call['label'] == 'ask_false' else 'SELECT')
                for call in calls)
    )
