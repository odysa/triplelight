"""Recompute the scoped verdict from retained answers using only the standard library."""
import argparse
import json
from pathlib import Path

from qualification import PROFILES, evaluate, routes_pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('attempt', type=Path)
    opts = parser.parse_args()
    summary = json.loads((opts.attempt / 'SUPERVISOR.json').read_text())
    expected = [(profile, boundary) for profile in PROFILES for boundary in ('load', 'reopen')]
    observed = summary['observations']
    if (summary.get('identity_postcheck') is not True or summary.get('scored') is not False
            or summary.get('full_workload_qualified') is not False
            or [(item['profile'], item['boundary']) for item in observed] != expected):
        raise RuntimeError('incomplete or inconsistent attempt')
    outputs = []
    for item in observed:
        profile, boundary = item['profile'], item['boundary']
        name = f'{profile}-{boundary}.json'
        if item.get('record') != name or item.get('exit_code') != 0 or item.get('state') != 'observed':
            raise RuntimeError(f'missing raw observation {name}')
        raw = json.loads((opts.attempt / name).read_text())
        if (raw['profile'], raw['boundary']) != (profile, boundary):
            raise RuntimeError(f'observation identity mismatch {name}')
        parser_name, normalization = PROFILES[profile]
        required = raw['literal_default'] if normalization == 'default' else False
        if raw['parser'] != parser_name or type(required) is not bool or raw['normalize_literals'] is not required:
            raise RuntimeError(f'profile identity mismatch {name}')
        checks = evaluate(raw)
        route = routes_pass(raw)
        verdict = not raw['errors'] and route and all(checks.values())
        for record in (item, raw):
            if record['checks'] != checks or record['routes_pass'] != route or record['tiny_pass'] != verdict:
                raise RuntimeError(f'answer verdict mismatch {name}')
        outputs.append({'profile': profile, 'boundary': boundary, 'checks': checks,
                        'routes_pass': route, 'tiny_pass': verdict})
    print(json.dumps(outputs, indent=2))


if __name__ == '__main__':
    main()
