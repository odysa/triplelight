# Grafeo and sparq native fixture execution

Use GIL-enabled macOS ARM64 CPython 3.14.3 with executable SHA-256 fe027e15…. The exact shared-machine lock owner is `Jianlin task39 Grafeo and sparq fixtures v1`. Recheck the current infrastructure rules, named handoff and lock, then announce the slot and claim it atomically. Each engine always uses its own root and venv. No Docker is needed.

```sh
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/harness/supervise.py setup grafeo --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/harness/supervise.py fixture grafeo --freeze FREEZE_SHA256 --runtime GRAFEO_RUNTIME_SHA256
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/harness/supervise.py setup sparq --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/harness/supervise.py fixture sparq --freeze FREEZE_SHA256 --runtime SPARQ_RUNTIME_SHA256
```

Roots are /private/tmp/rdf-jianlin-grafeo39-tiny-v1 and /private/tmp/rdf-jianlin-sparq39-tiny-v1. Setup verifies the exact wheel digests, installs wheel-only with no dependency resolution, runs pip check and checks installed RECORD contents without importing either RDF engine. Announce the actual runtime digest before each fixture invocation. Setup has a 180-second cap per engine. The fixture uses three sequential child processes with a shared 120-second cap per engine, a sampled 1 GiB write guard and 42 GiB host free-space floor. The fixture expects nine triples under native exact result gates. Driver failure preserves the last receipts and stops dependent stages. Independently authorized engines can continue in separate commands.

Grafeo runs a memory store, loads a persistent file and reopens that file after clean close in a new process. Its native tagged types are classified before conversion and checked for different kinds on two same-text terms. The host inventories the file and sidecars after loader exit, and the worker saves the WAL status at open. Only direct evidence of replay justifies a WAL recovery observation.

sparq reads the exact fixture with Graph.load, saves a separately loaded graph to disk, then calls Graph.open_read_only in a new process after the saver exits. It uses OxRDF terms with sparq's own evaluator. The build-and-save query still runs on the loader's graph. Open-read-only is the separate persistent index route. The tagged loader reads the input file into a string, which must be accounted for at scale.

Each memory, load and reopen output is independently checked against the same Jena reference. Ordinary query failures preserve their raw error and the remaining labels continue. No scored timings are collected. Confirm the supervisors returned and all own worker processes exited before exact lock release.
