"""Run the pinned native Python API against the shared fixture."""

import argparse
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIXTURE = HERE / "consumer-fixture.nt"
OWNER = "Jianlin task39 Grafeo and sparq fixtures v1"

QUERIES = {
    "group": (HERE / "consumer-fixture.rq").read_text(),
    "plain": "SELECT ?o WHERE { <urn:s> <urn:v> ?o }",
    "distinct": "SELECT DISTINCT ?o WHERE { <urn:s> <urn:v> ?o }",
    "count": "SELECT (COUNT(*) AS ?n) WHERE { <urn:s> <urn:v> ?o }",
    "distinct_count": "SELECT (COUNT(DISTINCT ?o) AS ?n) WHERE { <urn:s> <urn:v> ?o }",
    "empty": "SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }",
    "unbound": "SELECT ?o ?missing WHERE { <urn:s> <urn:v> ?o OPTIONAL { <urn:s> <urn:absent> ?missing } }",
    "ask_false": "ASK { <urn:absent> <urn:v> ?o }",
}


def require_lock():
    if Path("/private/tmp/rdf-bench.lock/owner").read_text().strip() != OWNER:
        raise RuntimeError("exact own lock required")


def grafeo_term(module, value):
    if type(value) is module.IRI:
        return {"type": "uri", "value": str(value)}
    if type(value) is module.BlankNode:
        return {"type": "bnode", "value": str(value)}
    if type(value) is module.Literal:
        term = {"type": "literal", "value": str(value), "datatype": str(value.datatype)}
        if value.language is not None:
            term["xml:lang"] = value.language
        return term
    raise TypeError(f"unexpected Grafeo value type {type(value).__name__}")


def sparq_term(module, value):
    if type(value) is not module.Term or value.kind not in {"uri", "bnode", "literal"}:
        raise TypeError(f"unexpected sparq RDF term {type(value).__name__}")
    term = {"type": value.kind, "value": value.value}
    if value.kind == "literal":
        term["datatype"] = value.datatype
        if value.language is not None:
            term["xml:lang"] = value.language
    if value.direction is not None:
        term["direction"] = value.direction
    return term


def typed_answer(columns, rows, term):
    if len(columns) != len(set(columns)):
        raise ValueError("duplicate projection")
    bindings = []
    for index, row in enumerate(rows):
        if index >= 128:
            raise ValueError("fixture result exceeds 128 rows")
        if set(row) - set(columns):
            raise ValueError("undeclared native binding")
        bindings.append({key: term(value) for key, value in row.items() if value is not None})
    return {"head": {"vars": columns}, "results": {"bindings": bindings}}


def grafeo_query(module, store, name, text):
    result = store.execute_sparql(text)
    if name == "ask_false":
        if result.kind != "boolean" or type(result.boolean) is not bool:
            raise TypeError("expected native boolean")
        return {"boolean": result.boolean}
    if result.kind != "rows":
        raise TypeError("expected native solutions")
    return typed_answer(result.columns, result, lambda term: grafeo_term(module, term))


def sparq_query(module, store, name, text):
    if name == "ask_false":
        result = store.ask(text)
        if type(result) is not bool:
            raise TypeError("expected native boolean")
        return {"boolean": result}
    result = store.query(text)
    if type(result) is not module.QueryResult:
        raise TypeError("expected native solutions")
    return typed_answer(result.vars, result.rows, lambda term: sparq_term(module, term))


def observe(module, store, run_query):
    observations = {}
    for label, query in QUERIES.items():
        require_lock()
        try:
            result = run_query(module, store, label, query)
            observations[label] = {"answer": result}
        except Exception as error:
            observations[label] = {"error": repr(error)[:2048]}
    return observations


def run(engine, stage, path):
    require_lock()
    if stage == "load" and path.exists():
        raise RuntimeError("persistent path must be fresh")
    if stage == "reopen" and not path.exists():
        raise RuntimeError("reopen is missing the prior artifact")
    if engine == "grafeo":
        import grafeo
        store = grafeo.GrafeoDB() if stage == "memory" else grafeo.GrafeoDB(path=path)
        try:
            wal_on_open = store.wal_status() if stage != "memory" else None
            count = store.load_rdf(FIXTURE, format="ntriples") if stage != "reopen" else None
            records = observe(grafeo, store, grafeo_query)
            metadata = {"features": sorted(grafeo.features()), "info": store.info(), "wal_on_open": wal_on_open}
        finally:
            store.close()
        return {"actual_added": count, "close_returned": True, "runtime_info": metadata, "queries": records}

    import sparq
    store = sparq.Graph.open_read_only(path) if stage == "reopen" else sparq.Graph.load(FIXTURE, format="ntriples")
    saved = stage == "load"
    if saved:
        store.save(path)
    native_count = len(store)
    records = observe(sparq, store, sparq_query)
    del store
    return {"length": native_count, "save_returned": saved, "queries": records}


def main():
    options = argparse.ArgumentParser()
    options.add_argument("engine", choices=["grafeo", "sparq"])
    options.add_argument("stage", choices=["memory", "load", "reopen"])
    options.add_argument("--store", type=Path, required=True)
    options.add_argument("--out", type=Path, required=True)
    args = options.parse_args()
    report = run(args.engine, args.stage, args.store)
    require_lock()
    with args.out.open("x") as handle:
        json.dump({"engine": args.engine, "stage": args.stage, **report}, handle, indent=2)
        handle.write("\n")


if __name__ == "__main__":
    main()
