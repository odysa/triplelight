"""Recompute the sparq fixture gates without importing an RDF engine."""

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"
RUN = ROOT / "run"
sys.path.insert(0, str(SOURCE))
from check_answers import check


def require(value, reason):
    if not value:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replay():
    inventory = read(SOURCE / "FREEZE.json")["files"]
    require(all(sha(SOURCE / path) == digest for path, digest in inventory.items()), "source drift")
    setup = read(RUN / "SETUP.json")
    runtime_sha = sha(RUN / "RUNTIME.json")
    require(setup == {
        "engine": "sparq", "engine_imported": False, "freeze": sha(SOURCE / "FREEZE.json"),
        "pip_check": "pass", "runtime": runtime_sha,
    }, "setup binding drift")
    fixture = RUN / "fixture"
    for name in ("RUNTIME-BEFORE.json", "RUNTIME-AFTER.json"):
        require(sha(fixture / name) == runtime_sha, "runtime drift")
    receipt = read(fixture / "RECEIPT.json")
    require(receipt["runtime"] == runtime_sha and receipt["engine"] == "sparq" and receipt["scored"] is False,
            "fixture binding drift")
    stages = {}
    for mode in ("memory", "load", "reopen"):
        record = read(fixture / (mode + ".json"))
        require(record["engine"] == "sparq" and record["stage"] == mode, "mode drift")
        checks = check(record)
        expected = receipt["stages"][mode]
        require(expected == {"status": "observed", **checks, "files_after": expected["files_after"]},
                "reported gate drift")
        stages[mode] = {"checks": checks["checks"], "native_length": record["length"], "passed": checks["tiny_pass"],
                        "file_count": len(expected["files_after"])}
    files = receipt["stages"]["load"]["files_after"]
    require(files and files == receipt["stages"]["reopen"]["files_after"], "reopen inventory drift")
    store = fixture / "store"
    actual = {str(p.relative_to(store)): {"bytes": p.stat().st_size, "sha256": sha(p)}
              for p in sorted(store.rglob("*")) if p.is_file()}
    require(actual == files, "preserved store identity drift")
    require(read(ROOT / "LOCK_RELEASE.json")["verified_workers"] == [], "uncertain cleanup")
    return {"runtime": runtime_sha, "stages": stages, "all_pass": all(s["passed"] for s in stages.values()),
            "same_files_after_read_only_reopen": True, "scored": False}


if __name__ == "__main__":
    print(json.dumps(replay(), indent=2, sort_keys=True))
