import collections,hashlib,json,subprocess,sys,shutil,inspect
from pathlib import Path
sys.dont_write_bytecode=True
source=Path(__file__).resolve().parent/'source';sys.path.insert(0,str(source))
import native,columnar,cast_domain
from union_queries import compile_union
import ladybug as lb
root=Path('/private/tmp/rdf-jianlin-analytical25');out=Path(sys.argv[1])
assert out.parent==root and Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen hybrid full-data preparation and qualification\n'
assert int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024<46*2**30 and shutil.disk_usage(root).free>48*2**30
out.mkdir(exist_ok=False);shutil.copytree(source,out/'source')
shutil.copy2(__file__,out/'semantic_fixture.py')
load_source=inspect.getsource(native.load).replace('(HEADER=false)', '(HEADER=false, PARALLEL=false)')
namespace=dict(native.__dict__);exec(load_source,namespace);serial_baseline_load=namespace['load']
report={'baseline_import_adjustment':'COPY PARALLEL=false for quoted newlines; generic and hybrid compilers explicitly cast lexical values for double(str()) ordering','scope':'hybrid tiny end-to-end mapping and compiler semantic controls; no benchmark timing','source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in source.glob('*.py')},'cases':{}}
nt=out/'input.nt'
nt.write_text('<urn:a> <urn:type> <urn:Thing> .\n<urn:b> <urn:type> <urn:Thing> .\n<urn:a> <urn:label> "A" .\n<urn:a> <urn:label> "A"^^<http://www.w3.org/2001/XMLSchema#string> .\n<urn:a> <urn:label> "line\\n,世界" .\n<urn:a> <urn:label> "Hi"@EN .\n<urn:a> <urn:text> "body" .\n<urn:a> <urn:n> "1"^^<http://www.w3.org/2001/XMLSchema#int> .\n<urn:a> <urn:n> "01"^^<http://www.w3.org/2001/XMLSchema#int> .\n<urn:a> <urn:n2> "6"^^<http://www.w3.org/2001/XMLSchema#int> .\n<urn:a> <urn:otherN> "01"^^<http://www.w3.org/2001/XMLSchema#int> .\n<urn:a> <urn:date> "2008-07-01T00:00:00"^^<http://www.w3.org/2001/XMLSchema#dateTime> .\n<urn:a> <urn:date> "2008-08-01T00:00:00" .\n<urn:a> <urn:edge> <urn:a> .\n<urn:a> <urn:mixed> <urn:b> .\n<urn:a> <urn:mixed> "literal" .\n<urn:a> <urn:feature> <urn:F1> .\n<urn:a> <urn:feature> <urn:F2> .\n<urn:c> <urn:missing> "only c" .\n')
CASES=[('multi_values_lexical', 'SELECT ?label ?n WHERE { <urn:a> <urn:label> ?label . <urn:a> <urn:n> ?n }'), ('optional_empty', 'SELECT ?x ?tag WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:missing> ?tag } }'), ('optional_filter_empty', 'SELECT ?x ?n WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:n> ?n FILTER (?n > 99) } }'), ('optional_language', 'SELECT ?x ?label WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:label> ?label FILTER (langMatches(lang(?label),"EN")) } }'), ('literal_identity_join', 'SELECT ?x ?n WHERE { ?x <urn:n> ?n . ?x <urn:otherN> ?n }'), ('numeric_lexical_rows', 'SELECT ?x ?n WHERE { ?x <urn:n> ?n FILTER (?n > 0 && ?n < 2) }'), ('typed_date_guard', 'SELECT ?d WHERE { <urn:a> <urn:date> ?d FILTER (?d > "2008-06-20T00:00:00"^^<http://www.w3.org/2001/XMLSchema#dateTime>) }'), ('variable_predicate_union_self_loop', 'SELECT ?property ?hasValue ?isValueOf WHERE { { <urn:a> ?property ?hasValue } UNION { ?isValueOf ?property <urn:a> } }'), ('shared_projection_union', 'SELECT DISTINCT ?product ?label ?text WHERE { { ?product <urn:type> <urn:Thing> . ?product <urn:label> ?label . ?product <urn:text> ?text . ?product <urn:feature> <urn:F1> . ?product <urn:n> ?nA . FILTER (?nA > 0) } UNION { ?product <urn:type> <urn:Thing> . ?product <urn:label> ?label . ?product <urn:text> ?text . ?product <urn:feature> <urn:F2> . ?product <urn:n2> ?nB . FILTER (?nB > 5) } } ORDER BY ?label LIMIT 10')]

nt.write_text(nt.read_text()+'''<urn:b> <urn:label> "B" .
<urn:rev1> <urn:reviewFor> <urn:a> .
<urn:rev1> <urn:reviewer> <urn:person1> .
<urn:person1> <urn:name> "P" .
<urn:rev1> <urn:title> "T" .
<urn:rev1> <urn:rating1> "3"^^<http://www.w3.org/2001/XMLSchema#int> .
<urn:rev1> <urn:rating1> "4"^^<http://www.w3.org/2001/XMLSchema#int> .
<urn:rev2> <urn:reviewFor> <urn:a> .
<urn:rev2> <urn:reviewer> <urn:person2> .
<urn:person2> <urn:name> "Q" .
<urn:rev2> <urn:title> "U" .
<urn:rev2> <urn:rating2> "7"^^<http://www.w3.org/2001/XMLSchema#int> .
''')
CASES += [
 ('whole_group_missing','SELECT ?x ?y ?n ?text WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:edge> ?y . ?y <urn:n> ?n . ?y <urn:missing> ?text } }'),
 ('whole_group_date_failure','SELECT ?x ?y ?d WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:edge> ?y . ?y <urn:date> ?d FILTER (?d > "2009-01-01T00:00:00"^^<http://www.w3.org/2001/XMLSchema#dateTime>) } }'),
 ('anti_join_label','SELECT ?x ?label WHERE { ?x <urn:type> <urn:Thing> . ?x <urn:label> ?label . OPTIONAL { ?x <urn:feature> <urn:F2> . ?x <urn:label> ?test } FILTER (!bound(?test)) }'),
 ('nested_ratings','SELECT ?product ?review ?name ?title ?r1 ?r2 WHERE { ?product <urn:type> <urn:Thing> . OPTIONAL { ?review <urn:reviewFor> ?product . ?review <urn:reviewer> ?person . ?person <urn:name> ?name . ?review <urn:title> ?title . OPTIONAL { ?review <urn:rating1> ?r1 } OPTIONAL { ?review <urn:rating2> ?r2 } } }'),
 ('independent_optional_multiplicity','SELECT ?x ?y ?n ?review ?title WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:edge> ?y . ?y <urn:n> ?n } OPTIONAL { ?review <urn:reviewFor> ?x . ?review <urn:title> ?title } }')]
nt.write_text(nt.read_text()+'<urn:o1> <urn:type> <urn:Offer> .\n<urn:o2> <urn:type> <urn:Offer> .\n<urn:o1> <urn:price> "2"^^<urn:USD> .\n<urn:o2> <urn:price> "10"^^<urn:USD> .\n')
nt.write_text(nt.read_text()+'<urn:o3> <urn:type> <urn:Offer> .\n<urn:o3> <urn:price> "2.0"^^<urn:USD> .\n<urn:o4> <urn:badPrice> "invalid"^^<urn:USD> .\n')
CASES.append(('custom_datatype_double_cast','PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> SELECT ?offer ?price WHERE { ?offer <urn:type> <urn:Offer> . ?offer <urn:price> ?price } ORDER BY xsd:double(str(?price))'))
XSD='http://www.w3.org/2001/XMLSchema#'
def U(x):return {'type':'uri','value':'urn:'+x}
def L(x,datatype=None,lang=None):
 t={'type':'literal','value':x}
 if datatype:t['datatype']=XSD+datatype
 if lang:t['xml:lang']=lang
 return t
labels=[L('A'),L('line\n,世界'),L('Hi',lang='en')];numbers=[L('1','int'),L('01','int')]
expected={
 'multi_values_lexical':[[l,n] for n in numbers for l in labels],
 'optional_empty':[[U(x),None] for x in ['a','b']],
 'optional_filter_empty':[[U(x),None] for x in ['a','b']],
 'optional_language':[[U('a'),L('Hi',lang='en')],[U('b'),None]],
 'literal_identity_join':[[U('a'),L('01','int')]],
 'numeric_lexical_rows':[[U('a'),n] for n in numbers],
 'typed_date_guard':[[L('2008-07-01T00:00:00','dateTime')]],
 'shared_projection_union':[[U('a'),l,L('body')] for l in sorted(labels,key=lambda t:t['value'])],
 'whole_group_missing':[[U(x),None,None,None] for x in ['a','b']],
 'whole_group_date_failure':[[U(x),None,None] for x in ['a','b']],
 'anti_join_label':[[U('b'),L('B')]],
 'nested_ratings':[[U('a'),U('rev1'),L('P'),L('T'),L(n,'int'),None] for n in ['3','4']]+[[U('a'),U('rev2'),L('Q'),L('U'),None,L('7','int')],[U('b'),None,None,None,None,None]],
 'independent_optional_multiplicity':[[U('a'),U('a'),n,U(rev),L(title)] for n in numbers for rev,title in [('rev1','T'),('rev2','U')]]+[[U('b'),None,None,None,None]]}
expected['custom_datatype_double_cast']=[[U('o1'),{'type':'literal','value':'2','datatype':'urn:USD'}],[U('o3'),{'type':'literal','value':'2.0','datatype':'urn:USD'}],[U('o2'),{'type':'literal','value':'10','datatype':'urn:USD'}]]
outgoing=[('type',U('Thing')),('text',L('body')),('n2',L('6','int')),('otherN',L('01','int')),('date',L('2008-07-01T00:00:00','dateTime')),('date',L('2008-08-01T00:00:00')),('edge',U('a')),('mixed',U('b')),('mixed',L('literal')),('feature',U('F1')),('feature',U('F2'))]+[('label',l) for l in labels]+[('n',n) for n in numbers]
expected['variable_predicate_union_self_loop']=[[U(p),o,None] for p,o in outgoing]+[[U('edge'),None,U('a')],[U('reviewFor'),None,U('rev1')],[U('reviewFor'),None,U('rev2')]]

connections=[];databases=[]
def execute(conn,rec):
 result=conn.execute(rec['cypher']);rows=[]
 while result.has_next():
  raw=result.get_next();row=[]
  for i,var in enumerate(rec['vars']):
   value=raw[i]
   if value is not None:
    value={'type':'uri','value':rec['predicate_labels'][value]} if var in rec.get('predicate_columns',[]) else json.loads(value)
   row.append(value)
  rows.append(row)
 return rows

def bag(rows):return collections.Counter(json.dumps(r,sort_keys=True,ensure_ascii=False) for r in rows)
try:
 native.prepare(nt,out/'generic');columnar.prepare(out/'generic',out/'columnar',retained_predicates=['urn:'+p for p in ['label','n','missing','date','name','title','rating1','rating2']])
 serial_baseline_load(out/'generic',out/'generic.db',64,1);report['conservation']=columnar.load(out/'columnar',out/'columnar.db',64,1)
 manifests=[json.loads((out/name/'manifest.json').read_text()) for name in ['generic','columnar']]
 audit=cast_domain.scan(out/'generic',['urn:price','urn:badPrice']);report['cast_domain_audit']=audit
 for manifest in manifests:manifest['cast_domain_audit']=audit
 resources=json.loads((out/'generic/resource-ids.json').read_text())
 for label in ['generic','columnar']:
  db=lb.Database(str(out/(label+'.db')),buffer_pool_size=64*1024**2,max_num_threads=1,read_only=True);databases.append(db);connections.append(lb.Connection(db))
 for name,query in CASES:
  entry={'query':query}
  try:
   base=compile_union(query,manifests[0],resources,native.compile_bgp,native.key) if 'UNION' in query else native.compile_bgp(query,manifests[0],resources)
   new=columnar.compile_union(query,manifests[1],resources) if 'UNION' in query else columnar.compile_bgp(query,manifests[1],resources)
   entry['cypher_baseline']=base['cypher'];entry['cypher_candidate']=new['cypher']
   a=execute(connections[0],base);b=execute(connections[1],new)
   entry.update(baseline=a,candidate=b,expected=expected[name],pass_bag=bag(a)==bag(b),pass_expected=bag(b)==bag(expected[name]),pass_sequence=([float(row[1]['value']) for row in b]==[2.0,2.0,10.0] if name=='custom_datatype_double_cast' else b==expected[name]) if 'ORDER BY' in query else None,physical_paths=new.get('physical_paths'))
  except Exception as e:entry['error']=repr(e)
  report['cases'][name]=entry
 negative_queries={
   'nested_constant_child':'SELECT ?x ?missing ?tag WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:missing> ?missing . OPTIONAL { <urn:a> <urn:label> ?tag } } }',
   'nested_outer_only_child':'SELECT ?x ?missing ?tag WHERE { ?x <urn:type> <urn:Thing> . OPTIONAL { ?x <urn:missing> ?missing . OPTIONAL { ?x <urn:label> ?tag } } }'}
 negative_queries['invalid_cast_domain']='PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> SELECT ?x ?price WHERE { ?x <urn:badPrice> ?price } ORDER BY xsd:double(str(?price))'
 report['negative_controls']={}
 for name,q in negative_queries.items():
  try:columnar.compile_bgp(q,manifests[1],resources);report['negative_controls'][name]={'refused':False}
  except ValueError as error:report['negative_controls'][name]={'refused':('finite-decimal cast domain' in str(error) if name=='invalid_cast_domain' else 'first bound by its parent' in str(error)),'error':str(error)}
 report['complete']=all(v['refused'] for v in report['negative_controls'].values()) and all(x.get('pass_bag') and x.get('pass_expected') and x.get('pass_sequence') is not False for x in report['cases'].values())
except BaseException as e:report['setup_error']=repr(e)
finally:
 for c in connections:c.close()
 for d in databases:d.close()
 (out/'result.json').write_text(json.dumps(report,indent=2));print(json.dumps({'complete':report.get('complete',False),'setup_error':report.get('setup_error'),'cases':{k:{x:v for x,v in r.items() if x in ['pass_bag','pass_expected','pass_sequence','error']} for k,r in report['cases'].items()}},indent=2))
