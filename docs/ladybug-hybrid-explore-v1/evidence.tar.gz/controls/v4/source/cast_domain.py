"""Fail-closed cast-domain audit for this fixed, finite-decimal price cohort.
Not a general xsd:double implementation; unsupported/error/null sort keys are refused.
"""
import csv,json,re,math,hashlib
from pathlib import Path
DECIMAL=re.compile(r'[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?\Z')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for data in iter(lambda:f.read(8*1024**2),b''):h.update(data)
 return h.hexdigest()
def scan(source,predicates):
 source=Path(source);m=json.loads((source/'manifest.json').read_text());wanted={};domains={};identities={}
 for iri in predicates:
  table=m['predicates'].get(iri,'')+'L'
  if table not in {r['table'] for r in m['relationships']}:raise ValueError('cast domain is not a source literal predicate')
  ids=set();edges=0
  with (source/(table+'.csv')).open(newline='') as f:
   for _,obj in csv.reader(f):ids.add(int(obj));edges+=1
  domains[iri]={'seen':0,'distinct_literals':len(ids),'edges':edges,'invalid':0,'complete':False,'approved_finite_decimal':False}
  identities[iri]={'table':table,'edge_sha256':sha(source/(table+'.csv'))}
  for ident in ids:wanted.setdefault(ident,[]).append(iri)
 with (source/'Literal.csv').open(newline='') as f:
  for ident,term,value,datatype,lang,num in csv.reader(f):
   iris=wanted.get(int(ident))
   if not iris:continue
   try:valid=DECIMAL.fullmatch(value) is not None and math.isfinite(float(value))
   except (ValueError,OverflowError):valid=False
   for iri in iris:domains[iri]['seen']+=1;domains[iri]['invalid']+=not valid
 for d in domains.values():
  d['complete']=d['seen']==d['distinct_literals'];d['approved_finite_decimal']=d['complete'] and d['invalid']==0
 return {'scope':'all source literals of declared predicates must be finite decimal lexical forms; invalid, nonfinite, nullable or unaudited cast keys are unsupported','source_manifest_sha256':sha(source/'manifest.json'),'source_literal_sha256':sha(source/'Literal.csv'),'identities':identities,'domains':domains}
def require(var,group,expand,manifest):
 preds={expand(p) for _,p,o in group[0] if o==var}
 if len(preds)!=1:raise ValueError('double(str()) ORDER BY requires one mandatory audited literal predicate')
 domain=manifest.get('cast_domain_audit',{}).get('domains',{}).get(next(iter(preds)),{})
 if not domain.get('approved_finite_decimal') or not domain.get('complete'):
  raise ValueError('double(str()) ORDER BY requires an approved finite-decimal cast domain')
