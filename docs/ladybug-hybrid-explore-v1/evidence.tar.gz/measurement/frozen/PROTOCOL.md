# Prospective Ladybug mapping comparison (draft; no scored attempt launched)

Compare the generic per-predicate relation mapping with a hybrid tuned schema on the same frozen20 BSBM10M Explore query texts. This is within Ladybug, not a new TripleLight or cross-engine ranking. Retain the generic historical step, pure-column15/20 syntax attempt and failed first hybrid q023 order qualification.

## Source and data

Use reviewed hybrid-v4 sources: complex OPTIONAL subtrees require a variable first bound by the parent, and explicit double(str()) ordering requires a complete audited mandatory finite-number domain. All570000 price edges/434461 distinct source literal IDs pass the finite lexical audit. Invalid/nonfinite/unaudited/nullable cast domains are refused. This translator does not implement general SPARQL cast-error/null ordering. The shared cast correction applies to both mappings.

Pin all driver/source/translation/audit hashes, source manifest and ID map, actual Literal.csv and audited edge hashes, both physical database hashes, and the hybrid prepared manifest. Before any query, verify actual files and deterministically recompile all40 query variants; repeat postflight after the last query. Abort on drift. Pin the newly imported generic DB (not the historical DB used for preliminary qualification).

## Requests and cache

SCHEDULE.json has120 once-only requests: one untimed full pass per mapping, then two recorded full passes. Each query has a generic/hybrid pair, alternating which mapping runs first per query; pass2 reverses query order and each query's pair order. A fresh read-only process per request uses Ladybug0.22.3, Python3.14.3, PyArrow26.0.1,10GiB pool/four threads. Label this warm-cache: OS cache is not reset and an untimed pass comes first; actual page residency is unmeasured. Prior imports/qualification also warmed files. Do not claim cold-cache results.

## Timing and memory

Primary: query_to_full_json_seconds, from before conn.execute through complete bulk Arrow fetch and SPARQL JSON bytes ready in memory. Record open, execution API, fetch, JSON encoding and close separately. Execute/fetch splits are descriptive because eagerness/laziness is implementation-dependent. Disk compression/writes, references, typed bag normalization and order checking are outside the primary interval. Open-through-close elapsed (including output storage, excluding Python process launch) is auxiliary; supervisor event elapsed also includes monitoring overhead.

Report Darwin process peak RSS in bytes for each query/export worker, including imports/open/query/export/output storage/close but excluding reference parsing and gates (a separate offline process). Also retain the high-water RSS at full JSON readiness. ps sampling is KiB multiplied by1024. Do not call either measure pure engine heap size. Import and conversion RSS/times are separate one-run observations; conversion's external sort child is not included in its parent ru_maxrss. Historical shared CSV preparation is separately attributed. Report all duplicate Literal nodes/edges and complete physical database/prepared-output sizes.

## Gates and caps

After all query workers exit, score every saved full response against the corresponding frozen Jena typed bag and nine declared order checks per full pass. Include warmup in eligibility. All120 requests and both post/preflight receipts must pass; otherwise both mappings' totals are null. No retries, replacement observations, best-of selection or unsupported-query omission. Retain both recorded passes separately and describe only this fixed workload; no confidence or broad speed claim from two observations.

Resource guard: approved48GiB total root footprint, internal stop46GiB, free-space floor48GiB, worker RSS16GiB. du only before/after each request; poll cheap free-space and ps every2s.180s/request,1800s total, no automatic retries. Registered40 qualification phases were at most about7.2s each (including heavier checks), giving expected total-cap margin; a timeout still invalidates the attempt. Recheck current lock/authority before launch and release only after all owned children exit.
