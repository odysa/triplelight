"""Run under the next owned window; write identities/preflight before registration or scoring."""
import sys,json,platform,importlib.metadata,ast,datetime,time
from pathlib import Path
sys.dont_write_bytecode=True
folder=Path(__file__).resolve().parent
from preflight import check,sha
assert Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen Ladybug warm-cache mapping comparison\n'
root=Path('/private/tmp/rdf-jianlin-analytical25')
assert json.loads((root/'ladybug-hybrid-requalification-v4/ELIGIBILITY.json').read_text())['eligible_for_prospective_measurement']
old=json.loads((folder/'SCHEMA-FREEZE-v4.json').read_text());freeze=dict(old)
for name in ['native.py','columnar.py']:
 for function in ['prepare','load']:
  def body(path):return ast.dump(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==function),include_attributes=False)
  assert body(root/'ladybug-hybrid-full-v1/frozen/source'/name)==body(folder/'source'/name)
source=Path('/private/tmp/rdf-jianlin-ladybug18/bsbm10-csv');expected=json.loads((source/'manifest.json').read_text())['counts']
load=json.loads((root/'ladybug-generic-import-v1/csv/load.json').read_text())['observed']
assert load=={'Resource':expected['resource_nodes'],'Literal':expected['literal_nodes'],'relationships':expected['unique_triples']}
freeze['databases']={}
for variant,path in {'generic':root/'ladybug-generic-import-v1/generic.db','hybrid':root/'ladybug-hybrid-full-v1/hybrid.db'}.items():freeze['databases'][variant]={'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size}
freeze['hybrid_prepared_manifest']=str(root/'ladybug-hybrid-full-v1/prepared/manifest.json');freeze['hybrid_prepared_manifest_sha256']=sha(freeze['hybrid_prepared_manifest'])
refs=Path('/private/tmp/rdf-jianlin-embedded22/bsbm10-reference');prov=json.loads((refs/'provenance.json').read_text());names=sorted(json.loads((folder/'hybrid-translations-v4.json').read_text()))
freeze['reference_provenance_sha256']=sha(refs/'provenance.json');freeze['reference_gzip_sha256']={n:sha(refs/(n+'.json.gz')) for n in names};freeze['reference_json_sha256']={n:prov['queries'][n]['json_sha256'] for n in names}
packages={d.metadata['Name']:d.version for d in importlib.metadata.distributions() if 'ladybug' in d.metadata['Name'].lower() or d.metadata['Name'].lower()=='pyarrow'}
assert any(v=='0.22.3' for k,v in packages.items() if 'ladybug' in k.lower()) and packages.get('pyarrow')=='26.0.1'
freeze['environment']={'python':platform.python_version(),'system':platform.system(),'machine':platform.machine(),'packages':packages};assert freeze['environment']['python']=='3.14.3' and freeze['environment']['system']=='Darwin' and freeze['environment']['machine']=='arm64'
freeze['python_executable']=sys.executable;freeze['schedule']=json.loads((folder/'SCHEDULE.json').read_text())
freeze['primary_metric']='query_to_full_json_seconds';freeze['timing_scope']='query execution API through complete Arrow fetch and SPARQL JSON bytes in memory; open/close/storage/gates excluded; API/fetch split descriptive';freeze['rss_scope']='Darwin worker lifetime peak bytes, including imports/open/query/export/output storage/close; references and gates run offline; also retain peak at full JSON readiness'
freeze['cache_scope']='warm-cache comparison: no OS cache reset, one untimed pass first, prior imports/qualification; actual file-page residency unmeasured';freeze['all_or_nothing']='All120 including warmup must pass typed bag and declared order gates; pre/postflight source/database identities must match; otherwise both totals null; no retries or replacements'
freeze['caps']={'request_seconds':180,'overall_seconds':1800,'allocated_root_stop_gib':46,'minimum_free_gib':48,'worker_peak_rss_gib':16,'pool_mib':10240,'threads':4,'monitor_seconds':2,'du':'before/after requests only'}
freeze['cap_margin_basis']='40 previous correctness phases were at most about7.2seconds each with heavier in-request checks;120x7.2=864seconds, below1800; timeout still invalidates attempt'
freeze['driver_sha256']={name:sha(folder/name) for name in ['preflight.py','measure_worker.py','measure_supervisor.py','score_offline.py','scoring.py','check_scoring_controls.py','build_registration.py','PROTOCOL.md','SCHEDULE.json']}
freeze['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();target=folder/'MEASUREMENT-FREEZE.json';assert not target.exists();target.write_text(json.dumps(freeze,indent=2))
start=time.perf_counter();receipt=check(folder,freeze);receipt['seconds']=time.perf_counter()-start;receipt['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(folder/'PREFLIGHT-BEFORE-REGISTRATION.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'freeze_sha256':sha(target),'preflight_pass':receipt['pass'],'databases':freeze['databases'],'environment':freeze['environment']},indent=2))
