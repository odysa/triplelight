import sys,json,subprocess,time,resource,shutil,os,signal,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
root=Path('/private/tmp/rdf-jianlin-analytical25');stage=root/'ladybug-generic-import-v1';source=Path('/private/tmp/rdf-jianlin-ladybug18/bsbm10-csv');folder=Path(__file__).resolve().parent
assert Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen hybrid full-data preparation and qualification\n'
python='<agent-workspace>/scratch/ladybug18-venv/bin/python'
if len(sys.argv)>1:
 sys.path.insert(0,str(stage/'source'));import native
 start=time.perf_counter();native.load(stage/'csv',stage/'generic.db',10240,4)
 (stage/'load-cost.json').write_text(json.dumps({'seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'pool_mb':10240,'threads':4},indent=2));sys.exit(0)
assert not stage.exists();stage.mkdir();shutil.copytree(folder/'source',stage/'source');shutil.copy2(__file__,stage/'fresh_generic_import.py');(stage/'csv').mkdir()
for path in list(source.glob('*.csv'))+[source/'manifest.json']:(stage/'csv'/path.name).symlink_to(path.resolve())
original_load_hash=hashlib.sha256((source/'load.json').read_bytes()).hexdigest();record={'scope':'one fresh generic import cost; no scored query timing','samples':[]};start=time.monotonic()
with (stage/'load.stdout').open('w') as stdout,(stage/'load.stderr').open('w') as stderr:
 process=subprocess.Popen([python,str(stage/'fresh_generic_import.py'),'worker'],stdout=stdout,stderr=stderr,start_new_session=True)
 while process.poll() is None:
  allocated=int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024;free=shutil.disk_usage(root).free
  try:rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(process.pid)],text=True).strip())*1024
  except (ValueError,subprocess.CalledProcessError):rss=0
  record['samples'].append({'elapsed':time.monotonic()-start,'root_allocated':allocated,'free':free,'rss':rss})
  if allocated>=46*2**30 or free<=48*2**30 or rss>16*2**30 or time.monotonic()-start>300:
   record['stopped_by_guard']=True;os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   break
  time.sleep(2)
 record['exit']=process.wait()
record['shared_load_metadata_unchanged']=hashlib.sha256((source/'load.json').read_bytes()).hexdigest()==original_load_hash;assert record['shared_load_metadata_unchanged']
record['elapsed']=time.monotonic()-start;(stage/'supervisor.json').write_text(json.dumps(record,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='samples'}),flush=True)
