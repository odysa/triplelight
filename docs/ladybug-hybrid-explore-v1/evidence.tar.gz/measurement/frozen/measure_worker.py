import sys,json,gzip,time,resource,platform
from pathlib import Path
sys.dont_write_bytecode=True
folder=Path(__file__).resolve().parent;sys.path.insert(0,str(folder/'source'))
import ladybug as lb,arrow_output
out=Path(sys.argv[1]);request_id=sys.argv[2]
freeze=json.loads((folder/'MEASUREMENT-FREEZE.json').read_text());rec=next(r for r in freeze['schedule'] if r['id']==request_id)
variant=rec['mapping'];name=rec['query'];compiled=json.loads((folder/(variant+'-translations-v4.json')).read_text())[name]
record={**rec,'executed':False,'platform':platform.platform(),'rss_unit':'bytes (Darwin ru_maxrss)'};db=None;conn=None;start=time.perf_counter()
try:
 assert platform.system()=='Darwin'
 t=time.perf_counter();db=lb.Database(freeze['databases'][variant]['path'],buffer_pool_size=10240*1024**2,max_num_threads=4,read_only=True);conn=lb.Connection(db);record['open_seconds']=time.perf_counter()-t
 boundary=time.perf_counter();t=boundary;result=conn.execute(compiled['cypher']);record['execute_api_seconds']=time.perf_counter()-t
 t=time.perf_counter();table=result.get_as_arrow();record['fetch_arrow_seconds']=time.perf_counter()-t
 t=time.perf_counter();body=arrow_output.encode(table,compiled);record['encode_json_seconds']=time.perf_counter()-t;record['query_to_full_json_seconds']=time.perf_counter()-boundary
 record['peak_rss_at_full_json_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 with gzip.open(out/(request_id+'.json.gz'),'wb') as f:f.write(body)
 record.update(payload_bytes=len(body),payload_sha256=__import__('hashlib').sha256(body).hexdigest(),executed=True)
except BaseException as error:record['error']=repr(error)
finally:
 t=time.perf_counter()
 if conn is not None:conn.close()
 if db is not None:db.close()
 record['close_seconds']=time.perf_counter()-t;record['open_through_close_seconds']=time.perf_counter()-start;record['peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 (out/(request_id+'.record.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
