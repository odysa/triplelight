import sys,subprocess,time,json,os,signal,shutil,datetime
from pathlib import Path
sys.dont_write_bytecode=True
folder=Path(__file__).resolve().parent
from preflight import check,sha
from scoring import summarize,validate_schedule
from score_offline import score
expected_sha=sys.argv[1];assert sha(folder/'MEASUREMENT-FREEZE.json')==expected_sha
freeze=json.loads((folder/'MEASUREMENT-FREEZE.json').read_text());assert validate_schedule(freeze['schedule'])
for file,digest in freeze['driver_sha256'].items():assert sha(folder/file)==digest
assert Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen Ladybug warm-cache mapping comparison\n'
root=Path('/private/tmp/rdf-jianlin-analytical25');stage=root/'ladybug-hybrid-measure-v1';stage.mkdir(exist_ok=False);shutil.copytree(folder,stage/'frozen')
for file,digest in freeze['driver_sha256'].items():assert sha(stage/'frozen'/file)==digest
python=freeze['python_executable'];manifest={'registration_sha256':expected_sha,'events':[],'complete':False,'eligible':False,'totals':None};start_all=time.monotonic()
try:
 receipt=check(stage/'frozen',freeze);(stage/'preflight.json').write_text(json.dumps(receipt,indent=2))
 for request in freeze['schedule']:
  assert Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen Ladybug warm-cache mapping comparison\n'
  allocated=int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024
  assert allocated<46*2**30 and shutil.disk_usage(root).free>48*2**30
  ident=request['id'];start=time.monotonic();samples=[];reason=None
  with (stage/(ident+'.stdout')).open('w') as stdout,(stage/(ident+'.stderr')).open('w') as stderr:
   process=subprocess.Popen([python,str(stage/'frozen/measure_worker.py'),str(stage),ident],stdout=stdout,stderr=stderr,start_new_session=True)
   while process.poll() is None:
    free=shutil.disk_usage(root).free
    try:rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(process.pid)],text=True).strip())*1024
    except (ValueError,subprocess.CalledProcessError):rss=0
    samples.append({'elapsed':time.monotonic()-start,'root_allocated_before_request':allocated,'free':free,'rss':rss})
    if free<=48*2**30 or rss>16*2**30:reason='resource guard'
    if time.monotonic()-start>180 or time.monotonic()-start_all>1800:reason='timeout'
    if reason:
     os.killpg(process.pid,signal.SIGTERM)
     try:process.wait(timeout=10)
     except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
     break
    time.sleep(2)
   code=process.wait()
  allocated_after=int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024
  if allocated_after>=46*2**30:reason='post-request allocation guard'
  event={'id':ident,'exit':code,'reason':reason,'elapsed':time.monotonic()-start,'allocated_before':allocated,'allocated_after':allocated_after,'samples':samples};manifest['events'].append(event);(stage/'supervisor.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in event.items() if k!='samples'}),flush=True)
  if code!=0 or reason is not None:break
 receipt=check(stage/'frozen',freeze);(stage/'postflight.json').write_text(json.dumps(receipt,indent=2))
 records=score(stage/'frozen',stage,freeze)
 summary=summarize(freeze['schedule'],records);manifest['complete']=len(manifest['events'])==120 and all(e['exit']==0 and e['reason'] is None for e in manifest['events'])
 if manifest['complete']:manifest.update(summary)
except BaseException as error:manifest['error']=repr(error)
finally:
 manifest['ended']=True;(stage/'supervisor.json').write_text(json.dumps(manifest,indent=2))
