"""All reference decoding and result gates run after the last measured worker exits."""
import json,gzip,sys,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'source'))
import contract
REFS=Path('/private/tmp/rdf-jianlin-embedded22/bsbm10-reference')
def score(folder,stage,freeze):
 assert hashlib.sha256((REFS/'provenance.json').read_bytes()).hexdigest()==freeze['reference_provenance_sha256']
 provenance=json.loads((REFS/'provenance.json').read_text());records=[]
 for rule in freeze['schedule']:
  ident=rule['id'];path=stage/(ident+'.record.json')
  if not path.exists():continue
  record=json.loads(path.read_text());record['eligible']=False
  try:
   assert all(record[k]==rule[k] for k in ['id','mapping','query','pass'])
   assert record['executed'] is True
   compiled=json.loads((folder/(rule['mapping']+'-translations-v4.json')).read_text())[rule['query']]
   prov=provenance['queries'][rule['query']];assert prov['json_sha256']==freeze['reference_json_sha256'][rule['query']]
   assert compiled['source_sha256']==prov['query_sha256']
   raw=gzip.decompress((REFS/(rule['query']+'.json.gz')).read_bytes());assert hashlib.sha256(raw).hexdigest()==prov['json_sha256']
   body=gzip.decompress((stage/(ident+'.json.gz')).read_bytes());assert len(body)==record['payload_bytes'] and hashlib.sha256(body).hexdigest()==record['payload_sha256']
   ref=json.loads(raw);payload=json.loads(body);variables=payload['head']['vars'];refvars=ref['head']['vars']
   rows=[[contract.json_term(row.get(v)) for v in variables] for row in payload['results']['bindings']]
   refrows=[[contract.json_term(row.get(v)) for v in refvars] for row in ref['results']['bindings']]
   observed=contract.signature(variables,rows);expected=contract.signature(refvars,refrows);record.update(observed=observed,expected=expected,pass_bag=observed==expected)
   if prov.get('order'):
    contract.check_order(refvars,refrows,prov['order']['keys']);record['order']=contract.check_order(variables,rows,prov['order']['keys'])
   else:record['order']=None
   record['pass_order']=True;record['eligible']=record['pass_bag'] and record['pass_order']
  except BaseException as error:record['gate_error']=repr(error);record['pass_order']=False
  (stage/(ident+'.gate.json')).write_text(json.dumps(record,indent=2));records.append(record)
 return records
