"""Actual-file binding and deterministic recompilation before any timed request."""
import json,sys,re,platform,importlib.metadata
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'source'))
import cast_domain,native,columnar
from union_queries import compile_union
sha=cast_domain.sha
SOURCE=Path('/private/tmp/rdf-jianlin-ladybug18/bsbm10-csv')
QUERIES=Path('/private/tmp/rdf-jianlin-embedded22/bsbm-fixed/queries/bsbm')
def check(folder,freeze):
 current={'python':platform.python_version(),'system':platform.system(),'machine':platform.machine(),'packages':{name:importlib.metadata.version(name) for name in freeze['environment']['packages']}}
 assert current==freeze['environment'],('environment',current)
 refs=Path('/private/tmp/rdf-jianlin-embedded22/bsbm10-reference')
 assert sha(refs/'provenance.json')==freeze['reference_provenance_sha256']
 for name,digest in freeze['reference_gzip_sha256'].items():assert sha(refs/(name+'.json.gz'))==digest

 for name,digest in freeze['source_sha256'].items():assert sha(folder/'source'/name)==digest,('source',name)
 audit=json.loads((folder/'cast-domain-audit-v4.json').read_text())
 assert sha(folder/'cast-domain-audit-v4.json')==freeze['cast_domain_audit_sha256']
 assert sha(SOURCE/'manifest.json')==audit['source_manifest_sha256']==freeze['manifest_sha256']
 assert sha(SOURCE/'Literal.csv')==audit['source_literal_sha256']
 assert sha(SOURCE/'resource-ids.json')==freeze['resource_ids_sha256']
 for identity in audit['identities'].values():assert sha(SOURCE/(identity['table']+'.csv'))==identity['edge_sha256']
 for name,record in freeze['databases'].items():assert sha(record['path'])==record['sha256'],('database',name)
 # Build compiler metadata from the hash-pinned physical manifest and recheck its complete schema.
 m=json.loads(Path(freeze['hybrid_prepared_manifest']).read_text());m['cast_domain_audit']=audit
 assert sha(freeze['hybrid_prepared_manifest'])==freeze['hybrid_prepared_manifest_sha256']
 assert m['retained_literal_relationships']==freeze['retained_literal_relationships']
 resources=json.loads((SOURCE/'resource-ids.json').read_text())
 for variant in ['generic','hybrid']:
  path=folder/(variant+'-translations-v4.json');assert sha(path)==freeze['translations'][variant]
  expected=json.loads(path.read_text())
  for name,record in expected.items():
   q=(QUERIES/(name+'.rq')).read_text();assert sha(QUERIES/(name+'.rq'))==record['source_sha256']
   current=(columnar.compile_union(q,m,resources) if 'UNION' in q else columnar.compile_bgp(q,m,resources)) if variant=='hybrid' else (compile_union(q,m,resources,native.compile_bgp,native.key) if 'UNION' in q else native.compile_bgp(q,m,resources))
   assert {k:v for k,v in record.items() if k!='source_sha256'}==current,('recompile',variant,name)
 return {'pass':True,'source_manifest':audit['source_manifest_sha256'],'source_literals':audit['source_literal_sha256'],'edge_tables':audit['identities'],'database_identities':freeze['databases'],'recompiled_queries_per_mapping':20}
