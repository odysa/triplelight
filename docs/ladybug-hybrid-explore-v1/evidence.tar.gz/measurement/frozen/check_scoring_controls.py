import sys,json,copy
from pathlib import Path
sys.dont_write_bytecode=True
from scoring import summarize,validate_schedule,FIELDS
folder=Path(__file__).resolve().parent;schedule=json.loads((folder/'SCHEDULE.json').read_text())
records=[{**r,'eligible':True,'pass_bag':True,'pass_order':True,**{k:1.0 for k in FIELDS}} for r in schedule]
checks={'valid':summarize(schedule,records)['eligible']}
for name,mutate in [('missing',lambda r:r.pop()),('duplicate',lambda r:r.__setitem__(-1,copy.deepcopy(r[0]))),('warmup_gate',lambda r:r[0].__setitem__('eligible',False)),('nonfinite',lambda r:r[0].__setitem__('execute_api_seconds',float('nan'))),('negative',lambda r:r[0].__setitem__('open_seconds',-1)),('mapping_drift',lambda r:r[0].__setitem__('mapping','other'))]:
 trial=copy.deepcopy(records);mutate(trial);result=summarize(schedule,trial);checks[name]=not result['eligible'] and result['totals'] is None
trial=copy.deepcopy(schedule);trial[0],trial[1]=trial[1],trial[0];checks['schedule_pair_order']=not validate_schedule(trial)
trial=copy.deepcopy(schedule);trial[-1],trial[-3]=trial[-3],trial[-1];checks['schedule_reverse_order']=not validate_schedule(trial)
assert all(checks.values());(folder/'offline-scoring-controls-v2.json').write_text(json.dumps(checks,indent=2));print(checks)
