import math
FIELDS=['open_seconds','execute_api_seconds','fetch_arrow_seconds','encode_json_seconds','query_to_full_json_seconds','close_seconds','open_through_close_seconds','peak_rss_bytes']
def validate_schedule(schedule):
 if len(schedule)!=120 or len({r['id'] for r in schedule})!=120:return False
 groups={}
 for r in schedule:
  if r['pass'] not in ['w','p1','p2'] or r['mapping'] not in ['generic','hybrid']:return False
  groups.setdefault((r['pass'],r['mapping']),[]).append(r['query'])
 if len(groups)!=6 or any(len(q)!=20 or len(set(q))!=20 for q in groups.values()):return False
 if not all(set(q)==set(next(iter(groups.values()))) for q in groups.values()):return False
 queries=sorted(next(iter(groups.values())));expected=[]
 for passname in ['w','p1','p2']:
  for q in (list(reversed(queries)) if passname=='p2' else queries):
   pair=['generic','hybrid'] if queries.index(q)%2==0 else ['hybrid','generic']
   if passname=='p2':pair.reverse()
   expected.extend((passname,q,v) for v in pair)
 return [(r['pass'],r['query'],r['mapping']) for r in schedule]==expected
def summarize(schedule,records):
 expected={r['id']:r for r in schedule};seen={r['id']:r for r in records}
 eligible=validate_schedule(schedule) and len(expected)==len(schedule)==120 and len(seen)==len(records)==120 and set(expected)==set(seen)
 for name,rec in seen.items():
  rule=expected.get(name,{})
  eligible &= rec.get('eligible') is True and rec.get('pass_bag') is True and rec.get('pass_order') is True
  eligible &= all(rec.get(k)==rule.get(k) for k in ['mapping','query','pass'])
  eligible &= all(type(rec.get(k)) in (int,float) and math.isfinite(rec[k]) and rec[k]>=0 for k in FIELDS)
 totals=None
 if eligible:
  totals={}
  for passname in ['p1','p2']:
   totals[passname]={}
   for variant in ['generic','hybrid']:
    rows=[r for r in records if r['pass']==passname and r['mapping']==variant]
    if len(rows)!=20:return {'eligible':False,'totals':None}
    totals[passname][variant]={k:sum(r[k] for r in rows) for k in FIELDS if k!='peak_rss_bytes'}
    totals[passname][variant]['peak_rss_bytes']=max(r['peak_rss_bytes'] for r in rows)
 return {'eligible':bool(eligible),'totals':totals,'requests':len(records)}
