import sys,json,hashlib,time,gzip,platform,resource
from pathlib import Path
sys.dont_write_bytecode=True
folder=Path(__file__).resolve().parent
sys.path.insert(0,str(folder/'source'))
import columnar,contract
source=Path('/private/tmp/rdf-jianlin-ladybug18/bsbm10-csv')
refs=Path('/private/tmp/rdf-jianlin-embedded22/bsbm10-reference')
out=Path(sys.argv[1]);phase=sys.argv[2]
assert Path('/tmp/rdf-bench.lock/owner').read_text()=='Jianlin task25 frozen hybrid full-data preparation and qualification\n'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
freeze=json.loads((folder/'SCHEMA-FREEZE-v2.json').read_text())
for name,digest in freeze['source_sha256'].items():assert sha(folder/'source'/name)==digest,name
assert sha(source/'manifest.json')==freeze['manifest_sha256']
assert sha(source/'resource-ids.json')==freeze['resource_ids_sha256']
start=time.perf_counter()
if phase=='prepare':
 columnar.prepare(source,out/'prepared')
 record={'phase':phase,'seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'python':platform.python_version(),'schema_freeze_sha256':sha(folder/'SCHEMA-FREEZE-v2.json')}
 (out/'prepare.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
elif phase=='load':
 r=columnar.load(out/'prepared',out/'hybrid.db',10240,4)
 record={'phase':phase,'seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'conservation':r,'buffer_pool_mb':10240,'threads':4}
 (out/'load.json').write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
else:
 import ladybug as lb
 name=phase
 rec=json.loads((folder/'resolved-translations-v1.json').read_text())[name]
 prov=json.loads((refs/'provenance.json').read_text())['queries'][name]
 assert rec['source_sha256']==prov['query_sha256']
 raw_ref=gzip.decompress((refs/(name+'.json.gz')).read_bytes());assert hashlib.sha256(raw_ref).hexdigest()==prov['json_sha256']
 reference=json.loads(raw_ref)
 db=lb.Database(str(out/'hybrid.db'),buffer_pool_size=10240*1024**2,max_num_threads=4,read_only=True);conn=lb.Connection(db)
 try:
  result=conn.execute(rec['cypher']);rows=[];bindings=[]
  while result.has_next():
   raw=result.get_next();binding={}
   for i,var in enumerate(rec['vars']):
    val=raw[i]
    if val is not None:binding[var]={'type':'uri','value':rec['predicate_labels'][val]} if var in rec.get('predicate_columns',[]) else json.loads(val)
   bindings.append(binding);rows.append([contract.json_term(binding.get(v)) for v in rec['vars']])
  payload={'head':{'vars':rec['vars']},'results':{'bindings':bindings}}
  refvars=reference['head']['vars'];refrows=[[contract.json_term(binding.get(v)) for v in refvars] for binding in reference['results']['bindings']]
  observed=contract.signature(rec['vars'],rows);expected=contract.signature(refvars,refrows)
  order_error=None
  try:order=contract.check_order(rec['vars'],rows,prov['order']['keys']) if prov.get('order') else None
  except Exception as error:order=None;order_error=repr(error)
  record={'query':name,'pass_bag':observed==expected,'observed':observed,'expected':expected,'order':order,'order_error':order_error,'elapsed_diagnostic_seconds':time.perf_counter()-start,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'physical_paths':rec.get('physical_paths')}
  (out/'qualification').mkdir(exist_ok=True)
  with gzip.open(out/'qualification'/(name+'.json.gz'),'wt') as f:json.dump(payload,f)
  (out/'qualification'/(name+'.gate.json')).write_text(json.dumps(record,indent=2));print(json.dumps(record),flush=True)
 finally:conn.close();db.close()
