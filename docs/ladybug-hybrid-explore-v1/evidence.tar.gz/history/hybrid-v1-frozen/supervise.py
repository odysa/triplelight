import sys,subprocess,time,json,os,signal,shutil,hashlib
from pathlib import Path
root=Path('/private/tmp/rdf-jianlin-analytical25');stage=root/'ladybug-hybrid-full-v1';folder=Path(__file__).resolve().parent
owner='Jianlin task25 frozen hybrid full-data preparation and qualification\n'
assert Path('/tmp/rdf-bench.lock/owner').read_text()==owner
assert not stage.exists();stage.mkdir();shutil.copytree(folder,stage/'frozen')
python=str(Path('<agent-workspace>/scratch/ladybug18-venv/bin/python'))
manifest={'root_cap_gib':48,'stop_at_allocated_gib':46,'minimum_free_gib':48,'samples_seconds':2,'scope':'prepare/load + untimed correctness qualification; no scored performance result','phases':[]}
try:
 for phase in ['prepare','load']+list(json.loads((stage/'frozen/resolved-translations-v1.json').read_text())):
  allocated=int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024
  assert allocated<46*2**30 and shutil.disk_usage(root).free>48*2**30
  start=time.monotonic();samples=[]
  with (stage/(phase+'.stdout')).open('w') as stdout,(stage/(phase+'.stderr')).open('w') as stderr:
   process=subprocess.Popen([python,str(stage/'frozen/full_fixture.py'),str(stage),phase],stdout=stdout,stderr=stderr,start_new_session=True)
   reason=None
   while process.poll() is None:
    allocated=int(subprocess.check_output(['du','-sk',str(root)],text=True).split()[0])*1024;free=shutil.disk_usage(root).free
    try:rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(process.pid)],text=True).strip())*1024
    except (ValueError,subprocess.CalledProcessError):rss=0
    samples.append({'elapsed':time.monotonic()-start,'root_allocated':allocated,'free':free,'rss':rss})
    if allocated>=46*2**30 or free<=48*2**30 or rss>16*2**30:reason='resource guard'
    if time.monotonic()-start>(900 if phase in ['prepare','load'] else 180):reason='timeout'
    if reason:
     os.killpg(process.pid,signal.SIGTERM)
     try:process.wait(timeout=10)
     except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
     break
    time.sleep(2)
   code=process.wait()
  record={'phase':phase,'exit':code,'reason':reason,'elapsed':time.monotonic()-start,'samples':samples}
  manifest['phases'].append(record);(stage/'supervisor.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({k:v for k,v in record.items() if k!='samples'}),flush=True)
  if code!=0:break
 manifest['complete']=len(manifest['phases'])==22 and all(p['exit']==0 for p in manifest['phases'])
finally:
 manifest['ended']=True;(stage/'supervisor.json').write_text(json.dumps(manifest,indent=2))
