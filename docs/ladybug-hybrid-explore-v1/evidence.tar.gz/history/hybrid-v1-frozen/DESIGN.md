# Proposed hybrid mapping contract (not implemented or qualified)

The pure column prototype translates 15/20 frozen BSBM Explore queries. It rejects q004 and q011/q012/q014/q015 at compile time. The retained nine tiny differential cases pass, but do not cover these complex OPTIONAL groups.

## Physical representation

- Keep the current Resource nodes, stable term IDs, all resource-object predicate edge tables, and literal STRUCT[] columns for mandatory patterns.
- Additionally retain the original Literal node table and a frozen whitelist of P#L edge tables used inside complex OPTIONAL groups. Whitelist IRIs: rdfs:label, bsbm:price, bsbm:validTo, foaf:name, dc:title, bsbm:rating1, bsbm:rating2. Freeze actual P# labels from the source manifest before preparing data; reject any omitted table required by the compiler.
- This deliberately duplicates some literal data. Count original RDF triples once via the columns plus resource edges. Separately report retained Literal nodes and duplicate physical edge rows, bytes, preparation/load time and query memory. Never describe this as reduced storage without measurement.
- Variable-predicate UNION must enumerate only one representation of each original triple (columns plus resource edges), never retained duplicate edges.

## Compilation

- Ordinary mandatory BGP literal patterns continue to use STRUCT[] UNWIND. Simple single-triple OPTIONAL keeps the already-tested list_filter/null padding.
- A complex OPTIONAL subtree uses the retained relation tables for all its literal patterns, including nested OPTIONAL, with filters attached to the matching OPTIONAL MATCH as in the baseline. The entire mandatory portion of each group must match before its new variables become bound.
- Shared resource variables retain original Resource node identity. Literal-node and literal-struct aliases have the same stable ID/term representation but are different Cypher types: reject any shared literal binding crossing those boundaries unless an explicit identity comparison and alias conversion is implemented and tested. No implicit alias reuse.
- Empty/missing candidates must null every variable introduced by that group, preserving the multiplicity of the left input. A successful outer group followed by a failing nested group must retain the outer variables.
- Record the chosen physical translation per query. Refuse unsupported forms; no silent generic compiler fallback.

## Required controls before full data

1. q004-shaped anti-join, both feature-present and feature-absent resources, multiple labels and no labels.
2. Complex optional with two mandatory literal properties: one missing must null the entire group, with no partially bound resource/price.
3. Complex optional where a date filter rejects every candidate; preserve the left row.
4. Two independent complex optionals: verify the product of successful bag multiplicities and one null extension on failure.
5. Nested ratings: successful review/reviewer/title remains bound if a rating is absent; multiple ratings multiply correctly.
6. Variable-predicate UNION does not double count retained edges, including resource self-loops.
7. Lexical/datatype/language conservation and explicit expected typed bags in addition to baseline agreement.
8. Static translation coverage of all20 frozen sources, with resolved constants before execution.

Only then prepare a new large-data directory after a fresh disk-budget check. Full original-triple conservation, all20 exact Jena bags and nine ORDER checks precede any prospective paired measurement. Preserve every failed stage. Do not pool historical TripleLight timings or claim a new cross-engine ranking.
