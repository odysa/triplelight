"""Experimental RDF-literal column mapping for the frozen BSBM Explore cohort.
This is a schema-aware, narrow translator. Baseline native.py remains byte-identical.
No performance result is valid before full conservation/bag/order qualification.
"""
import argparse,csv,hashlib,itertools,json,os,re,shutil,subprocess,time
from pathlib import Path
import native
csv.field_size_limit(32*1024**2)
FIELDS='id INT64, term STRING, value STRING, datatype STRING, lang STRING, num DOUBLE'

def read_rows(path):
 with Path(path).open(newline='') as f:yield from csv.reader(f)

def prepare(source,out):
 import pyarrow as pa
 import pyarrow.parquet as pq
 out.mkdir(parents=True,exist_ok=False);m=json.loads((source/'manifest.json').read_text());start=time.monotonic()
 literal=[r for r in m['relationships'] if r['target']=='Literal'];resource=[r for r in m['relationships'] if r['target']=='Resource']
 columns=sorted(r['table'][:-1] for r in literal)
 if len(columns)!=len(set(columns)):raise ValueError('duplicate virtual literal table')
 # Records are copied without lexical/datatype/language normalization.
 terms={}
 for ident,term,value,datatype,lang,num in read_rows(source/'Literal.csv'):
  terms[int(ident)]={'id':int(ident),'term':term,'value':value,'datatype':datatype,'lang':lang,'num':float(num) if num else None}
 struct=pa.struct([('id',pa.int64()),('term',pa.string()),('value',pa.string()),('datatype',pa.string()),('lang',pa.string()),('num',pa.float64())])
 schema=pa.schema([('id',pa.int64()),('term',pa.string()),('value',pa.string())]+[(c,pa.list_(struct)) for c in columns])
 props=out/'properties.unsorted.tsv'
 with props.open('w') as f:
  for rel in literal:
   for s,o in read_rows(source/(rel['table']+'.csv')):f.write(s+'\t'+rel['table'][:-1]+'\t'+o+'\n')
 sorted_props=out/'properties.sorted.tsv'
 with sorted_props.open('wb') as f:subprocess.run(['sort','-S','256M','-T',str(out),'-t','\t','-k1,1n','-k2,2',str(props)],stdout=f,check=True,env={**os.environ,'LC_ALL':'C'})
 props.unlink();nodes=lit_count=0;batch=[];writer=pq.ParquetWriter(out/'Resource.parquet',schema,compression='snappy')
 def flush():
  if batch:writer.write_table(pa.Table.from_pylist(batch,schema=schema));batch.clear()
 try:
  with sorted_props.open() as f:
   groups=itertools.groupby((l.rstrip('\n').split('\t') for l in f),lambda x:int(x[0]));current=next(groups,None)
   for ident,term,value in read_rows(source/'Resource.csv'):
    ident=int(ident);row={'id':ident,'term':term,'value':value,**{c:[] for c in columns}}
    if current is not None and current[0]<ident:raise ValueError('literal property subject not in Resource')
    if current is not None and current[0]==ident:
     for _,col,obj in current[1]:row[col].append(terms[int(obj)]);lit_count+=1
     current=next(groups,None)
    batch.append(row);nodes+=1
    if len(batch)>=4096:flush()
   if current is not None:raise ValueError('unconsumed property records')
 finally:flush();writer.close()
 sorted_props.unlink();res_count=0
 for rel in resource:
  shutil.copyfile(source/(rel['table']+'.csv'),out/(rel['table']+'.csv'));res_count+=rel['rows']
 assert nodes==m['counts']['resource_nodes'] and lit_count==sum(r['rows'] for r in literal)
 assert lit_count+res_count==m['counts']['unique_triples']
 m.update(mapping='resource-nodes-literal-struct-lists-v1',source_csv=str(source.resolve()),literal_columns=columns,physical_resource_relationships=resource,pyarrow_version=pa.__version__,column_prepare_seconds=time.monotonic()-start)
 m['conservation']={'resource_nodes':nodes,'literal_elements':lit_count,'resource_edges':res_count,'rdf_triples':lit_count+res_count}
 (out/'manifest.json').write_text(json.dumps(m,indent=2));return m

def load(source,dbpath,memory_mb=10240,threads=4):
 import ladybug as lb
 m=json.loads((source/'manifest.json').read_text());db=lb.Database(str(dbpath),buffer_pool_size=memory_mb*1024**2,max_num_threads=threads);conn=lb.Connection(db)
 try:
  columns=['id INT64','term STRING','value STRING']+[c+' STRUCT('+FIELDS+')[]' for c in m['literal_columns']]+['PRIMARY KEY(id)']
  conn.execute('CREATE NODE TABLE Resource('+', '.join(columns)+')');conn.execute('COPY Resource FROM '+json.dumps(str((source/'Resource.parquet').resolve())))
  n=conn.execute('MATCH(n:Resource) RETURN count(*)').get_next()[0];assert n==m['conservation']['resource_nodes']
  literal_total=0
  for c in m['literal_columns']:literal_total+=int(conn.execute('MATCH(n:Resource) RETURN sum(size(n.'+c+'))').get_next()[0] or 0)
  resource_total=0
  for rel in m['physical_resource_relationships']:
   table=rel['table'];conn.execute(f'CREATE REL TABLE {table}(FROM Resource TO Resource)');conn.execute(f'COPY {table} FROM '+json.dumps(str((source/(table+'.csv')).resolve()))+' (HEADER=false)')
   observed=conn.execute(f'MATCH()-[r:{table}]->() RETURN count(*)').get_next()[0];assert observed==rel['rows'];resource_total+=observed
  assert literal_total+resource_total==m['counts']['unique_triples']
  conn.execute('CHECKPOINT');return {'resource_nodes':n,'literal_elements':literal_total,'resource_edges':resource_total,'rdf_triples':literal_total+resource_total}
 finally:conn.close();db.close()

RDF=native.RDF
XSD=native.XSD
IRI=native.IRI
LIT=native.LIT
term=native.term
key=native.key

def filter_expression(s,resources):
    s=re.sub(r'langMatches\s*\(\s*lang\s*\(\s*(\?\w+)\s*\)\s*,\s*"EN"\s*\)',lambda m:f'(v_{m[1][1:]}.lang = "en" OR starts_with(v_{m[1][1:]}.lang,"en-"))',s,flags=re.I)
    s=re.sub(r'!\s*bound\s*\(\s*(\?\w+)\s*\)',lambda m:f'(v_{m[1][1:]} IS NULL)',s,flags=re.I)
    # URI != resource and numeric arithmetic are separate typed operations.
    def iri_compare(m):
        ident=resources.get(key(term(m[1])),-1)
        return f'({ident} {m[2]} v_{m[3][1:]}.id)'
    s=re.sub(r'(<[^>]+>)\s*(!=|=)\s*(\?\w+)',iri_compare,s)
    # The benchmark's date constants/values use one timezone-free ISO format.
    def date_compare(m):
        constant=term(m[3])
        if constant.get('datatype')!=XSD+'dateTime':raise ValueError('Only fixed-format dateTime comparison is translated')
        return f'(v_{m[1][1:]}.datatype = '+json.dumps(XSD+'dateTime')+f' AND v_{m[1][1:]}.value {m[2]} '+json.dumps(constant['value'])+')'
    s=re.sub(r'(\?\w+)\s*(>|<|>=|<=)\s*("[^"]+"\^\^<[^>]+>)',date_compare,s)
    s=re.sub(r'\?(\w+)',r'v_\1.num',s)
    s=s.replace('&&',' AND ').replace('||',' OR ').replace('!=','<>')
    # Reject untranslated functions, IRIs and unsupported operators.
    if '?' in s or '^^' in s or re.search(r'\b(?:regex|str|bound|lang)\s*\(',s,re.I):raise ValueError('Unsupported FILTER '+s)
    return s

def compile_bgp(query, manifest, resources):
    prefixes = dict(re.findall(r'PREFIX\s+([\w-]+):\s*<([^>]+)>',query,re.I))
    query = re.sub(r'PREFIX\s+[\w-]+:\s*<[^>]+>','',query,flags=re.I).strip()
    m = re.fullmatch(r'SELECT\s+(.*?)\s+WHERE\s*\{(.*)\}\s*([^{}]*)',query,re.I|re.S)
    if not m: raise ValueError('Unsupported SELECT syntax')
    projection = m[1].split()
    distinct = projection[0].upper()=='DISTINCT'
    if distinct:projection=projection[1:]
    if not all(re.fullmatch(r'\?\w+',v) for v in projection): raise ValueError('Unsupported projection')
    tok = re.compile(rf'{LIT}|{IRI}|\?\w+|[\w-]+:[\w-]+|\ba\b')
    def balanced(s,pos,left,right):
        assert s[pos]==left
        start=pos+1;depth=1;pos+=1
        while pos<len(s):
            quoted=re.match(r'"(?:[^"\\]|\\.)*"|<[^<>\s]*>',s[pos:])
            if quoted:pos+=quoted.end();continue
            if s[pos]==left:depth+=1
            if s[pos]==right:
                depth-=1
                if not depth:return s[start:pos],pos+1
            pos+=1
        raise ValueError('Unclosed group/expression')
    def parse(body):
        triples=[];opts=[];filters=[];pos=0
        while pos<len(body):
            if body[pos].isspace() or body[pos]=='.':pos+=1;continue
            kw=re.match(r'(OPTIONAL|FILTER)\s*',body[pos:],re.I)
            if kw:
                pos+=kw.end();optional=kw[1].upper()=='OPTIONAL'
                if not optional and body[pos]!='(':
                    fn=re.match(r'(\w+)\s*',body[pos:])
                    if not fn:raise ValueError('Unsupported FILTER expression')
                    pos+=fn.end()
                    content,pos=balanced(body,pos,'(',')')
                    filters.append(fn[1]+'('+content+')');continue
                content,pos=balanced(body,pos,'{' if optional else '(','}' if optional else ')')
                (opts if optional else filters).append(parse(content) if optional else content)
                continue
            triple=[]
            for _ in range(3):
                while pos<len(body) and body[pos].isspace():pos+=1
                t=tok.match(body,pos)
                if not t:raise ValueError('Unsupported syntax near '+body[pos:pos+60])
                triple.append(t[0]);pos=t.end()
            triples.append(triple)
        return triples,opts,filters
    group=parse(m[2])
    def expand(t):
        if t=='a':return RDF+'type'
        if t.startswith('<'):return term(t)['value']
        a,b=t.split(':',1);return prefixes[a]+b
    constants={};bound=set()
    def node(t):
        if t.startswith('?'):
            bound.add(t);return 'v_'+t[1:]
        iri=expand(t)
        if iri not in constants:
            alias='c_'+str(len(constants));constants[iri]=alias
            i=resources.get(key({'type':'uri','value':iri}),-1)
            constants[iri]=(alias,i)
        return constants[iri][0]
    rels={r['table'] for r in manifest['relationships']}
    def expression(s):return filter_expression(s,resources)
    literal_bound=set();nullable=set();serial=itertools.count()
    def render(g,optional=False):
        triples,opts,filters=g
        mandatory_vars={t for triple in triples for t in triple if t.startswith('?')}
        before=[s for s in filters if set(re.findall(r'\?\w+',s))<=mandatory_vars]
        after=[s for s in filters if s not in before]
        if optional and after:raise ValueError('nested OPTIONAL filter binding is unsupported')
        patterns=[];literals=[];usedconstants=set();subjects=set()
        for s,p,o in triples:
            if s in literal_bound:raise ValueError('literal variable used as a subject is not translated')
            a=node(s);pred=expand(p)
            if pred not in manifest['predicates']:raise ValueError('predicate missing from source')
            base=manifest['predicates'][pred]
            kinds={r['target'] for r in manifest['relationships'] if r['table'] in (base+'R',base+'L')}
            if len(kinds)!=1:raise ValueError('mixed resource/literal predicate range is not translated')
            if not s.startswith('?'):usedconstants.add(expand(s))
            if kinds=={'Literal'}:
                if not o.startswith('?'):raise ValueError('literal constants not translated by this cohort compiler')
                literals.append((s,a,base,o));subjects.add(s)
            else:
                if o in literal_bound:raise ValueError('literal/resource variable collision is not translated')
                b=node(o)
                if not o.startswith('?'):usedconstants.add(expand(o))
                patterns.append(f'({a}:Resource)-[:{base}R]->({b}:Resource)')
        if optional and literals and (len(triples)!=1 or opts):raise ValueError('only single-triple literal OPTIONAL is currently translated')
        # Bind subjects that have only property-column patterns. Re-matching an already bound resource is harmless.
        patterns += ['('+node(s)+':Resource)' for s in sorted(subjects)]
        if not patterns:raise ValueError('empty group not translated')
        text=('OPTIONAL MATCH ' if optional else 'MATCH ')+', '.join(patterns)
        constraints=[f'{constants[c][0]}.id = {constants[c][1]}' for c in sorted(usedconstants)]
        if constraints:text+=' WHERE '+' AND '.join('('+c+')' for c in constraints)
        for s,a,base,o in literals:
            alias='v_'+o[1:];already=o in bound
            if already and o not in literal_bound:raise ValueError('mixed resource/literal variable not translated')
            if o in nullable:raise ValueError('re-binding a nullable literal variable is not translated')
            local='__column_'+str(next(serial));arr=a+'.'+base;conds=[]
            if already:conds.append(local+'.id = '+alias+'.id')
            if optional:
                for condition in before:conds.append(re.sub(r'\b'+re.escape(alias)+r'\b',local,expression(condition)))
            if conds:arr='list_filter('+arr+', '+local+' -> '+' AND '.join('('+c+')' for c in conds)+')'
            if optional:arr='CASE WHEN '+arr+' IS NULL OR size('+arr+')=0 THEN [NULL] ELSE '+arr+' END'
            target=local if already else alias
            text+=' UNWIND '+arr+' AS '+target
            if not already:
                bound.add(o);literal_bound.add(o)
                if optional:nullable.add(o)
        if before and not(optional and literals):text+=' WITH * WHERE '+' AND '.join('('+expression(c)+')' for c in before)
        for child in opts:text+=' '+render(child,True)
        if after:text+=' WITH * WHERE '+' AND '.join('('+expression(c)+')' for c in after)
        return text
    cypher=render(group)
    if not set(projection)<=bound:raise ValueError('Unbound projection')
    tail=m[3].strip();order=[]
    ordermatch=re.search(r'ORDER\s+BY\s+(.*?)(?=\bOFFSET\b|\bLIMIT\b|$)',tail,re.I|re.S)
    if ordermatch:
        expr=ordermatch[1].strip();desc=False
        dm=re.fullmatch(r'DESC\s*\(\s*(\?\w+)\s*\)',expr,re.I)
        cast=re.fullmatch(r'xsd:double\s*\(\s*str\s*\(\s*(\?\w+)\s*\)\s*\)',expr,re.I)
        if dm:expr=dm[1];desc=True
        elif cast:expr=cast[1]
        if not re.fullmatch(r'\?\w+',expr):raise ValueError('Unsupported ORDER BY')
        order=[('v_'+expr[1:]+('.num' if cast else '.value'),desc)]
        tail=tail[:ordermatch.start()]+tail[ordermatch.end():]
    limit=re.search(r'LIMIT\s+(\d+)',tail,re.I);offset=re.search(r'OFFSET\s+(\d+)',tail,re.I)
    extra=re.sub(r'(?:LIMIT|OFFSET)\s+\d+','',tail,flags=re.I).strip()
    if extra:raise ValueError('Unsupported query modifier: '+extra)
    ret=['v_'+v[1:]+'.term AS '+v[1:] for v in projection]
    ret += [expr+f' AS sort_{i}' for i,(expr,_) in enumerate(order)]
    cypher+=' RETURN '+('DISTINCT ' if distinct else '')+', '.join(ret)
    if order:cypher+=' ORDER BY '+', '.join(f'sort_{i}'+(' DESC' if desc else '') for i,(_,desc) in enumerate(order))
    if offset:cypher+=' SKIP '+offset[1]
    if limit:cypher+=' LIMIT '+limit[1]
    return {'vars':[v[1:] for v in projection],'cypher':cypher}



def compile_union(query,m,resources):
 prefixes='\n'.join(re.findall(r'PREFIX\s+[\w-]+:\s*<[^>]+>',query,re.I))
 q=re.sub(r'PREFIX\s+[\w-]+:\s*<[^>]+>','',query,flags=re.I).strip()
 match=re.fullmatch(r'SELECT\s+(.*?)\s+WHERE\s*\{\s*\{(.*?)\}\s*UNION\s*\{(.*?)\}\s*\}\s*(.*)',q,re.S|re.I)
 if not match:raise ValueError('unsupported column UNION shape')
 projection=match[1].split()
 if projection==['?property','?hasValue','?isValueOf'] and not match[4].strip():
  outgoing=re.fullmatch(r'\s*<([^>]+)>\s+\?property\s+\?hasValue\s*\.?\s*',match[2]);incoming=re.fullmatch(r'\s*\?isValueOf\s+\?property\s+<([^>]+)>\s*\.?\s*',match[3])
  if not outgoing or not incoming or outgoing[1]!=incoming[1]:raise ValueError('unsupported variable-predicate UNION')
  ident=resources.get(key({'type':'uri','value':outgoing[1]}),-1);clauses=[]
  if any(r['target']=='Resource' for r in m['relationships']):
   clauses += [f'MATCH (s:Resource)-[r]->(o:Resource) WHERE s.id={ident} RETURN label(r) AS property,o.term AS hasValue,CAST(NULL AS STRING) AS isValueOf',f'MATCH (s:Resource)-[r]->(o:Resource) WHERE o.id={ident} RETURN label(r) AS property,CAST(NULL AS STRING) AS hasValue,s.term AS isValueOf']
  for col in m['literal_columns']:
   clauses.append(f'MATCH(s:Resource) WHERE s.id={ident} UNWIND s.{col} AS o RETURN '+json.dumps(col+'L')+' AS property,o.term AS hasValue,CAST(NULL AS STRING) AS isValueOf')
  if not clauses:raise ValueError('no RDF predicate tables to scan')
  reverse={r['table']:pred for pred,base in m['predicates'].items() for r in m['relationships'] if r['table'] in (base+'R',base+'L')}
  return {'vars':['property','hasValue','isValueOf'],'cypher':' UNION ALL '.join(clauses),'predicate_columns':['property'],'predicate_labels':reverse}
 if not projection or projection.pop(0).upper()!='DISTINCT':raise ValueError('only DISTINCT shared-projection UNION supported')
 if any(re.search(r'OPTIONAL|UNION',match[i],re.I) for i in [2,3]):raise ValueError('nested branch OPTIONAL/UNION unsupported')
 prefixes_map=dict(re.findall(r'PREFIX\s+([\w-]+):\s*<([^>]+)>',prefixes,re.I))
 def expand(t):
  if t=='a':return RDF+'type'
  if t.startswith('<'):return term(t)['value']
  a,b=t.split(':',1);return prefixes_map[a]+b
 token=r'(?:\?\w+|<[^>]+>|[\w-]+:[\w-]+|a)';triple=re.compile(rf'({token})\s+({token})\s+({token})\s*\.')
 branches=[triple.findall(match[i]) for i in [2,3]];shared=[t for t in branches[0] if t in branches[1]]
 outer={x for t in shared for x in t if x.startswith('?')}
 if not set(projection)<=outer:raise ValueError('UNION projections must be bound by shared triples')
 common=' '.join(' '.join(t)+' .' for t in shared)
 root=compile_bgp(prefixes+' SELECT DISTINCT '+' '.join(projection)+' WHERE { '+common+' } '+match[4],m,resources)
 conditions=[]
 for bi,triples in enumerate(branches):
  extra=[t for t in triples if t not in shared];patterns=[];constraints=[];literal=[];bound_constants={}
  filters=re.findall(r'FILTER\s*\(([^()]*)\)',match[bi+2],re.I)
  # The registered cohort's branch filters are simple numeric comparisons; refuse rather than partly translate more.
  if len(filters)!=len(re.findall(r'\bFILTER\b',match[bi+2],re.I)):raise ValueError('nested UNION filter unsupported')
  def node(t):
   if t.startswith('?'):return 'v_'+t[1:] if t in outer else f'b{bi}_v_'+t[1:]
   iri=expand(t)
   if iri not in bound_constants:
    alias=f'b{bi}_c_'+str(len(bound_constants));bound_constants[iri]=alias
    constraints.append(alias+'.id='+str(resources.get(key({'type':'uri','value':iri}),-1)))
   return bound_constants[iri]
  for a,pred,b in extra:
   base=m['predicates'].get(expand(pred));kinds={r['target'] for r in m['relationships'] if r['table'] in (str(base)+'R',str(base)+'L')}
   if kinds=={'Resource'}:patterns.append('('+node(a)+':Resource)-[:'+base+'R]->('+node(b)+':Resource)')
   elif kinds=={'Literal'}:
    if not b.startswith('?'):raise ValueError('UNION literal constant unsupported')
    literal.append((node(a),base,b))
   else:raise ValueError('mixed/missing UNION predicate unsupported')
  if len(literal)>1:raise ValueError('multiple extra literal bindings in UNION branch not translated')
  if literal:
   subject,col,var=literal[0];alias=f'b{bi}_literal';local=[]
   if var in outer:local.append(alias+'.id=v_'+var[1:]+'.id')
   for f in filters:local.append(re.sub(r'\bv_'+re.escape(var[1:])+r'\b',alias,filter_expression(f,resources)))
   constraints.append('ANY('+alias+' IN '+subject+'.'+col+' WHERE '+(' AND '.join('('+f+')' for f in local) if local else 'true')+')')
  else:constraints += [filter_expression(f,resources) for f in filters]
  body=' AND '.join('('+c+')' for c in constraints) or 'true'
  conditions.append('EXISTS { MATCH '+', '.join(patterns)+' WHERE '+body+' }' if patterns else body)
 before,ret=root['cypher'].split(' RETURN ',1);root['cypher']=before+' WITH * WHERE ('+' OR '.join(conditions)+') RETURN '+ret;return root

def compile_queries(source,qdir,out):
 m=json.loads((source/'manifest.json').read_text());origin=Path(m.get('source_csv',source));resources=json.loads((origin/'resource-ids.json').read_text());records={}
 for path in sorted(qdir.glob('*.rq')):
  query=path.read_text()
  try:record=compile_union(query,m,resources) if re.search(r'\bUNION\b',query,re.I) else compile_bgp(query,m,resources)
  except ValueError as e:record={'unsupported':str(e)}
  records[path.stem]={'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),**record}
 out.write_text(json.dumps(records,indent=2));return records
