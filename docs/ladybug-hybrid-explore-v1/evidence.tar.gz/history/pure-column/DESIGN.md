# BSBM10M tuned Ladybug follow-up — draft, no new engine run

Purpose: isolate the effect of RDF representation within Ladybug on the existing 20-query Explore workload. Compare original lossless Resource/Literal-node/per-predicate-edge mapping with a literal-property-column mapping in a newly registered paired session. This is a schema-aware translation comparison, not a new cross-engine ranking or a general SPARQL implementation. Do not combine old TripleLight timings with new Ladybug observations.

Read-only historical inputs:
- Generic CSV + manifest: /private/tmp/rdf-jianlin-ladybug18/bsbm10-csv, input SHA3a207c6725820036eec87d08dd414090d3548ac2839ca192414dad6e352f680e, unique10102032 triples.
- Current frozen historical translators: /private/tmp/rdf-jianlin-ladybug18/final-service-source; never edit them.
- Queries: /private/tmp/rdf-jianlin-embedded22/bsbm-fixed/queries/bsbm. Jena references: /private/tmp/rdf-jianlin-embedded22/bsbm10-reference (gzip JSON + provenance). Do not assume filename correspondence without checking source hashes.

Static-only coverage observation:20queries,6DISTINCT,13FILTER,13OPTIONAL,2UNION,9ORDER/LIMIT. These are regex markers, not successful translation counts. Existing tuned.py accepts only plain LUBM SELECT BGP, with63-bit type masks; it cannot be reused unchanged to claim20-query coverage.

Candidate representation:
- Keep all Resource nodes and stable resource IDs. Keep RDF type and every resource-object predicate as graph edges. No new class inference or type-specific filtering.
- Replace literal nodes/edges by per-predicate list columns of STRUCT records, retaining literal ID, complete serialized RDF term, lexical value, datatype, language and identical comparison helper fields. A repeated literal variable must join by exact identity, not only numeric value.
- Preserve every literal value and every multivalued predicate. Require conservation: explicit RDF type facts + other resource edges + all literal property elements equals10102032, with original triple set semantics.
- Prefer Parquet nested struct lists for ingestion; first validate actual Ladybug0.22.3 support on a tiny real fixture with a bounded buffer pool, before any large preparation. Unsupported STRUCT/UNWIND paths are a setup result, not evidence for or against performance.

Compiler obligations before timing:
- Cover all20original queries, preserving source hashes. UNION multiplicity, variable predicates and exact term reconstruction must match the generic translator.
- OPTIONAL literal properties need a real left-join implementation: naive UNWIND removes a row when its list is empty. Test empty lists, unmatched filters, multiple optional values, and null/unbound serialization explicitly. Do not silently fall back to the generic representation for selected difficult queries while calling the full suite tuned.
- Keep ORDER BY lexical strings, dates and numeric casts; LIMIT ties handled by the existing reference policy, not by sequence hash alone.
- Independently gate all bags and the9ordered queries, including tiny datatype/language/lexical-form/self-loop/multivalue/OPTIONAL/UNION controls.

Prospective measurement (draft, not registered): both mappings in the same native Python/Ladybug version, same thread count and nominal pool limit, full response decoding/consumption included, fixed query order with alternating mapping order across fresh processes, warmups retained, all samples result-gated. Publish both passes and raw observations, no selective retries. Determine resource/import headroom and exact phase counts before registration.

Next: inspect generic translator bindings and optional-group shapes; implement a separate candidate source directory and tiny semantic fixtures. Large conversion/import/benchmarks require a fresh live lock/directive check, approved disk cap and a frozen execution contract. Current ROOT near40GiB guard: budget candidate outputs first; only remove owned reproducible build caches after recording rebuildability.
