"""Recompute SQLite adapter observations using only the retained evidence."""
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import sys

XSD = 'http://www.w3.org/2001/XMLSchema#'


def rdf_key(obj):
    if obj['type'] == 'uri':
        return ('uri', obj['value'], '', '')
    language = obj.get('language', obj.get('xml:lang', '')).lower()
    datatype = obj.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
                                       if language else XSD + 'string')
    return ('literal', obj['value'], datatype, language)


def main():
    root = Path(sys.argv[1])
    run = root / 'attempt'
    setup = json.loads((root/'SETUP.json').read_bytes())
    runtime = (root/'setup/brickschema-runtime.json').read_bytes()
    assert setup['receipts']['upstream-0.5.4']['state'] == 'plugin-import-failed'
    assert setup['receipts']['upstream-0.5.4']['exit'] == 1
    assert "No module named 'pkg_resources'" in (root/'setup/upstream-import.stderr').read_text()
    assert setup['receipts']['brickschema-0.7.1']['runtime_sha256'] == sha256(runtime).hexdigest()
    identity = json.loads(runtime)
    assert identity['sqlite_version'] == '3.50.4'
    summary = json.loads((run/'SUPERVISOR.json').read_bytes())
    assert summary['identity_postcheck'] is True and summary['full_workload_qualified'] is False
    assert summary['setup_sha256'] == sha256((root/'SETUP.json').read_bytes()).hexdigest()
    assert summary['source_sha256'] == sha256((root/'source/FREEZE.json').read_bytes()).hexdigest()
    schema = json.loads((root/'DATABASE_SCHEMA.json').read_bytes())
    observations = summary['observations']
    assert len(observations) == 8
    reference = json.loads((root/'source/consumer-fixture-jena.json').read_bytes())
    expected = Counter(('urn:s','urn:v',rdf_key(row['o'])) for row in reference['results']['bindings'])
    assert sum(expected.values()) == len(expected) == 9
    answers = []
    loader_tables = {}
    for index, obs in enumerate(observations):
        expected_profile = 'upstream-0.5.4' if index<4 else 'brickschema-0.7.1'
        expected_normalization = 'default' if index%4<2 else 'preserve'
        expected_boundary = 'load' if index%2==0 else 'reopen'
        profile, mode, boundary = obs['profile'],obs['normalization'],obs['boundary']
        assert (profile,mode,boundary)==(expected_profile,expected_normalization,expected_boundary)
        if profile=='upstream-0.5.4':
            assert obs['state']=='skipped-setup' and obs['setup_outcome']=='plugin-import-failed'
            answers.append(dict(obs))
            continue
        assert obs['state']=='observed' and obs['worker_exit']==0
        raw=json.loads((run/obs['record']).read_bytes())
        assert (raw['profile'],raw['normalization'],raw['boundary'])==(profile,mode,boundary)
        assert raw['normalize_literals'] is (mode=='default')
        assert raw['closed'] is True and raw['step']=='complete'
        assert raw['sqlite_version']==identity['sqlite_version'] and raw['journal_mode']=='delete'
        assert raw['table_prefix']==raw['plugin_table_prefix']=='kb_9cc0b3e5f1'
        assert raw['tables']==obs['tables'] and all(t.startswith(raw['table_prefix']+'_') for t in raw['tables'])
        triples=Counter((row['s'],row['p'],rdf_key(row['o'])) for row in raw['triples'])
        assert sum(triples.values())==len(triples)==9
        gates={'count':type(raw['count']) is int and raw['count']==9,'exact_triple_bag':triples==expected}
        assert gates==raw['checks']==obs['storage_checks']
        partitions=defaultdict(set)
        for subject,predicate,obj in triples:
            partitions[obj[0]].add((subject,predicate,obj[1]))
        projection_count=sum(len(rows) for rows in partitions.values())
        assert projection_count==raw['count']
        if boundary=='load':
            assert raw['add_calls']==9
            loader_tables[mode]=raw['tables']
        else:
            assert obs['same_sqlite_tables'] is True and raw['tables']==loader_tables[mode]
            files=obs['before_reopen_files']
            assert len(files)==1 and schema[mode]['sha256']==next(iter(files.values()))['sha256']
            assert 'objdatatype VARCHAR' in schema[mode]['literal_partition_ddl']
        evaluator=raw['shared_evaluator']
        assert evaluator['passes'] is obs['shared_evaluator_pass'] is False and evaluator['columns']==['o']
        assert len(evaluator['rows'])==9
        answers.append({'profile':profile,'normalization':mode,'boundary':boundary,
                        'graph_length':raw['count'],'direct_triples':sum(triples.values()),
                        'source_based_projection_count':projection_count,
                        'missing':sorted((expected-triples).elements()),'additional':sorted((triples-expected).elements()),
                        'shared_filter_false_rows':len(evaluator['rows'])})
    print(json.dumps(answers,indent=2))


if __name__=='__main__':
    main()
