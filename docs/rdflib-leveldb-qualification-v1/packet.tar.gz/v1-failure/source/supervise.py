"""Run the pinned setup or storage container under an already-owned machine lock."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
from urllib.request import urlopen

from runtime import LABEL, LABEL_KEY, LIBRARIES, OWNER, PINS, SOURCE, load, require, sha, write

ROOT = Path('/private/tmp/rdf-jianlin-rdflib-leveldb39-v1')
LOCK = Path('/private/tmp/rdf-bench.lock')
TMPFS = 'rw,nosuid,size=128m'
CPUS = 2
MEMORY = 2 << 30
CAP = 2 << 30
FLOOR = 40_000_000_000
LOADER = str(LIBRARIES)
INCLUDE = '-I/runtime/debian/usr/include'
LINK = '-L' + LOADER + ' -Wl,-rpath-link,' + LOADER


def docker(*args):
    result = subprocess.run(['docker', *args], capture_output=True, text=True, timeout=25)
    require(result.returncode == 0, f'docker {args[:2]} failed: {result.stderr[-600:]}')
    return result.stdout


def lock():
    require((LOCK / 'owner').read_text() == OWNER + '\n', 'exact owned machine lock required')


def source_identity(digest):
    manifest = SOURCE / 'FREEZE.json'
    require(sha(manifest) == digest, 'wrong freeze manifest')
    for name, expected in load(manifest).items():
        require(sha(SOURCE / name) == expected, f'changed source: {name}')


def guard(deadline):
    lock()
    require(time.monotonic() < deadline, 'stage deadline')
    require(shutil.disk_usage(ROOT).free >= FLOOR, 'shared disk free-space floor')
    allocated = 0
    for path in ROOT.rglob('*'):
        try:
            allocated += path.lstat().st_blocks * 512
        except FileNotFoundError:
            continue
    require(allocated < CAP, 'private root allocation cap')
    return allocated


def prepare_inputs(directory, deadline):
    directory.mkdir()
    for entry in PINS['archives'] + PINS['wheel_inputs']:
        path = directory / entry['filename']
        length = 0
        with urlopen(entry['url'], timeout=15) as response, path.open('xb') as output:
            while chunk := response.read(65536):
                length += len(chunk)
                require(length <= entry['bytes'], f'oversize input: {path.name}')
                output.write(chunk)
                guard(deadline)
        require(length == entry['bytes'] and sha(path) == entry['sha256'], f'wrong input: {path.name}')


def inspect_container(name):
    return json.loads(docker('container', 'inspect', name))[0]


def exists(name):
    return name in docker('ps', '-a', '--format', '{{.Names}}').splitlines()


def configuration(info, image_id, mounts, environment, command):
    host = info['HostConfig']
    actual = {m['Destination']: (str(Path(m['Source']).resolve()), m['RW']) for m in info['Mounts']}
    wanted = {dest: (str(path.resolve()), writable) for dest, (path, writable) in mounts.items()}
    env = set(info['Config']['Env'])
    require(info['Platform'] == 'linux' and info['Image'] == image_id
            and host['NetworkMode'] == 'none' and host['ReadonlyRootfs'] is True
            and host['CgroupnsMode'] == 'private' and host['NanoCpus'] == CPUS * 10**9
            and host['Memory'] == host['MemorySwap'] == MEMORY
            and host.get('Tmpfs', {}).get('/tmp') == TMPFS
            and info['Config']['Labels'].get(LABEL_KEY) == LABEL
            and actual == wanted and set(environment) <= env and info['Config']['Cmd'] == command,
            'container binding check failed')
    return {'mounts': actual, 'network': 'none', 'readonly_root': True, 'private_cgroup': True,
            'cpu_count': CPUS, 'memory_bytes': MEMORY, 'memory_swap_bytes': MEMORY,
            'tmpfs': TMPFS, 'command': command}


def cleanup(name, created_possible, process):
    if created_possible and exists(name):
        info = inspect_container(name)
        require(info['Config']['Labels'].get(LABEL_KEY) == LABEL, 'cleanup refused for another owner')
        ident = info['Id']
        if info['State']['Running']:
            docker('stop', '--time', '3', ident)
        docker('rm', ident)
    if process:
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    require(not created_possible or not exists(name), 'owned container remains')
    return 'verified-removed' if created_possible else 'not-created'


def run(args):
    lock()
    source_identity(args.freeze_sha256)
    runtime_dir = ROOT / 'runtime'
    setup = args.stage == 'setup'
    if setup:
        ROOT.mkdir()
    else:
        receipt = runtime_dir / 'RUNTIME.json'
        require(args.runtime_sha256 and sha(receipt) == args.runtime_sha256
                and load(receipt)['state'] == 'ready', 'reviewed ready runtime required')
    phase = ROOT / args.stage
    phase.mkdir()
    name = LABEL + '-' + args.stage
    report = {'stage': args.stage, 'source_sha256': args.freeze_sha256, 'image': PINS['python_image'],
              'stage_cap_seconds': 300 if setup else 120}
    deadline = time.monotonic() + report['stage_cap_seconds']
    process = None
    created_possible = False
    try:
        guard(deadline)
        image = json.loads(docker('image', 'inspect', PINS['python_image']))[0]
        require(image['Os'] == 'linux' and image['Architecture'] == 'arm64', 'wrong pinned image platform')
        image_id = image['Id']
        report['image_id'] = image_id

        mounts = {'/src': (SOURCE, False), '/guard': (LOCK, False), '/runtime': (runtime_dir, setup)}
        environment = ['PYTHONDONTWRITEBYTECODE=1', 'LD_LIBRARY_PATH=' + LOADER]
        if setup:
            inputs = ROOT / 'inputs'
            prepare_inputs(inputs, deadline)
            runtime_dir.mkdir()
            mounts['/inputs'] = (inputs, False)
            environment += ['CFLAGS=' + INCLUDE, 'CXXFLAGS=' + INCLUDE, 'LDFLAGS=' + LINK]
            command = ['/usr/local/bin/python3', '-E', '-s', '-B', '/src/setup_inside.py']
        else:
            data = phase / 'out'
            data.mkdir()
            mounts['/out'] = (data, True)
            command = ['/usr/local/bin/python3', '-E', '-s', '-B', '/src/storage_inside.py',
                       '--runtime-sha256', args.runtime_sha256]

        require(not exists(name), 'container name preexists')
        cmd = ['create', '--pull=never', '--name', name, '--platform', PINS['platform'],
               '--label', LABEL_KEY + '=' + LABEL, '--cpus', str(CPUS), '--memory', str(MEMORY),
               '--memory-swap', str(MEMORY), '--network=none', '--cgroupns=private', '--read-only',
               '--tmpfs', '/tmp:' + TMPFS, '--workdir', '/tmp']
        for variable in environment:
            cmd.extend(('-e', variable))
        for destination, (path, writable) in mounts.items():
            spec = f'type=bind,src={path},dst={destination}'
            cmd.extend(('--mount', spec if writable else spec + ',readonly'))
        guard(deadline)
        created_possible = True
        ident = docker(*cmd, PINS['python_image'], *command).strip()
        info = inspect_container(ident)
        report['container_id'] = ident
        report['binding'] = configuration(info, image_id, mounts, environment, command)
        with (phase / 'container.stdout').open('xb') as stdout, (phase / 'container.stderr').open('xb') as stderr:
            process = subprocess.Popen(['docker', 'start', '-a', ident], stdout=stdout, stderr=stderr)
            while process.poll() is None:
                guard(deadline)
                log_bytes = os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size
                require(log_bytes < 8 << 20, 'container output cap')
                time.sleep(0.25)
            report['attach_exit'] = process.wait()
        state = inspect_container(ident)['State']
        report.update(exit_code=state['ExitCode'], oom_killed=state['OOMKilled'], running=state['Running'])
        require(report['attach_exit'] == report['exit_code'] == 0
                and not report['oom_killed'] and not report['running'], 'container did not exit normally')
        guard(deadline)
        source_identity(args.freeze_sha256)
        if setup:
            record = load(runtime_dir / 'RUNTIME.json')
            report.update(runtime_sha256=sha(runtime_dir / 'RUNTIME.json'),
                          runtime_state=record['state'], rdf_data_opened=record['rdf_data_opened'])
        else:
            require(sha(runtime_dir / 'RUNTIME.json') == args.runtime_sha256, 'runtime receipt changed')
            require((phase / 'out/OBSERVATIONS.json').is_file(), 'storage evidence missing')
    except BaseException as exc:
        report['error'] = repr(exc)
    finally:
        try:
            report['cleanup'] = cleanup(name, created_possible, process)
            lock()
        except BaseException as exc:
            report.update(cleanup='unverified', cleanup_error=repr(exc))
        write(phase / 'SUPERVISOR.json', report)
    return int('error' in report or report['cleanup'] != 'verified-removed')


def interrupted(signum, frame):
    raise RuntimeError(f'host supervisor received signal {signum}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('setup', 'storage'))
    parser.add_argument('--freeze-sha256', required=True)
    parser.add_argument('--runtime-sha256')
    for sig in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    raise SystemExit(run(parser.parse_args()))
