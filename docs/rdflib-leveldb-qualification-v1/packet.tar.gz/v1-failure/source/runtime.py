"""Identity checks shared by the offline build and fresh reader processes."""
from base64 import urlsafe_b64encode
from hashlib import file_digest
from importlib.metadata import distribution
import json
from pathlib import Path
import platform
import sys

SOURCE = Path(__file__).resolve().parent
PINS = json.loads((SOURCE / 'PINS.json').read_bytes())
RUNTIME = Path('/runtime')
LIBRARIES = RUNTIME / 'debian/usr/lib/aarch64-linux-gnu'
PYTHON = RUNTIME / 'venv/bin/python'
IMAGE_PYTHON = Path('/usr/local/bin/python3')
OWNER = 'Jianlin task39 RDFLib LevelDB Linux v1'
LABEL = 'jianlin-leveldb39-linux-v1'
LABEL_KEY = 'org.triplelight.jianlin.qualification'
LOCK = Path('/guard/owner')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    with Path(path).open('rb') as handle:
        return file_digest(handle, 'sha256').hexdigest()


def write(path, record):
    with path.open('x') as output:
        json.dump(record, output, indent=2, sort_keys=True)
        output.write('\n')


def load(path):
    return json.loads(path.read_bytes())


def platform_check():
    require(LOCK.read_text() == OWNER + '\n', 'exact LevelDB owner required')
    require(platform.system() == 'Linux' and platform.machine() == 'aarch64'
            and platform.python_version() == PINS['python_version'], 'wrong Linux ARM64 Python')


def installed():
    prefix = PYTHON.parent.parent
    files = {}
    for name, version in PINS['versions'].items():
        dist = distribution(name)
        require(dist.version == version and dist.files, f'wrong installed distribution {name}')
        for member in dist.files:
            path = Path(dist.locate_file(member)).resolve(strict=True)
            require(path.is_relative_to(prefix), f'installed file escaped private venv: {member}')
            digest = sha(path)
            if member.hash:
                encoded = urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip('=')
                require(member.hash.mode == 'sha256' and encoded == member.hash.value
                        and path.stat().st_size == member.size, f'RECORD mismatch: {member}')
            else:
                require(str(member).endswith('.dist-info/RECORD'), f'unsigned RECORD entry: {member}')
            files[str(path.relative_to(RUNTIME))] = digest
    return files


def native_identity():
    import plyvel
    from plyvel import _plyvel

    expected = {(LIBRARIES / soname).resolve(strict=True)
                for soname in ('libleveldb.so.1d', 'libsnappy.so.1v5')}
    mapped = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith('/'):
            path = Path(fields[5])
            if path.name.startswith(('libleveldb.so', 'libsnappy.so')):
                mapped.add(path.resolve(strict=True))
    require(mapped == expected and len(expected) == 2 and all(path.parent == LIBRARIES for path in expected),
            'native path mismatch')
    extension = Path(_plyvel.__file__).resolve(strict=True)
    require(extension.is_relative_to(RUNTIME / 'venv'), 'Plyvel extension escaped private venv')
    return {
        'extension': {str(extension.relative_to(RUNTIME)): sha(extension)},
        'libraries': {str(path.relative_to(RUNTIME)): sha(path) for path in sorted(mapped)},
        'plyvel_leveldb_version': list(plyvel.__leveldb_version__),
    }


def adapter_identity():
    import rdflib
    from rdflib_leveldb.leveldbstore import LevelDBStore
    from rdflib.store import Store

    require(rdflib.plugin.get('LevelDB', Store) is LevelDBStore, 'wrong RDFLib LevelDB entry point')
    return rdflib


def runtime_identity(digest):
    platform_check()
    receipt = RUNTIME / 'RUNTIME.json'
    require(sha(receipt) == digest, 'setup receipt digest changed')
    record = load(receipt)
    require(record['state'] == 'ready' and record['rdf_data_opened'] is False, 'runtime is not ready')
    require(Path(sys.executable) == PYTHON and sha(PYTHON) == record['python_sha256'],
            'storage must run with the registered Python')
    require(installed() == record['installed'], 'installed files changed')
    require(native_identity() == record['native'], 'mapped native runtime changed')
    return adapter_identity()
