# RDFLib LevelDB qualification plan

Use the declared Linux dependency path on an ARM64 Linux virtual machine. The RDFLib LevelDB plugin has no published release wheel at the selected revision. Its source build declares upstream Plyvel on Linux and plyvel-wheels on Darwin. PyPI publishes Plyvel 1.5.1 source and x86-64 Linux wheels. The selected ARM64 environment will build the unmodified sdist with the C++ already generated in the release and link against Debian LevelDB. [Plugin packaging](https://github.com/RDFLib/rdflib-leveldb/blob/a0f3386c71e6b1cfbd09c257e29400f5fde43ed3/setup.py) · [Plyvel release](https://pypi.org/project/plyvel/1.5.1/)

The Docker Official Image `docker.io/library/python` ARM64 manifest is `sha256:3dc01f342e31ad8de39338d14ab12de0090c9102b34f75ca9774ff1f4f5e904e` (Bookworm, CPython 3.12.16). The registry manifest and config content matched their digests. The compressed image layer sum is 370,997,938 bytes. No image has been pulled. Use the ARM64 manifest explicitly. [Official image](https://hub.docker.com/_/python)

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| RDFLib LevelDB source archive at a0f3386c71e6b1cfbd09c257e29400f5fde43ed3 | 1,382,917 | `54bd01f95dca96a7baf0a0fe95e11eebaaca794bebb26852d1ada1248b564622` |
| Plyvel 1.5.1 sdist | 200,128 | `3caf6009e4fc24fbf8712d3f5ef3da7e56495c26a488df2161218fc34e46019c` |
| Debian Bookworm libleveldb-dev 1.23-4 ARM64 | 174,916 | `b624c9d239f7da934e858011178956abdf8831b9076b5e7e901352977c02ad50` |
| Debian Bookworm libleveldb1d 1.23-4 ARM64 | 122,988 | `e881e5d034b90de44cb6b656bfe1693c1ac10db3e749d844acb8d40543e64fd9` |
| Debian Bookworm libsnappy1v5 1.1.9-3 ARM64 | 25,412 | `7d9a01c7f175cdc6f1ac23dde7b21c0ff840f098069e95a896fda56c824a5828` |

These hashes identify bytes fetched from official distribution endpoints. Record exact package build and runtime wheel identities in the frozen harness. [Debian LevelDB development package](https://packages.debian.org/bookworm/arm64/libleveldb-dev) · [Debian LevelDB runtime package](https://packages.debian.org/bookworm/arm64/libleveldb1d) · [Debian Snappy package](https://packages.debian.org/bookworm/arm64/libsnappy1v5)

## Setup

- Freeze source and build dependencies before the image pull. Pin RDFLib 7.6.0 and its dependencies plus setuptools and wheel. Build and install both source packages offline in a private runtime. Use `dpkg-deb -x` on the three exact ARM64 packages under the private mount. Pass that include and library location to the build without installing packages on the host or in a shared environment. Reject a package or module whose loaded binary path escapes the private environment. At import, record the exact loaded LevelDB and Snappy paths and digests from the process's Linux maps. Reject unexpected architecture, version or origin. Verify wheel RECORD and entry-point identity before opening any RDF data.
- Run under the active machine queue and an atomic lock in a new scratch root. Bind separate read-only input and writable output directories, cap resources, log exit status, and stop or remove only identified children or containers. Use the setup receipt to bind the next stage. Preserve errors rather than changing the profile after seeing the outcome.

## Storage checks

Use the same nine-term N-Triples fixture and exact typed reference as the earlier RDFLib persistence qualifications. Test two separately created stores, RDFLib's default literal normalization and normalization explicitly disabled before the fixture parse. Keep each graph identifier fixed over load and reopen. Record the parsed in-memory bag before writing, the direct store graph length and typed iteration after load, then close and open with create disabled in a fresh child. Record the store file inventory and count/typed bag again. A profile passes fidelity only if the bags and counts equal the reference at both observations. If the parsed bag differs, report the first observed boundary without ascribing persisted changes to the backend. Keep the separate shared RDFLib FILTER(false) probe out of the storage gate.

This is a tiny persistent storage qualification. No workload timing or durability, concurrent access, or general SPARQL qualification is planned. No build, installation or engine import has run.
