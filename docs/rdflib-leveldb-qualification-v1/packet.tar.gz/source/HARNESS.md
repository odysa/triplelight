# Frozen execution steps

The host supervisor expects an already-owned `/tmp/rdf-bench.lock` with owner `Jianlin task39 RDFLib LevelDB Linux v2` and a fresh `/private/tmp/rdf-jianlin-rdflib-leveldb39-v2`. Confirm the live handoff, disk floor and exact source manifest before claiming the lock. Check for the exact local ARM64 image and pull only that digest if necessary, while holding the lock. A pull runs separately from setup, and its outcome belongs in the execution record.

Run the setup supervisor first. It verifies nine distribution inputs, checks the ARM64 image and bind configuration, builds with networking disabled and captures compiler versions and locally built wheel digests.

```bash
rtk proxy python3 -E -s -B scratch/rdflib-leveldb39-plan-v2/supervise.py setup --freeze-sha256 <freeze-sha256>
```

Read `setup/SUPERVISOR.json` and `runtime/RUNTIME.json` in the new run root. The stage is ready for data access only when the container has exited successfully, exact cleanup is verified, and the runtime states `ready`. The probe records any native or adapter import failure at its first observed step. Report a source build or package failure at setup. Do not patch either source package during the attempt.

After announcing the setup identities, run storage against the exact runtime digest reported by setup. The runtime mount is read-only in the storage container. Every worker rechecks installed files, interpreter and mapped libraries before opening a store. The parent records observations and the database directory inventory after each child exits. The first process parses into an RDFLib memory graph and inserts those terms into the named disk graph. Reopen uses the same graph identifier with creation disabled. Separate default and preservation profiles have separate stores. Retained LOG snapshots and the nonempty numbered WAL inventory make it possible to distinguish evidence of actual WAL recovery from a WAL file's presence.

```bash
rtk proxy python3 -E -s -B scratch/rdflib-leveldb39-plan-v2/supervise.py storage --freeze-sha256 <freeze-sha256> --runtime-sha256 <runtime-sha256>
```

Setup and storage cap at 300 and 120 seconds respectively, each with two CPUs, 2 GiB RAM and no additional swap. The private root cap is 2 GiB and the host free-space floor is 40 GB. Both containers use a read-only root filesystem and private cgroup namespace. The host measures allocation during the attached run, captures output and checks the exact container label before cleanup. Release the lock only after confirming all owned processes exited and any created container was removed. Keep the original root if a stage fails. No fallback profile is defined here.

The offline controls exercise bag fidelity, persisted-file classification and container binding validation. They run on the local macOS CPython 3.12.12 without importing an RDF engine or invoking Docker. The execution environment is separately pinned Linux ARM64 CPython 3.12.16.

## Revision 2

Revision 1 built both wheels and verified their installed files, then the native identity check tried to resolve the Debian package name suffix as part of the Snappy library SONAME. The retained ELF metadata gives `libsnappy.so.1`. Revision 2 pins that SONAME, its versioned target and digest, and the matching LevelDB identities. The maps check still requires both private files and rejects outside mappings. The workload and build inputs are unchanged. Use a fresh host root, owner and container label.
