"""Engine-free controls for the native storage harness."""
import ast
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile

import storage_inside as storage
import supervise as host
from runtime import LABEL, LABEL_KEY, SOURCE, load, write


def rejects(call, expected):
    try:
        call()
    except RuntimeError as exc:
        assert str(exc) == expected
    else:
        raise AssertionError(f'expected rejection: {expected}')


def main():
    for path in SOURCE.glob('*.py'):
        ast.parse(path.read_text(), filename=str(path), feature_version=(3, 12))
    ref = load(SOURCE / 'consumer-fixture-jena.json')
    fixtures = [[{'type': 'uri', 'value': 'urn:s'}, {'type': 'uri', 'value': 'urn:v'}, row['o']]
                for row in ref['results']['bindings']]
    assert storage.exact_bag(fixtures)
    assert not storage.exact_bag(fixtures[:-1] + fixtures[:1])
    assert not storage.exact_bag(fixtures + fixtures[:1])
    normalized = deepcopy(fixtures)
    index = next(i for i, row in enumerate(fixtures) if row[2]['value'] == '01')
    normalized[index][2]['value'] = '1'
    assert not storage.exact_bag(normalized)

    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        names = ('CURRENT', 'MANIFEST-000004', 'LOCK', 'LOG', '000003.log', '000009.log', '000006.ldb')
        for name in names:
            (root / name).write_text('data' if name == '000003.log' else '')
        files = storage.inventory(root)
        facts = storage.lifecycle(files)
        assert set(files) == set(names)
        assert facts == {'current': True, 'manifests': ['MANIFEST-000004'],
                         'nonempty_wal': ['000003.log'], 'tables': ['000006.ldb'],
                         'lock_file': True, 'info_log': True}

    mounts = {'/src': (Path('/private/tmp/leveldb39-source'), False)}
    environment = ['LD_LIBRARY_PATH=' + host.LOADER]
    command = ['python']
    container = {'HostConfig': {'NetworkMode': 'none', 'ReadonlyRootfs': True, 'CgroupnsMode': 'private',
                                'NanoCpus': host.CPUS * 10**9, 'Memory': host.MEMORY,
                                'MemorySwap': host.MEMORY, 'Tmpfs': {'/tmp': host.TMPFS}},
                 'Config': {'Labels': {LABEL_KEY: LABEL}, 'Env': environment, 'Cmd': command},
                 'Platform': 'linux', 'Image': 'secretless-image-id',
                 'Mounts': [{'Destination': '/src', 'Source': str(mounts['/src'][0]), 'RW': False}]}
    validate = lambda info: host.configuration(info, container['Image'], mounts, environment, command)
    assert validate(container)['network'] == 'none'
    for key, wrong in [('NetworkMode', 'bridge'), ('ReadonlyRootfs', False), ('MemorySwap', host.MEMORY * 2)]:
        changed = deepcopy(container)
        changed['HostConfig'][key] = wrong
        rejects(lambda: validate(changed), 'container binding check failed')
    changed = deepcopy(container)
    changed['Mounts'][0]['RW'] = True
    rejects(lambda: validate(changed), 'container binding check failed')

    assert not {'rdflib', 'plyvel', 'rdflib_leveldb'}.intersection(sys.modules)
    print(json.dumps({'python_syntax': '3.12', 'engine_imported': False,
                      'exact_bag_controls': 4, 'lifecycle_controls': 1,
                      'container_binding_controls': 5}, sort_keys=True))


if __name__ == '__main__':
    main()
