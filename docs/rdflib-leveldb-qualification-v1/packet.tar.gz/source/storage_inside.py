"""Record the parsed, loaded and fresh-process reopened fixture boundaries."""
import argparse
from collections import Counter
from pathlib import Path
import re
import shutil
import subprocess
import sys

from runtime import (PYTHON, SOURCE, load, platform_check, require, runtime_identity,
                     sha, write)

OUT = Path('/out')
FILTER_FALSE = 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }'
GRAPH = 'urn:triplelight:qualification:leveldb39'
PROFILES = ('default', 'preserve')
BOUNDARIES = ('load', 'reopen')


def key(term):
    kind = term['type']
    value = term['value']
    if kind == 'uri':
        return kind, value, '', ''
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if language
                                        else 'http://www.w3.org/2001/XMLSchema#string')
    return kind, value, datatype, language


def exact_bag(rows):
    reference = load(SOURCE / 'consumer-fixture-jena.json')
    subject = ('uri', 'urn:s', '', '')
    predicate = ('uri', 'urn:v', '', '')
    expected = Counter((subject, predicate, key(row['o'])) for row in reference['results']['bindings'])
    require(sum(expected.values()) == 9 and len(expected) == 9, 'incorrect reference size')
    return Counter(tuple(map(key, row)) for row in rows) == expected


def observe(rdflib, profile, boundary, db, record):
    from rdflib.store import VALID_STORE

    loading = boundary == 'load'
    record['step'] = 'configure'
    require(rdflib.NORMALIZE_LITERALS is True, 'unexpected RDFLib normalization default')
    rdflib.NORMALIZE_LITERALS = profile == 'default'
    record['normalize_literals'] = rdflib.NORMALIZE_LITERALS

    def term(value):
        if isinstance(value, rdflib.URIRef):
            return {'type': 'uri', 'value': str(value)}
        if isinstance(value, rdflib.Literal):
            result = {'type': 'literal', 'value': str(value)}
            if value.datatype:
                result['datatype'] = str(value.datatype)
            if value.language:
                result['language'] = value.language
            return result
        raise TypeError(f'unsupported fixture term {type(value).__name__}')

    def terms(triples):
        return [[term(value) for value in row] for row in triples]

    if loading:
        record['step'] = 'parse'
        memory = rdflib.Graph()
        memory.parse(source=SOURCE / 'consumer-fixture.nt', format='nt')
        rows = list(memory)
        record['parsed'] = terms(rows)
        record['parsed_count'] = len(memory)
        record['parsed_exact'] = exact_bag(record['parsed'])
        memory.close()
    record['step'] = 'construct'
    graph = rdflib.Graph(store='LevelDB', identifier=rdflib.URIRef(GRAPH))
    record['step'] = 'open'
    record['open_result'] = graph.open(str(db), create=loading)
    require(record['open_result'] == VALID_STORE, 'LevelDB Graph open did not return VALID_STORE')
    try:
        if loading:
            record['step'] = 'add'
            record['added'] = 0
            for row in rows:
                graph.add(row)
                record['added'] += 1
        record['step'] = 'iterate'
        record['count'] = len(graph)
        record['triples'] = terms(graph.triples((None, None, None)))
        record['exact_bag'] = exact_bag(record['triples'])
        record['step'] = 'diagnostic'
        try:
            result = graph.query(FILTER_FALSE, use_store_provided=False)
            columns = [str(var) for var in result.vars]
            result_rows = [[None if value is None else term(value) for value in row] for row in result]
            record['shared_evaluator'] = {'columns': columns, 'rows': result_rows,
                                          'passes': columns == ['o'] and not result_rows}
        except Exception as exc:
            record['shared_evaluator'] = {'error': repr(exc), 'passes': False}
    finally:
        active_error = sys.exc_info()[0] is not None
        if not active_error:
            record['step'] = 'close'
        try:
            graph.close()
            record['closed'] = True
        except Exception as exc:
            record['close_error'] = repr(exc)
            if not active_error:
                raise
    record['step'] = 'complete'


def run_boundary(args):
    rdflib = runtime_identity(args.runtime_sha256)
    db = OUT / args.profile / 'db'
    loading = args.boundary == 'load'
    require(not db.is_symlink() and loading != db.exists(), 'wrong load/reopen database path')
    record = {'profile': args.profile, 'boundary': args.boundary, 'graph': GRAPH, 'create': loading}
    try:
        observe(rdflib, args.profile, args.boundary, db, record)
    except Exception as exc:
        record['error'] = repr(exc)
    platform_check()
    write(db.parent / (args.boundary + '.json'), record)


def inventory(db):
    if not db.exists():
        return {}
    require(db.is_dir() and not db.is_symlink(), 'invalid LevelDB directory')
    files = {}
    for path in sorted(db.iterdir()):
        require(path.is_file() and not path.is_symlink(), 'unexpected LevelDB file type')
        files[path.name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    return files


def lifecycle(files):
    return {'current': 'CURRENT' in files,
            'manifests': sorted(name for name in files if name.startswith('MANIFEST-')),
            'nonempty_wal': sorted(name for name, meta in files.items()
                                   if re.fullmatch(r'\d+\.log', name) and meta['bytes'] > 0),
            'tables': sorted(name for name in files if name.endswith(('.ldb', '.sst'))),
            'lock_file': 'LOCK' in files, 'info_log': 'LOG' in files}


def run_all(digest):
    platform_check()
    report = {'runtime_sha256': digest, 'full_workload_qualified': False, 'profiles': {}}
    try:
        for profile in PROFILES:
            root = OUT / profile
            root.mkdir()
            phases = report['profiles'][profile] = {}
            for boundary in BOUNDARIES:
                if boundary == 'reopen' and phases['load']['step'] != 'complete':
                    phases[boundary] = {'state': 'skipped-after-load-error'}
                    break
                command = [PYTHON, '-E', '-s', '-B', __file__, '--runtime-sha256', digest,
                           '--profile', profile, '--boundary', boundary]
                with (root / (boundary+'.stdout')).open('xb') as stdout, (root / (boundary+'.stderr')).open('xb') as stderr:
                    result = subprocess.run(command, stdout=stdout, stderr=stderr, check=False)
                require(result.returncode == 0, f'worker did not produce an observation: {profile}/{boundary}')
                record = load(root / (boundary+'.json'))
                files = inventory(root / 'db')
                observed_lifecycle = lifecycle(files)
                info_logs = {}
                for name in ('LOG', 'LOG.old'):
                    if name in files:
                        output = root / f'{boundary}.{name}'
                        require(files[name]['bytes'] < 1 << 20, 'LevelDB info log exceeds expected bound')
                        shutil.copyfile(root / 'db' / name, output)
                        require(sha(output) == files[name]['sha256'], 'LevelDB info log changed')
                        info_logs[name] = output.name
                phases[boundary] = {'step': record['step'], 'exit': result.returncode,
                                    'inventory': files, 'lifecycle': observed_lifecycle,
                                    'info_logs': info_logs}
                if record['step'] == 'complete':
                    require(observed_lifecycle['current'] and observed_lifecycle['manifests'],
                            'complete LevelDB read lacks mandatory lifecycle files')
                    require(record['exact_bag'] is exact_bag(record['triples']), 'typed bag check disagrees')
    finally:
        write(OUT/'OBSERVATIONS.json', report)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--runtime-sha256', required=True)
    parser.add_argument('--profile', choices=PROFILES)
    parser.add_argument('--boundary', choices=BOUNDARIES)
    args = parser.parse_args()
    if args.profile and args.boundary:
        run_boundary(args)
    else:
        require(not args.profile and not args.boundary, 'partial worker arguments')
        run_all(args.runtime_sha256)
