"""Offline image-side setup. No RDF file is opened here."""
import argparse
import os
import subprocess
import sys
import tarfile
from pathlib import Path

from runtime import (IMAGE_PYTHON, LIBRARIES, PINS, PYTHON, RUNTIME, adapter_identity,
                     installed, native_identity, platform_check, require, sha, write)

INPUTS = Path('/inputs')
RECEIPT = RUNTIME / 'RUNTIME.json'
BUILD = RUNTIME / 'build'


def run(*args):
    subprocess.run(args, check=True)


def probe():
    platform_check()
    require(Path(sys.executable) == PYTHON, 'wrong private Python entry point')
    record = {'state': 'native-import', 'rdf_data_opened': False,
              'python_sha256': sha(PYTHON), 'installed': installed()}
    try:
        record['native'] = native_identity()
        record['state'] = 'adapter-import'
        adapter_identity()
        record['state'] = 'ready'
    except Exception as exc:
        record['error'] = repr(exc)
    write(RECEIPT, record)


def setup():
    platform_check()
    require(Path(sys.executable).resolve() == IMAGE_PYTHON.resolve(), 'wrong image interpreter')
    require(str(LIBRARIES) == os.environ['LD_LIBRARY_PATH'], 'wrong loader path')
    for artifact in PINS['archives'] + PINS['wheel_inputs']:
        path = INPUTS / artifact['filename']
        require(path.stat().st_size == artifact['bytes'] and sha(path) == artifact['sha256'],
                f'changed build input {path.name}')
    toolchain = {tool: subprocess.check_output([tool, '--version'], text=True).splitlines()[0]
                 for tool in ('gcc', 'g++', 'dpkg-deb')}
    write(RUNTIME / 'TOOLCHAIN.json', toolchain)

    BUILD.mkdir()
    for artifact in PINS['archives']:
        path = INPUTS / artifact['filename']
        if path.suffix == '.deb':
            require(subprocess.check_output(['dpkg-deb', '-f', path, 'Architecture'],
                                            text=True).strip() == 'arm64', 'wrong Debian architecture')
            run('dpkg-deb', '-x', path, RUNTIME / 'debian')
    run(IMAGE_PYTHON, '-I', '-B', '-m', 'venv', PYTHON.parent.parent)
    pip = [PYTHON, '-I', '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check', '--no-cache-dir']
    run(*pip, 'install', '--no-index', '--no-deps', '--no-compile',
        *(INPUTS / entry['filename'] for entry in PINS['wheel_inputs']))
    for artifact in PINS['archives']:
        path = INPUTS / artifact['filename']
        if path.suffix == '.gz':
            run(*pip, 'wheel', '--no-index', '--no-deps', '--no-build-isolation', '-w', BUILD, path)
    wheels = sorted(BUILD.glob('*.whl'))
    require(len(wheels) == 2, 'wrong number of locally built wheels')
    write(RUNTIME / 'BUILT_WHEELS.json', {path.name: sha(path) for path in wheels})
    run(*pip, 'install', '--no-index', '--no-deps', '--no-compile', *wheels)
    run(*pip, 'check')

    site = PYTHON.parent.parent / 'lib/python3.12/site-packages'
    with tarfile.open(INPUTS / 'rdflib-leveldb-source.tar.gz') as archive:
        for name in ('__init__.py', 'leveldbstore.py'):
            suffix = '/rdflib_leveldb/' + name
            members = [entry for entry in archive.getmembers()
                       if entry.isfile() and entry.name.endswith(suffix)]
            require(len(members) == 1, 'wrong adapter source archive layout')
            source = archive.extractfile(members[0]).read()
            require((site / 'rdflib_leveldb' / name).read_bytes() == source, 'adapter source changed')
    run(PYTHON, '-E', '-s', '-B', Path(__file__), '--probe')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--probe', action='store_true')
    if parser.parse_args().probe:
        probe()
    else:
        setup()
