"""Replay LevelDB fixture evidence using the standard library and retained raw records."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

XSD = 'http://www.w3.org/2001/XMLSchema#'
LANG_STRING = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
PREFIX = '<urn:s> <urn:v> '
SUBJECT = ('uri', 'urn:s', '', '')
PREDICATE = ('uri', 'urn:v', '', '')


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def fixture_object(encoded):
    if encoded.startswith('<') and encoded.endswith('>'):
        return 'uri', encoded[1:-1], '', ''
    lexical, end = json.JSONDecoder().raw_decode(encoded)
    assert isinstance(lexical, str)
    suffix = encoded[end:]
    if suffix.startswith('@'):
        return 'literal', lexical, LANG_STRING, suffix[1:].lower()
    if suffix.startswith('^^<') and suffix.endswith('>'):
        return 'literal', lexical, suffix[3:-1], ''
    assert not suffix
    return 'literal', lexical, XSD + 'string', ''


def typed(term):
    kind = term['type']
    assert kind in ('literal', 'uri')
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype', LANG_STRING if language else XSD + 'string') if kind == 'literal' else ''
    return kind, term['value'], datatype, language


def reference(source):
    expected = Counter()
    for line in (source / 'consumer-fixture.nt').read_text().splitlines():
        assert line.startswith(PREFIX) and line.endswith(' .')
        expected[SUBJECT, PREDICATE, fixture_object(line[len(PREFIX):-2])] += 1
    jena = load(source / 'consumer-fixture-jena.json')['results']['bindings']
    assert len(expected) == sum(expected.values()) == 9
    assert expected == Counter((SUBJECT, PREDICATE, typed(item['o'])) for item in jena)
    return expected


def bag(rows):
    return Counter(tuple(typed(term) for term in row) for row in rows)


def compare(expected, actual):
    return {'exact': expected == actual, 'terms': sum(actual.values()),
            'missing': sorted((expected - actual).items()),
            'extra': sorted((actual - expected).items())}


def check_inventory(folder, stage):
    info_logs = stage['info_logs']
    files = stage['inventory']
    observed = stage['lifecycle']
    assert observed['current'] == ('CURRENT' in files)
    assert observed['manifests'] == sorted(name for name in files if name.startswith('MANIFEST-'))
    assert observed['nonempty_wal'] == sorted(name for name, meta in files.items()
                                             if re.fullmatch(r'[0-9]+\.log', name) and meta['bytes'])
    assert observed['tables'] == sorted(name for name in files if name.endswith(('.sst', '.ldb')))
    assert observed['lock_file'] == ('LOCK' in files)
    assert observed['info_log'] == ('LOG' in files)
    assert set(info_logs) == {'LOG', 'LOG.old'} & set(files)
    for name, path in info_logs.items():
        file = folder / path
        assert digest(file) == files[name]['sha256'] and file.stat().st_size == files[name]['bytes']
    return observed


def frozen_identity(source):
    manifest = source / 'FREEZE.json'
    for name, expected in load(manifest).items():
        assert digest(source / name) == expected, name
    return digest(manifest)


def replay(root):
    failed = root / 'v1-failure'
    failed_src = frozen_identity(failed / 'source')
    failed_setup = load(failed / 'setup/SUPERVISOR.json')
    failed_runtime = failed / 'runtime/RUNTIME.json'
    failed_probe = load(failed_runtime)
    assert failed_setup['source_sha256'] == failed_src
    assert failed_setup['cleanup'] == 'verified-removed'
    assert failed_setup['runtime_sha256'] == digest(failed_runtime)
    assert failed_setup['runtime_state'] == failed_probe['state'] == 'native-import'
    assert failed_probe['rdf_data_opened'] is False and failed_probe['error'].startswith('FileNotFoundError')
    assert not (failed / 'storage').exists()

    source = root / 'source'
    freeze = frozen_identity(source)
    expected = reference(source)
    setup = load(root / 'setup' / 'SUPERVISOR.json')
    assert setup['source_sha256'] == freeze and setup['stage'] == 'setup'
    assert setup['cleanup'] in ('not-created', 'verified-removed')
    output = {'source_sha256': freeze, 'setup_error': setup.get('error'), 'reference_terms': 9,
              'v1_native_identity_error': failed_probe['error']}
    if 'runtime_state' not in setup:
        assert setup.get('error')
        return output
    runtime = root / 'runtime' / 'RUNTIME.json'
    runtime_digest = digest(runtime)
    assert setup['runtime_sha256'] == runtime_digest and setup['rdf_data_opened'] is False
    state = load(runtime)
    assert state['state'] == setup['runtime_state'] and state['rdf_data_opened'] is False
    output.update(runtime_sha256=runtime_digest, runtime_state=state['state'],
                  runtime_error=state.get('error'))
    if state['state'] != 'ready':
        assert state['state'] in ('native-import', 'adapter-import') and state.get('error')
        return output

    supervisor = load(root / 'storage' / 'SUPERVISOR.json')
    assert supervisor['source_sha256'] == freeze and supervisor['stage'] == 'storage'
    assert supervisor['cleanup'] in ('not-created', 'verified-removed')
    output['storage_error'] = supervisor.get('error')
    path = root / 'storage' / 'out'
    observation_path = path / 'OBSERVATIONS.json'
    if not observation_path.exists():
        assert supervisor.get('error')
        return output
    report = load(observation_path)
    assert report['runtime_sha256'] == runtime_digest and report['full_workload_qualified'] is False
    if not supervisor.get('error'):
        assert set(report['profiles']) == {'default', 'preserve'}
    summaries = {}
    for profile, phases in report['profiles'].items():
        assert profile in ('default', 'preserve')
        if not supervisor.get('error'):
            assert set(phases) == {'load', 'reopen'}
        summary = summaries[profile] = {}
        parsed = None
        for boundary in ('load', 'reopen'):
            if boundary not in phases:
                continue
            stage = phases[boundary]
            if stage.get('state') == 'skipped-after-load-error':
                assert boundary == 'reopen' and phases['load']['step'] != 'complete'
                summary[boundary] = {'state': stage['state']}
                continue
            row = load(path / profile / (boundary + '.json'))
            assert row['profile'] == profile and row['boundary'] == boundary
            assert row['create'] is (boundary == 'load')
            assert row['step'] == stage['step'] and stage['exit'] == 0
            result = summary[boundary] = {'step': row['step'], 'error': row.get('error')}
            result['lifecycle'] = check_inventory(path / profile, stage)
            if 'parsed' in row:
                assert boundary == 'load'
                parsed = bag(row['parsed'])
                result['parsed'] = compare(expected, parsed)
                assert row['parsed_exact'] is result['parsed']['exact']
                assert row['parsed_count'] == result['parsed']['terms']
            if row['step'] != 'complete':
                assert row.get('error')
                continue
            assert row['normalize_literals'] is (profile == 'default') and row['closed'] is True
            assert row['open_result'] == 1
            assert parsed is not None
            observed = bag(row['triples'])
            result.update(graph_length=row['count'], count_exact=type(row['count']) is int and row['count'] == 9,
                          to_reference=compare(expected, observed),
                          to_parsed=compare(parsed, observed))
            assert row['exact_bag'] is result['to_reference']['exact']
            probe = row['shared_evaluator']
            assert probe['passes'] is (probe.get('columns') == ['o'] and probe.get('rows') == [])
            result['diagnostic_rows'] = len(probe['rows']) if 'rows' in probe else None
            result['diagnostic_error'] = probe.get('error')
            if boundary == 'reopen':
                folder = path / profile
                database = folder / 'db'
                assert set(stage['inventory']) == {item.name for item in database.iterdir()}
                for name, identity in stage['inventory'].items():
                    file = database / name
                    assert digest(file) == identity['sha256'] and file.stat().st_size == identity['bytes']
                info_log = (folder / stage['info_logs']['LOG']).read_text()
                result['wal_recovery_log_ids'] = [int(index) for index in re.findall(r'Recovering log #([0-9]+)', info_log)]
    output['profiles'] = summaries
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('packet_directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.packet_directory), sort_keys=True, indent=2))
