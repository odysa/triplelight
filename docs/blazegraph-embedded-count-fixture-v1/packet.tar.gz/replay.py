"""Recheck saved Blazegraph observations without running the engine."""

import json
import sys
from pathlib import Path

PACKET = Path(__file__).resolve().parent
sys.path.insert(0, str(PACKET / "controls/source"))
from run_diagnostics import actual_facts, check_queries


def load(path):
    return json.loads(path.read_text())


def require(check, detail):
    if not check:
        raise ValueError(detail)


def phase(root, prefix):
    path = root / prefix
    receipt = load(path / "RECEIPT.json")
    require(receipt["status"] == "complete" and receipt["cleanup"] == "verified-removed"
            and receipt["exit"] == {"attached": 0, "worker": 0, "oom_killed": False, "running": False},
            f"failed process boundary: {prefix}")
    return path, receipt


def observation(root, prefix, inline, inferred, baseline=False):
    load_run, _ = phase(root, prefix + "-load")
    reopen_run, reopen_receipt = phase(root, prefix + "-reopen")
    query_run, query_receipt = phase(root, prefix + "-query")
    require(reopen_receipt["journal_before_sha256"] == load(load_run / "JOURNAL.json")["sha256"],
            "reopen journal identity mismatch")
    require(query_receipt["journal_before_sha256"] == load(reopen_run / "JOURNAL.json")["sha256"],
            "query journal identity mismatch")
    if baseline:
        for run in (load_run, reopen_run):
            require((run / "stdout").read_text().splitlines().count("exact_triples=9") == 1, "baseline count")
        stack = (query_run / "stdout").read_text()
        fast = "FastRangeCountOp.java:376" in stack
    else:
        config = ("21.0.13+9", inline, inferred)
        actual_facts(load_run, "load", config)
        actual_facts(reopen_run, "reopen", config)
        fast = actual_facts(query_run, "query", config)
    answers = check_queries(query_run / "out/answers", inline)
    require(answers["terms.rq"]["bag_matches"] and answers["empty.rq"]["matches"], "term or empty-result failure")
    return {"answers": answers, "fast_range_count_line_376": fast,
            "total_and_explicit_equal_9_in_query_process": None if baseline else True}


def replay():
    baseline = observation(PACKET / "baseline", "smoke", False, False, baseline=True)
    controls = PACKET / "controls"
    all_statements = observation(controls, "no-inline-all-statements", False, True)
    default_inline = observation(controls, "default-inline-explicit", True, False)
    for result in (baseline, default_inline):
        require(result["fast_range_count_line_376"]
                and result["answers"]["count.rq"]["status"] == "query-error", "expected explicit-only stop")
    require(all_statements["answers"]["count.rq"]["matches"] and not all_statements["fast_range_count_line_376"],
            "all-statements COUNT did not match")
    old_java = load(controls / "JDK17_STAGE_AUDIT.json")
    release = load(controls / "LOCK_RELEASE.json")
    require(old_java["no_java17_container"] and release["java17_container_launched"] is False,
            "unexpected Java 17 activity")
    return {"no_inline_explicit_only": baseline, "no_inline_all_statements": all_statements,
            "default_inline_explicit_only": default_inline,
            "java17": {"status": "setup-stop", **old_java}, "scored": False}


if __name__ == "__main__":
    print(json.dumps(replay(), indent=2, sort_keys=True))
