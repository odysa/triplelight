# COUNT fixture execution

Root /private/tmp/rdf-jianlin-blazegraph39-count-diag-v1 must be fresh. The exact owner string is `Jianlin task39 Blazegraph COUNT diagnostics v1`. Check the current infrastructure rules and queue, acquire the lock atomically and announce the fixture window. Use the existing Temurin 21 Linux ARM64 image and the read-only verified Blazegraph jar.

```sh
rtk proxy python3 -E -s -B scratch/blazegraph39-count-diagnostics-v1/run_diagnostics.py --freeze FREEZE_SHA256
```

The wrapper compiles one Java 17-targeted worker under Temurin 21. It runs the two Java 21 profiles, stages the pinned Java 17 archive and then runs the Java 17 profile. The Java 17 binary and JVM library are hashed after verified extraction and checked again after the profile. All run stages use network-none containers, private cgroups, no module-opening or assertion options, separately recorded effective resource limits and exact label-based cleanup. Runtime arguments are checked in each JVM. The worker does not receive Jena answer files.

An exception record for COUNT is an observed engine outcome. The wrapper evaluates all three query records and preserves their observed datatype, projection, bag, exception or mismatch. A zero CLI exit means all three profiles produced evaluable observations. Consult DIAGNOSTICS.json and raw records for the actual answers. A failed setup or phase preserves its receipts and prevents later phases from silently running.

After process exit, verify all exact owned container labels are absent and the owner file still matches before releasing the lock. A container cleanup uncertainty keeps the lock with this run until resolved. No full dataset input is mounted in these diagnostics.
