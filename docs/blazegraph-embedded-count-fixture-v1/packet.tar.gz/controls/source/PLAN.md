# Blazegraph 2.1.5 COUNT fixture diagnostics

Baseline: frozen streaming harness 9ca1a0c9…, runtime 4f0f7e23…. On Linux ARM64 and Temurin 21.0.13+9, the no-XSD-inline store returned nine triples after load and reopen, nine exact SELECT terms, and an empty SELECT with native projection o. COUNT(*) raised QueryEvaluationException with a nested explicit AssertionError at FastRangeCountOp.java:376. The pinned source throws there when the predicate has an index-local filter. This stopped admission before LUBM-100. Preserve the baseline unchanged. [Pinned Blazegraph source](https://github.com/blazegraph/database/blob/cb089919/bigdata-core/bigdata/src/java/com/bigdata/bop/join/FastRangeCountOp.java#L371-L381).

Use the same Maven jar, fixture, three query texts, native serializer, DiskRW, parser normalization off, NoAxioms, truth maintenance off and count API. Use fresh journals and three clean JVMs per profile. Keep load and reopen total counts, native projection, typed SELECT bag, COUNT value/datatype or exception and FILTER(false) evidence individually. Default XSD inlining may change the one known integer lexical form and the default verifier must check against that prospectively defined bag. Retain all partial records and compare them against the baseline. Capture the all-statements total and explicit-only exact count in the same query process after the three requests.

Run in the order below, each with distinct labels and fresh outputs.

| Profile | Java | XSD inlining | Tuple query IncludeInferred | Predicted discriminator |
|---|---|---|---|---|
| no-inline-all-statements | 21.0.13+9 | off | true | Primary hypothesis is that the explicit-only index filter causes the failure. COUNT may now return nine as xsd:integer. With NoAxioms and truth maintenance off, the fixture contains only explicit statements. |
| default-inline-explicit | 21.0.13+9 | engine default | false | A repeated exception would show that disabling inlining is unnecessary for this failure. |
| jdk17-no-inline-explicit | 17.0.21+9 | off | false | A repeated exception would show that Java 21 is unnecessary for this failure. A difference would identify a runtime-dependent observation for these builds, with additional investigation needed to identify cause. |

For Java 17 use the vendor's aarch64 Linux HotSpot archive, 192,336,814 bytes, SHA-256 3e4eca7ead088f080af1476007decf010a240a1eb4e1e78c54fa32fbcc347084. Mount that verified JDK read-only on the same existing Linux ARM64 Temurin 21 image. Compile the diagnostic worker with Java 21 using --release 17 so the same class bytes run across all profiles. Record real runtime release, JVM arguments and binary identities. [Temurin archive release](https://github.com/adoptium/temurin17-binaries/releases/tag/jdk-17.0.21%2B9).

Keep query text identical. Do not patch the jar, add JVM assertion flags or change the store after observing an outcome. Preset 180 seconds each for compile and Java 17 archive staging, and up to 120 seconds per profile, with the existing root resource guards, offline containers, per-record output limits and verified exact cleanup. Ordinary complete query mismatches and query exceptions count as diagnostic observations. Identity, resource or process failures stop their affected stage, and an unmet dependency leaves its later stages pending. Disclose remaining differences when interpreting a control.

The no-inline Java 21 explicit-only profile stays ineligible for LUBM-100. A successful all-statements control can qualify only a separately reviewed profile, with no inference configured and an independent count plus typed answer gates. This diagnostic batch imports no large dataset and collects no scored latency.
