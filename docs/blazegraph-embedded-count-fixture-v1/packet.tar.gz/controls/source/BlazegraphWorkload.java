import com.bigdata.journal.Options;
import com.bigdata.rdf.axioms.NoAxioms;
import com.bigdata.rdf.internal.ILexiconConfiguration;
import com.bigdata.rdf.sail.BigdataSail;
import com.bigdata.rdf.sail.BigdataSailRepository;
import com.bigdata.rdf.sail.BigdataSailRepositoryConnection;
import com.bigdata.rdf.store.AbstractTripleStore;

import org.openrdf.model.BNode;
import org.openrdf.model.Literal;
import org.openrdf.model.Statement;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.query.BindingSet;
import org.openrdf.query.MalformedQueryException;
import org.openrdf.query.QueryEvaluationException;
import org.openrdf.query.QueryLanguage;
import org.openrdf.query.TupleQuery;
import org.openrdf.query.TupleQueryResult;
import org.openrdf.repository.RepositoryException;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFHandlerException;
import org.openrdf.rio.RDFParser;
import org.openrdf.rio.Rio;
import org.openrdf.rio.helpers.BasicParserSettings;
import org.openrdf.rio.helpers.RDFHandlerBase;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;

public final class BlazegraphWorkload {
    private static final long RECORD_LIMIT = 64L << 20;
    private static final long ANSWER_LIMIT = (256L << 20) - (1L << 20);
    private static final int BUFFER_CAPACITY = 10_000;
    private static final boolean DEFAULT_INLINE = Boolean.getBoolean("diagnostic.defaultInline");
    private static final boolean INCLUDE_INFERRED = Boolean.getBoolean("diagnostic.includeInferred");

    private static final class Budget {
        private long remaining = ANSWER_LIMIT;
    }

    private static final class Record implements AutoCloseable {
        private final BufferedOutputStream stream;
        private final Budget budget;
        private long remaining = RECORD_LIMIT;

        Record(Path path, Budget budget) throws IOException {
            stream = new BufferedOutputStream(Files.newOutputStream(path, StandardOpenOption.CREATE_NEW));
            this.budget = budget;
        }

        void line(String... fields) throws IOException {
            byte[] bytes = (String.join("\t", fields) + "\n").getBytes(StandardCharsets.US_ASCII);
            if (bytes.length > remaining || bytes.length > budget.remaining) {
                throw new IOException("answer byte limit");
            }
            stream.write(bytes);
            remaining -= bytes.length;
            budget.remaining -= bytes.length;
        }

        @Override public void close() throws IOException {
            stream.close();
        }
    }

    private static String encode(String text) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    private static String term(Value value) {
        if (value == null) return "unbound";
        if (value instanceof URI) return "iri:" + encode(value.stringValue());
        if (value instanceof BNode) return "bnode:" + encode(value.stringValue());
        if (value instanceof Literal literal) {
            URI datatype = literal.getDatatype();
            String language = literal.getLanguage();
            return "literal:" + encode(literal.getLabel()) + ":"
                + encode(datatype == null ? "" : datatype.stringValue()) + ":"
                + encode(language == null ? "" : language);
        }
        throw new IllegalArgumentException("unexpected value class: " + value.getClass().getName());
    }

    private static Properties settings(Path journal) {
        Properties properties = new Properties();
        properties.setProperty(Options.FILE, journal.toString());
        properties.setProperty(Options.BUFFER_MODE, "DiskRW");
        properties.setProperty(BigdataSail.Options.NAMESPACE, "blazegraph39workload");
        properties.setProperty(BigdataSail.Options.TRUTH_MAINTENANCE, "false");
        properties.setProperty(BigdataSail.Options.BUFFER_CAPACITY, Integer.toString(BUFFER_CAPACITY));
        properties.setProperty(BigdataSail.Options.QUEUE_CAPACITY, "0");
        properties.setProperty(AbstractTripleStore.Options.QUADS, "false");
        properties.setProperty(AbstractTripleStore.Options.STATEMENT_IDENTIFIERS, "false");
        properties.setProperty(AbstractTripleStore.Options.AXIOMS_CLASS, NoAxioms.class.getName());
        properties.setProperty(AbstractTripleStore.Options.TEXT_INDEX, "false");
        if (!DEFAULT_INLINE) {
            properties.setProperty(AbstractTripleStore.Options.INLINE_XSD_DATATYPE_LITERALS, "false");
        }
        return properties;
    }

    private static void load(BigdataSailRepositoryConnection connection, Path source) throws Exception {
        RDFParser parser = Rio.createParser(RDFFormat.NTRIPLES);
        parser.getParserConfig().set(BasicParserSettings.NORMALIZE_DATATYPE_VALUES, false);
        System.out.println("normalize_datatype_values="
            + parser.getParserConfig().get(BasicParserSettings.NORMALIZE_DATATYPE_VALUES));
        parser.setRDFHandler(new RDFHandlerBase() {
            @Override public void handleStatement(Statement statement) throws RDFHandlerException {
                try {
                    connection.add(statement);
                } catch (RepositoryException error) {
                    throw new RDFHandlerException(error);
                }
            }
        });
        connection.setAutoCommit(false);
        try (InputStream input = Files.newInputStream(source)) {
            parser.parse(input, "urn:blazegraph39:");
        }
        System.out.println("parse_returned=true");
        connection.commit();
        System.out.println("commit_returned=true");
    }

    private static void observeSettings(AbstractTripleStore store) {
        ILexiconConfiguration<?> lexicon = store.getLexiconRelation().getLexiconConfiguration();
        Properties properties = store.getProperties();
        String buffer = properties.getProperty(BigdataSail.Options.BUFFER_CAPACITY);
        String queue = properties.getProperty(BigdataSail.Options.QUEUE_CAPACITY);
        System.out.println("inline_xsd=" + lexicon.isInlineLiterals());
        System.out.println("inline_text=" + lexicon.isInlineTextLiterals());
        System.out.println("inline_datetimes=" + lexicon.isInlineDateTimes());
        System.out.println("inline_max_string_length=" + lexicon.getMaxInlineStringLength());
        System.out.println("inline_bnodes=" + properties.getProperty(AbstractTripleStore.Options.INLINE_BNODES,
            AbstractTripleStore.Options.DEFAULT_INLINE_BNODES));
        System.out.println("axioms_class=" + store.getAxioms().getClass().getName());
        System.out.println("buffer_capacity=" + buffer);
        System.out.println("queue_capacity=" + queue);
        if (lexicon.isInlineLiterals() != DEFAULT_INLINE || store.getAxioms().getClass() != NoAxioms.class
                || !"10000".equals(buffer) || !"0".equals(queue)) {
            throw new IllegalStateException("effective store configuration differs from registration");
        }
    }

    private static void select(BigdataSailRepositoryConnection connection, String sparql, Record output)
            throws IOException, RepositoryException, MalformedQueryException, QueryEvaluationException {
        TupleQuery query = connection.prepareTupleQuery(QueryLanguage.SPARQL, sparql);
        query.setIncludeInferred(INCLUDE_INFERRED);
        System.out.println("include_inferred=" + query.getIncludeInferred());
        TupleQueryResult result = query.evaluate();
        long rows = 0;
        try {
            List<String> variables = result.getBindingNames();
            String[] header = new String[variables.size() + 1];
            header[0] = "vars";
            for (int index = 0; index < variables.size(); index++) {
                header[index + 1] = encode(variables.get(index));
            }
            output.line(header);
            while (result.hasNext()) {
                BindingSet row = result.next();
                String[] fields = new String[variables.size() + 1];
                fields[0] = "row";
                for (int index = 0; index < variables.size(); index++) {
                    fields[index + 1] = term(row.getValue(variables.get(index)));
                }
                output.line(fields);
                rows++;
            }
        } catch (IOException | QueryEvaluationException | RuntimeException error) {
            try {
                result.close();
            } catch (QueryEvaluationException closeError) {
                error.addSuppressed(closeError);
            }
            throw error;
        }
        result.close();
        output.line("complete", Long.toString(rows));
    }

    private static void query(BigdataSailRepositoryConnection connection, Path sources, Path output)
            throws IOException {
        List<String> labels = Files.readAllLines(sources.resolve("ORDER.txt"), StandardCharsets.US_ASCII);
        if (labels.isEmpty() || labels.size() > 30 || new HashSet<>(labels).size() != labels.size()) {
            throw new IOException("invalid query order");
        }
        Budget budget = new Budget();
        for (int index = 0; index < labels.size(); index++) {
            String label = labels.get(index);
            if (!label.matches("(lubm/)?[a-z0-9_]+\\.rq")) throw new IOException("bad label");
            String sparql = Files.readString(sources.resolve(label), StandardCharsets.UTF_8);
            Path path = output.resolve(String.format(java.util.Locale.ROOT, "%02d.tsv", index + 1));
            try (Record record = new Record(path, budget)) {
                record.line("label", encode(label));
                try {
                    select(connection, sparql, record);
                } catch (MalformedQueryException | RepositoryException | QueryEvaluationException error) {
                    record.line("query-error", encode(error.getClass().getName()));
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) throw new IllegalArgumentException("stage journal [input] [out]");
        String stage = args[0];
        boolean load = stage.equals("load") && args.length == 3;
        boolean reopen = stage.equals("reopen") && args.length == 2;
        boolean query = stage.equals("query") && args.length == 4;
        if (!(load || reopen || query)) throw new IllegalArgumentException("invalid stage arguments");
        Path journal = Path.of(args[1]);
        if (load ? Files.exists(journal, LinkOption.NOFOLLOW_LINKS)
                : !Files.isRegularFile(journal, LinkOption.NOFOLLOW_LINKS)) {
            throw new IllegalArgumentException("wrong journal lifecycle");
        }
        System.out.println("java_version=" + System.getProperty("java.runtime.version"));
        System.out.println("java_arch=" + System.getProperty("os.arch"));
        for (String argument : java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            System.out.println("java_argument=" + argument);
        }
        BigdataSailRepository repository = new BigdataSailRepository(new BigdataSail(settings(journal)));
        repository.initialize();
        try {
            BigdataSailRepositoryConnection connection = repository.getConnection();
            try {
                AbstractTripleStore store = connection.getTripleStore();
                observeSettings(store);
                if (load) load(connection, Path.of(args[2]));
                if (query) {
                    query(connection, Path.of(args[2]), Path.of(args[3]));
                    System.out.println("total_exact_triples=" + store.getStatementCount(true));
                    System.out.println("explicit_exact_triples=" + store.getExplicitStatementCount(null));
                } else {
                    System.out.println("exact_triples=" + store.getStatementCount(true));
                }
            } finally {
                connection.close();
                System.out.println("connection_closed=true");
            }
        } finally {
            repository.shutDown();
            System.out.println("shutdown_returned=true");
        }
        System.out.println("stage_complete=" + stage);
    }
}
