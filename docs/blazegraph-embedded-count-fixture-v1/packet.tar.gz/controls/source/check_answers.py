"""Replay Blazegraph's native tuple stream against independently frozen answers."""

import base64
import re

RECORD_LIMIT = 64 << 20
ANSWER_LIMIT = (256 << 20) - (1 << 20)
ENCODED = re.compile(r"[A-Za-z0-9_-]*\Z")
POSITIVE = re.compile(r"(?:0|[1-9][0-9]*)\Z")


def decode(value):
    if not ENCODED.fullmatch(value):
        raise ValueError("invalid base64 alphabet")
    with_padding = value + "=" * (-len(value) % 4)
    decoded = base64.b64decode(with_padding, altchars=b"-_", validate=True)
    if base64.urlsafe_b64encode(decoded).decode("ascii").rstrip("=") != value:
        raise ValueError("non-canonical base64")
    return decoded.decode("utf-8")


def rdf_term(token):
    if token == "unbound":
        return None
    parts = token.split(":")
    if len(parts) == 2 and parts[0] in {"iri", "bnode"}:
        value = decode(parts[1])
        if not value:
            raise ValueError("empty IRI or blank-node label")
        return {"type": "uri" if parts[0] == "iri" else "bnode", "value": value}
    if len(parts) != 4 or parts[0] != "literal":
        raise ValueError("unknown RDF term token")
    value, datatype, language = map(decode, parts[1:])
    if language and datatype not in {"", "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString"}:
        raise ValueError("language tag with unrelated datatype")
    term = {"type": "literal", "value": value}
    if language:
        term["xml:lang"] = language
    if datatype:
        term["datatype"] = datatype
    return term


def fields(raw):
    if not raw.endswith(b"\n") or b"\r" in raw:
        raise ValueError("unterminated or malformed TSV")
    return raw[:-1].decode("ascii").split("\t")


def read_answer(path, label):
    if path.is_symlink() or path.stat().st_size > RECORD_LIMIT:
        raise ValueError("result path or byte cap")
    with path.open("rb") as source:
        if fields(source.readline()) != ["label", encoded_label(label)]:
            raise ValueError("query label drift")
        variables = None
        bindings = []
        for raw in source:
            kind, *values = fields(raw)
            if kind == "vars" and variables is None:
                variables = list(map(decode, values))
                if not variables or not all(variables) or len(variables) != len(set(variables)):
                    raise ValueError("invalid native projection")
            elif kind == "row" and variables is not None and len(values) == len(variables):
                terms = [rdf_term(value) for value in values]
                bindings.append({key: value for key, value in zip(variables, terms) if value is not None})
            elif kind == "query-error" and len(values) == 1:
                name = decode(values[0])
                if not name or source.read(1):
                    raise ValueError("malformed terminal query error")
                return {"status": "query-error", "class": name, "partial_rows": len(bindings)}
            elif kind == "complete" and variables is not None and len(values) == 1:
                if not POSITIVE.fullmatch(values[0]) or int(values[0]) != len(bindings) or source.read(1):
                    raise ValueError("wrong final row count or trailing data")
                return {
                    "status": "complete",
                    "answer": {"head": {"vars": variables}, "results": {"bindings": bindings}},
                }
            else:
                raise ValueError("unexpected TSV record")
    raise ValueError("missing terminal record")


def encoded_label(label):
    return base64.urlsafe_b64encode(label.encode("ascii")).decode("ascii").rstrip("=")

