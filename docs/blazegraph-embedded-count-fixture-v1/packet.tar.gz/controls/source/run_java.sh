#!/bin/sh
set -eu
test "$(cat /guard/owner)" = 'Jianlin task39 Blazegraph COUNT diagnostics v1'
test "$(uname -m)" = aarch64
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS CLASSPATH
mkdir -p /out/metrics
grep '^MemTotal:' /proc/meminfo > /out/metrics/memtotal
for name in memory.max memory.swap.max cpu.max memory.events; do
    cat "/sys/fs/cgroup/$name" > "/out/metrics/before.$name"
done
if [ "$1" = compile ]; then
    java -version
    javac -version
    rc=0
    javac --release 17 -encoding UTF-8 -J-Xmx512m -J-XX:ActiveProcessorCount=4 -cp /engine.jar \
        -d /runtime /BlazegraphWorkload.java || rc=$?
else
    profile=$1
    shift
    java_bin=java
    default_inline=false
    include_inferred=false
    case "$profile" in
        no-inline-all-statements) include_inferred=true ;;
        default-inline-explicit) default_inline=true ;;
        jdk17-no-inline-explicit) java_bin=/jdk17/bin/java ;;
        *) exit 77 ;;
    esac
    rc=0
    "$java_bin" -Xmx8g -XX:ActiveProcessorCount=4 -Djava.io.tmpdir=/tmp \
        "-Ddiagnostic.defaultInline=$default_inline" "-Ddiagnostic.includeInferred=$include_inferred" \
        -cp /runtime:/engine.jar BlazegraphWorkload "$@" || rc=$?
fi
for name in memory.events memory.peak memory.current; do
    cat "/sys/fs/cgroup/$name" > "/out/metrics/after.$name"
done
test "$(cat /guard/owner)" = 'Jianlin task39 Blazegraph COUNT diagnostics v1'
exit "$rc"
