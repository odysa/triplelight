"""Three predeclared fixture-only COUNT diagnostics."""

import argparse
import json
import shutil
import signal
import subprocess
import tarfile
import time
from collections import Counter
from pathlib import Path

from check_answers import read_answer
from run_qualification import (
    GIB, ROOT, SOURCE, class_hashes, compile_worker, digest, guard, image_id,
    load_json, phase, preflight, require, resource_sample, sizes, validate_runtime, write_json,
)

PROFILES = {
    "no-inline-all-statements": ("21.0.13+9", False, True),
    "default-inline-explicit": ("21.0.13+9", True, False),
    "jdk17-no-inline-explicit": ("17.0.21+9", False, False),
}


def stage_jdk():
    pins = load_json(SOURCE / "JDK17.json")
    deadline = time.monotonic() + 180
    archive = ROOT / "temurin17.tar.gz"
    subprocess.run(
        ["curl", "--disable", "--fail", "--silent", "--show-error", "--location",
         "--proto", "=https", "--proto-redir", "=https", "--max-time", "145",
         "--max-filesize", str(pins["bytes"]), "--output", str(archive), pins["url"]],
        check=True, timeout=150,
    )
    require(archive.stat().st_size == pins["bytes"] and digest(archive, deadline) == pins["sha256"],
            "wrong vendor JDK17 archive")
    target = ROOT / "jdk17"
    target.mkdir()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            guard(resource_sample(), deadline)
            bundle.extract(member, target, filter="data", set_attrs=True)
    paths = list(target.iterdir())
    require(len(paths) == 1 and paths[0].is_dir() and not paths[0].is_symlink(), "JDK root layout")
    jdk = paths[0]
    require('JAVA_VERSION="17.0.21"' in (jdk / "release").read_text(), "JDK release identity")
    digests = {str(path.relative_to(jdk)): digest(path, deadline)
               for path in (jdk / "release", jdk / "bin/java", jdk / "lib/server/libjvm.so")}
    write_json(ROOT / "JDK17_RECEIPT.json", {"archive_sha256": pins["sha256"], "files": digests})
    return jdk


def actual_facts(run, stage, configuration):
    jdk, inline, inferred = configuration
    lines = (run / "stdout").read_text().splitlines()
    require(sum(line in {f"java_version={jdk}", f"java_version={jdk}-LTS"} for line in lines) == 1,
            "observed Java version drift")
    arguments = [line.removeprefix("java_argument=") for line in lines if line.startswith("java_argument=")]
    require(arguments == [
        "-Xmx8g", "-XX:ActiveProcessorCount=4", "-Djava.io.tmpdir=/tmp",
        f"-Ddiagnostic.defaultInline={str(inline).lower()}",
        f"-Ddiagnostic.includeInferred={str(inferred).lower()}",
    ], "observed JVM arguments changed")
    expected = {
        "java_arch=aarch64": 1,
        f"inline_xsd={str(inline).lower()}": 1,
        "axioms_class=com.bigdata.rdf.axioms.NoAxioms": 1,
        "buffer_capacity=10000": 1,
        "queue_capacity=0": 1,
        "connection_closed=true": 1,
        "shutdown_returned=true": 1,
        f"stage_complete={stage}": 1,
    }
    if stage == "load":
        expected.update({"normalize_datatype_values=false": 1, "parse_returned=true": 1, "commit_returned=true": 1})
    if stage == "query":
        expected.update({
            f"include_inferred={str(inferred).lower()}": 3,
            "total_exact_triples=9": 1,
            "explicit_exact_triples=9": 1,
        })
    else:
        expected["exact_triples=9"] = 1
    require(all(lines.count(fact) == count for fact, count in expected.items()), f"invalid {stage} receipt")
    return any("FastRangeCountOp.java:376" in line and "determineRangeCount" in line for line in lines)


def canonical(term):
    value = dict(term)
    if value.get("datatype") in {
        "http://www.w3.org/2001/XMLSchema#string", "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString",
    }:
        del value["datatype"]
    return tuple(sorted(value.items()))


def check_queries(path, default_inline):
    expected = load_json(SOURCE / "smoke/jena.json")["results"]["bindings"]
    terms_reference = [dict(row["o"]) for row in expected]
    if default_inline:
        for term in terms_reference:
            if term.get("datatype") == "http://www.w3.org/2001/XMLSchema#int" and term["value"] == "01":
                term["value"] = "1"
    result = {}
    for index, label in enumerate(("terms.rq", "count.rq", "empty.rq"), 1):
        record = read_answer(path / f"{index:02d}.tsv", label)
        if record["status"] != "complete":
            result[label] = record
            continue
        answer = record["answer"]
        projection = answer["head"]["vars"]
        rows = answer["results"]["bindings"]
        if label == "terms.rq":
            matched = projection == ["o"] and Counter(canonical(row["o"]) for row in rows) == Counter(
                map(canonical, terms_reference)
            )
            result[label] = {"status": "complete", "projection": projection, "rows": len(rows), "bag_matches": matched}
        elif label == "empty.rq":
            result[label] = {"status": "complete", "projection": projection, "rows": len(rows),
                             "matches": projection == ["o"] and not rows}
        else:
            wanted = {"type": "literal", "value": "9", "datatype": "http://www.w3.org/2001/XMLSchema#integer"}
            result[label] = {"status": "complete", "projection": projection, "rows": rows,
                             "matches": projection == ["count_result"] and rows == [{"count_result": wanted}]}
    return result


def run_profile(name, config, runtime, image, jdk):
    deadline = time.monotonic() + 120
    directory = ROOT / (name + "-db")
    directory.mkdir()
    journal = directory / "store.jnl"
    workfile = "/db/store.jnl"
    load = phase(name + "-load", [name, "load", workfile, "/input.nt"], deadline,
                 runtime, image, directory, data=SOURCE / "smoke/fixture.nt", jdk=jdk)
    actual_facts(load, "load", config)
    loaded = {"sha256": digest(journal, deadline), **sizes(journal)}
    write_json(load / "JOURNAL.json", loaded)
    reopen = phase(name + "-reopen", [name, "reopen", workfile], deadline, runtime, image,
                   directory, journal_sha=loaded["sha256"], jdk=jdk)
    actual_facts(reopen, "reopen", config)
    reopened = {"sha256": digest(journal, deadline), **sizes(journal)}
    write_json(reopen / "JOURNAL.json", reopened)
    query = phase(name + "-query", [name, "query", workfile, "/queries", "/out/answers"], deadline,
                  runtime, image, directory, journal_sha=reopened["sha256"],
                  query_source=SOURCE / "smoke/queries", jdk=jdk)
    fast_range_exception = actual_facts(query, "query", config)
    answers = check_queries(query / "out/answers", config[1])
    guard(resource_sample(), deadline)
    return {"status": "observed", "load_count": 9, "reopen_count": 9, "query_total_count": 9,
            "query_explicit_count": 9, "fast_range_count_line_376": fast_range_exception, "answers": answers}


def run(freeze):
    preflight(freeze)
    require(shutil.disk_usage(ROOT.parent).free >= 64 * GIB, "64 GiB launch floor")
    ROOT.mkdir()
    image = image_id()
    runtime = ROOT / "classes"
    results = {name: {"status": "not-run"} for name in PROFILES}
    report = {"freeze": freeze, "profiles": results, "scored": False}
    try:
        runtime_sha = digest(compile_worker(runtime, freeze, image))
        report["runtime"] = runtime_sha
        require(all((runtime / name).read_bytes()[6:8] == b"\x00\x3d" for name in class_hashes(runtime)),
                "worker compilation target must be Java 17 (class major 61)")
        for profile, config in PROFILES.items():
            try:
                preflight(freeze)
                validate_runtime(runtime, freeze, image, runtime_sha)
                jdk = stage_jdk() if profile == "jdk17-no-inline-explicit" else None
                results[profile] = run_profile(profile, config, runtime, image, jdk)
                validate_runtime(runtime, freeze, image, runtime_sha)
                if jdk is not None:
                    manifest = load_json(ROOT / "JDK17_RECEIPT.json")
                    require(all(digest(jdk / name) == sha for name, sha in manifest["files"].items()),
                            "mounted JDK changed")
            except (OSError, RuntimeError, ValueError, subprocess.SubprocessError, tarfile.TarError) as error:
                results[profile] = {"status": "failed", "error": repr(error)}
                break
        preflight(freeze)
    except BaseException as error:
        report["error"] = repr(error)
    finally:
        write_json(ROOT / "DIAGNOSTICS.json", report)
    print(json.dumps(report))
    return 0 if all(row["status"] == "observed" for row in results.values()) and "error" not in report else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", required=True)
    args = parser.parse_args()

    def cancel(sig, _frame):
        raise RuntimeError(f"interrupted by signal {sig}")

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, cancel)
    raise SystemExit(run(args.freeze))
