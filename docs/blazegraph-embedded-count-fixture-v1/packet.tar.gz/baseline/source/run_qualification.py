"""Bounded compile and route smoke for the Blazegraph workload worker."""

import argparse
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from collections import Counter
from pathlib import Path

from check_answers import read_answer

SOURCE = Path(__file__).resolve().parent
ROOT = Path("/private/tmp/rdf-jianlin-blazegraph39-workload-v1")
JAR = Path("/private/tmp/rdf-jianlin-blazegraph39-v1/artifact/blazegraph.jar")
JAR_SHA = "8f38b1dae5ad92b0c786b92d1f260a18a4ca64151b62c8d5017dd59b743e131e"
IMAGE = "eclipse-temurin@sha256:432e54724c3e57d1846aeb886f4d339f3b0522931c4e64119c2797013b7cfc3c"
OWNER = "Jianlin task39 Blazegraph LUBM v1"
PREFIX = "rdf-jianlin-blazegraph39-lubm-v1"
LABEL = "org.triplelight.jianlin.qualification"
OWNER_FILE = Path("/private/tmp/rdf-bench.lock/owner")
TMPFS = "rw,noexec,nosuid,size=64m"
GIB = 1 << 30


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def digest(path, deadline=None):
    require(path.is_file() and not path.is_symlink(), f"not a regular file: {path}")
    result = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1 << 20):
            if deadline is not None:
                require(time.monotonic() < deadline, "hash deadline")
            result.update(chunk)
    return result.hexdigest()


def write_json(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def load_json(path):
    return json.loads(path.read_text())


def owned_lock():
    require(OWNER_FILE.read_text().strip() == OWNER, "exact own lock required")


def preflight(freeze):
    owned_lock()
    manifest = SOURCE / "FREEZE.json"
    require(digest(manifest) == freeze, "freeze digest mismatch")
    files = load_json(manifest)["files"]
    present = {str(path.relative_to(SOURCE)) for path in SOURCE.rglob("*") if path.is_file()}
    require(present == set(files) | {"FREEZE.json"}, "unexpected or missing harness file")
    for name, expected in files.items():
        require(digest(SOURCE / name) == expected, f"changed harness file: {name}")
    require(digest(JAR) == JAR_SHA, "wrong retained Maven jar")


def docker(*args):
    return subprocess.run(
        ["docker", *args], check=True, capture_output=True, text=True, timeout=20,
    ).stdout


def inspect_container(identifier):
    return json.loads(docker("container", "inspect", identifier))[0]


def container_exists(name):
    return name in docker("ps", "-a", "--format", "{{.Names}}").splitlines()


def image_id():
    info = json.loads(docker("image", "inspect", IMAGE))[0]
    require((info["Os"], info["Architecture"]) == ("linux", "arm64"), "wrong image platform")
    return info["Id"]


def sizes(path):
    stat = path.stat()
    return {"apparent": stat.st_size, "allocated": stat.st_blocks * 512}


def resource_sample():
    owned_lock()
    allocated = sum(path.stat().st_blocks * 512 for path in ROOT.rglob("*"))
    return {"free": shutil.disk_usage(ROOT).free, "allocated": allocated}


def guard(resource, deadline):
    require(time.monotonic() < deadline, "phase deadline")
    require(resource["allocated"] < 15 * GIB, "sampled allocation guard")
    require(resource["free"] >= 42 * GIB, "sampled free-space guard")


def binding(info, wanted_image, mounts, command):
    host = info["HostConfig"]
    actual = {m["Destination"]: (str(Path(m["Source"]).resolve()), m["RW"]) for m in info["Mounts"]}
    expected = {dest: (str(path.resolve()), rw) for dest, (path, rw) in mounts.items()}
    require(
        info["Image"] == wanted_image and info["Platform"] == "linux"
        and host["NanoCpus"] == 4_000_000_000
        and host["Memory"] == host["MemorySwap"] == 12 * GIB
        and host["ReadonlyRootfs"] and host["NetworkMode"] == "none"
        and host["CgroupnsMode"] == "private"
        and host["Tmpfs"].get("/tmp") == TMPFS
        and host["LogConfig"]["Type"] == "none"
        and any(limit == {"Name": "core", "Hard": 0, "Soft": 0} for limit in host["Ulimits"])
        and info["Config"]["Labels"].get(LABEL) == PREFIX
        and info["Config"]["Cmd"] == command and actual == expected,
        "container binding mismatch",
    )
    return {
        "image_id": wanted_image, "mounts": actual, "command": command,
        "cpus": 4, "memory": 12 * GIB, "memory_plus_swap": 12 * GIB,
        "network": "none", "read_only": True, "cgroupns": "private", "tmpfs": TMPFS,
    }


def cleanup(name, may_exist, attached):
    if may_exist and container_exists(name):
        info = inspect_container(name)
        require(info["Config"]["Labels"].get(LABEL) == PREFIX, "foreign container owner")
        identifier = info["Id"]
        if info["State"]["Running"]:
            docker("stop", "--time", "3", identifier)
        docker("rm", identifier)
    if attached is not None:
        try:
            attached.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(attached.pid, signal.SIGKILL)
            attached.wait(timeout=8)
    require(not may_exist or not container_exists(name), "owned container remains")
    return "verified-removed" if may_exist else "not-created"


def metric_pair(path):
    return dict((key, int(value)) for key, value in (line.split() for line in path.read_text().splitlines()))


def resources(path):
    metrics = path / "metrics"
    before = metric_pair(metrics / "before.memory.events")
    after = metric_pair(metrics / "after.memory.events")
    cpu_quota, cpu_period = map(int, (metrics / "before.cpu.max").read_text().split())
    memory = int((metrics / "before.memory.max").read_text())
    swap = int((metrics / "before.memory.swap.max").read_text())
    peak = int((metrics / "after.memory.peak").read_text())
    require(cpu_quota == 4 * cpu_period and memory == 12 * GIB and swap == 0, "cgroup limit drift")
    require(after["oom_kill"] == before["oom_kill"] and after["oom"] == before["oom"], "cgroup OOM")
    return {"events_before": before, "events_after": after, "peak_bytes": peak}


def phase(name, stage_args, deadline, runtime, image, journal_dir=None, journal_sha=None,
          data=None, query_source=None):
    owned_lock()
    run = ROOT / name
    run.mkdir()
    output = run / "out"
    output.mkdir()
    (output / "answers").mkdir()
    container = PREFIX + "-" + name
    mounts = {"/run_java.sh": (SOURCE / "run_java.sh", False), "/guard": (OWNER_FILE.parent, False),
              "/runtime": (runtime, name == "compile"),
              "/engine.jar": (JAR, False), "/out": (output, True)}
    if name == "compile":
        mounts["/BlazegraphWorkload.java"] = (SOURCE / "BlazegraphWorkload.java", False)
    if journal_dir is not None:
        mounts["/db"] = (journal_dir, True)
    if data is not None:
        mounts["/input.nt"] = (data, False)
    if query_source is not None:
        mounts["/queries"] = (query_source, False)
    command = ["/bin/sh", "/run_java.sh", *stage_args]
    options = [
        "create", "--pull=never", "--name", container, "--platform", "linux/arm64",
        "--label", f"{LABEL}={PREFIX}", "--cpus=4", "--memory=12g", "--memory-swap=12g",
        "--network=none", "--cgroupns=private", "--read-only", "--tmpfs", "/tmp:" + TMPFS,
        "--workdir", "/tmp", "--log-driver", "none", "--ulimit", "core=0:0",
    ]
    for dest, (path, rw) in mounts.items():
        spec = f"type=bind,src={path},dst={dest}" + ("" if rw else ",readonly")
        options += ["--mount", spec]
    receipt = {"stage": name, "status": "failed", "cleanup": "not-created"}
    attached = None
    may_exist = False
    try:
        guard(resource_sample(), deadline)
        require(not container_exists(container), "container name already in use")
        may_exist = True
        identifier = docker(*options, IMAGE, *command).strip()
        receipt["container_id"] = identifier
        receipt["binding"] = binding(inspect_container(identifier), image, mounts, command)
        if journal_sha is not None:
            require(digest(journal_dir / "store.jnl", deadline) == journal_sha, "journal identity drift")
            receipt["journal_before_sha256"] = journal_sha
        guard(resource_sample(), deadline)
        with (run / "stdout").open("xb") as stdout, (run / "stderr").open("xb") as stderr, (
            run / "samples.jsonl"
        ).open("x", buffering=1) as samples:
            attached = subprocess.Popen(
                ["docker", "start", "-a", identifier], stdout=stdout, stderr=stderr, start_new_session=True,
            )
            while True:
                sample = {**resource_sample(), "monotonic_seconds": time.monotonic()}
                samples.write(json.dumps(sample) + "\n")
                guard(sample, deadline)
                require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size < 8 << 20,
                        "diagnostic output cap")
                if attached.poll() is not None:
                    break
                time.sleep(1)
        state = inspect_container(identifier)["State"]
        receipt["exit"] = {"attached": attached.returncode, "worker": state["ExitCode"],
                           "oom_killed": state["OOMKilled"], "running": state["Running"]}
        require(attached.returncode == state["ExitCode"] == 0 and not state["Running"]
                and not state["OOMKilled"], "worker exit or OOM")
        receipt["resources"] = resources(output)
        receipt["status"] = "complete"
    except BaseException as error:
        receipt["error"] = repr(error)
    finally:
        handlers = {sig: signal.signal(sig, signal.SIG_IGN) for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)}
        try:
            if may_exist:
                receipt["cleanup"] = "unverified"
            receipt["cleanup"] = cleanup(container, may_exist, attached)
            require(receipt["cleanup"] == "verified-removed", "no owned completed container")
            guard(resource_sample(), deadline)
        except BaseException as error:
            receipt["status"] = "failed"
            receipt["postflight_error"] = repr(error)
        finally:
            write_json(run / "RECEIPT.json", receipt)
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    require(receipt["status"] == "complete", f"phase failed: {name}")
    return run


def class_hashes(runtime):
    paths = sorted(runtime.iterdir())
    require(all(path.suffix == ".class" for path in paths), "unexpected runtime artifact")
    return {path.name: digest(path) for path in paths}


def compile_worker(runtime, freeze, image):
    runtime.mkdir()
    run = phase("compile", ["compile"], time.monotonic() + 180, runtime, image)
    version = (run / "stderr").read_text() + (run / "stdout").read_text()
    require("21.0.13+9" in version and "javac 21.0.13" in version, "wrong Java runtime or compiler")
    classes = class_hashes(runtime)
    require("BlazegraphWorkload.class" in classes, "missing compiled worker")
    preflight(freeze)
    path = ROOT / "RUNTIME.json"
    write_json(path, {"freeze": freeze, "image": IMAGE, "image_id": image, "jar": JAR_SHA,
                      "classes": classes, "version": version, "rdf_data_opened": False})
    return path


def validate_runtime(runtime, freeze, image, runtime_sha):
    receipt = ROOT / "RUNTIME.json"
    require(digest(receipt) == runtime_sha, "runtime receipt drift")
    expected = load_json(receipt)
    require(expected["classes"] == class_hashes(runtime) and expected["freeze"] == freeze
            and expected["image_id"] == image and expected["jar"] == JAR_SHA, "runtime identity drift")


def smoke_answers(directory):
    integer = "http://www.w3.org/2001/XMLSchema#integer"
    reference = load_json(SOURCE / "smoke/jena.json")["results"]["bindings"]
    expected = {
        "terms.rq": (["o"], [{"o": row["o"]} for row in reference]),
        "count.rq": (["count_result"], [{"count_result": {"type": "literal", "value": "9", "datatype": integer}}]),
        "empty.rq": (["o"], []),
    }

    def bag(rows):
        return Counter(json.dumps(row, sort_keys=True) for row in rows)

    for index, (label, (projection, rows)) in enumerate(expected.items(), 1):
        record = read_answer(directory / f"{index:02d}.tsv", label)
        require(record["status"] == "complete", f"incomplete smoke response: {label}")
        answer = record["answer"]
        require(answer["head"]["vars"] == projection, f"wrong smoke projection: {label}")
        if label == "terms.rq":
            normalized = []
            for row in answer["results"]["bindings"]:
                term = dict(row["o"])
                if term.get("datatype") in (
                    "http://www.w3.org/2001/XMLSchema#string",
                    "http://www.w3.org/1999/02/22-rdf-syntax-ns#langString",
                ):
                    del term["datatype"]
                normalized.append({"o": term})
            actual = normalized
        else:
            actual = answer["results"]["bindings"]
        require(bag(actual) == bag(rows), f"wrong smoke terms or count: {label}")


def gate_output(run, stage, expected_count=None):
    facts = (run / "stdout").read_text().splitlines()
    required = [
        "java_version=21.0.13+9-LTS", "java_arch=aarch64", "inline_xsd=false",
        "connection_closed=true", "shutdown_returned=true", f"stage_complete={stage}",
    ]
    if stage == "load":
        required += ["normalize_datatype_values=false", "parse_returned=true", "commit_returned=true"]
    if expected_count is not None:
        required += [f"exact_triples={expected_count}"]
    require(all(facts.count(fact) == 1 for fact in required), f"native {stage} receipt mismatch")


def smoke(runtime, freeze, image, runtime_sha):
    deadline = time.monotonic() + 120
    validate_runtime(runtime, freeze, image, runtime_sha)
    directory = ROOT / "smoke-db"
    directory.mkdir()
    journal = directory / "store.jnl"
    workfile = "/db/store.jnl"
    load = phase("smoke-load", ["load", workfile, "/input.nt"], deadline, runtime, image, directory,
                 data=SOURCE / "smoke/fixture.nt")
    gate_output(load, "load", 9)
    loaded = {"sha256": digest(journal, deadline), **sizes(journal)}
    write_json(load / "JOURNAL.json", loaded)
    reopen = phase("smoke-reopen", ["reopen", workfile], deadline, runtime, image, directory,
                   journal_sha=loaded["sha256"])
    gate_output(reopen, "reopen", 9)
    reopened = {"sha256": digest(journal, deadline), **sizes(journal)}
    write_json(reopen / "JOURNAL.json", reopened)
    query = phase(
        "smoke-query", ["query", workfile, "/queries", "/out/answers"],
        deadline, runtime, image, directory, journal_sha=reopened["sha256"],
        query_source=SOURCE / "smoke/queries",
    )
    gate_output(query, "query")
    smoke_answers(query / "out/answers")
    validate_runtime(runtime, freeze, image, runtime_sha)
    preflight(freeze)
    guard(resource_sample(), deadline)
    write_json(ROOT / "SMOKE.json", {
        "status": "pass", "freeze": freeze, "runtime": runtime_sha,
        "load_count": 9, "reopen_count": 9, "loaded": loaded, "reopened": reopened,
        "checks": ["typed SELECT", "xsd:integer COUNT", "FILTER(false)"],
    })


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["compile", "smoke"])
    parser.add_argument("--freeze", required=True)
    parser.add_argument("--runtime")
    args = parser.parse_args()

    def cancel(signum, _frame):
        raise RuntimeError(f"interrupted by signal {signum}")

    for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, cancel)
    preflight(args.freeze)
    require(shutil.disk_usage(ROOT.parent).free >= 64 * GIB, "64 GiB launch floor")
    image = image_id()
    runtime = ROOT / "classes"
    if args.stage == "compile":
        ROOT.mkdir()
        receipt = compile_worker(runtime, args.freeze, image)
        print(digest(receipt))
    else:
        require(args.runtime, "runtime digest is required")
        smoke(runtime, args.freeze, image, args.runtime)
        print(digest(ROOT / "SMOKE.json"))


if __name__ == "__main__":
    main()
