"""Check one persisted DuckDB layout against frozen Jena answers, without timing."""
import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

VALUE_SHA = "70ad4ab0cc3299c20a8177c64568d0698bbe8eed3b391d122214d94ebf1f0f6a"
ARMS = ("single", "always-spo", "longest-constant-prefix")
EXPECTED_CASES = {"bi10m": 60, "lubm": 30, "watdiv": 42}


def read_bytes(path, digest):
    data = path.read_bytes()
    if sha256(data).hexdigest() != digest:
        raise ValueError(f"input hash differs for {path}")
    return data


def read_json(path, digest):
    return json.loads(read_bytes(path, digest))


def put(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, sort_keys=True)
        stream.write("\n")


def exact_bag(actual, reference, exact_term):
    columns = reference["head"]["vars"]
    got = actual["head"]["vars"]
    if len(got) != len(set(got)) or set(columns) != set(got):
        return False

    def rows(body):
        bindings = body["results"]["bindings"]
        if any(not set(row) <= set(columns) for row in bindings):
            raise ValueError("undeclared binding")
        return Counter(tuple(exact_term(row.get(name)) for name in columns) for row in bindings)

    return rows(actual) == rows(reference)


class Workload:
    def __init__(self, registry, binding, binding_sha, dataset):
        self.dataset = dataset
        self.registry = registry
        self.binding = read_json(binding, binding_sha)
        self.items = self.binding["queries"][dataset]
        if self.binding["sql_executed"] or len(self.items) != EXPECTED_CASES[dataset]:
            raise ValueError("query binding scope differs")
        sys.path.insert(0, str(registry / "validator-source"))
        if dataset == "bi10m":
            from envelope_qualify import FrozenInputs
            from http_measure_value import check_policy

            digest = self.binding["bi_manifest_sha256"]
            manifest = read_json(registry / "workloads/bi10m/manifest.json", digest)
            policy = check_policy(registry / "policies/value-policy-freeze.json", VALUE_SHA, digest)
            if self.binding["bi_reference_files"] != policy["reference_files"]:
                raise ValueError("BI reference binding differs from policy")
            self.requests = {item["file"]: item for item in manifest["queries"]}
            if list(self.requests) != list(self.items):
                raise ValueError("BI request sequence differs")
            self.numeric = FrozenInputs(registry / "policies/numeric", policy["numeric_freeze_sha256"],
                                        manifest["source_data_sha256"], digest)
            self.references = registry / "references/bi10m"
        else:
            self.references = registry / "references/agg72"

    def prepared(self, name, arm):
        item = self.items[name]
        if self.dataset == "bi10m":
            from fixture_check import duck_result

            request = self.requests[name]
            if (item["query_sha256"], item["template"], item["warmup"]) != (
                    request["sha256"], request["template"], request["warmup"]):
                raise ValueError("BI request identity differs")
            query = self.registry / "workloads/bi10m/queries" / name
            read_bytes(query, item["query_sha256"])

            def convert(rows):
                return duck_result(request["template"], rows)
        else:
            from aggregate_sql import translate

            query = self.registry / "workloads/agg72" / name
            translation = translate(read_bytes(query, item["query_sha256"]).decode("utf-8"))
            if translation.sql != item["arms"]["single"]["sql"]:
                raise ValueError("single-table SQL differs from the frozen translator")
            convert = translation.result_json

        sql = item["arms"][arm]
        if sha256(sql["sql"].encode()).hexdigest() != sql["sql_sha256"]:
            raise ValueError("SQL hash differs")
        reference = read_json(self.references / item["reference"], item["reference_sha256"])
        return sql["sql"], convert, reference

    def check(self, name, actual, reference):
        from qualify import exact_term

        exact = exact_bag(actual, reference, exact_term)
        if self.dataset != "bi10m":
            from aggregate_count_policy import compare
            return {"exact_typed_bag": exact, **compare(actual, reference, self.items[name]["columns"])}

        from http_measure import verify
        from value_diagnostic import diagnose

        request = self.requests[name]
        number = request["template"]
        diagnostic = None
        if number == 7:
            key = f"{Path(name).stem}-diagnostic.json"
            diagnostic = read_json(self.references / key, self.binding["bi_reference_files"][key])
        result = {"exact_typed_bag": exact}
        try:
            result["primary"] = {"status": "pass", **verify(
                number, actual, reference, diagnostic, self.numeric, request)}
        except (ValueError, KeyError, OverflowError) as error:
            result["primary"] = {"status": "fail", "error": str(error)}
        try:
            if number == 7:
                outcome = verify(number, actual, reference, diagnostic, self.numeric, request)
                outcome["order"] = {"status": "pass", **outcome["order"]}
            else:
                inputs = self.numeric.for_instance(request) if number in (4, 5, 6) else None
                outcome = diagnose(number, actual, reference, inputs)
            result["value"] = {"status": "pass" if outcome["order"]["status"] == "pass" else "order_failure",
                               **outcome}
        except (ValueError, KeyError, OverflowError) as error:
            result["value"] = {"status": "fail", "error": str(error)}
        return result

    def admitted(self, record):
        if self.dataset == "bi10m":
            return record.get("value", {}).get("status") == "pass"
        return record.get("count_compatible_pass", False)


def run(args):
    import duckdb

    if duckdb.__version__ != args.duckdb_version:
        raise ValueError("DuckDB runtime version differs")
    workload = Workload(args.registry, args.binding, args.binding_sha256, args.dataset)
    files = list(workload.items)
    prepared = {name: workload.prepared(name, args.arm) for name in files}
    args.output.mkdir()
    spill = args.output / "spill"
    spill.mkdir()
    report = {"dataset": args.dataset, "arm": args.arm, "complete": False, "scored": False,
              "eligible": False, "scheduled": files}
    put(args.output / "SCHEDULE.json", report)
    records = []
    try:
        with duckdb.connect(str(args.database), read_only=True) as connection, (
                args.output / "queries.jsonl").open("x", encoding="utf-8") as journal:
            connection.execute("SET threads=?", [args.threads])
            connection.execute("SET memory_limit=?", [args.memory_limit])
            connection.execute("SET temp_directory=?", [str(spill)])
            connection.execute("SET max_temp_directory_size=?", [args.max_spill])
            for index, name in enumerate(files, 1):
                sql, convert, reference = prepared[name]
                item = {"label": name, "index": index, "status": "not_completed"}
                if args.dataset == "bi10m":
                    item["warmup_position"] = workload.requests[name]["warmup"]
                journal.write(json.dumps({**item, "status": "started"}, sort_keys=True) + "\n")
                journal.flush()
                try:
                    actual = convert(connection.execute(sql).fetchall())
                    path = args.output / f"{index:03d}.json"
                    put(path, actual)
                    item.update(status="collected", answer_file=path.name,
                                answer_sha256=sha256(path.read_bytes()).hexdigest())
                    item.update(workload.check(name, actual, reference))
                except (duckdb.Error, ValueError, KeyError, OverflowError) as error:
                    item.update(status="error", error=f"{type(error).__name__}: {error}")
                records.append(item)
                journal.write(json.dumps(item, sort_keys=True) + "\n")
                journal.flush()
        report.update(complete=True, eligible=all(row["status"] == "collected" and workload.admitted(row)
                                                  for row in records))
        return 0 if report["eligible"] else 1
    finally:
        report["finished"] = len(records)
        put(args.output / "FINAL.json", report)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("registry", "binding", "database", "output"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    parser.add_argument("--binding-sha256", required=True)
    parser.add_argument("--dataset", choices=EXPECTED_CASES, required=True)
    parser.add_argument("--arm", choices=ARMS, required=True)
    parser.add_argument("--duckdb-version", required=True)
    parser.add_argument("--threads", required=True, type=int)
    parser.add_argument("--memory-limit", required=True)
    parser.add_argument("--max-spill", required=True)
    raise SystemExit(run(parser.parse_args()))
