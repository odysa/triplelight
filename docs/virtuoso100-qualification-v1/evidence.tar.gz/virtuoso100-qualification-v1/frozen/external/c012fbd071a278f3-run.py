"""One untimed Virtuoso100M correctness attempt; no comparative timing or ranking.
Requires independently acquired exact lock and matching prospective registration.
The shared original DB is never mounted. Only the already-authorized private copy is opened.
"""
import argparse,configparser,hashlib,io,json,os,signal,subprocess,sys,time,urllib.parse,urllib.request,shutil
from pathlib import Path
ROOT=Path('/private/tmp/rdf-jianlin-analytical25')
STAGE=ROOT/'virtuoso100-qualification-v1'
DB=ROOT/'virtuoso100-provenance-v1/store-copy'
OLD=ROOT/'matched-vm-100m-v1'
REF=ROOT/'bsbm100-reference-v1'
SOURCE=OLD/'bench-source'
IMAGE='openlink/virtuoso-opensource-7@sha256:0dbe1ab4fa0cb7bbafc1f6c0c2b0a5d6f22d918dbd17672f2ddb24580aa6756a'
NAME='jianlin-virtuoso100-qualification-v1'
OWNER='Jianlin task25 Virtuoso100M frozen answer qualification v1'
PORT=31651
ENDPOINT=f'http://127.0.0.1:{PORT}/sparql'
DATA_SHA='6e4ef939f05b15677802d17257096de9da32a452fe33dd40c07d0b0537ee430d'
GATES={'numeric_freeze':'63e127b60ac8de510a172748108639f0834e17bc3772e1d16ce226404aa58cca','count_policy':'5049fb75210fc6fc78ebf1fb2553b88baef197ae73495b70f110a203a70a4663','value_policy':'7b3f640bbab516db80ceba87549b9670802a93c5ff77181bdda66c0855fc3dfb'}

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  while b:=f.read(8*1024*1024):h.update(b)
 return h.hexdigest()

def save(p,r):p.write_text(json.dumps(r,indent=2))
def owner():
 if Path('/tmp/rdf-bench.lock/owner').read_text().strip()!=OWNER:raise RuntimeError('lock mismatch')
def guard():
 owner()
 stamp=time.time()
 try:used=int(subprocess.check_output(['du','-sk',str(ROOT)],text=True,timeout=15).split()[0])*1024
 except subprocess.TimeoutExpired as e:raise RuntimeError(f'disk guard du timeout at unix={stamp}') from e
 free=shutil.disk_usage(ROOT).free
 if used>=40*2**30 or free<=48*2**30:raise RuntimeError('conservative disk guard')
 return {'unix':time.time(),'allocated_bytes':used,'free_bytes':free}
def docker(*a,check=True):
 r=subprocess.run(['docker',*a],capture_output=True,text=True,timeout=60)
 if check and r.returncode:raise RuntimeError('docker '+a[0]+': '+r.stderr)
 return r

def identities():
 owner()
 # Only called under our lock; validator and query files are small, but numeric/reference sets can be larger.
 files={str(p):sha(p) for d in [SOURCE,OLD/'workload',REF/'reference',ROOT/'numeric-freeze-100m-v1'] for p in sorted(d.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
 for p in [REF/'count-policy-freeze.json',REF/'value-policy-freeze.json',Path(__file__).resolve(),ROOT/'virtuoso100-provenance-v1/input-receipt.json']:files[str(p)]=sha(p)
 assert files[str(REF/'count-policy-freeze.json')]==GATES['count_policy']
 assert files[str(REF/'value-policy-freeze.json')]==GATES['value_policy']
 return files

def rendered_ini():
 cfg=configparser.ConfigParser(strict=False);cfg.optionxform=str;cfg.read(DB/'virtuoso.ini')
 for k,v in {'NumberOfBuffers':'1360000','MaxDirtyBuffers':'1000000','ThreadsPerQuery':'4','AsyncQueueMaxThreads':'4'}.items():cfg.set('Parameters',k,v)
 out=io.StringIO();cfg.write(out);return out.getvalue().encode()

def register():
 guard();STAGE.mkdir(exist_ok=False)
 proto={'schema':'virtuoso100-untimed-qualification-v1','owner':OWNER,'image':IMAGE,'dataset_sha256':DATA_SHA,'gates':GATES,'files':identities(),'database_before_open':{f:sha(DB/f) for f in ['virtuoso.db','virtuoso.trx']},'rendered_ini_sha256':hashlib.sha256(rendered_ini()).hexdigest(),
 'server':{'cpus':4,'memory_bytes':12*2**30,'extra_swap_bytes':0,'endpoint':ENDPOINT,'NumberOfBuffers':1360000,'MaxDirtyBuffers':1000000,'ThreadsPerQuery':4,'AsyncQueueMaxThreads':4},
 'schedule':'the existing 60 requests in workload/manifest.json, once; no retries; correctness failures retained; transport failure stops remaining requests',
 'reference':'existing 100M Jena reference and frozen strict/COUNT/value gates; no gate widening or query rewriting',
 'scope':'retrospective copied-store correctness screen only; missing original import receipts remain unresolved; four-thread query settings differ from the historical ten-thread configuration; no comparative timing or ranking',
 'limits':{'query_timeout_seconds':600,'readiness_seconds':180,'client_wall_cap_seconds':3600,'root_allocated_guard_bytes':40*2**30,'free_floor_bytes':48*2**30},
 'registered_unix':time.time()}
 save(STAGE/'registration.json',proto);print(sha(STAGE/'registration.json'))

def ask(query,timeout=10):
 data=urllib.parse.urlencode({'query':query,'format':'application/sparql-results+json','default-graph-uri':'http://bench/bsbm100'}).encode()
 with urllib.request.urlopen(urllib.request.Request(ENDPOINT,data=data,headers={'Accept':'application/sparql-results+json'}),timeout=timeout) as r:return json.load(r)

def run(expected):
 owner();reg=STAGE/'registration.json'
 assert sha(reg)==expected
 protocol=json.loads(reg.read_text());assert identities()==protocol['files']
 assert {f:sha(DB/f) for f in protocol['database_before_open']}==protocol['database_before_open']
 attempt=STAGE/'attempt';attempt.mkdir(exist_ok=False)
 state={'complete':False,'scope':protocol['scope'],'queries_started':False};created=False;child=None;samples=[]
 def stop_signal(sig,frame):raise RuntimeError('signal '+str(sig))
 for s in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(s,stop_signal)
 try:
  if docker('ps','-a','--filter',f'name=^{NAME}$','--format','{{.Names}}').stdout.strip():raise RuntimeError('exact container name already exists')
  ini=rendered_ini()
  assert hashlib.sha256(ini).hexdigest()==protocol['rendered_ini_sha256'],'rendered ini differs from registration'
  (DB/'virtuoso.ini').write_bytes(ini)
  lockfile=DB/'virtuoso.lck'
  save(attempt/'copy-lock-before.json',{'present':lockfile.exists(),'bytes':lockfile.stat().st_size if lockfile.exists() else None,'sha256':sha(lockfile) if lockfile.exists() else None,'scope':'private copy lock metadata only; no shared lock touched'})
  # Freeze this private copy as it actually exists before open. Database keys/config are never exported.
  save(attempt/'store-before.json',{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in DB.iterdir() if p.is_file() and p.suffix not in ('.key','.crt')})
  created=True
  docker('create','--name',NAME,'--cpus','4','--memory','12g','--memory-swap','12g','-p',f'127.0.0.1:{PORT}:8890','--mount',f'type=bind,src={DB},dst=/database','--entrypoint','/bin/sh',IMAGE,'-c','exec virtuoso-t -f -c /database/virtuoso.ini')
  info=json.loads(docker('inspect',NAME).stdout)[0]
  hc=info['HostConfig'];img=json.loads(docker('image','inspect',IMAGE).stdout)[0]
  assert info['Image']==img['Id'] and hc['NanoCpus']==4*10**9 and hc['Memory']==12*2**30 and hc['MemorySwap']==12*2**30
  assert len(info['Mounts'])==1 and info['Mounts']==[m for m in info['Mounts'] if m['Destination']=='/database' and Path(m['Source']).resolve()==DB.resolve() and m['RW']]
  # Never persist Config.Env or the unredacted whole inspect object.
  save(attempt/'container-identity.json',{'image_id':info['Image'],'image':IMAGE,'mounts':info['Mounts'],'cpus':hc['NanoCpus'],'memory':hc['Memory'],'memory_swap':hc['MemorySwap']})
  docker('start',NAME);deadline=time.monotonic()+180
  while True:
   samples.append(guard())
   if not json.loads(docker('inspect',NAME,'--format','{{json .State}}').stdout)['Running']:raise RuntimeError('server exited before ready')
   try:
    if ask('ASK {}')['boolean']:break
   except Exception:pass
   if time.monotonic()>deadline:raise RuntimeError('readiness timeout')
   time.sleep(2)
  loader=docker('exec',NAME,'isql','1111','dba','dba','EXEC=select ll_file, ll_state, ll_error from DB.DBA.load_list;').stdout
  (attempt/'load-list-before.txt').write_text(loader)
  rows=[l.split() for l in loader.splitlines() if '/import/bsbm100.nt' in l]
  assert rows==[['/import/bsbm100.nt','2','NULL']]
  count=ask('SELECT (COUNT(*) AS ?n) WHERE { ?s ?p ?o }',timeout=600);save(attempt/'graph-count-before.json',count)
  assert int(count['results']['bindings'][0]['n']['value'])==98861444
  evidence={'system':'virtuoso','endpoint':ENDPOINT,'source_or_image':IMAGE,'dataset_sha256':DATA_SHA,'threads':4,'memory_configuration':protocol['server'],'cache_profile':'normal engine caches, untimed correctness screen','query_fields':{'default-graph-uri':'http://bench/bsbm100','format':'application/sparql-results+json'},'store_provenance':protocol['scope']}
  save(attempt/'runtime-evidence.json',evidence)
  args=[sys.executable,str(SOURCE/'http_measure_value.py'),'--workload',str(OLD/'workload'),'--reference',str(REF/'reference'),'--out',str(attempt/'queries'),'--runtime-evidence',str(attempt/'runtime-evidence.json'),'--numeric-inputs',str(ROOT/'numeric-freeze-100m-v1'),'--numeric-freeze-sha256',GATES['numeric_freeze'],'--count-policy-freeze',str(REF/'count-policy-freeze.json'),'--count-policy-sha256',GATES['count_policy'],'--value-policy-freeze',str(REF/'value-policy-freeze.json'),'--value-policy-sha256',GATES['value_policy'],'--lock-owner',OWNER,'--timeout','600']
  save(attempt/'client-command.json',args);state['queries_started']=True
  with (attempt/'client.log').open('w') as log:child=subprocess.Popen(args,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  client_deadline=time.monotonic()+3600
  while child.poll() is None:
   samples.append(guard())
   if time.monotonic()>client_deadline:raise RuntimeError('qualification client whole-attempt wall cap')
   time.sleep(2)
  state['client_exit']=child.returncode
  if child.returncode:raise RuntimeError('qualification client failed; retain partial outputs')
  report=json.loads((attempt/'queries/measurements.json').read_text())
  state.update(complete=report['complete'],attempted=sum(q['status']!='not_run' for q in report['queries'].values()),strict_pass=sum(q['status']=='pass' for q in report['queries'].values()),count_pass=sum(q.get('count_equivalence',{}).get('status')=='pass' for q in report['queries'].values()),value_pass=sum(q.get('value_compatibility',{}).get('status')=='pass' for q in report['queries'].values()))
  if report['complete']:
   count=ask('SELECT (COUNT(*) AS ?n) WHERE { ?s ?p ?o }',timeout=600);save(attempt/'graph-count-after.json',count)
   assert int(count['results']['bindings'][0]['n']['value'])==98861444
  state['identities_unchanged']=identities()==protocol['files']
 except BaseException as e:state['error']=repr(e)
 finally:
  for s in [signal.SIGTERM,signal.SIGINT,signal.SIGHUP]:signal.signal(s,signal.SIG_IGN)
  if child is not None and child.poll() is None:
   child.terminate()
   try:child.wait(timeout=15)
   except subprocess.TimeoutExpired:child.kill();child.wait(timeout=15)
  cleanup=[]
  if created:
   def cleanup_step(label,fn):
    try:return fn()
    except Exception as e:cleanup.append(label+': '+repr(e));return None
   cleanup_step('resources',lambda:(attempt/'cgroup-after.txt').write_text(docker('exec',NAME,'sh','-c','cat /sys/fs/cgroup/memory.peak /sys/fs/cgroup/memory.events',check=False).stdout))
   cleanup_step('stop',lambda:docker('stop','-t','15',NAME,check=False))
   cleanup_step('state',lambda:save(attempt/'server-state.json',json.loads(docker('inspect',NAME,'--format','{{json .State}}').stdout)))
   cleanup_step('logs',lambda:(attempt/'server.log').write_text(docker('logs',NAME,check=False).stdout))
   cleanup_step('remove',lambda:docker('rm','-f',NAME,check=False))
   absent=cleanup_step('confirm-absence',lambda:not docker('ps','-a','--filter',f'name=^{NAME}$','--format','{{.Names}}').stdout.strip())
   if absent is not True:cleanup.append('container absence not confirmed')
  state['cleanup_errors']=cleanup;save(attempt/'state.json',state);save(attempt/'disk-guard.json',samples)
  # On cleanup uncertainty retain the lock so another job cannot overlap an unconfirmed server.
  lock=Path('/tmp/rdf-bench.lock')
  if not cleanup and (lock/'owner').read_text().strip()==OWNER:(lock/'owner').unlink();lock.rmdir()
 print(json.dumps(state,indent=2))

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['register','run']);a.add_argument('--registration-sha256');x=a.parse_args()
 if x.action=='register':register()
 else:
  if not x.registration_sha256:a.error('--registration-sha256 required')
  run(x.registration_sha256)
