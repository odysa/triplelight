"""Small offline replay (~5 MB inputs); no engine, build, scan or timing run."""
import hashlib,json,sys,collections
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/private/tmp/rdf-jianlin-analytical25');S=ROOT/'virtuoso100-qualification-v1';A=S/'attempt';OLD=ROOT/'matched-vm-100m-v1';REF=ROOT/'bsbm100-reference-v1';SRC=OLD/'bench-source'
sys.path.insert(0,str(SRC))
import http_measure,http_measure_value,count_equivalence,value_diagnostic
from envelope_qualify import FrozenInputs

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
reg=read(S/'registration.json');state=read(A/'state.json');report=read(A/'queries/measurements.json');manifest=read(OLD/'workload/manifest.json')
assert sha(S/'registration.json')=='84a6d66ff6704bc9a55dd0200fa7c07d46ad99b3505b7ff67fab7ca9c604297c'
assert sum(Path(f).stat().st_size for f in reg['files'])<16*2**20
for f,h in reg['files'].items():assert sha(f)==h,f
http_measure_value.check_policy(REF/'value-policy-freeze.json',reg['gates']['value_policy'],sha(OLD/'workload/manifest.json'))
count_equivalence.load_freeze(REF/'count-policy-freeze.json',reg['gates']['count_policy'])
frozen=FrozenInputs(ROOT/'numeric-freeze-100m-v1',reg['gates']['numeric_freeze'],reg['dataset_sha256'],sha(OLD/'workload/manifest.json'))
assert state['complete'] and state['client_exit']==0 and state['identities_unchanged'] and not state['cleanup_errors']
assert len(report['queries'])==60 and set(report['queries'])=={q['file'] for q in manifest['queries']}
counts=collections.Counter();failures=[];q5=[]
for q in manifest['queries']:
 name=q['file'];stem=Path(name).stem;n=q['template'];e=report['queries'][name]
 raw=(A/'queries'/(stem+'.body')).read_bytes();assert hashlib.sha256(raw).hexdigest()==e['body_sha256'] and len(raw)==e['bytes']
 assert e['http_status']==200 and not e['transport_error']
 actual=json.loads(raw);reference=read(REF/'reference'/(stem+'.json'))
 diag=read(REF/'reference'/(stem+'-diagnostic.json')) if n==7 else None
 statuses={}
 for gate,fn in [('strict',lambda:http_measure.verify(n,actual,reference,diag,frozen,q)),('count',lambda:http_measure.verify(n,count_equivalence.normalize(n,actual),count_equivalence.normalize(n,reference),diag,frozen,q))]:
  try:fn();statuses[gate]=True
  except (ValueError,KeyError,OverflowError):statuses[gate]=False
  expected=e['status']=='pass' if gate=='strict' else e.get('count_equivalence',{}).get('status')=='pass'
  assert statuses[gate]==expected,(name,gate)
 try:
  if n==7:http_measure.verify(7,actual,reference,diag,frozen,q);passed=True
  else:
   inputs=frozen.for_instance(q) if n in (4,5,6) else None
   v=value_diagnostic.diagnose(n,actual,reference,inputs);passed=v['order']['status']=='pass'
 except (ValueError,KeyError,OverflowError):passed=False
 assert passed==(e['value_compatibility']['status']=='pass'),name
 for k,v in {**statuses,'value':passed}.items():counts[k]+=int(v)
 detail={'query':name,'template':n,'mix':q['mix'],'scored':e['scored'],'actual_rows':len(actual['results']['bindings']),'reference_rows':len(reference['results']['bindings'])}
 if not passed:failures.append(detail)
 if n==5:q5.append(detail)
assert dict(counts)=={'strict':42,'count':42,'value':59}
assert not report['ranking_eligible'] and not report['integer_value_equivalent_eligible'] and not report['value_compatible_eligible']
assert all(report[k] is None for k in ['measured_total_ns','integer_value_equivalent_total_ns','value_compatible_total_ns'])
server=read(A/'server-state.json');assert not server['Running'] and not server['OOMKilled'] and server['ExitCode']==0
assert all(int(read(A/('graph-count-'+x+'.json'))['results']['bindings'][0]['n']['value'])==98861444 for x in ['before','after'])
resource=(A/'cgroup-after.txt').read_text().splitlines();events=dict(l.split() for l in resource[1:]);assert all(int(events[k])==0 for k in ['oom','oom_kill','oom_group_kill','max','high'])
result={'complete':True,'registered_auxiliary_files_verified':len(reg['files']),'response_files_verified':60,'counts':dict(counts),'value_gate_failures':failures,'q5_reference_rows':q5,'all_ranking_totals_null':True,'container_exit_0_no_oom':True,'no_original_import_receipts':True,'scope':'retrospective copied-store untimed correctness screen, not a performance comparison; current store equality beyond the frozen query set unproved'}
Path(__file__).with_name('AUDIT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
