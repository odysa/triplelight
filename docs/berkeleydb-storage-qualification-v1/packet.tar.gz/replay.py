"""Replay BerkeleyDB storage outcomes from an extracted packet without engine imports."""
from collections import Counter
import json
from pathlib import Path
import sys

XSD = 'http://www.w3.org/2001/XMLSchema#'


def term_key(term):
    if term['type'] == 'uri':
        return 'uri', term['value'], '', ''
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype', '') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
                                           if language else XSD + 'string')
    return 'literal', term['value'], datatype, language


def main():
    root = Path(sys.argv[1])
    run = root / 'storage-attempt-1'
    reference = json.loads((root / 'source/consumer-fixture-jena.json').read_text())
    expected = Counter(('urn:s', 'urn:v', term_key(row['o'])) for row in reference['results']['bindings'])
    assert len(expected) == sum(expected.values()) == 9
    summary = json.loads((run / 'SUPERVISOR.json').read_text())
    observations = summary['observations']
    assert summary['identity_postcheck'] is True and summary['full_workload_qualified'] is False
    assert [(o['profile'], o['boundary']) for o in observations] == [
        ('default', 'load'), ('default', 'reopen'), ('preserve', 'load'), ('preserve', 'reopen')]
    report = []
    previous = {}
    for observation in observations:
        profile, boundary = observation['profile'], observation['boundary']
        name = f'{profile}-{boundary}.json'
        assert observation['record'] == name and observation['state'] == 'observed' and observation['exit'] == 0
        raw = json.loads((run / name).read_text())
        assert raw['profile'] == profile and raw['boundary'] == boundary
        assert raw['graph'] == 'urn:triplelight:qualification:berkeleydb39'
        assert raw['normalize_literals'] is (profile == 'default')
        assert raw['closed'] is True
        actual = Counter((row['subject'], row['predicate'], term_key(row['object'])) for row in raw['triples'])
        computed = {'scoped_count': type(raw['count']) is int and raw['count'] == 9,
                    'exact_scoped_triple_bag': actual == expected, 'clean_close': raw['closed']}
        assert computed == raw['storage_checks'] == observation['storage_checks']
        assert sum(actual.values()) == raw['count']
        evaluator = raw['shared_evaluator_diagnostic']
        assert evaluator['columns'] == ['o'] and all(len(row) == 1 for row in evaluator['rows'])
        correct_empty = not evaluator['rows']
        assert correct_empty is evaluator['passes'] is observation['shared_evaluator_pass']
        inventory = observation.get('before_reopen_files', {})
        if boundary == 'reopen':
            assert actual == previous[profile]
            assert any(n.startswith('__db.') and size > 0 for n, size in inventory.items())
            assert {'c^s^p^o^', 'c^o^s^p^', 'c^p^o^s^'} <= {n for n, size in inventory.items() if size > 0}
        else:
            previous[profile] = actual
        report.append({'profile': profile, 'boundary': boundary, 'scoped_count': raw['count'],
                       'exact_scoped_triple_bag': actual == expected,
                       'missing': sorted((expected - actual).elements()),
                       'additional': sorted((actual - expected).elements()),
                       'close_returned': raw['closed'],
                       'shared_evaluator_filter_false_rows': len(evaluator['rows']),
                       'recorded_log_files': sorted(n for n in inventory if n.startswith('log.'))})
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
