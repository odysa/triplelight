# RDFLib BerkeleyDB packaging and disk qualification plan

Try the RDFLib 7.6.0 BerkeleyDB storage plugin with an isolated build of Python berkeleydb 18.1.15 against Berkeley DB 5.3.28. The publisher ships this binding as source on PyPI and lists Python 3.14 and Berkeley DB 5.3 in its test matrix. The Homebrew package index supplies a matching host-architecture bottle. The pin manifest records candidate bytes and the exact Python interpreter used by the preceding Mac qualification. No package has been installed or built.

## Isolated preparation

Use a fresh private scratch tree and a bounded machine window. Download only the pinned public source, bottle and wheels, and verify digests before using any. Extract the bottle into scratch with validated member paths and links. Build a binding wheel with the pinned setuptools and an explicit Berkeley DB include/library prefix. The release's setup3.py accepts these paths through BERKELEYDB_DIR or BERKELEYDB_INCDIR and BERKELEYDB_LIBDIR. Keep package caches and build output inside scratch. Use the installed Apple toolchain and record exact compiler and SDK facts. Keep all modifications in the scratch tree.

The setup step should record the C header, actual Berkeley DB library, built binding extension and wheel digests, inspect link dependencies and verify which private library will be loaded. Homebrew relocation placeholders are a feasibility question. If needed, use an explicit reviewed relocation confined to the private library and preserve the original artifact identity. Treat any unresolved dynamic link or mismatched ABI as a setup failure, before query admission.

## Correctness boundary

Use the existing Jena nine-term fixture. Compare RDFLib's installed normalization default and explicit lexical preservation. Each profile has a fresh BerkeleyDB store, load and separate-process reopen of the same graph IRI, using the ordinary RDFLib N-Triples parser and SPARQL evaluator. Compare scoped Graph length, the exact typed triple bag returned directly by the store, and clean close. Run the separate FILTER(false) diagnostic through the shared RDFLib evaluator. Capture the plugin class, evaluator path and store files between processes. Record each observation independently and retain setup failures. Results describe this RDFLib storage configuration. The underlying SPARQL evaluator is shared with RDFLib Memory, so a passing storage result alone cannot establish query admission. No timing is planned at this stage.

- [RDFLib 7.6.0 BerkeleyDB store source](https://github.com/RDFLib/rdflib/blob/7.6.0/rdflib/plugins/stores/berkeleydb.py)
- [Pinned Python binding release](https://pypi.org/project/berkeleydb/18.1.15/)
- [Binding publisher's compatibility notes](https://www.jcea.es/programacion/pybsddb.htm)
- [Berkeley DB 5.3 bottle metadata](https://formulae.brew.sh/formula/berkeley-db%405)

## Prospective evaluator prediction

RDFLib Memory returned nine rows for FILTER(false) where zero were expected. Because BerkeleyDB uses RDFLib's same SPARQL evaluator, we predict the same failure. Keep that query as a shared-evaluator diagnostic and report it separately from the BerkeleyDB length, exact stored-term and close/reopen checks. No workload admission follows from this storage check.

RDFLib 7.6.0 uses the Berkeley DB Concurrent Data Store environment with memory-pool and CDB flags. The on-disk inventory checks for region and index files and records any log files present. The source does not request transactional logging or recovery.
