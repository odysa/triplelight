"""Observe storage and one shared-evaluator diagnostic at one disk boundary."""
import argparse
from collections import Counter
import ctypes
import importlib.metadata
import json
from pathlib import Path

from setup_private import LOCK, sha

HERE = Path(__file__).resolve().parent
GRAPH = 'urn:triplelight:qualification:berkeleydb39'
ROOT = Path('/private/tmp/rdf-jianlin-berkeleydb39-v1')
SETUP_SHA = 'aa70eb7ee7878cc0debc836b6b75233960b14b9dda9db0c5fa7a62f104da07c0'
FILTER_FALSE = 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }'
QUERY_OWNER = 'Jianlin task39 BerkeleyDB storage qualification v1'


def require_query_lock():
    if LOCK.read_text().strip() != QUERY_OWNER:
        raise RuntimeError('owned BerkeleyDB query lock required')


def runtime_identity():
    receipt = ROOT / 'SETUP.json'
    if sha(receipt) != SETUP_SHA:
        raise RuntimeError('setup receipt changed')
    setup = json.loads(receipt.read_text())
    import sys
    if Path(sys.executable) != ROOT / 'venv/bin/python' or sha(Path(sys.executable)) != setup['executable_sha256']:
        raise RuntimeError('wrong isolated interpreter')
    from berkeleydb import _berkeleydb, db
    import rdflib
    versions = {name: importlib.metadata.version(name) for name in ('berkeleydb', 'rdflib', 'pyparsing')}
    if versions != {'berkeleydb': '18.1.15', 'rdflib': '7.6.0', 'pyparsing': '3.3.3'}:
        raise RuntimeError('unexpected package versions')
    libraries = []
    dyld = ctypes.CDLL(None)
    dyld._dyld_image_count.restype = ctypes.c_uint32
    dyld._dyld_get_image_name.argtypes = [ctypes.c_uint32]
    dyld._dyld_get_image_name.restype = ctypes.c_char_p
    for index in range(dyld._dyld_image_count()):
        path = Path(dyld._dyld_get_image_name(index).decode()).resolve()
        if path.name.startswith('libdb') and path.suffix == '.dylib':
            libraries.append(path)
    library = ROOT / 'private-db/lib/libdb-5.3.dylib'
    if (libraries != [library] or list(db.version()) != [5, 3, 28]
            or sha(library) != setup['private_library_sha256']
            or sha(Path(_berkeleydb.__file__)) != setup['extension_sha256']):
        raise RuntimeError('private Berkeley DB runtime mismatch')
    return rdflib, versions


def key(term):
    if term['type'] == 'uri':
        return 'uri', term['value'], '', ''
    language = term.get('language', '').lower()
    datatype = term.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if language
                                        else 'http://www.w3.org/2001/XMLSchema#string')
    return 'literal', term['value'], datatype, language


def checks(record):
    reference = json.loads((HERE / 'consumer-fixture-jena.json').read_text())
    expected = []
    for row in reference['results']['bindings']:
        term = dict(row['o'])
        if 'xml:lang' in term:
            term['language'] = term.pop('xml:lang')
        expected.append(key(term))
    expected_rows = Counter(('urn:s', 'urn:v', term) for term in expected)
    actual_rows = Counter((row['subject'], row['predicate'], key(row['object'])) for row in record['triples'])
    return {
        'scoped_count': type(record['count']) is int and record['count'] == 9,
        'exact_scoped_triple_bag': actual_rows == expected_rows,
        'clean_close': record['closed'] is True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=('default', 'preserve'), required=True)
    parser.add_argument('--boundary', choices=('load', 'reopen'), required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    require_query_lock()
    rdflib, versions = runtime_identity()
    from rdflib.plugins.stores.berkeleydb import BerkeleyDB
    from rdflib.store import VALID_STORE
    default = rdflib.NORMALIZE_LITERALS
    rdflib.NORMALIZE_LITERALS = default if args.profile == 'default' else False
    graph = rdflib.Graph(store='BerkeleyDB', identifier=rdflib.URIRef(GRAPH))
    if type(graph.store) is not BerkeleyDB:
        raise RuntimeError('unexpected RDFLib plugin')
    loading = args.boundary == 'load'
    if args.db.is_symlink() or loading == args.db.exists():
        raise RuntimeError('expected fresh load or existing reopen path')
    if graph.open(str(args.db), create=loading) != VALID_STORE:
        raise RuntimeError('BerkeleyDB Graph open failed')

    def term(value):
        if isinstance(value, rdflib.URIRef):
            return {'type': 'uri', 'value': str(value)}
        if isinstance(value, rdflib.Literal):
            result = {'type': 'literal', 'value': str(value)}
            if value.datatype:
                result['datatype'] = str(value.datatype)
            if value.language:
                result['language'] = value.language
            return result
        raise TypeError(f'unsupported fixture term {type(value).__name__}')

    record = {'profile': args.profile, 'boundary': args.boundary,
              'versions': versions, 'graph': GRAPH, 'literal_default': default,
              'normalize_literals': rdflib.NORMALIZE_LITERALS}
    try:
        if loading:
            graph.parse(source=HERE / 'consumer-fixture.nt', format='nt')
        record['count'] = len(graph)
        record['triples'] = [{'subject': str(s), 'predicate': str(p), 'object': term(o)}
                             for s, p, o in graph.triples((None, None, None))]
        try:
            result = graph.query(FILTER_FALSE, use_store_provided=False)
            columns = [str(var) for var in result.vars]
            rows = [[None if value is None else term(value) for value in row] for row in result]
            record['shared_evaluator_diagnostic'] = {'columns': columns, 'rows': rows,
                                                     'passes': columns == ['o'] and not rows}
        except Exception as exc:
            record['shared_evaluator_diagnostic'] = {'error': repr(exc), 'passes': False}
    finally:
        graph.close()
        record['closed'] = True
    require_query_lock()
    record['storage_checks'] = checks(record)
    with args.out.open('x') as output:
        json.dump(record, output, indent=2)
        output.write('\n')


if __name__ == '__main__':
    main()
