"""Prepare a pinned private Berkeley DB binding and verify the loaded C library."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import signal
import subprocess
import sys
import tarfile
import time
from urllib.request import urlopen

HERE = Path(__file__).resolve().parent
OWNER = 'Jianlin task39 BerkeleyDB setup feasibility v1'
LOCK = Path('/tmp/rdf-bench.lock/owner')
BOTTLE = 'berkeley-db-5.3.28.arm64_golden_gate.bottle.tar.gz'
BOTTLE_ROOT = 'berkeley-db@5/5.3.28_1'
PINS_SHA256 = '70a0fbbabc995e29b3a34bb0fc7696a31c518ecb7c02330ecfb0184ae3a09d58'
NETWORK_DENIED = ['sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']


def sha(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def require_lock():
    if LOCK.read_text().strip() != OWNER:
        raise RuntimeError('exact owned lock required')


def setup(out):
    require_lock()
    if not out.is_absolute() or out.exists():
        raise RuntimeError('fresh absolute setup directory required')
    pins_path = HERE / 'PINS.json'
    if sha(pins_path) != PINS_SHA256:
        raise RuntimeError('package pins changed')
    pins = json.loads(pins_path.read_text())
    if (platform.machine() != 'arm64' or platform.system() != 'Darwin' or sys.version_info[:3] != (3, 14, 3)
            or sha(Path(sys.executable)) != pins['python']['sha256']):
        raise RuntimeError('unregistered setup interpreter')
    bottle = HERE / BOTTLE
    if sha(bottle) != pins['db_bottle']['sha256']:
        raise RuntimeError('bottle identity mismatch')
    out.mkdir()
    deadline = time.monotonic() + 300
    record = {'engine_query_executed': False, 'status': 'incomplete'}

    def remaining():
        require_lock()
        if time.monotonic() >= deadline:
            raise TimeoutError('setup deadline expired')
        if shutil.disk_usage(out).free < 40_000_000_000:
            raise RuntimeError('host free space floor')
        size = 0
        for path in out.rglob('*'):
            try:
                size += path.stat(follow_symlinks=False).st_blocks * 512
            except FileNotFoundError:
                continue
        if size >= 512 * 2**20:
            raise RuntimeError('private setup allocation cap')
        return deadline - time.monotonic()

    def run(name, command, *, extra_env=None):
        env = os.environ.copy()
        for key in tuple(env):
            if key.startswith(('PIP_', 'PYTHON', 'DYLD_', 'BERKELEYDB_', 'CFLAGS', 'CPPFLAGS', 'LDFLAGS')):
                del env[key]
        env.update({'TMPDIR': str(out / 'tmp'), **(extra_env or {})})
        remaining()
        with (out / f'{name}.stdout').open('xb') as log, (out / f'{name}.stderr').open('xb') as err:
            process = subprocess.Popen(command, env=env, cwd=out, stdout=log, stderr=err,
                                       start_new_session=True)
            try:
                while process.poll() is None:
                    remaining()
                    time.sleep(0.2)
            except BaseException:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
                raise
            if process.returncode:
                raise subprocess.CalledProcessError(process.returncode, command)
        remaining()
        return (out / f'{name}.stdout').read_text()

    try:
        (out / 'tmp').mkdir()
        packages = {}
        for package in pins['python_packages']:
            target = out / package['filename']
            size = package['size']
            with urlopen(package['url'], timeout=min(15, remaining())) as response:
                data = response.read(size + 1)
            if len(data) != size or hashlib.sha256(data).hexdigest() != package['sha256']:
                raise RuntimeError(f'download identity mismatch {target.name}')
            target.write_bytes(data)
            packages[package['name']] = target
        prefix = out / 'private-db'
        header = prefix / 'include/db.h'
        library = prefix / 'lib/libdb-5.3.dylib'
        with tarfile.open(bottle) as tar:
            for path in (header, library):
                rel = path.relative_to(prefix)
                member = tar.getmember(f'{BOTTLE_ROOT}/{rel}')
                if not member.isfile() or not 0 < member.size < 4 * 2**20:
                    raise RuntimeError(f'unexpected bottle member {rel}')
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(tar.extractfile(member).read())
        (library.parent / 'libdb.dylib').symlink_to(library.name)
        record['original_header_sha256'] = sha(header)
        record['original_library_sha256'] = sha(library)
        if record['original_library_sha256'] != 'd3fd59901c6174bc4f1fda0b48a7baaad69f83275fe82f457fb87a583780f768':
            raise RuntimeError('unexpected library member')
        run('library-before', ['otool', '-L', str(library)])
        run('relocate', ['install_name_tool', '-id', str(library), str(library)])
        run('resign', ['codesign', '--force', '--sign', '-', str(library)])
        run('verify-signature', ['codesign', '--verify', '--strict', str(library)])
        if str(library) not in run('library-after', ['otool', '-D', str(library)]).splitlines()[1:]:
            raise RuntimeError('private install name not verified')
        record['private_library_sha256'] = sha(library)
        with tarfile.open(packages['berkeleydb']) as source:
            for name in ('setup.py', 'setup3.py', 'pyproject.toml'):
                data = source.extractfile(f'berkeleydb-18.1.15/{name}').read()
                (out / f'sdist-{name}').write_bytes(data)
                record[name + '_sha256'] = hashlib.sha256(data).hexdigest()
        run('compiler', ['xcrun', 'clang', '--version'])
        run('sdk', ['xcrun', '--show-sdk-path'])
        run('sdk-version', ['xcrun', '--show-sdk-version'])
        run('venv', NETWORK_DENIED + [sys.executable, '-I', '-B', '-m', 'venv', str(out / 'venv')])
        python = str(out / 'venv/bin/python')
        pip = NETWORK_DENIED + [python, '-I', '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check', '--no-cache-dir']
        install = pip + ['install', '--no-index', '--no-deps', '--no-compile']
        run('build-tool', install + [str(packages['setuptools'])])
        wheel_dir = out / 'wheels'
        wheel_dir.mkdir()
        run('build-binding', pip + ['wheel', '--no-index', '--no-deps', '--no-build-isolation',
                                   '--wheel-dir', str(wheel_dir), str(packages['berkeleydb'])],
            extra_env={'BERKELEYDB_DIR': str(prefix)})
        wheel, = wheel_dir.glob('berkeleydb-18.1.15-*.whl')
        run('install-binding', install + [str(wheel), str(packages['rdflib']), str(packages['pyparsing'])])
        probe = '''
import ctypes
import json
from pathlib import Path
import sys
from berkeleydb import _berkeleydb, db
dyld = ctypes.CDLL(None)
dyld._dyld_image_count.restype = ctypes.c_uint32
dyld._dyld_get_image_name.argtypes = [ctypes.c_uint32]
dyld._dyld_get_image_name.restype = ctypes.c_char_p
images = [Path(dyld._dyld_get_image_name(i).decode()).resolve()
          for i in range(dyld._dyld_image_count())]
libraries = [path for path in images if path.name.startswith('libdb') and path.suffix == '.dylib']
assert libraries == [Path(sys.argv[1]).resolve()], libraries
assert db.version() == (5, 3, 28), db.version()
print(json.dumps({'berkeley_db_version':db.version(), 'extension':_berkeleydb.__file__,
                  'loaded_db_libraries':[str(path) for path in libraries]}))
'''
        identity = json.loads(run('binding-probe', NETWORK_DENIED + [python, '-I', '-B', '-c', probe, str(library)]))
        linkage = run('binding-linkage', ['otool', '-L', identity['extension']])
        if str(library) not in linkage:
            raise RuntimeError('extension not linked to pinned private library')
        remaining()
        record.update(identity, status='ready', wheel_sha256=sha(wheel),
                      extension_sha256=sha(Path(identity['extension'])), executable_sha256=sha(Path(python)))
    except Exception as exc:
        record['error'] = repr(exc)
        raise
    finally:
        (out / 'SETUP.json').write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 2**20,) * 2)
    setup(args.out)
