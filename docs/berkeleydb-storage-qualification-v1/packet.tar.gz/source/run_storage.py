"""Supervise four BerkeleyDB observations. No timing or workload results."""
import argparse
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

from setup_private import sha
from storage_worker import HERE, ROOT, checks, require_query_lock

PROFILES = ('default', 'preserve')
BOUNDARIES = ('load', 'reopen')


def inventory(directory, *, active=False):
    result = {}
    for path in directory.rglob('*'):
        try:
            info = path.lstat()
        except FileNotFoundError:
            if not active:
                raise
            continue
        if stat.S_ISREG(info.st_mode):
            result[str(path.relative_to(directory))] = info.st_size
        elif not stat.S_ISDIR(info.st_mode):
            raise RuntimeError(f'unexpected run file {path.name}')
    if sum(result.values()) >= 256 * 2**20:
        raise RuntimeError('storage attempt allocation cap')
    return result


def query_one(run, db, record, deadline):
    profile, boundary = record['profile'], record['boundary']
    name = f'{profile}-{boundary}'
    command = ['sandbox-exec', '-p', '(version 1) (allow default) (deny network*)',
               sys.executable, '-E', '-s', '-B', str(HERE / 'storage_worker.py'),
               '--profile', profile, '--boundary', boundary, '--db', str(db),
               '--out', str(run / f'{name}.json')]
    require_query_lock()
    with (run / f'{name}.stdout').open('xb') as stdout, (run / f'{name}.stderr').open('xb') as stderr:
        process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while process.poll() is None:
                require_query_lock()
                if time.monotonic() >= deadline:
                    raise TimeoutError('storage attempt deadline')
                if os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size >= 8 * 2**20:
                    raise RuntimeError('storage attempt log cap')
                inventory(run, active=True)
                time.sleep(0.1)
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            raise
    require_query_lock()
    inventory(run)
    return process.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-sha256', required=True)
    args = parser.parse_args()
    require_query_lock()
    manifest = HERE / 'STORAGE_FREEZE.json'
    setup = ROOT / 'SETUP.json'
    installed = ROOT / 'INSTALLED_FILES.json'
    runtime = json.loads(installed.read_bytes())

    def identities():
        if sha(manifest) != args.source_sha256:
            raise RuntimeError('unannounced source digest')
        identity = json.loads(manifest.read_text())
        if sha(setup) != identity['setup_sha256'] or sha(installed) != identity['installed_manifest_sha256']:
            raise RuntimeError('setup or installed manifest changed')
        if any(sha(HERE / name) != digest for name, digest in identity['files'].items()):
            raise RuntimeError('frozen source or input changed')
        if any(sha(ROOT / name) != digest for name, digest in runtime.items()):
            raise RuntimeError('installed runtime file changed')

    identities()
    run = ROOT / 'storage-attempt-1'
    run.mkdir()
    result = {'observations': [], 'source_sha256': args.source_sha256,
              'identity_postcheck': False, 'full_workload_qualified': False}
    deadline = time.monotonic() + 120
    try:
        for profile in PROFILES:
            db = run / f'{profile}.db'
            loader_closed = False
            for boundary in BOUNDARIES:
                record = {'profile': profile, 'boundary': boundary}
                result['observations'].append(record)
                if boundary == 'reopen':
                    if not loader_closed:
                        record['state'] = 'skipped-loader-did-not-close'
                        continue
                    files = inventory(db)
                    if not (any(name.startswith('__db.') and size > 0 for name, size in files.items())
                            and any(not name.startswith(('__db.', 'log.')) and size > 0
                                    for name, size in files.items())):
                        raise RuntimeError('BerkeleyDB region or index files missing after close')
                    record['before_reopen_files'] = files
                record['exit'] = query_one(run, db, record, deadline)
                loader_closed = False
                if record['exit'] != 0:
                    record['state'] = 'worker-error'
                    continue
                name = f'{profile}-{boundary}.json'
                raw = json.loads((run / name).read_text())
                if (raw['profile'], raw['boundary']) != (profile, boundary) or raw['storage_checks'] != checks(raw):
                    raise RuntimeError('observation identity or gate mismatch')
                record.update(state='observed', record=name, storage_checks=raw['storage_checks'],
                              shared_evaluator_pass=raw['shared_evaluator_diagnostic']['passes'])
                loader_closed = raw['closed'] is True
        identities()
        require_query_lock()
        result['identity_postcheck'] = True
    finally:
        (run / 'SUPERVISOR.json').write_text(json.dumps(result, indent=2) + '\n')
    if any(record['state'] != 'observed' for record in result['observations']):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
