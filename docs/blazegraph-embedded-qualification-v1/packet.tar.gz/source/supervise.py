"""Run pinned Blazegraph compile or storage stages under the exact machine lock."""
import argparse
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
from urllib.request import Request, urlopen
from zipfile import ZipFile

SOURCE = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/rdf-jianlin-blazegraph39-v1')
LOCK = Path('/private/tmp/rdf-bench.lock')
PINS = json.loads((SOURCE / 'PINS.json').read_bytes())
OWNER = PINS['owner']
LABEL = 'jianlin-blazegraph39-v1'
LABEL_KEY = 'org.triplelight.jianlin.qualification'
TMPFS = 'rw,nosuid,size=128m'
CPUS = 2
MEMORY = 2 << 30
CAP = 2 << 30
FLOOR = 40_000_000_000


def load(path):
    return json.loads(path.read_bytes())


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path, algorithm='sha256'):
    with path.open('rb') as stream:
        return file_digest(stream, algorithm).hexdigest()


def sha(path):
    return digest(path)


def write(path, record):
    with path.open('x') as stream:
        json.dump(record, stream, indent=2, sort_keys=True)
        stream.write('\n')


def docker(*args):
    result = subprocess.run(['docker', *args], capture_output=True, text=True, timeout=25)
    require(result.returncode == 0, f'docker {args[:2]} failed: {result.stderr[-600:]}')
    return result.stdout


def lock():
    require((LOCK / 'owner').read_text() == OWNER + '\n', 'exact owned machine lock required')


def source_identity(digest):
    manifest = SOURCE / 'FREEZE.json'
    require(sha(manifest) == digest, 'wrong freeze manifest')
    for name, expected in load(manifest).items():
        require(sha(SOURCE / name) == expected, f'changed source: {name}')


def guard(deadline):
    lock()
    require(time.monotonic() < deadline, 'stage deadline')
    require(shutil.disk_usage(ROOT).free >= FLOOR, 'shared disk free-space floor')
    allocated = 0
    for path in ROOT.rglob('*'):
        try:
            allocated += path.lstat().st_blocks * 512
        except FileNotFoundError:
            continue
    require(allocated < CAP, 'private root allocation cap')
    return allocated


def fetch_artifact(directory, deadline):
    directory.mkdir()
    jar = directory / 'blazegraph.jar'
    request = Request(PINS['jar_url'], headers={'If-Match': PINS['etag']})
    length = 0
    with urlopen(request, timeout=15) as response, jar.open('xb') as output:
        while chunk := response.read(1 << 18):
            length += len(chunk)
            require(length <= PINS['size'], 'oversize Maven artifact')
            output.write(chunk)
            guard(deadline)
    require(length == PINS['size'] and digest(jar, 'sha1') == PINS['central_sha1'],
            'Maven artifact identity mismatch')
    with ZipFile(jar) as archive:
        require(archive.read('META-INF/MANIFEST.MF').decode() == PINS['jar_manifest'],
                'Maven manifest changed')
        for name, expected in PINS['sample_classes'].items():
            require(sha256(archive.read(name)).hexdigest() == expected['sha256'],
                    f'Maven class changed: {name}')
    return sha(jar)


def runtime_identity(runtime, jar, freeze, identity):
    manifest = runtime / 'RUNTIME.json'
    require(identity and sha(manifest) == identity, 'wrong reviewed runtime receipt')
    record = load(manifest)
    require(record['freeze_sha256'] == freeze and record['jar_sha256'] == sha(jar)
            and record['java_version'] == PINS['java_version'] and record['jvm_module_flags'] == [],
            'runtime manifest changed')
    classes = {path.name: sha(path) for path in sorted((runtime/'classes').glob('*.class'))}
    require(classes == record['classes'] and classes, 'compiled adapter changed')


def inspect_container(name):
    return json.loads(docker('container', 'inspect', name))[0]


def exists(name):
    return name in docker('ps', '-a', '--format', '{{.Names}}').splitlines()


def configuration(info, image_id, mounts, environment, command):
    host = info['HostConfig']
    actual = {m['Destination']: (str(Path(m['Source']).resolve()), m['RW']) for m in info['Mounts']}
    wanted = {dest: (str(path.resolve()), writable) for dest, (path, writable) in mounts.items()}
    env = set(info['Config']['Env'])
    require(info['Platform'] == 'linux' and info['Image'] == image_id
            and host['NetworkMode'] == 'none' and host['ReadonlyRootfs'] is True
            and host['CgroupnsMode'] == 'private' and host['NanoCpus'] == CPUS * 10**9
            and host['Memory'] == host['MemorySwap'] == MEMORY
            and host.get('Tmpfs', {}).get('/tmp') == TMPFS
            and info['Config']['Labels'].get(LABEL_KEY) == LABEL
            and actual == wanted and set(environment) <= env and info['Config']['Cmd'] == command,
            'container binding check failed')
    return {'mounts': actual, 'network': 'none', 'readonly_root': True, 'private_cgroup': True,
            'cpu_count': CPUS, 'memory_bytes': MEMORY, 'memory_swap_bytes': MEMORY,
            'tmpfs': TMPFS, 'command': command}


def cleanup(name, created_possible, process):
    if created_possible and exists(name):
        info = inspect_container(name)
        require(info['Config']['Labels'].get(LABEL_KEY) == LABEL, 'cleanup refused for another owner')
        ident = info['Id']
        if info['State']['Running']:
            docker('stop', '--time', '3', ident)
        docker('rm', ident)
    if process:
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
    require(not created_possible or not exists(name), 'owned container remains')
    return 'verified-removed' if created_possible else 'not-created'


def run(args):
    lock()
    source_identity(args.freeze_sha256)
    runtime_dir = ROOT / 'runtime'
    artifact = ROOT / 'artifact'
    jar = artifact / 'blazegraph.jar'
    setup = args.stage == 'setup'
    if setup:
        ROOT.mkdir()
    else:
        runtime_identity(runtime_dir, jar, args.freeze_sha256, args.runtime_sha256)
    phase = ROOT / args.stage
    phase.mkdir()
    name = LABEL + '-' + args.stage
    report = {'stage': args.stage, 'source_sha256': args.freeze_sha256, 'image': PINS['java_image'],
              'stage_cap_seconds': 180 if setup else 120}
    deadline = time.monotonic() + report['stage_cap_seconds']
    process = None
    created_possible = False
    try:
        guard(deadline)
        image = json.loads(docker('image', 'inspect', PINS['java_image']))[0]
        require(image['Os'] == 'linux' and image['Architecture'] == 'arm64', 'wrong pinned image platform')
        image_id = image['Id']
        report['image_id'] = image_id
        if not setup:
            require(load(runtime_dir / 'RUNTIME.json')['image_id'] == image_id, 'Java image identity changed')

        mounts = {'/src': (SOURCE, False), '/guard': (LOCK, False),
                  '/runtime': (runtime_dir, setup), '/artifact': (artifact, False)}
        environment = []
        if setup:
            jar_hash = fetch_artifact(artifact, deadline)
            runtime_dir.mkdir()
            command = ['/bin/sh', '/src/compile.sh']
        else:
            data = phase / 'out'
            data.mkdir()
            mounts['/out'] = (data, True)
            command = ['/bin/sh', '/src/storage.sh']

        require(not exists(name), 'container name preexists')
        cmd = ['create', '--pull=never', '--name', name, '--platform', 'linux/arm64',
               '--label', LABEL_KEY + '=' + LABEL, '--cpus', str(CPUS), '--memory', str(MEMORY),
               '--memory-swap', str(MEMORY), '--network=none', '--cgroupns=private', '--read-only',
               '--tmpfs', '/tmp:' + TMPFS, '--workdir', '/tmp']
        for variable in environment:
            cmd.extend(('-e', variable))
        for destination, (path, writable) in mounts.items():
            spec = f'type=bind,src={path},dst={destination}'
            cmd.extend(('--mount', spec if writable else spec + ',readonly'))
        guard(deadline)
        created_possible = True
        ident = docker(*cmd, PINS['java_image'], *command).strip()
        info = inspect_container(ident)
        report['container_id'] = ident
        report['binding'] = configuration(info, image_id, mounts, environment, command)
        with (phase / 'container.stdout').open('xb') as stdout, (phase / 'container.stderr').open('xb') as stderr:
            process = subprocess.Popen(['docker', 'start', '-a', ident], stdout=stdout, stderr=stderr)
            while process.poll() is None:
                guard(deadline)
                log_bytes = os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size
                require(log_bytes < 8 << 20, 'container output cap')
                time.sleep(0.25)
            report['attach_exit'] = process.wait()
        state = inspect_container(ident)['State']
        report.update(exit_code=state['ExitCode'], oom_killed=state['OOMKilled'], running=state['Running'])
        require(report['attach_exit'] == report['exit_code'] == 0
                and not report['oom_killed'] and not report['running'], 'container did not exit normally')
        guard(deadline)
        source_identity(args.freeze_sha256)
        if setup:
            logs = (phase/'container.stdout').read_text() + (phase/'container.stderr').read_text()
            require(PINS['java_version'] in logs and 'javac 21.0.13' in logs, 'wrong Temurin compiler')
            require(sha(jar) == jar_hash, 'compiled against changed jar')
            classes = {path.name: sha(path) for path in sorted((runtime_dir/'classes').glob('*.class'))}
            require('BlazegraphProbe.class' in classes, 'compiled adapter not found')
            manifest = runtime_dir / 'RUNTIME.json'
            write(manifest, {'jar_sha256': jar_hash, 'classes': classes,
                             'java_version': PINS['java_version'], 'image_id': image_id,
                             'freeze_sha256': args.freeze_sha256, 'jvm_module_flags': [],
                             'rdf_data_opened': False})
            report['runtime_sha256'] = sha(manifest)
        else:
            runtime_identity(runtime_dir, jar, args.freeze_sha256, args.runtime_sha256)
            report['runtime_sha256'] = args.runtime_sha256
            for profile in ('default', 'no-xsd-inline'):
                require((phase / 'out' / profile / 'load.exit').is_file(), 'load receipt missing')
    except BaseException as exc:
        report['error'] = repr(exc)
    finally:
        try:
            report['cleanup'] = cleanup(name, created_possible, process)
            lock()
        except BaseException as exc:
            report.update(cleanup='unverified', cleanup_error=repr(exc))
        write(phase / 'SUPERVISOR.json', report)
    return int('error' in report or report['cleanup'] != 'verified-removed')


def interrupted(signum, frame):
    raise RuntimeError(f'host supervisor received signal {signum}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('stage', choices=('setup', 'storage'))
    parser.add_argument('--freeze-sha256', required=True)
    parser.add_argument('--runtime-sha256')
    for sig in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    raise SystemExit(run(parser.parse_args()))
