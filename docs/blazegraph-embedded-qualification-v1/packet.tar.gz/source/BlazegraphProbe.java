import com.bigdata.journal.Options;
import com.bigdata.rdf.axioms.NoAxioms;
import com.bigdata.rdf.internal.ILexiconConfiguration;
import com.bigdata.rdf.sail.BigdataSail;
import com.bigdata.rdf.sail.BigdataSailRepository;
import com.bigdata.rdf.sail.BigdataSailRepositoryConnection;
import com.bigdata.rdf.store.AbstractTripleStore;

import org.openrdf.model.BNode;
import org.openrdf.model.Literal;
import org.openrdf.model.Statement;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.query.BindingSet;
import org.openrdf.query.QueryLanguage;
import org.openrdf.query.TupleQuery;
import org.openrdf.query.TupleQueryResult;
import org.openrdf.repository.RepositoryResult;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFParser;
import org.openrdf.rio.Rio;
import org.openrdf.rio.helpers.BasicParserSettings;
import org.openrdf.rio.helpers.StatementCollector;

import java.io.BufferedWriter;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Properties;

public final class BlazegraphProbe {
    private static final String PATTERN = " <urn:s> <urn:v> ?o ";
    private static final String SELECT = "SELECT ?o WHERE {" + PATTERN + "}";
    private static final String FILTER_FALSE = "SELECT ?o WHERE {" + PATTERN + "FILTER(false) }";
    private static final String ASK_FALSE = "ASK WHERE { <urn:absent> <urn:v> ?o }";
    private static final Path FIXTURE = Path.of("/src/consumer-fixture.nt");

    private record Output(BufferedWriter writer) {
        void line(String... fields) throws Exception {
            writer.write(String.join("\t", fields));
            writer.newLine();
            writer.flush();
        }

        void fact(String name, Object value) throws Exception {
            line("fact", name, encode(String.valueOf(value)));
        }

        void triple(String stage, Statement statement) throws Exception {
            line("triple", stage, term(statement.getSubject()), term(statement.getPredicate()),
                 term(statement.getObject()));
        }
    }

    private static String encode(String text) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    private static String term(Value value) {
        if (value == null) return "unbound";
        if (value instanceof URI) return "iri:" + encode(value.stringValue());
        if (value instanceof BNode) return "bnode:" + encode(value.stringValue());
        if (value instanceof Literal literal) {
            URI datatype = literal.getDatatype();
            String language = literal.getLanguage();
            return "literal:" + encode(literal.getLabel()) + ":"
                + encode(datatype == null ? "" : datatype.stringValue()) + ":"
                + encode(language == null ? "" : language);
        }
        throw new IllegalArgumentException("Unexpected RDF term " + value.getClass().getName());
    }

    private static List<Statement> parse(Output output) throws Exception {
        List<Statement> statements = new ArrayList<>();
        RDFParser parser = Rio.createParser(RDFFormat.NTRIPLES);
        parser.getParserConfig().set(BasicParserSettings.NORMALIZE_DATATYPE_VALUES, false);
        output.fact("parser_normalize_datatype_values",
                    parser.getParserConfig().get(BasicParserSettings.NORMALIZE_DATATYPE_VALUES));
        parser.setRDFHandler(new StatementCollector(statements));
        try (InputStream input = Files.newInputStream(FIXTURE)) {
            parser.parse(input, "urn:fixture:");
        }
        for (Statement statement : statements) output.triple("parsed", statement);
        return statements;
    }

    private static Properties settings(Path journal, boolean disableInlining) {
        Properties properties = new Properties();
        properties.setProperty(Options.FILE, journal.toString());
        properties.setProperty(Options.BUFFER_MODE, "DiskRW");
        properties.setProperty(BigdataSail.Options.NAMESPACE, "blazegraph39");
        properties.setProperty(BigdataSail.Options.TRUTH_MAINTENANCE, "false");
        properties.setProperty(AbstractTripleStore.Options.QUADS, "false");
        properties.setProperty(AbstractTripleStore.Options.STATEMENT_IDENTIFIERS, "false");
        properties.setProperty(AbstractTripleStore.Options.AXIOMS_CLASS, NoAxioms.class.getName());
        properties.setProperty(AbstractTripleStore.Options.TEXT_INDEX, "false");
        if (disableInlining)
            properties.setProperty(AbstractTripleStore.Options.INLINE_XSD_DATATYPE_LITERALS, "false");
        return properties;
    }

    private static void select(BigdataSailRepositoryConnection connection, Output output,
                               String name, String sparql) throws Exception {
        TupleQuery query = connection.prepareTupleQuery(QueryLanguage.SPARQL, sparql);
        query.setIncludeInferred(false);
        TupleQueryResult result = query.evaluate();
        try {
            List<String> variables = result.getBindingNames();
            output.line("vars", name, String.join(",", variables));
            while (result.hasNext()) {
                BindingSet row = result.next();
                List<String> fields = new ArrayList<>();
                fields.add("row");
                fields.add(name);
                for (String variable : variables) fields.add(term(row.getValue(variable)));
                output.line(fields.toArray(String[]::new));
            }
        } finally {
            result.close();
        }
    }

    private static void observe(Output output, String profile, String boundary, Path journal) throws Exception {
        boolean load = boundary.equals("load");
        if (Files.isSymbolicLink(journal) || load == Files.exists(journal))
            throw new IllegalArgumentException("wrong journal lifecycle path");
        output.fact("profile", profile);
        output.fact("boundary", boundary);
        output.fact("java_version", System.getProperty("java.runtime.version"));
        output.fact("java_arch", System.getProperty("os.arch"));
        output.fact("options_inline_xsd_override", profile.equals("no-xsd-inline") ? "false" : "absent");

        output.fact("step", "parse");
        List<Statement> statements = load ? parse(output) : List.of();
        output.fact("step", "construct");
        Properties properties = settings(journal, profile.equals("no-xsd-inline"));
        BigdataSail sail = new BigdataSail(properties);
        BigdataSailRepository repository = new BigdataSailRepository(sail);
        output.fact("step", "initialize");
        try {
            repository.initialize();
            BigdataSailRepositoryConnection connection = repository.getConnection();
            try {
                AbstractTripleStore store = connection.getTripleStore();
                ILexiconConfiguration<?> lexicon = store.getLexiconRelation().getLexiconConfiguration();
                output.fact("inline_xsd", lexicon.isInlineLiterals());
                output.fact("inline_text", lexicon.isInlineTextLiterals());
                output.fact("inline_datetimes", lexicon.isInlineDateTimes());
                output.fact("inline_max_string_length", lexicon.getMaxInlineStringLength());
                output.fact("inline_bnodes_option",
                    store.getProperties().getProperty(AbstractTripleStore.Options.INLINE_BNODES,
                        AbstractTripleStore.Options.DEFAULT_INLINE_BNODES));
                output.fact("axioms_class", store.getAxioms().getClass().getName());
                output.fact("step", "store");
                if (load) {
                    connection.setAutoCommit(false);
                    for (Statement statement : statements) connection.add(statement);
                    connection.commit();
                    output.fact("commit_returned", true);
                }
                output.fact("store_count", connection.size());
                RepositoryResult<Statement> triples = connection.getStatements(null, null, null, false);
                try {
                    while (triples.hasNext()) output.triple("stored", triples.next());
                } finally {
                    triples.close();
                }
                output.fact("step", "select");
                select(connection, output, "reference", SELECT);
                output.fact("step", "filter_false");
                select(connection, output, "filter_false", FILTER_FALSE);
                output.fact("step", "ask_false");
                var ask = connection.prepareBooleanQuery(QueryLanguage.SPARQL, ASK_FALSE);
                ask.setIncludeInferred(false);
                output.fact("ask_false_result", ask.evaluate());
            } finally {
                connection.close();
                output.fact("connection_closed", true);
            }
        } finally {
            repository.shutDown();
            output.fact("shutdown_returned", true);
        }
        output.fact("step", "complete");
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 4 || !List.of("default", "no-xsd-inline").contains(args[0])
            || !List.of("load", "reopen").contains(args[1]))
            throw new IllegalArgumentException("profile boundary journal observation");
        try (BufferedWriter writer = Files.newBufferedWriter(Path.of(args[3]), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE_NEW)) {
            observe(new Output(writer), args[0], args[1], Path.of(args[2]));
        }
    }
}
