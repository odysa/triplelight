#!/bin/sh
set -eu
test "$(cat /guard/owner)" = "Jianlin task39 Blazegraph stable v1"
test "$(uname -m)" = aarch64
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS
for profile in default no-xsd-inline; do
    dir="/out/$profile"
    mkdir "$dir"
    journal="$dir/private.jnl"
    for step in load reopen; do
        if test "$step" = reopen; then
            if test "$(cat "$dir/load.exit")" != 0 || ! test -s "$journal"; then
                printf '%s\n' skipped-after-load-error > "$dir/reopen.skipped"
                break
            fi
            sha256sum "$journal" > "$dir/reopen.before.sha256"
            cmp "$dir/load.after.sha256" "$dir/reopen.before.sha256"
        fi
        status=0
        java -Xms64m -Xmx512m -XX:ActiveProcessorCount=2 \
            -cp /artifact/blazegraph.jar:/runtime/classes BlazegraphProbe "$profile" "$step" \
            "$journal" "$dir/$step.tsv" > "$dir/$step.stdout" 2> "$dir/$step.stderr" || status=$?
        printf '%s\n' "$status" > "$dir/$step.exit"
        if test -f "$journal"; then
            test ! -L "$journal"
            sha256sum "$journal" > "$dir/$step.after.sha256"
            wc -c < "$journal" > "$dir/$step.after.bytes"
        fi
    done
done
