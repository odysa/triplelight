# Blazegraph execution

Verify `FREEZE.json`, the live machine handoff and a fresh `/private/tmp/rdf-jianlin-blazegraph39-v1`. The exact lock owner is `Jianlin task39 Blazegraph stable v1`. Require the 40 GB host floor and inspect the pinned ARM64 Temurin image while holding the lock. The approved image is already used by the JVM qualification. Pull only the exact image if missing.

```bash
rtk proxy python3 -E -s -B scratch/blazegraph39-plan-v1/supervise.py setup --freeze-sha256 <freeze>
```

Setup downloads the Maven artifact against the expected ETag and checks the declared size and publisher SHA-1, the manifest and six class hashes. It compiles the frozen source with the pinned JVM and reads no RDF data. The setup receipt binds the calculated jar SHA-256, class digests, compiler, image and freeze. Announce the ready runtime digest before storage.

```bash
rtk proxy python3 -E -s -B scratch/blazegraph39-plan-v1/supervise.py storage --freeze-sha256 <freeze> --runtime-sha256 <runtime>
```

Storage receives the artifact and compiled code read-only. The four Java processes run sequentially, each with 512 MiB heap on two CPUs. Load and reopen pass the identical profile properties and private root. Reopen requires the journal from a successful, closed load and verifies the digest before opening. The Java program records the last reached stage as it runs, with separate exit and journal receipts after its process exits. Captured failures preserve the status and logs. No extra module-opening options are used. The host gives setup 180 seconds and storage 120 seconds, checks the network, mounts, image and resource limits, and verifies removal of its exact labeled container before the caller releases the lock.

The engine-free replay reads `setup/`, `runtime/`, `storage/` and a frozen `source/` directory in a retained packet. It independently parses the fixture's N-Triples term bag and cross-checks the retained Jena reference. There is no HTTP server or timing workload.
