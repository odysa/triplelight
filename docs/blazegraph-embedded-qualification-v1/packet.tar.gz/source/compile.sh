#!/bin/sh
set -eu
test "$(cat /guard/owner)" = "Jianlin task39 Blazegraph stable v1"
test "$(uname -m)" = aarch64
unset JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS
java -version
javac -version
mkdir /runtime/classes
javac -cp /artifact/blazegraph.jar -d /runtime/classes /src/BlazegraphProbe.java
