"""Replay embedded Blazegraph fixture evidence without loading the engine."""
import argparse
from base64 import urlsafe_b64decode
from collections import Counter
from hashlib import file_digest
import json
from pathlib import Path

XSD = 'http://www.w3.org/2001/XMLSchema#'
LANG = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString'
S = ('iri', 'urn:s', '', '')
P = ('iri', 'urn:v', '', '')
PROFILES = ('default', 'no-xsd-inline')
BOUNDARIES = ('load', 'reopen')


def digest(path):
    with path.open('rb') as stream:
        return file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def decode(token):
    return urlsafe_b64decode(token + '=' * ((-len(token)) % 4)).decode()


def typed(kind, value, datatype='', language=''):
    if kind == 'literal' and not datatype:
        datatype = LANG if language else XSD + 'string'
    return kind, value, datatype, language.lower()


def term(raw):
    if raw == 'unbound':
        return ('unbound', '', '', '')
    kind, *parts = raw.split(':')
    assert len(parts) == (3 if kind == 'literal' else 1) and kind in ('literal', 'iri', 'bnode')
    return typed(kind, *(decode(part) for part in parts))


def object_key(raw):
    if raw.startswith('<') and raw.endswith('>'):
        return typed('iri', raw[1:-1])
    value, end = json.JSONDecoder().raw_decode(raw)
    assert isinstance(value, str)
    suffix = raw[end:]
    if suffix.startswith('@'):
        return typed('literal', value, language=suffix[1:])
    if suffix.startswith('^^<') and suffix.endswith('>'):
        return typed('literal', value, suffix[3:-1])
    assert not suffix
    return typed('literal', value)


def reference(root):
    result = Counter()
    prefix = '<urn:s> <urn:v> '
    for line in (root/'consumer-fixture.nt').read_text().splitlines():
        assert line.startswith(prefix) and line.endswith(' .')
        result[S, P, object_key(line[len(prefix):-2])] += 1
    jena = load(root/'consumer-fixture-jena.json')['results']['bindings']
    expected = Counter((S, P, typed('iri' if o['type'] == 'uri' else 'literal', o['value'],
                                  o.get('datatype', ''), o.get('xml:lang', '')))
                       for binding in jena for o in [binding['o']])
    assert result == expected and len(result) == sum(result.values()) == 9
    return result


def observe(path):
    facts, triples, variables, rows = {}, {}, {}, {}
    for line in path.read_text().splitlines():
        kind, name, *rest = line.split('\t')
        if kind == 'fact':
            assert len(rest) == 1
            assert name == 'step' or name not in facts
            facts[name] = decode(rest[0])
        elif kind == 'triple':
            assert len(rest) == 3
            triples.setdefault(name, Counter())[tuple(map(term, rest))] += 1
        elif kind == 'vars':
            assert len(rest) == 1 and name not in variables
            variables[name] = rest[0].split(',') if rest[0] else []
        else:
            assert kind == 'row' and name in variables and len(rest) == len(variables[name])
            rows.setdefault(name, Counter())[tuple(map(term, rest))] += 1
    return facts, triples, variables, rows


def differences(wanted, result):
    return {'exact': wanted == result, 'rows': sum(result.values()),
            'missing': sorted((wanted-result).items()), 'extra': sorted((result-wanted).items())}


def phase(root, boundary, profile, expected):
    skipped = root/(boundary + '.skipped')
    if skipped.exists():
        assert boundary == 'reopen'
        return {'state': skipped.read_text().strip()}
    status = int((root/(boundary + '.exit')).read_text())
    result = {'exit': status}
    tsv = root/(boundary + '.tsv')
    if not tsv.exists():
        assert status
        return result
    facts, triples, variables, rows = observe(tsv)
    assert facts['profile'] == profile and facts['boundary'] == boundary
    result.update(facts=facts, projection=variables)
    after = root/(boundary + '.after.sha256')
    if after.exists():
        result['journal'] = {'sha256': after.read_text().split()[0],
                             'bytes': int((root/(boundary+'.after.bytes')).read_text())}
    if boundary == 'reopen':
        actual = (root/'reopen.before.sha256').read_text()
        assert actual == (root/'load.after.sha256').read_text()
    if 'parsed' in triples:
        result['parsed'] = differences(expected, triples['parsed'])
    if 'stored' in triples:
        result['stored'] = differences(expected, triples['stored'])
    if status:
        return result
    assert facts['step'] == 'complete' and facts['connection_closed'] == facts['shutdown_returned'] == 'true'
    assert facts['inline_xsd'] == ('true' if profile == 'default' else 'false')
    assert facts['axioms_class'] == 'com.bigdata.rdf.axioms.NoAxioms'
    if boundary == 'load':
        assert facts['parser_normalize_datatype_values'] == 'false'
        assert facts['commit_returned'] == 'true'
    objects = Counter((row[2],) for row in expected.elements())
    assert facts['java_arch'] == 'aarch64' and facts['java_version'].startswith('21.0.13+9')
    result['checks'] = {'count': facts['store_count'] == '9',
                        'stored_exact': result.get('stored', {}).get('exact', False),
                        'projection': variables.get('reference') == ['o'],
                        'query_exact': rows.get('reference', Counter()) == objects,
                        'filter_false': variables.get('filter_false') == ['o'] and not rows.get('filter_false'),
                        'ask_false': facts['ask_false_result'] == 'false'}
    if boundary == 'load':
        result['checks']['parsed_exact'] = result.get('parsed', {}).get('exact', False)
        result['store_to_parser'] = differences(triples.get('parsed', Counter()), triples.get('stored', Counter()))
    result['select'] = differences(objects, rows.get('reference', Counter()))
    result['filter_false_rows'] = sum(rows.get('filter_false', Counter()).values())
    assert result['journal']['bytes'] > 0
    return result


def main(root):
    source = root/'source'
    freeze = digest(source/'FREEZE.json')
    for name, expected in load(source/'FREEZE.json').items():
        assert digest(source/name) == expected, name
    expected = reference(source)
    setup = load(root/'setup/SUPERVISOR.json')
    assert setup['source_sha256'] == freeze and setup['cleanup'] in ('verified-removed', 'not-created')
    summary = {'source_sha256': freeze, 'setup_error': setup.get('error')}
    if setup.get('error'):
        return summary
    runtime = root/'runtime/RUNTIME.json'
    assert digest(runtime) == setup['runtime_sha256']
    data = load(runtime)
    assert data['rdf_data_opened'] is False and data['jvm_module_flags'] == []
    assert data['freeze_sha256'] == freeze and data['java_version'] == '21.0.13+9'
    summary.update(runtime_sha256=digest(runtime), jar_sha256=data['jar_sha256'])
    storage = load(root/'storage/SUPERVISOR.json')
    assert storage['source_sha256'] == freeze and storage['cleanup'] in ('verified-removed', 'not-created')
    summary['storage_error'] = storage.get('error')
    if storage.get('error'):
        return summary
    assert storage['runtime_sha256'] == summary['runtime_sha256']
    summary['profiles'] = {profile: {boundary: phase(root/'storage/out'/profile, boundary, profile, expected)
                                     for boundary in BOUNDARIES} for profile in PROFILES}
    return summary


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('packet', type=Path)
    args = parser.parse_args()
    print(json.dumps(main(args.packet), indent=2, sort_keys=True))
