"""Replay the retained comparator checks using Python's standard library."""

from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(relative):
    return json.loads((ROOT / relative).read_text())


def verify_inputs():
    manifest = {}
    for line in (ROOT / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if name in manifest:
            raise ValueError(f"duplicate manifest entry: {name}")
        manifest[name] = expected
        path = ROOT / name
        if path.is_symlink() or not path.resolve().is_relative_to(ROOT) or sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f"artifact digest mismatch: {name}")
    files = {path.relative_to(ROOT).as_posix() for path in ROOT.rglob("*") if path.is_file()}
    if set(manifest) != files - {"AUDIT.json", "SHA256SUMS"}:
        raise ValueError("manifest does not cover the complete packet")


def typed_bag(answer, variables):
    if answer["head"]["vars"] != variables:
        raise ValueError("binding names or order differ")
    bag = Counter()
    for row in answer["results"]["bindings"]:
        if row.keys() - set(variables):
            raise ValueError("undeclared binding")
        cells = []
        for variable in variables:
            term = row.get(variable)
            if term is None:
                cells.append(None)
                continue
            datatype = term.get("datatype")
            if datatype == "http://www.w3.org/2001/XMLSchema#string":
                datatype = None
            cells.append((term["type"], term["value"], datatype, term.get("xml:lang")))
        bag[tuple(cells)] += 1
    return bag


def replay_distinct(record, reference):
    if record["columns"] != ["v_o", "d_o"] or record["sql_types"] != ["VARCHAR", "VARCHAR"]:
        raise ValueError("DISTINCT tag columns differ")
    rows = []
    for lexical, tag in record["rows"]:
        if tag == "I":
            term = {"type": "uri", "value": lexical}
        elif tag.startswith("@") and len(tag) > 1:
            term = {"type": "literal", "value": lexical, "xml:lang": tag[1:]}
        elif tag.startswith("D") and len(tag) > 1:
            term = {"type": "literal", "value": lexical, "datatype": tag[1:]}
        else:
            raise ValueError("unrecognized DuckDB DISTINCT tag")
        rows.append({"o": term})
    actual = {"head": {"vars": ["o"]}, "results": {"bindings": rows}}
    expected = {
        "head": {"vars": ["o"]},
        "results": {"bindings": [{"o": item["o"]} for item in reference["results"]["bindings"]]},
    }
    return typed_bag(actual, ["o"]) == typed_bag(expected, ["o"])


def replay_duck():
    final = read("duck-v3/FINAL.json")
    if "stop" in final:
        return {"completed": False, "stop": final["stop"]}
    runtime = read("duck-v3/results/RUNTIME.json")
    install = read("duck-v3/results/install/RECEIPT.json")
    if (runtime["unsigned_extensions_enabled"] is not False
            or install["repository"] != "community"
            or install["binary_sha256"] != install["expected_binary_sha256"]
            or runtime["extension_metadata"][0][0] is not True
            or not runtime["extension_metadata"][0][1]):
        raise ValueError("signature enforcement, binary pin, or load metadata differs")

    fixture_spec = importlib.util.spec_from_file_location("frozen_fixture", ROOT / "fixture/run.py")
    fixture = importlib.util.module_from_spec(fixture_spec)
    fixture_spec.loader.exec_module(fixture)
    inputs = read("fixture/inputs.json")
    records = []
    for index, case in enumerate(inputs["cases"]):
        record = read(f"duck-v3/results/case-{index:02}.json")
        if record["id"] != case["id"] or record["query"] != case["query"]:
            raise ValueError("case identity differs")
        mapping = ROOT / "fixture" / (case["mapping"] + ".ttl")
        if sha256(mapping.read_bytes()).hexdigest() != record["mapping_sha256"]:
            raise ValueError("mapping digest differs")
        if "error" not in record:
            actual = fixture.checks(case, record["columns"], record["rows"], inputs)
            if actual != record["checks"]:
                raise ValueError("saved row checks differ from replay")
        records.append(record)
    distinct = next(record for record in records if record["id"] == "distinct-nine")
    distinct_exact = replay_distinct(distinct, read("fixture/consumer-fixture-jena.json"))
    passed = fixture.admission(records, inputs["cases"], "duckdb")
    if passed != final["qualification"]["necessary_fixture_checks_pass"]:
        raise ValueError("saved DuckDB verdict differs from replay")
    return {
        "completed": True,
        "cases": len(records),
        "tagged_distinct_exact_typed_bag": distinct_exact,
        "failed_cases": [record["id"] for record in records if "translation_error" in record
                         or "error" in record or not all(record["checks"].values())],
        "necessary_fixture_checks_pass": passed,
    }


def replay_fusion():
    final = read("rdf-fusion-v3/FINAL.json")
    if "stop" in final:
        return {"completed": False, "stop": final["stop"]}
    load = read("rdf-fusion-v3/load/stdout.txt")
    reopen = read("rdf-fusion-v3/reopen/stdout.txt")
    if load != {"stage": "load", "quads": 9} or reopen != {"stage": "reopen", "quads": 9}:
        raise ValueError("load or reopen receipt differs")
    reference = read("fixture/consumer-fixture-jena.json")
    query = read("rdf-fusion-v3/query/stdout.txt")
    if query["stage"] != "query":
        raise ValueError("unexpected RDF Fusion query receipt")
    columns = reference["head"]["vars"]
    actual_bag = typed_bag(query["result"], columns)
    exact = actual_bag == typed_bag(reference, columns)
    if exact != final["qualification"]["exact_typed_bag"]:
        raise ValueError("saved RDF Fusion verdict differs from replay")
    return {"completed": True, "quads": 9, "rows": actual_bag.total(), "exact_typed_bag": exact}


def main():
    verify_inputs()
    initial = read("duck-v2/FINAL.json")
    provenance = read("PROVENANCE.json")
    for arm, expected in provenance.items():
        final = read(f"{arm}/FINAL.json")
        if final["scored"] is not False or final["registration_sha256"] != expected["registration_sha256"]:
            raise ValueError(f"invalid registration or scoring receipt: {arm}")
        if any(stage["group_clear"] is not True for stage in final["stages"].values()):
            raise ValueError(f"process cleanup receipt missing: {arm}")
    first_error = (ROOT / "duck-v2/duck/stderr.txt").read_text()
    if "stop" not in initial or "signature is either missing or invalid" not in first_error:
        raise ValueError("initial DuckDB signature failure missing")
    fusion_initial = read("rdf-fusion-v2/FINAL.json")
    if (read("rdf-fusion-v2/load/stdout.txt") != {"quads": 9, "stage": "load"}
            or "reopen exited 1" not in fusion_initial.get("stop", "")
            or "persistent DeltaQuads log missing" not in (ROOT / "rdf-fusion-v2/reopen/stderr.txt").read_text()):
        raise ValueError("initial RDF Fusion load or wrapper stop receipt differs")
    result = {"duck_rdf_v3": replay_duck(), "rdf_fusion_v3": replay_fusion()}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
