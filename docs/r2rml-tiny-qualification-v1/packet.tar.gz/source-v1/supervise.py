#!/usr/bin/env python3
"""One tiny untimed attempt; caller acquires and later releases its own lock."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OWNER = 'Jianlin task46 R2RML tiny qualification v1'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extension', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--freeze-sha256', required=True)
    args = ap.parse_args()
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != OWNER:
        raise SystemExit('own lock required; no execution')
    if hashlib.sha256((HERE / 'FREEZE.json').read_bytes()).hexdigest() != args.freeze_sha256:
        raise SystemExit('freeze mismatch; no execution')
    args.out.mkdir(parents=True, exist_ok=False)
    command = [sys.executable, str(HERE / 'run.py'), '--extension', str(args.extension),
               '--out', str(args.out / 'results'), '--freeze-sha256', args.freeze_sha256]
    receipt = {'command': command, 'scored': False, 'timeout_seconds': 120,
               'lock_owner': OWNER, 'child_exited': False}
    try:
        with (args.out / 'stdout.log').open('wb') as out, (args.out / 'stderr.log').open('wb') as err:
            try:
                # run.py has no subprocess launch. subprocess.run kills and waits on
                # this single owned child before raising TimeoutExpired.
                result = subprocess.run(command, stdout=out, stderr=err, timeout=120)
                receipt.update(exit_code=result.returncode, timed_out=False, child_exited=True)
            except subprocess.TimeoutExpired:
                receipt.update(exit_code=None, timed_out=True, child_exited=True)
    finally:
        (args.out / 'supervisor.json').write_text(json.dumps(receipt, indent=2) + '\n')
    # The caller verifies the receipt and child absence, then releases the exact
    # lock it acquired. This supervisor never removes a lock or another process.
    if receipt.get('timed_out') or receipt.get('exit_code') != 0:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
