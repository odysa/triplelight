#!/usr/bin/env python3
"""Untimed, fixed tiny controls. No installs, downloads, or workload scores."""
import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sqlite3
import sys
from urllib.parse import quote

HERE = Path(__file__).resolve().parent
OWNER = 'Jianlin task46 R2RML tiny qualification v1'
EXT_SHA = '95c96225f67ab44c1011017f9221a2f02a17b37c37578e9b8f871c853947b400'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, obj):
    # Only our new output directory is writable. Flush each case before continuing.
    temp = path.with_suffix('.tmp')
    with temp.open('w') as f:
        json.dump(observed(obj), f, indent=2, default=str, allow_nan=False)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    temp.replace(path)


def canonical(value):
    return json.dumps(observed(value), default=str, ensure_ascii=False, allow_nan=False)


def observed(value):
    """Preserve non-finite SQL observations without emitting invalid JSON."""
    if isinstance(value, float) and not math.isfinite(value):
        return {'float': 'nan' if math.isnan(value) else 'inf' if value > 0 else '-inf'}
    if isinstance(value, dict):
        return {k: observed(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [observed(v) for v in value]
    return value


def checks(case, cols, rows, inputs):
    result = {'row_count': len(rows) == case['expected_rows']}
    expected = case['expected_values']
    if case['id'] == 'group-nine':
        # This is only a necessary lexical/count check. It cannot recover lost types.
        expected = [[v, 1] for _, v in inputs['terms']]
    elif case['id'] in ('project-nine', 'distinct-nine'):
        expected = [[v] for _, v in inputs['terms']]
    if expected is not None:
        normalized = []
        for row in rows:
            row = list(row)
            if case['id'] == 'group-nine' and len(row) == 2:
                row[1] = int(row[1])
            elif case['id'] in ('count-nine', 'distinct-count-nine',
                                'same-term-iri', 'same-term-string', 'lang-en'):
                row = [int(v) for v in row]
            normalized.append(row)
        result['expected_scalar_bag'] = Counter(map(canonical, normalized)) == Counter(map(canonical, expected))
    if case['id'] == 'typed-projection':
        def boolean(v):
            if v in (True, 1, 'true', '1'):
                return True
            if v in (False, 0, 'false', '0'):
                return False
            raise ValueError('invalid boolean result: ' + repr(v))
        ref = json.loads((HERE / 'consumer-fixture-jena.json').read_text())
        expected_typed = []
        for binding in ref['results']['bindings']:
            term = binding['o']
            literal = term['type'] in ('literal', 'typed-literal')
            lang = term.get('xml:lang', '')
            datatype = term.get('datatype') or (
                'http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if lang else
                'http://www.w3.org/2001/XMLSchema#string' if literal else '')
            expected_typed.append([term['value'], term['type'] == 'uri',
                                   term['type'] == 'bnode', datatype, lang])
        actual_typed = [[r[0], boolean(r[1]), boolean(r[2]), r[3] or '', r[4] or ''] for r in rows]
        result['full_rdf_term_projection'] = (
            Counter(map(canonical, actual_typed)) == Counter(map(canonical, expected_typed)))
    if case['id'] == 'empty-projection':
        result['projection'] = cols == ['v_person', 'v_name']
    elif case['id'] == 'employee-optional':
        result['projection'] = cols == ['v_person', 'v_name', 'v_missing']
    return result


def admission(records, cases, engine):
    entries = [r for r in records if r.get('engine') == engine]
    if Counter(r['id'] for r in entries) != Counter(c['id'] for c in cases):
        return False
    if any('translation_error' in r or 'error' in r for r in entries):
        return False
    if any(not r.get('checks') or any(type(v) is not bool or not v for v in r['checks'].values()) for r in entries):
        return False
    typed = [r for r in entries if r['id'] == 'typed-projection']
    return len(typed) == 1 and typed[0]['checks'].get('full_rdf_term_projection') is True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--extension', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--freeze-sha256', required=True)
    args = ap.parse_args()
    if Path('/tmp/rdf-bench.lock/owner').read_text().strip() != OWNER:
        raise SystemExit('own machine lock required')
    freeze_path = HERE / 'FREEZE.json'
    if sha(freeze_path) != args.freeze_sha256:
        raise SystemExit('freeze identity mismatch')
    freeze = json.loads(freeze_path.read_text())
    for name, expected in freeze['files'].items():
        if sha(HERE / name) != expected:
            raise SystemExit('input/source identity mismatch: ' + name)
    extension = args.extension.resolve()
    if sha(extension) != EXT_SHA:
        raise SystemExit('extension identity mismatch')
    import duckdb
    import _duckdb
    import _sqlite3
    if duckdb.__version__ != '1.5.6':
        raise SystemExit('expected DuckDB 1.5.6')
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise SystemExit('this profile is pinned to the existing macOS ARM64 binary')
    args.out.mkdir(parents=True, exist_ok=False)
    inputs = json.loads((HERE / 'inputs.json').read_text())
    identity = {'python': sys.version, 'executable': sys.executable,
                'platform': platform.platform(), 'duckdb': duckdb.__version__,
                'sqlite': sqlite3.sqlite_version, 'extension_sha256': sha(extension),
                'python_binary_sha256': sha(Path(sys.executable).resolve()),
                'duckdb_module_sha256': sha(Path(_duckdb.__file__)),
                'sqlite_module_sha256': sha(Path(_sqlite3.__file__)),
                'freeze_sha256': sha(freeze_path),
                'source_files': freeze['files'], 'scored': False}
    save(args.out / 'identity.json', identity)
    duck = duckdb.connect(':memory:', config={'threads': '1', 'memory_limit': '256MB',
                                             'autoload_known_extensions': 'false',
                                             'autoinstall_known_extensions': 'false'})
    lite = sqlite3.connect(':memory:')
    lite.create_function('url_encode', 1, lambda v: None if v is None else quote(str(v), safe=''), deterministic=True)
    records = []
    try:
        # Explicit local binary; no INSTALL and no mutation of the shared extension tree.
        duck.execute('LOAD ' + "'" + str(extension).replace("'", "''") + "'")
        for con in [duck, lite]:
            for name, value in inputs['terms']:
                con.execute(f'CREATE TABLE term_{name}(lex VARCHAR)')
                con.execute(f'INSERT INTO term_{name} VALUES (?)', [value])
            con.execute('CREATE TABLE duplicate_terms(lex VARCHAR)')
            con.executemany('INSERT INTO duplicate_terms VALUES (?)', [('duplicate',), ('duplicate',)])
            con.execute('CREATE TABLE employee(id INTEGER NOT NULL, name VARCHAR)')
            con.executemany('INSERT INTO employee VALUES (?,?)', [(1, 'Alice'), (2, 'Bob'), (3, None)])
        for case in inputs['cases']:
            translated = {'id': case['id'], 'mapping_sha256': sha(HERE / (case['mapping'] + '.ttl')),
                          'query': case['query'], 'scored': False}
            try:
                sql = duck.execute('SELECT sparql_to_sql(?,?)', [case['query'], str(HERE / (case['mapping'] + '.ttl'))]).fetchone()[0]
                translated['sql'] = sql
            except Exception as e:
                translated['translation_error'] = str(e)
                save(args.out / (case['id'] + '-translation.json'), translated)
                records.append(translated)
                continue
            save(args.out / (case['id'] + '-translation.json'), translated)
            # DuckDB executes through its native extension; SQLite executes the identical
            # generated SQL plus the explicitly declared url_encode UDF. No SQL rewrites.
            for engine, con in [('duckdb', duck), ('sqlite', lite)]:
                record = dict(translated, engine=engine)
                try:
                    if engine == 'duckdb':
                        cur = con.execute('SELECT * FROM execute_sparql(?,?)',
                                          [case['query'], str(HERE / (case['mapping'] + '.ttl'))])
                    else:
                        cur = con.execute(sql)
                    record['columns'] = [c[0] for c in cur.description]
                    record['sql_types'] = [str(c[1]) for c in cur.description]
                    record['rows'] = observed([list(r) for r in cur.fetchall()])
                    record['checks'] = checks(case, record['columns'], record['rows'], inputs)
                    if case['mapping'] == 'terms' and case['id'] in ('group-nine', 'project-nine', 'distinct-nine'):
                        record['limitations'] = ['Native scalar columns alone do not expose RDF kind/datatype/language for this mixed variable; typed-projection is a separate query, not a general result rewriter.']
                except Exception as e:
                    record['error'] = str(e)
                save(args.out / (case['id'] + '-' + engine + '.json'), record)
                records.append(record)
        save(args.out / 'summary.json', {'scored': False, 'records': records,
             'admitted_duckdb': admission(records, inputs['cases'], 'duckdb'),
             'admitted_sqlite': admission(records, inputs['cases'], 'sqlite'),
             'full_workload_qualified': False,
             'note': 'Admission means these tiny necessary controls only, including the explicit typed projection. Native mixed-variable metadata limits remain. No full-workload admission or general typed-result rewriter is delivered.'})
    finally:
        lite.close()
        duck.close()
        save(args.out / 'postflight.json', {'extension_unchanged': sha(extension) == EXT_SHA,
             'frozen_files_unchanged': all(sha(HERE / n) == h for n, h in freeze['files'].items()),
             'connections_closed': True})


if __name__ == '__main__':
    main()
