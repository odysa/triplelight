"""Frozen paths, schedule and process containment shared by the qualification stages."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/private/tmp/rdf-jianlin-rdflib-sqlite39-upstream-compat-v1')
LOCK = Path('/tmp/rdf-bench.lock/owner')
OWNERS = {'setup': 'Jianlin task39 RDFLib SQLite upstream compatibility setup v1',
          'storage': 'Jianlin task39 RDFLib SQLite upstream compatibility storage v1'}
PINS = json.loads((HERE / 'PINS.json').read_bytes())
PROFILES = tuple(PINS['profiles'])
DENY_NETWORK = ['/usr/bin/sandbox-exec', '-p', '(version 1) (allow default) (deny network*)']


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


def lock(stage):
    if LOCK.read_text().strip() != OWNERS[stage]:
        raise RuntimeError(f'exact {stage} owner required')


def source_identity(digest):
    manifest = HERE / 'FREEZE.json'
    if sha(manifest) != digest:
        raise RuntimeError('unregistered source digest')
    files = json.loads(manifest.read_bytes())
    if any(sha(HERE / name) != expected for name, expected in files.items()):
        raise RuntimeError('frozen source or fixture changed')


def guard(stage, deadline):
    lock(stage)
    if time.monotonic() >= deadline:
        raise TimeoutError(f'{stage} deadline')
    if shutil.disk_usage(ROOT).free < 40_000_000_000:
        raise RuntimeError('host free-space floor')
    size = 0
    for path in ROOT.rglob('*'):
        try:
            size += path.stat(follow_symlinks=False).st_blocks * 512
        except FileNotFoundError:
            continue
    limit = (1024 if stage == 'setup' else 2048) * 2**20
    if size >= limit:
        raise RuntimeError(f'{stage} allocation cap')


def run(stage, deadline, command, output, label):
    guard(stage, deadline)
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('PYTHON', 'PIP_', 'DYLD_'))}
    env['TMPDIR'] = str(output / 'tmp')
    with (output / f'{label}.stdout').open('xb') as stdout, (output / f'{label}.stderr').open('xb') as stderr:
        process = subprocess.Popen(DENY_NETWORK + command, env=env, cwd=output,
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while process.poll() is None:
                guard(stage, deadline)
                if os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size >= 8 * 2**20:
                    raise RuntimeError(f'{label} log cap')
                time.sleep(0.2)
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            raise
    guard(stage, deadline)
    return process.returncode
