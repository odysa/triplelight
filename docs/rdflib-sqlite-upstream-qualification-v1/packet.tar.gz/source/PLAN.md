# Original RDFLib-SQLAlchemy 0.5.4 with an explicit pkg_resources provider

The first, declared-dependency environment reached import and stopped with ModuleNotFoundError for pkg_resources. That evidence stays in the original packet. This separately declared environment adds only the setuptools 80.9.0 wheel to the original 0.5.4 profile and retains all its other versions, the same macOS ARM64 CPython 3.12.12 and wheel-only installation. The pinned setuptools wheel contains pkg_resources. The adapter's released source stays unchanged. Use a new private root. Do not install the BrickSchema fork or rerun it for this variant.

Use the previously reviewed setup, worker and supervisor. The common source changes only the dedicated root and stage owner strings. The setup cap is 300 seconds, the storage cap is 120 seconds. Report import, open or add errors at the actual stage. With an eligible setup, test the same default and preserve normalization profiles at load and in a fresh reopening process, including exact typed triple bag, Graph length, journal and schema, and the separate RDFLib FILTER(false) diagnostic. Only a live machine window allows execution.

Expect the original loader to show the same parser normalization difference. The release's length projection needs separate source inspection before attributing any discrepancy. No performance timings or broader admission are planned.

- [Original adapter release](https://pypi.org/project/rdflib-sqlalchemy/0.5.4/)
- [Pinned setuptools release](https://pypi.org/project/setuptools/80.9.0/)
