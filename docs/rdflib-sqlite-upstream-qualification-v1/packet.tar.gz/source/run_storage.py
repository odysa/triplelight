"""Run the two independent SQLite adapters against the same frozen fixture."""
import argparse
import json
from pathlib import Path
import sys
import time

from common import HERE, PINS, PROFILES, ROOT, lock, run, sha, source_identity, write
from storage_worker import BOUNDARIES, NORMALIZATIONS, checks


def inventory(db):
    files = {}
    for path in (db, *(db.with_name(db.name + suffix) for suffix in ('-wal', '-journal', '-shm'))):
        if path.is_symlink() or path.exists() and not path.is_file():
            raise RuntimeError(f'unexpected database entry {path.name}')
        if path.is_file():
            files[path.name] = {'bytes': path.stat().st_size, 'sha256': sha(path)}
    if not files.get(db.name, {}).get('bytes'):
        raise RuntimeError('existing SQLite database missing after loader')
    return files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--setup-sha256', required=True)
    args = parser.parse_args()
    lock('storage')
    if sha(Path(sys.executable)) != PINS['interpreter_sha256']:
        raise RuntimeError('wrong supervisor interpreter')
    setup = ROOT / 'SETUP.json'

    def identities():
        source_identity(args.source_sha256)
        if sha(setup) != args.setup_sha256:
            raise RuntimeError('wrong setup receipt digest')
        data = json.loads(setup.read_bytes())
        if data['source_sha256'] != args.source_sha256 or data['rdf_data_opened'] is not False:
            raise RuntimeError('unexpected setup receipt')
        for profile, status in data['receipts'].items():
            if status['state'] != 'ready':
                continue
            target = ROOT / profile
            runtime = target / 'plugin-import.stdout'
            if sha(runtime) != status['runtime_sha256']:
                raise RuntimeError(f'{profile} runtime manifest changed')
            record = json.loads(runtime.read_bytes())
            python = target / 'venv/bin/python'
            if not python.is_file() or sha(python) != record['python_sha256']:
                raise RuntimeError(f'{profile} interpreter changed')
            module = Path(record['sqlite_module']) if record['sqlite_module'] else python
            if sha(module) != record['sqlite_module_sha256']:
                raise RuntimeError(f'{profile} SQLite driver changed')
            if any(sha(target / 'venv' / name) != digest for name, digest in record['installed'].items()):
                raise RuntimeError(f'{profile} installed runtime changed')
        return data

    before = identities()
    if set(before['receipts']) != set(PROFILES):
        raise RuntimeError('setup is incomplete')
    out = ROOT / 'storage-attempt-1'
    out.mkdir()
    (out / 'tmp').mkdir()
    deadline = time.monotonic() + 120
    receipt = {'source_sha256': args.source_sha256, 'setup_sha256': args.setup_sha256,
               'full_workload_qualified': False, 'observations': [], 'identity_postcheck': False}
    try:
        for profile in PROFILES:
            target = ROOT / profile
            state = before['receipts'][profile]['state']
            for normalization in NORMALIZATIONS:
                name = f'{profile}-{normalization}'
                db = out / f'{name}.sqlite'
                loader = None
                for boundary in BOUNDARIES:
                    record = {'profile': profile, 'normalization': normalization, 'boundary': boundary}
                    receipt['observations'].append(record)
                    if state != 'ready':
                        record.update(state='skipped-setup', setup_outcome=state)
                        continue
                    if boundary == 'reopen':
                        if loader is None:
                            record['state'] = 'skipped-incomplete-load'
                            continue
                        record['before_reopen_files'] = inventory(db)
                    label = f'{name}-{boundary}'
                    raw_path = out / f'{label}.json'
                    command = [str(target / 'venv/bin/python'), '-E', '-s', '-B', str(HERE / 'storage_worker.py'),
                               '--profile', profile, '--normalization', normalization, '--boundary', boundary,
                               '--db', str(db), '--out', str(raw_path)]
                    record['worker_exit'] = run('storage', deadline, command, out, label)
                    if record['worker_exit']:
                        record['state'] = 'worker-error'
                        continue
                    raw = json.loads(raw_path.read_bytes())
                    if (raw['profile'], raw['normalization'], raw['boundary']) != (profile, normalization, boundary):
                        raise RuntimeError('raw observation identity mismatch')
                    record['record'] = raw_path.name
                    if raw.get('step') != 'complete' or 'error' in raw or raw.get('closed') is not True:
                        record.update(state='adapter-error', failed_step=raw['step'])
                        continue
                    expected = checks(raw)
                    if raw['checks'] != expected:
                        raise RuntimeError('raw store check mismatch')
                    identity = json.loads((target / 'plugin-import.stdout').read_bytes())
                    if raw['sqlite_version'] != identity['sqlite_version']:
                        raise RuntimeError('storage worker SQLite version changed')
                    record.update(state='observed', storage_checks=expected, tables=raw['tables'],
                                  shared_evaluator_pass=raw['shared_evaluator']['passes'])
                    if boundary == 'load':
                        loader = raw
                    if boundary == 'reopen':
                        record['same_sqlite_tables'] = loader['tables'] == raw['tables']
        identities()
        lock('storage')
        receipt['identity_postcheck'] = True
    finally:
        write(out / 'SUPERVISOR.json', receipt)


if __name__ == '__main__':
    main()
