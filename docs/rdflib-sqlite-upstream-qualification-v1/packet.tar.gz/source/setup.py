"""Install two pinned, isolated SQLite plugin environments without graph operations."""
import argparse
import base64
import importlib.metadata
import inspect
import json
from pathlib import Path
import platform
import sqlite3
import sys
import time
from urllib.request import urlopen

from common import HERE, PINS, PROFILES, ROOT, guard, lock, run, sha, source_identity, write


def probe(profile):
    import rdflib
    from rdflib.store import Store
    from rdflib_sqlalchemy.store import SQLAlchemy
    import _sqlite3
    import sqlalchemy

    packages = [PINS['wheels'][name] for name in PINS['profiles'][profile]]
    installed = {}
    runtime_root = Path(sys.prefix).resolve()
    for pkg in packages:
        dist = importlib.metadata.distribution(pkg['name'])
        if dist.version != pkg['version'] or not dist.files:
            raise RuntimeError(f'unexpected distribution {pkg["name"]}')
        for item in dist.files:
            path = Path(dist.locate_file(item)).resolve(strict=True)
            if not path.is_relative_to(runtime_root):
                raise RuntimeError(f'RECORD path outside environment {item}')
            digest = sha(path)
            if item.hash:
                encoded = base64.urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip('=')
                if item.hash.mode != 'sha256' or encoded != item.hash.value or item.size != path.stat().st_size:
                    raise RuntimeError(f'installed RECORD mismatch {item}')
            elif not str(item).endswith('.dist-info/RECORD'):
                raise RuntimeError(f'unsigned RECORD entry {item}')
            installed[str(path.relative_to(runtime_root))] = digest
    package_key = PINS['profiles'][profile][0]
    released = json.loads((HERE / 'WHEEL_SOURCE_INSPECTION.json').read_bytes())[package_key]
    plugin_dir = Path(inspect.getfile(SQLAlchemy)).resolve().parent
    for name, hashes in released['code'].items():
        if sha(plugin_dir / Path(name).name) != hashes['wheel_sha256']:
            raise RuntimeError(f'installed plugin source mismatch {name}')
    if rdflib.plugin.get('SQLAlchemy', Store) is not SQLAlchemy:
        raise RuntimeError('plugin registration mismatch')
    sqlite_origin = getattr(_sqlite3, '__file__', None)
    return {'profile': profile, 'installed': installed, 'sqlite_version': sqlite3.sqlite_version,
            'sqlite_module_sha256': sha(Path(sqlite_origin or sys.executable)), 'sqlite_module': sqlite_origin,
            'sqlalchemy_version': sqlalchemy.__version__, 'python': sys.version,
            'python_sha256': sha(Path(sys.executable))}


def setup(digest):
    lock('setup')
    source_identity(digest)
    if (sys.version_info[:3] != (3, 12, 12) or platform.system() != 'Darwin' or platform.machine() != 'arm64'
            or sha(Path(sys.executable)) != PINS['interpreter_sha256']):
        raise RuntimeError('wrong setup interpreter')
    ROOT.mkdir()
    wheels = ROOT / 'wheels'
    wheels.mkdir()
    deadline = time.monotonic() + 300
    receipts = {}
    try:
        for profile in PROFILES:
            target = ROOT / profile
            target.mkdir()
            (target / 'tmp').mkdir()
            receipts[profile] = {'state': 'downloads'}
            paths = []
            for key in PINS['profiles'][profile]:
                wheel = PINS['wheels'][key]
                path = wheels / wheel['filename']
                guard('setup', deadline)
                if not path.exists():
                    with urlopen(wheel['url'], timeout=15) as response, path.open('xb') as out:
                        data = response.read(wheel['bytes'] + 1)
                        out.write(data)
                if path.stat().st_size != wheel['bytes'] or sha(path) != wheel['sha256']:
                    raise RuntimeError(f'wheel identity mismatch {key}')
                paths.append(str(path))
            python = str(target / 'venv/bin/python')
            pip = [python, '-I', '-B', '-m', 'pip', '--isolated', '--disable-pip-version-check',
                   '--no-cache-dir']
            commands = {
                'venv': [sys.executable, '-I', '-B', '-m', 'venv', str(target / 'venv')],
                'install': pip + ['install', '--no-index', '--no-deps', '--no-compile', '--only-binary=:all:', *paths],
                'pip-check': pip + ['check'],
                'plugin-import': [python, '-E', '-s', '-B', str(HERE / 'setup.py'), '--probe', profile],
            }
            for step, command in commands.items():
                receipts[profile]['state'] = step
                exit_code = run('setup', deadline, command, target, step)
                receipts[profile]['exit'] = exit_code
                if exit_code:
                    receipts[profile]['state'] = f'{step}-failed'
                    break
            else:
                receipts[profile]['state'] = 'ready'
                receipts[profile]['runtime_sha256'] = sha(target / 'plugin-import.stdout')
        source_identity(digest)
    finally:
        write(ROOT / 'SETUP.json', {'receipts': receipts, 'source_sha256': digest, 'rdf_data_opened': False})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--source-sha256')
    group.add_argument('--probe', choices=PROFILES)
    args = parser.parse_args()
    if args.probe:
        lock('setup')
        print(json.dumps(probe(args.probe), indent=2, sort_keys=True))
    else:
        setup(args.source_sha256)
