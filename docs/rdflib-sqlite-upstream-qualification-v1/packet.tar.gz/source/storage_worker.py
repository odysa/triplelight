"""Record one RDFLib SQLAlchemy SQLite storage observation or failed stage."""
import argparse
from collections import Counter
from contextlib import closing
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
from unittest.mock import patch

from common import HERE, PINS, PROFILES, lock, sha, write

STORE = 'urn:triplelight:qualification:rdflib-sqlite39:store'
GRAPH = 'urn:triplelight:qualification:rdflib-sqlite39:graph'
TABLE_PREFIX = 'kb_' + hashlib.sha1(STORE.encode('utf-8')).hexdigest()[:10]
NORMALIZATIONS = ('default', 'preserve')
BOUNDARIES = ('load', 'reopen')
FILTER_FALSE = 'SELECT ?o WHERE { <urn:s> <urn:v> ?o FILTER(false) }'


def term_key(term):
    if term['type'] == 'uri':
        return 'uri', term['value'], '', ''
    language = term.get('language', term.get('xml:lang', '')).lower()
    datatype = term.get('datatype') or ('http://www.w3.org/1999/02/22-rdf-syntax-ns#langString' if language
                                        else 'http://www.w3.org/2001/XMLSchema#string')
    return 'literal', term['value'], datatype, language


def checks(record):
    reference = json.loads((HERE / 'consumer-fixture-jena.json').read_text())
    expected = Counter(('urn:s', 'urn:v', term_key(row['o'])) for row in reference['results']['bindings'])
    rows = Counter((row['s'], row['p'], term_key(row['o'])) for row in record['triples'])
    return {'count': type(record['count']) is int and record['count'] == 9, 'exact_triple_bag': rows == expected}


def observe(args, record):
    import rdflib
    from rdflib.store import Store, VALID_STORE
    from rdflib_sqlalchemy.store import SQLAlchemy

    if rdflib.plugin.get('SQLAlchemy', Store) is not SQLAlchemy or sha(Path(sys.executable)) != PINS['interpreter_sha256']:
        raise RuntimeError('profile identity mismatch')
    default = rdflib.NORMALIZE_LITERALS
    rdflib.NORMALIZE_LITERALS = default if args.normalization == 'default' else False
    record.update(literal_default=default, normalize_literals=rdflib.NORMALIZE_LITERALS, closed=False)
    store = SQLAlchemy(identifier=rdflib.URIRef(STORE))
    record['plugin_table_prefix'] = store._interned_id
    if record['plugin_table_prefix'] != TABLE_PREFIX:
        raise RuntimeError('plugin used an unexpected SQLite table prefix')
    graph = rdflib.Graph(store=store, identifier=rdflib.URIRef(GRAPH))
    loading = args.boundary == 'load'
    if not args.db.is_absolute() or args.db.is_symlink() or loading == args.db.exists():
        raise RuntimeError('load/reopen path contract')
    record['step'] = 'open'
    opened = False

    def term(value):
        if isinstance(value, rdflib.URIRef):
            return {'type': 'uri', 'value': str(value)}
        if isinstance(value, rdflib.Literal):
            out = {'type': 'literal', 'value': str(value)}
            if value.datatype:
                out['datatype'] = str(value.datatype)
            if value.language:
                out['language'] = value.language
            return out
        raise TypeError(f'unsupported term {type(value).__name__}')

    try:
        url = 'sqlite+pysqlite:///' + str(args.db)
        record['open_status'] = graph.open(url, create=loading)
        opened = True
        if record['open_status'] != VALID_STORE:
            raise RuntimeError('Graph.open did not return VALID_STORE')
        dialect = store.engine.dialect
        driver = dialect.dbapi
        if dialect.name != 'sqlite' or dialect.driver != 'pysqlite' or driver.sqlite_version != sqlite3.sqlite_version:
            raise RuntimeError('unexpected SQLite driver')
        record['sqlite_version'] = sqlite3.sqlite_version
        record['dbapi_module'] = driver.__name__
        if loading:
            original_add = store.add
            record['add_calls'] = 0

            def traced_add(*values, **kwargs):
                record['add_calls'] += 1
                record['step'] = 'first-add' if record['add_calls'] == 1 else 'subsequent-add'
                value = original_add(*values, **kwargs)
                record['step'] = 'parse'
                return value

            record['step'] = 'parse'
            with patch.object(store, 'add', traced_add):
                graph.parse(source=HERE / 'consumer-fixture.nt', format='nt')

        record['step'] = 'storage-read'
        record['count'] = len(graph)
        record['triples'] = [{'s': str(s), 'p': str(p), 'o': term(o)}
                             for s, p, o in graph.triples((None, None, None))]
        record['checks'] = checks(record)
        record['step'] = 'schema-read'
        with closing(sqlite3.connect(args.db.as_uri() + '?mode=ro', uri=True)) as connection:
            record['journal_mode'] = connection.execute('PRAGMA journal_mode').fetchone()[0]
            record['tables'] = [row[0] for row in connection.execute(
                "SELECT name FROM sqlite_schema WHERE type = 'table' ORDER BY name")]
        application_tables = [name for name in record['tables'] if not name.startswith('sqlite_')]
        if not application_tables or any(not name.startswith(TABLE_PREFIX + '_') for name in application_tables):
            raise RuntimeError('unexpected store namespace in SQLite schema')
        record['table_prefix'] = TABLE_PREFIX

        record['step'] = 'shared-evaluator'
        try:
            result = graph.query(FILTER_FALSE, use_store_provided=False)
            columns = [str(var) for var in result.vars]
            rows = [[None if value is None else term(value) for value in row] for row in result]
            record['shared_evaluator'] = {'columns': columns, 'rows': rows,
                                          'passes': columns == ['o'] and not rows}
        except Exception as exc:
            record['shared_evaluator'] = {'error': repr(exc), 'passes': False}
        record['step'] = 'complete'
    finally:
        if opened:
            try:
                graph.close()
                record['closed'] = True
            except Exception as exc:
                record['close_error'] = repr(exc)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=PROFILES, required=True)
    parser.add_argument('--normalization', choices=NORMALIZATIONS, required=True)
    parser.add_argument('--boundary', choices=BOUNDARIES, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    lock('storage')
    record = {'profile': args.profile, 'normalization': args.normalization, 'boundary': args.boundary,
              'store_identifier': STORE, 'graph_identifier': GRAPH, 'step': 'import'}
    try:
        observe(args, record)
    except Exception as exc:
        record['error'] = repr(exc)
    lock('storage')
    write(args.out, record)


if __name__ == '__main__':
    main()
