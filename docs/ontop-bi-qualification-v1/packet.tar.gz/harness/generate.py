"""Generate R2RML from a validated predicate and rdf:type class catalog."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import re

RDF_TYPE = "http://www.w3.org/1999/02/22-rdf-syntax-ns#type"
XSD_STRING = "http://www.w3.org/2001/XMLSchema#string"
MAX_BRANCHES = 512


def iri(value):
    if (not isinstance(value, str) or not re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", value)
            or re.search(r'[\x00-\x20\x7f-\x9f<>"{}|^\x60\\]', value)):
        raise ValueError("unsupported predicate or class IRI syntax")
    return f"<{value}>"


def sql_string(value):
    return "'" + value.replace("'", "''") + "'"


def generate(catalog, expected_rows, expected_by_kind):
    if not isinstance(catalog, list) or not 1 <= len(catalog) <= MAX_BRANCHES:
        raise ValueError("invalid catalog size")
    counts = Counter()
    branches = {}
    for row in catalog:
        if set(row) != {"predicate", "kind", "class_iri", "rows"}:
            raise ValueError("unexpected fields in catalog row")
        predicate, kind, clazz, rows = (row[name] for name in ("predicate", "kind", "class_iri", "rows"))
        iri(predicate)
        if type(kind) is not int or kind not in (0, 2) or type(rows) is not int or rows <= 0:
            raise ValueError("unexpected object domain or row count")
        if predicate == RDF_TYPE:
            if kind != 0:
                raise ValueError("rdf:type object must be an IRI in this workload mapping")
            iri(clazz)
        elif clazz is not None:
            raise ValueError("class value outside rdf:type catalog")
        key = predicate, kind, clazz
        if key in branches:
            raise ValueError("duplicate mapping branch")
        branches[key] = rows
        counts[kind] += rows
    if sum(counts.values()) != expected_rows or counts != Counter(expected_by_kind):
        raise ValueError("catalog counts differ from the sealed view")

    records = ["@prefix rr: <http://www.w3.org/ns/r2rml#> .", ""]
    for number, (predicate, kind, clazz) in enumerate(sorted(branches), 1):
        source = (f"SELECT s, lexical AS lex FROM ontop_triples WHERE p = {sql_string(predicate)}"
                  f" AND kind = {kind} AND datatype IS NULL AND lang IS NULL")
        if clazz is None:
            mapping = ("rr:objectMap [ rr:column \"lex\"; rr:termType rr:IRI ]" if kind == 0
                       else f'rr:objectMap [ rr:column "lex"; rr:datatype {iri(XSD_STRING)} ]')
        else:
            source += f" AND lexical = {sql_string(clazz)}"
            mapping = f"rr:object {iri(clazz)}"
        records.extend((
            f"<urn:ontop-workload:ground-map:{number}> a rr:TriplesMap;",
            f"  rr:logicalTable [ rr:sqlQuery {json.dumps(source, ensure_ascii=False)} ];",
            '  rr:subjectMap [ rr:column "s"; rr:termType rr:IRI ];',
            f"  rr:predicateObjectMap [ rr:predicate {iri(predicate)}; {mapping} ] .",
            "",
        ))
    return ("\n".join(records) + "\n").encode()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("catalog", type=Path)
    parser.add_argument("prepared_view", type=Path)
    parser.add_argument("mapping", type=Path)
    args = parser.parse_args()
    catalog = json.loads(args.catalog.read_bytes())
    view = json.loads(args.prepared_view.read_bytes())
    counts = {row["kind"]: row["rows"] for row in view["domains"]}
    if len(counts) != len(view["domains"]) or view["invalid"] or view["base_only"] or view["view_only"]:
        raise ValueError("invalid prepared view receipt")
    mapping = generate(catalog, view["rows"], counts)
    with args.mapping.open("xb") as output:
        output.write(mapping)
    print(sha256(mapping).hexdigest())
