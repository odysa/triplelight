"""Generate grounded R2RML for the BSBM BI typed triples view."""

from collections import Counter
import json
from pathlib import Path
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from generate import RDF_TYPE, XSD_STRING, iri, sql_string


def generate_bi(catalog, expected_rows, expected_domains, branch_cap):
    if type(branch_cap) is not int or branch_cap <= 0:
        raise ValueError("invalid registered branch cap")
    if not isinstance(catalog, list) or not 1 <= len(catalog) <= branch_cap:
        raise ValueError("invalid catalog size")
    counts = Counter()
    branches = set()
    for row in catalog:
        if set(row) != {"predicate", "kind", "class_iri", "datatype", "lang", "rows"}:
            raise ValueError("unexpected catalog row")
        predicate, kind, clazz, datatype, lang, count = (
            row[name] for name in ("predicate", "kind", "class_iri", "datatype", "lang", "rows")
        )
        iri(predicate)
        if type(kind) is not int or kind not in (0, 2) or type(count) is not int or count <= 0:
            raise ValueError("invalid term kind or branch row count")
        if datatype is not None:
            iri(datatype)
        if lang is not None and (
            not isinstance(lang, str) or not re.fullmatch(r"[a-z]+(?:-[a-z0-9]+)*", lang)
        ):
            raise ValueError("invalid or noncanonical language tag")
        if (kind == 0 and (datatype is not None or lang is not None)) or (
            datatype is not None and lang is not None
        ):
            raise ValueError("inconsistent term metadata")
        if predicate == RDF_TYPE:
            if kind != 0:
                raise ValueError("rdf:type object must be an IRI for this corpus mapping")
            iri(clazz)
        elif clazz is not None:
            raise ValueError("class IRI outside rdf:type")
        branch = predicate, kind, clazz, datatype, lang
        if branch in branches:
            raise ValueError("duplicate branch")
        branches.add(branch)
        counts[kind, datatype, lang] += count
    if sum(counts.values()) != expected_rows or dict(counts) != expected_domains:
        raise ValueError("catalog counts differ from the independently verified view domains")

    records = ["@prefix rr: <http://www.w3.org/ns/r2rml#> .", ""]
    for number, (predicate, kind, clazz, datatype, lang) in enumerate(
        sorted(branches, key=lambda branch: tuple("" if item is None else item for item in branch)), 1
    ):
        conditions = [f"p = {sql_string(predicate)}", f"kind = {kind}"]
        for column, value in (("datatype", datatype), ("lang", lang)):
            conditions.append(f"{column} IS NULL" if value is None else f"{column} = {sql_string(value)}")
        if clazz is not None:
            conditions.append(f"lexical = {sql_string(clazz)}")
            object_map = f"rr:object {iri(clazz)}"
        else:
            if kind == 0:
                term_map = "rr:termType rr:IRI"
            elif lang is not None:
                term_map = "rr:language " + json.dumps(lang)
            else:
                term_map = "rr:datatype " + iri(datatype or XSD_STRING)
            object_map = f'rr:objectMap [ rr:column "lex"; {term_map} ]'
        source = "SELECT s, lexical AS lex FROM ontop_triples WHERE " + " AND ".join(conditions)
        records.extend((
            f"<urn:ontop-workload:bi-ground-map:{number}> a rr:TriplesMap;",
            f"  rr:logicalTable [ rr:sqlQuery {json.dumps(source, ensure_ascii=False)} ];",
            '  rr:subjectMap [ rr:column "s"; rr:termType rr:IRI ];',
            f"  rr:predicateObjectMap [ rr:predicate {iri(predicate)}; {object_map} ] .",
            "",
        ))
    return ("\n".join(records) + "\n").encode()

def validate_census(catalog, view, census, branch_cap):
    """Check branch and triple counts separately for every predicate."""
    census_by_predicate = {}
    for row in census["predicates"]:
        predicate = row["predicate"]
        iri(predicate)
        branches, triples, classes, non_iri = (
            row[key] for key in ("branches", "rows", "class_branches", "rdf_type_non_iri_rows")
        )
        if (predicate in census_by_predicate or any(type(value) is not int for value in (branches, triples, classes, non_iri))
                or not triples >= branches >= 1 or classes != (branches if predicate == RDF_TYPE else 0)
                or non_iri != 0):
            raise ValueError("invalid census predicate, size, or rdf:type domain")
        census_by_predicate[predicate] = (branches, triples, classes)
    observed_total = sum(row[0] for row in census_by_predicate.values())
    if observed_total <= 512 or branch_cap != 4 * observed_total or len(catalog) != observed_total:
        raise ValueError("catalog size or prospective cap differs from the observed census")
    if sum(row[1] for row in census_by_predicate.values()) != view["rows"]:
        raise ValueError("census triple counts do not cover the sealed view")

    by_predicate = Counter()
    rows_by_predicate = Counter()
    classes_by_predicate = Counter()
    for row in catalog:
        predicate = row["predicate"]
        by_predicate[predicate] += 1
        rows_by_predicate[predicate] += row["rows"]
        classes_by_predicate[predicate] += row["class_iri"] is not None
    if {predicate: (count, rows_by_predicate[predicate], classes_by_predicate[predicate])
            for predicate, count in by_predicate.items()} != census_by_predicate:
        raise ValueError("catalog does not match the independently counted predicate branches and triples")
    domains = {(row["kind"], row["datatype"], row["lang"]): row["rows"] for row in view["domains"]}
    if len(domains) != len(view["domains"]):
        raise ValueError("repeated object domain in sealed view")
    return generate_bi(catalog, view["rows"], domains, branch_cap)
