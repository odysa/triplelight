"""Classify BI typed-answer differences from the replayed packet receipts."""

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

FLOAT_COLUMN = {4: "priceRatio", 5: "avgPrice", 6: "reviewerAvgScore", 8: "cheapExpensiveRatio"}
ARMS = ("single", "always-spo", "longest-constant-prefix")
XSD_FLOAT = "http://www.w3.org/2001/XMLSchema#float"


def read(path):
    return json.loads(path.read_bytes())


def rows(path):
    return read(path)["results"]["bindings"]


def keyed(rows, float_column, exact_term):
    result = {}
    for row in rows:
        identity = tuple(sorted((name, exact_term(value)) for name, value in row.items()
                                if name != float_column))
        if identity in result:
            raise ValueError("non-float fields do not uniquely identify an answer")
        result[identity] = row[float_column]
    return result


def classify(packet):
    registry = packet / "registry"
    sys.path.insert(0, str(registry / "validator-source"))
    from float_envelope import decimal_to_binary32
    from qualify import exact_term, q7_allowed_products, ulps
    from envelope_qualify import FrozenInputs, anchor
    from workload_check import diagnostics

    manifest = read(registry / "workloads/bi10m/manifest.json")
    requests = {row["file"]: row for row in manifest["queries"]}
    policy = read(registry / "policies/value-policy-freeze.json")
    numeric = FrozenInputs(registry / "policies/numeric", policy["numeric_freeze_sha256"],
                           manifest["source_data_sha256"], policy["workload_manifest_sha256"])
    results = {}
    for arm in ARMS:
        source = packet / "raw/data/queries" / arm / "results"
        aggregate = defaultdict(Counter)
        for line in (source / "queries.jsonl").read_text().splitlines():
            record = json.loads(line)
            if record["status"] != "collected" or record["exact_typed_bag"]:
                continue
            if record["value"]["status"] != "pass" or record["primary"]["status"] != "pass":
                raise ValueError("classification expects passing BI requests")
            label = record["label"]
            template = requests[label]["template"]
            ref = registry / "references/bi10m" / Path(label).with_suffix(".json").name
            got = rows(source / record["answer_file"])
            expected = rows(ref)
            group = aggregate[template]
            group["queries"] += 1
            if template == 7:
                data = diagnostics(read(ref.with_name(ref.stem + "-diagnostic.json")))
                candidate_products = [row["product"]["value"] for row in got]
                reference_products = [row["product"]["value"] for row in expected]
                left = q7_allowed_products(candidate_products, data)
                right = q7_allowed_products(reference_products, data)
                cutoff = left["cutoff_offer_count"]
                eligible_ties = {row["product"] for row in data if row["offerCount"] == cutoff and not row["blocked"]}
                difference = set(candidate_products) ^ set(reference_products)
                if not (left["ambiguous_boundary"] and right["ambiguous_boundary"]
                        and difference and difference <= eligible_ties):
                    raise ValueError("unexpected Q7 difference outside cutoff ties")
                size_class = "same_row_count" if left["rows"] == right["rows"] else "different_row_count"
                group[size_class] += 1
                group["duckdb_only_tied_product_rows"] += len(set(candidate_products) - set(reference_products))
                group["jena_only_tied_product_rows"] += len(set(reference_products) - set(candidate_products))
                continue

            column = FLOAT_COLUMN[template]
            actual = keyed(got, column, exact_term)
            reference = keyed(expected, column, exact_term)
            if actual.keys() != reference.keys():
                raise ValueError(f"non-float fields differ for {label}")
            inputs = numeric.for_instance(requests[label]) if template in (4, 5) else None
            changed_bits = 0
            for key in actual:
                first, second = actual[key], reference[key]
                if not (first.get("datatype") == second.get("datatype") == XSD_FLOAT
                        and first["type"] == second["type"] == "literal"):
                    raise ValueError(f"datatype or term kind differs for {label}")
                a, b = first["value"], second["value"]
                fa, fb = decimal_to_binary32(a), decimal_to_binary32(b)
                if inputs is not None:
                    entity = dict(key)[{4: "feature", 5: "product"}[template]][1]
                    bounds, _ = anchor(template, inputs["groups"][entity])
                    if not bounds.contains(fa) or not bounds.contains(fb):
                        raise ValueError(f"float outside registered rounding envelope for {label}")
                    group["cells_with_both_values_inside_envelope"] += 1
                    group["max_duckdb_jena_binary32_ulps"] = max(
                        group["max_duckdb_jena_binary32_ulps"], ulps(float(fa), float(fb)))
                if a == b:
                    continue
                if fa == fb:
                    group["different_lexical_same_binary32"] += 1
                else:
                    group["different_binary32"] += 1
                    changed_bits += 1
            group["queries_different_binary32" if changed_bits else "queries_lexical_only"] += 1
        results[arm] = aggregate
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet", type=Path)
    args = parser.parse_args()
    print(json.dumps(classify(args.packet), sort_keys=True, indent=2))
