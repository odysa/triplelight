"""Audit native Ontop BSBM BI answers against the original Jena policy."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SCRATCH = HERE.parent
LAYOUT = HERE
sys.path.insert(0, str(LAYOUT))
from qualify_queries import Workload

from classify_bi_exact import FLOAT_COLUMN, XSD_FLOAT, keyed


def different_class(suite, name, actual, reference, result):
    from float_envelope import decimal_to_binary32
    from qualify import exact_term, q7_allowed_products, ulps
    from envelope_qualify import anchor
    from workload_check import diagnostics

    template = suite.requests[name]["template"]
    if result["exact_typed_bag"]:
        return {"class": "exact"}
    if not suite.admitted(result) or result["primary"]["status"] != "pass":
        return {"class": "policy_failure"}
    got = actual["results"]["bindings"]
    expected = reference["results"]["bindings"]
    if template == 7:
        diagnostic = suite.references / (Path(name).stem + "-diagnostic.json")
        data = diagnostics(json.loads(diagnostic.read_bytes()))
        products = [row["product"]["value"] for row in got]
        ref_products = [row["product"]["value"] for row in expected]
        left = q7_allowed_products(products, data)
        right = q7_allowed_products(ref_products, data)
        cutoff = left["cutoff_offer_count"]
        ties = {row["product"] for row in data if row["offerCount"] == cutoff and not row["blocked"]}
        difference = set(products) ^ set(ref_products)
        if left["ambiguous_boundary"] and right["ambiguous_boundary"] and difference and difference <= ties:
            return {"class": "cutoff_ties", "ontop_rows": left["rows"], "jena_rows": right["rows"]}
        return {"class": "other_registered_difference"}
    if template not in FLOAT_COLUMN:
        return {"class": "other_registered_difference"}
    column = FLOAT_COLUMN[template]
    try:
        left = keyed(got, column, exact_term)
        right = keyed(expected, column, exact_term)
    except (KeyError, ValueError):
        return {"class": "other_registered_difference"}
    if left.keys() != right.keys():
        return {"class": "other_registered_difference"}
    def is_float(term):
        return term.get("type") == "literal" and term.get("datatype") == XSD_FLOAT

    if any(not (is_float(left[key]) and is_float(right[key])) for key in left):
        return {"class": "term_kind_or_datatype"}
    counts = Counter()
    inputs = suite.numeric.for_instance(suite.requests[name]) if template in (4, 5) else None
    for key, term in left.items():
        a, b = term["value"], right[key]["value"]
        value, ref = decimal_to_binary32(a), decimal_to_binary32(b)
        if inputs is not None:
            field = "feature" if template == 4 else "product"
            entity = dict(key)[field][1]
            bounds, _ = anchor(template, inputs["groups"][entity])
            if not bounds.contains(value) or not bounds.contains(ref):
                return {"class": "outside_rounding_envelope"}
            counts["paired_cells_within_envelope"] += 1
        counts["max_binary32_ulps"] = max(counts["max_binary32_ulps"], ulps(float(value), float(ref)))
        if a != b:
            counts["changed_binary32" if value != ref else "lexical_only_cells"] += 1
    return {
        "class": ("binary32_difference" if counts["changed_binary32"]
                  else "lexical_only" if counts["lexical_only_cells"]
                  else "other_registered_difference"),
        **counts,
    }


def audit(answers, suite, schedule, record_cap, read_strict):
    receipts = {}
    for item in schedule:
        name = item["file"]
        output = answers / Path(name).with_suffix(".json").name
        if not output.exists() and not output.is_symlink():
            receipts[name] = {"class": "missing"}
            continue
        try:
            if output.is_symlink() or not output.is_file() or output.stat().st_size > record_cap:
                raise ValueError("invalid answer file")
            raw = output.read_bytes()
            record = read_strict(raw)
            if (record["dataset"] != "bi10m" or record["label"] != "bi10m/" + name
                    or record["query_sha256"] != item["query_sha256"] or record["scored"] is not False):
                raise ValueError("answer identity differs")
            if record["status"] == "query-error":
                if not isinstance(record.get("error"), str) or not record["error"] or "answer" in record:
                    raise ValueError("invalid query error")
                receipts[name] = {"class": "query_error", "error": record["error"]}
            elif record["status"] == "complete" and "error" not in record:
                _, _, reference = suite.prepared(name, "single")
                actual = record["answer"]
                checks = suite.check(name, actual, reference)
                receipts[name] = {**checks, **different_class(suite, name, actual, reference, checks)}
            else:
                raise ValueError("invalid answer status")
            receipts[name]["answer_record_sha256"] = sha256(raw).hexdigest()
        except (OSError, ValueError, TypeError, KeyError, AttributeError, OverflowError) as error:
            receipts[name] = {"class": "integrity_error", "error": str(error)}
    expected_names = {Path(item["file"]).with_suffix(".json").name for item in schedule}
    unexpected = sorted(p.name for p in answers.iterdir() if p.name not in expected_names) if answers.is_dir() else []
    return {"dataset": "bi10m", "scored": False, "requests": receipts,
            "class_counts": dict(Counter(v["class"] for v in receipts.values())),
            "unexpected_files": unexpected,
            "exact_typed": sum(row.get("exact_typed_bag") is True for row in receipts.values()),
            "primary_pass": sum(row.get("primary", {}).get("status") == "pass" for row in receipts.values()),
            "value_policy_pass": sum(suite.admitted(row) for row in receipts.values())}
