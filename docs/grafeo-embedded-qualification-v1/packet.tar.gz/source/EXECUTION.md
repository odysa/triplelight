# Grafeo fixture v3

v1 stopped during venv creation when pip renamed a temporary bytecode file between listing and lstat. The fixture never opened Grafeo. v2 tolerates only FileNotFoundError for a sampled entry, retains the same allocation and free-space guards, and keeps the v1 results and root. The sparq v1 fixture already completed.

v2 installed the pinned runtime and passed all eight in-memory checks. Disk load stopped at the constructor because its path parameter expects str and the harness supplied a PosixPath. v3 converts the path at that call for disk load and reopen. The v2 root and receipts are retained.

Use CPython 3.14.3 on macOS ARM64 and the existing pinned wheels. After the live named handoff, announce and atomically claim the exact owner `Jianlin task39 Grafeo fixture v3`. The new root is /private/tmp/rdf-jianlin-grafeo39-tiny-v3.

```sh
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/grafeo-v3/supervise.py setup grafeo --freeze FREEZE_SHA256
rtk proxy python3 -E -s -B scratch/embedded39-new-candidates-v1/grafeo-v3/supervise.py fixture grafeo --freeze FREEZE_SHA256 --runtime RUNTIME_SHA256
```

Announce the successful setup runtime digest before fixture execution. The v3 worker uses the same memory, disk load and separate-process reopen routes, exact typed answer checks, Grafeo-sidecar inventory and pip check as v1. Report the Grafeo load count and SPARQL COUNT separately. Retain raw setup and fixture receipts, and release the exact lock only after its owned workers exit.
