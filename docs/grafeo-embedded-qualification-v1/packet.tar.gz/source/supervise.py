"""Install pinned wheels and supervise isolated native fixture processes."""

import argparse
import base64
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import sysconfig
import time
from pathlib import Path
from urllib.request import urlopen

from check_answers import check
from worker import HERE, require_lock

PYTHON_SHA = "fe027e1504df20b6b93b1c9dbc2695a3dc592cd0dc7916b1a3349c97d9104527"
GIB = 1 << 30
MODES = ("memory", "load", "reopen")


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open("x") as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write("\n")


def require(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def source_check(expected):
    manifest = HERE / "FREEZE.json"
    require(sha(manifest) == expected, "freeze digest drift")
    files = read(manifest)["files"]
    present = {str(p.relative_to(HERE)) for p in HERE.rglob("*") if p.is_file()}
    require(present == set(files) | {"FREEZE.json"}, "source inventory drift")
    require(all(sha(HERE / path) == digest for path, digest in files.items()), "frozen source drift")


def guard(root, deadline):
    require_lock()
    require(time.monotonic() < deadline, "phase deadline")
    require(shutil.disk_usage(root).free >= 42 * GIB, "host free-space guard")
    require(allocated_bytes(root.rglob("*")) < GIB, "fixture size guard")


def allocated_bytes(paths):
    total = 0
    for path in paths:
        try:
            total += path.lstat().st_blocks * 512
        except FileNotFoundError:
            # pip bootstrap can rename temporary bytecode after directory enumeration.
            continue
    return total


def command(args, root, label, deadline, stdout_path=None):
    output = stdout_path or root / (label + ".stdout")
    with output.open("xb") as stdout, (root / (label + ".stderr")).open("xb") as stderr:
        child = subprocess.Popen(args, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while child.poll() is None:
                guard(root, deadline)
                sampled = os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size
                require(sampled <= 4 << 20, "diagnostic output limit")
                time.sleep(0.1)
            require(child.wait() == 0, f"{label} exited {child.returncode}")
            require(os.fstat(stdout.fileno()).st_size + os.fstat(stderr.fileno()).st_size <= 4 << 20,
                    "diagnostic output limit")
        finally:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
    guard(root, deadline)


def runtime(engine):
    require_lock()
    require(sys.prefix != sys.base_prefix, "expected isolated venv")
    root = Path(sys.prefix).resolve()
    pins = read(HERE / "DEPENDENCIES.json")[engine]
    distributions = {}
    for pin in pins:
        dist = importlib.metadata.distribution(pin["name"])
        require(dist.version == pin["version"] and dist.files, "installed version mismatch")
        files = {}
        for item in dist.files:
            path = Path(dist.locate_file(item)).resolve(strict=True)
            require(path.is_file() and path.is_relative_to(root), "invalid RECORD path")
            digest = sha(path)
            if item.hash is not None:
                encoded = base64.urlsafe_b64encode(bytes.fromhex(digest)).decode().rstrip("=")
                require(item.hash.mode == "sha256" and item.hash.value == encoded and item.size == path.stat().st_size,
                        f"invalid RECORD hash: {item}")
            else:
                require(str(item).endswith(".dist-info/RECORD"), "unexpected unsigned file")
            files[str(path.relative_to(root))] = digest
        distributions[pin["name"]] = {"version": pin["version"], "files": files}
    return {"python": sys.version, "executable_sha256": sha(sys.executable), "distributions": distributions}


def runtime_command(engine, python):
    return [str(python), "-E", "-s", "-B", str(HERE / "supervise.py"), "runtime", engine]


def prepare(engine, root, freeze):
    root.mkdir()
    deadline = time.monotonic() + 180
    wheel_paths = []
    for pin in read(HERE / "DEPENDENCIES.json")[engine]:
        path = root / pin["filename"]
        with urlopen(pin["url"], timeout=12) as response, path.open("xb") as handle:
            total = 0
            while chunk := response.read(1 << 16):
                total += len(chunk)
                require(total <= pin["bytes"], "wheel length above pin")
                handle.write(chunk)
                guard(root, deadline)
        require(total == pin["bytes"] and sha(path) == pin["sha256"], "wheel pin mismatch")
        wheel_paths.append(str(path))
    command([sys.executable, "-I", "-B", "-m", "venv", str(root / "venv")], root, "venv", deadline)
    python = root / "venv/bin/python"
    pip = [str(python), "-I", "-B", "-m", "pip", "--isolated", "--disable-pip-version-check"]
    command(pip + ["install", "--no-index", "--no-deps", "--only-binary=:all:", "--no-compile", *wheel_paths],
            root, "install", deadline)
    command(pip + ["check"], root, "pip-check", deadline)
    command(runtime_command(engine, python), root, "runtime", deadline, root / "RUNTIME.json")
    source_check(freeze)
    write(root / "SETUP.json", {"engine": engine, "freeze": freeze, "runtime": sha(root / "RUNTIME.json"),
                                "pip_check": "pass", "engine_imported": False})


def inventory(directory):
    return {str(p.relative_to(directory)): {"bytes": p.stat().st_size, "sha256": sha(p)}
            for p in sorted(directory.rglob("*")) if p.is_file() and not p.is_symlink()}


def qualify(engine, root, freeze, runtime_sha):
    require(sha(root / "RUNTIME.json") == runtime_sha, "unexpected runtime digest")
    setup = read(root / "SETUP.json")
    require(setup == {"engine": engine, "freeze": freeze, "runtime": runtime_sha,
                      "pip_check": "pass", "engine_imported": False}, "setup contract mismatch")
    before = read(root / "RUNTIME.json")
    run = root / "fixture"
    run.mkdir()
    store = run / "store"
    store.mkdir()
    path = store / ("fixture.grafeo" if engine == "grafeo" else "fixture-sparq")
    deadline = time.monotonic() + 120
    results = {label: {"status": "not-run"} for label in MODES}
    python = root / "venv/bin/python"
    report = {"engine": engine, "runtime": runtime_sha, "stages": results, "scored": False}
    try:
        command(runtime_command(engine, python), run, "runtime-before", deadline, run / "RUNTIME-BEFORE.json")
        require(read(run / "RUNTIME-BEFORE.json") == before, "runtime drift")
        for mode in MODES:
            results[mode] = {"status": "started"}
            if mode == "reopen":
                require(inventory(store) == results["load"]["files_after"], "persisted artifact drift")
            output = run / (mode + ".json")
            command([str(python), "-E", "-s", "-B", str(HERE / "worker.py"), engine, mode,
                     "--store", str(path), "--out", str(output)], run, mode, deadline)
            record = read(output)
            require(record["engine"] == engine and record["stage"] == mode, "worker receipt mismatch")
            results[mode] = {"status": "observed", **check(record), "files_after": inventory(store)}
            if mode == "load":
                require(bool(results[mode]["files_after"]), "missing persisted files")
        command(runtime_command(engine, python), run, "runtime-after", deadline, run / "RUNTIME-AFTER.json")
        require(read(run / "RUNTIME-AFTER.json") == before, "runtime drift")
        source_check(freeze)
        guard(root, deadline)
        report["pass"] = all(result["tiny_pass"] for result in results.values())
    except BaseException as error:
        report["error"] = repr(error)
        report["pass"] = False
    finally:
        write(run / "RECEIPT.json", report)
    print(json.dumps({"engine": engine, "pass": report["pass"], "runtime": runtime_sha}))
    return 0 if report["pass"] else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["setup", "fixture", "runtime"])
    parser.add_argument("engine", choices=["grafeo"])
    parser.add_argument("--freeze")
    parser.add_argument("--runtime")
    args = parser.parse_args()
    require_lock()
    require(sys.version_info[:3] == (3, 14, 3) and platform.system() == "Darwin"
            and platform.machine() == "arm64" and not sysconfig.get_config_var("Py_GIL_DISABLED")
            and sha(sys.executable) == PYTHON_SHA, "unexpected interpreter")
    if args.stage == "runtime":
        print(json.dumps(runtime(args.engine), indent=2, sort_keys=True))
        return 0
    source_check(args.freeze)
    root = Path("/private/tmp/rdf-jianlin-grafeo39-tiny-v3")
    require(shutil.disk_usage(root.parent).free >= 42 * GIB, "host free-space launch floor")
    if args.stage == "setup":
        prepare(args.engine, root, args.freeze)
        print(sha(root / "RUNTIME.json"))
        return 0
    return qualify(args.engine, root, args.freeze, args.runtime)


if __name__ == "__main__":
    raise SystemExit(main())
