"""Replay the recorded Grafeo fixture without importing Grafeo."""
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source"
RUN = HERE / "run"
FIXTURE = RUN / "fixture"
sys.path.insert(0, str(SOURCE))
from check_answers import check


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


freeze = SOURCE / "FREEZE.json"
assert sha(freeze) == "055330af035a94a0135ca09cb4ee07039ba6b8a2766a14482e7bf0c1405261af"
members = read(freeze)["files"]
assert {path.name for path in SOURCE.iterdir()} == set(members) | {"FREEZE.json"}
for path, expected in members.items():
    assert sha(SOURCE / path) == expected

runtime = sha(RUN / "RUNTIME.json")
assert runtime == "82162655db1aa32d1e50220a68061b0e526086e720e23fe558bd2d2ebbc7e760"
for phase in ("BEFORE", "AFTER"):
    assert sha(FIXTURE / f"RUNTIME-{phase}.json") == runtime
receipt = read(FIXTURE / "RECEIPT.json")
assert receipt["runtime"] == runtime and receipt["pass"] is True and receipt["scored"] is False

store = FIXTURE / "store"
paths = sorted(p for p in store.rglob("*") if p.is_file())
inventory = {str(p.relative_to(store)): {"bytes": p.stat().st_size, "sha256": sha(p)} for p in paths}
assert set(inventory) == {"fixture.grafeo"}
stages = {}
for stage in ("memory", "load", "reopen"):
    record = read(FIXTURE / f"{stage}.json")
    assert record["engine"] == "grafeo" and record["stage"] == stage
    observed = check(record)
    recorded = receipt["stages"][stage]
    assert all(recorded[k] == v for k, v in observed.items())
    assert recorded["status"] == "observed" and observed["tiny_pass"]
    assert recorded["files_after"] == ({} if stage == "memory" else inventory)
    info = record["runtime_info"]
    assert info["info"]["version"] == "0.6.3" and info["info"]["mode"] == "lpg"
    assert info["info"]["is_persistent"] is (stage != "memory")
    wal = info["wal_on_open"]
    if stage == "memory":
        assert wal is None
    else:
        assert wal["enabled"] and wal["record_count"] == 0 and wal["size_bytes"] == 0
    stages[stage] = {**observed, "load_added": record["actual_added"], "wal_records_at_open": None if wal is None else wal["record_count"]}

prior = HERE / "v2"
assert check(read(prior / "memory.json"))["tiny_pass"]
prior_receipt = read(prior / "RECEIPT.json")
assert prior_receipt["pass"] is False
assert prior_receipt["stages"]["reopen"]["status"] == "not-run"
assert "PosixPath" in (prior / "load.stderr").read_text()

print(json.dumps({
    "engine": "grafeo",
    "freeze_sha256": sha(freeze),
    "runtime_sha256": runtime,
    "scored": False,
    "stages": stages,
    "store_after_load_and_reopen": inventory,
    "typed_checks_passed": sum(len(item["checks"]) for item in stages.values()),
    "v2_memory_pass_disk_constructor_stopped": True,
}, indent=2, sort_keys=True))
