"""Replay typed Python answer records without the database engines."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "validators"))
from aggregate_count_policy import compare


def document(path):
    return json.loads(path.read_bytes())


refs = document(root / "replay-inputs.json")
receipt = document(root / "query.json")
if not receipt["complete"] or receipt["mode"] != "discard-only":
    raise ValueError("wrong qualification receipt")
runs = [entry for entry in receipt["runs"] if entry["worker"]["phase"] == "discard"]
if [entry["worker"]["engine"] for entry in runs] != ["triplelight", "pyoxigraph"]:
    raise ValueError("incorrect qualification engine set")
for entry in runs:
    worker = entry["worker"]
    engine = worker["engine"]
    labels = [row["label"] for row in refs]
    if (worker["completed_labels"] != labels or worker["graph_count"] != 13_409_395
            or len(refs) != 30 or len(set(labels)) != 30):
        raise ValueError("incorrect label set or graph size")
    folder = root / engine
    expected = {f"{i:02d}.json" for i in range(1, len(refs) + 1)}
    if {path.name for path in folder.glob("*.json")} != expected:
        raise ValueError("unexpected answer inventory")
    for i, row in enumerate(refs, 1):
        candidate = document(folder / f"{i:02d}.json")
        reference = document(root / "reference" / row["reference"])
        if not compare(candidate, reference, row["columns"])["primary_pass"]:
            raise ValueError(f"typed answer mismatch for {engine} {row['label']}")
    if entry["exact_typed_answers"] != len(refs):
        raise ValueError("receipt reports different answer count")
    print(f"{engine}: {len(refs)} exact typed answers")
