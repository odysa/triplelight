"""Classify saved #46 results without starting any database or JVM."""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path

HARNESS = Path(__file__).resolve().parents[1] / "ontop46-aggregate-view-gate"


def read(path):
    return json.loads(path.read_bytes())


def load_checker():
    spec = importlib.util.spec_from_file_location("aggregate_check_answers", HARNESS / "check_answers.py")
    checker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checker)
    return checker


def mismatch_kind(actual, reference, columns):
    from aggregate_count_policy import checked_rows, exact_term

    def keys(body):
        return Counter(
            tuple(exact_term(row.get(key)) for key, role in columns if role == "term")
            for row in checked_rows(body, columns)
        )

    left, right = keys(actual), keys(reference)
    return "group-key-or-multiplicity" if left != right else "count-values"


def classify(root, dataset, max_bytes):
    checker = load_checker()
    binding_path = HARNESS / "AGGREGATE-BINDINGS.json"
    registry_path = HARNESS / "FROZEN-QUERY-REFERENCES.json"
    bindings = read(binding_path)["queries"][dataset]
    archive = read(registry_path)
    registry = HARNESS / archive["root"]
    final = read(root / "FINAL.json")
    if final["dataset"] != dataset or final["scored"] is not False:
        raise ValueError("run identity differs")
    if not (root / "answers").is_dir():
        return {"dataset": dataset, "complete": False, "scheduled": len(bindings),
                "status": "no-query-output", "stop": final.get("stop")}

    checked = checker.audit(root / "answers", binding_path, registry_path, dataset, max_bytes)
    saved_audit = root / "AUDIT.json"
    if saved_audit.exists() and read(saved_audit) != checked:
        raise ValueError("saved audit differs from engine-free answer replay")
    classes = {}
    for label, receipt in checked["labels"].items():
        category = receipt["status"]
        if category == "complete":
            if receipt["primary_pass"]:
                category = "exact"
            elif receipt["count_compatible_pass"]:
                category = "compatible-count-representation"
            elif "count_compatible_error" in receipt:
                category = "invalid-count-representation"
            else:
                answer = read(root / "answers" / Path(label).with_suffix(".json").name)["answer"]
                reference = read(registry / archive["files"][dataset][label]["reference"])
                category = mismatch_kind(answer, reference, bindings[label]["rule"]["columns"])
        classes.setdefault(category, []).append(label)
    summary = {name: {"count": len(labels), "labels": labels} for name, labels in sorted(classes.items())}
    return {"dataset": dataset, "complete": final["complete"], "scheduled": len(bindings),
            "unexpected_files": checked["unexpected_files"], "stop": final.get("stop"), "classes": summary}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("dataset", choices=("lubm", "watdiv"))
    parser.add_argument("--record-cap", type=int, default=64 << 20)
    args = parser.parse_args()
    print(json.dumps(classify(args.root, args.dataset, args.record_cap), indent=2, sort_keys=True))
