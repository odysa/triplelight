"""Compare each completed Ontop result with its pinned aggregate reference."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "oxilite39-workload-harness-draft/validators"))
from aggregate_count_policy import compare


def unique_object(pairs):
    values = dict(pairs)
    if len(values) != len(pairs):
        raise ValueError("duplicate JSON field")
    return values


def reject_constant(value):
    raise ValueError(f"invalid JSON constant: {value}")


def read_json(data):
    return json.loads(data, object_pairs_hook=unique_object, parse_constant=reject_constant)


def check(path, dataset, label, binding, reference, max_bytes):
    if path.is_symlink() or not path.is_file():
        raise ValueError("answer must be a regular file")
    with path.open("rb") as stream:
        raw = stream.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise ValueError("answer above per-record cap")
    outcome = read_json(raw)
    rule = binding["rule"]
    if (outcome["dataset"] != dataset or outcome["label"] != label
            or outcome["query_sha256"] != rule["query_sha256"] or outcome["scored"] is not False):
        raise ValueError("answer identity differs")
    if outcome["status"] == "query-error":
        if not isinstance(outcome.get("error"), str) or not outcome["error"] or "answer" in outcome:
            raise ValueError("invalid query-error record")
        return {"status": "query-error", "error": outcome["error"]}
    if outcome["status"] != "complete" or "error" in outcome:
        raise ValueError("invalid completed-record status")
    if sha256(reference).hexdigest() != binding["reference_sha256"]:
        raise ValueError("Jena reference digest differs")
    actual = outcome["answer"]
    columns = rule["columns"]
    if actual["head"]["vars"] != [column for column, _ in columns]:
        raise ValueError("native projection order differs")
    result = compare(actual, read_json(reference), columns)
    return {"status": "complete", **result}


def audit(output, bindings, archive, dataset, max_bytes):
    source = read_json(archive.read_bytes())
    original = bindings.read_bytes()
    if source["bindings_sha256"] != sha256(original).hexdigest():
        raise ValueError("alternate archive binding differs")
    plans = read_json(original)
    rows = plans["queries"][dataset]
    if not rows:
        raise ValueError("empty registered workload")
    root = archive.resolve().parent / source["root"]
    statuses = {}
    for label, binding in rows.items():
        filename = Path(label).with_suffix(".json").name
        path = output / filename
        if not path.exists() and not path.is_symlink():
            statuses[label] = {"status": "missing"}
            continue
        try:
            reference = root / source["files"][dataset][label]["reference"]
            statuses[label] = check(path, dataset, label, binding, reference.read_bytes(), max_bytes)
        except (OSError, ValueError, KeyError, TypeError, AttributeError, IndexError) as error:
            statuses[label] = {"status": "integrity-error", "error": str(error)}
    expected = {Path(label).with_suffix(".json").name for label in rows}
    unexpected = sorted(p.name for p in output.iterdir() if p.name not in expected)
    return {
        "dataset": dataset,
        "scored": False,
        "labels": statuses,
        "unexpected_files": unexpected,
        "all_exact": not unexpected and all(value.get("primary_pass") is True for value in statuses.values()),
        "all_count_compatible": not unexpected
        and all(value.get("count_compatible_pass") is True for value in statuses.values()),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("bindings", type=Path)
    parser.add_argument("archive", type=Path)
    parser.add_argument("dataset", choices=("lubm", "watdiv"))
    parser.add_argument("max_bytes", type=int)
    args = parser.parse_args()
    if args.max_bytes <= 0:
        parser.error("answer cap must be positive")
    result = audit(args.output, args.bindings, args.archive, args.dataset, args.max_bytes)
    print(json.dumps(result, indent=2, sort_keys=True))
    raise SystemExit(0 if result["all_exact"] else 1)
