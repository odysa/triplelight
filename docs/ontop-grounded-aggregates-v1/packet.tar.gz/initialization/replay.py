"""Verify the two retained pre-query Ontop stops from saved receipts."""

from hashlib import sha256
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED = {"lubm": (13_409_395, 30), "watdiv": (10_914_314, 41)}


def read(root, relative):
    return json.loads((root / relative).read_bytes())


def require(predicate, reason):
    if not predicate:
        raise ValueError(reason)


def verify(dataset):
    root = HERE / dataset
    rows, scheduled = EXPECTED[dataset]
    final = read(root, "FINAL.json")
    view = read(root, "PREPARED-VIEW.json")
    raw = read(root, "RAW-RECEIPTS.json")
    postflight = read(root, "POSTFLIGHT.json")
    require(final["dataset"] == view["dataset"] == postflight["dataset"] == dataset
            and final["scored"] is False and final["complete"] is False,
            "unexpected dataset or qualification state")
    require(view["rows"] == rows and sum(x["rows"] for x in view["domains"]) == rows
            and view["view_catalog_entries"] == 1 and view["read_only_reopen"] is True
            and view["closed"] is True and view["base_only"] == view["view_only"] == view["invalid"] == 0,
            "flattened view receipt differs")
    for stage, code in (("compile", 0), ("prepare", 0), ("query", 1)):
        receipt = read(root, f"{stage}/PROCESS.json")
        require(final[stage] == postflight["stages_verified"][stage] == receipt
                and receipt["exit_code"] == code and receipt["group_clear"] is True,
                f"unexpected process receipt for {stage}")
    require(sha256((root / "FINAL.json").read_bytes()).hexdigest() == postflight["final_sha256"]
            == raw["raw_sha256"]["FINAL.json"], "final receipt digest differs")
    require("NoGroundPredicateOntopInternalBugException" in (root / "query/stderr.txt").read_text()
            and "MappingCanonicalTransformerImpl" in (root / "query/stderr.txt").read_text()
            and raw["query_events_file_present"] is False and raw["answer_files"] == 0,
            "expected pre-query failure evidence missing")
    mapping = (root / "mapping.ttl").read_bytes()
    require(mapping.count(b'rr:predicateMap [ rr:column "p"') == 2, "expected column-valued predicate")
    return {"view_rows": rows, "scheduled": scheduled, "queries_reached": 0, "phase": "mapping-initialization"}


if __name__ == "__main__":
    print(json.dumps({dataset: verify(dataset) for dataset in EXPECTED}, indent=2, sort_keys=True))
