# Ontop 5.5.0 column-valued mapping initialization

Both DuckDB JDBC 2.0.0.0 runs compiled the harness and reopened a private flattened view read-only. LUBM preserved 13,409,395 rows and WatDiv preserved 10,914,314. Both view-to-base bag differences and invalid-row counts were zero.

Ontop rejected the mapping while constructing its canonical mapping index. The predicate maps read the predicate IRI from the column `p`, and the index expected a ground IRI. Each query worker exited before its repository opened. No aggregate answers were produced from the 30 LUBM or 41 WatDiv requests.

Run `python3 -IB replay.py` to reproduce the receipt audit. The saved stack traces replace host-local paths. The original hashes and exact process cleanup receipts are recorded for both attempts. All work was untimed.
