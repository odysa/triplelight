"""Dry-run the host workflow with stubbed Docker stages and no engine."""
from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import supervise
from supervise import Attempt, HERE, identity, put


class Stub(Attempt):
    def __init__(self, reg, scenario):
        super().__init__(reg, "lubm")
        self.scenario = scenario
        self.visits = []

    def docker(self, *args):
        assert args[:2] == ("image", "inspect")
        return "linux/arm64 " + self.reg["image"]["config"]

    def wheels(self):
        return self.root / "stubbed-wheels"

    def stage(self, stage, seconds, command, mounts=(), *, setup=False):
        self.visits.append(stage)
        paths = {container: (host, ro) for host, container, ro in mounts}
        if stage == "setup":
            assert setup and paths["/wheels"][1]
            pip_temp, read_only = paths["/pip-tmp"]
            assert pip_temp == self.root / "pip-tmp" and pip_temp.is_dir() and not read_only
            assert "TMPDIR=/pip-tmp python -m pip" in command[-1]
            assert "df -Pk /tmp /pip-tmp /modules" in command[-1]
            (self.root / "setup.stdout.log").write_text("3.11.18 2.0.0 26.0.1\n")
            return 0
        dest, ro = paths["/out"]
        assert not ro
        if stage == "import":
            assert paths["/input.nt"][1]
            (dest / "control.db").write_bytes(b"synthetic control")
            put(dest / "import.json", {"complete": True, "unique_triples": self.dataset["triples"],
                                       "source_sha256": self.dataset["sha256"]})
        elif stage == "build":
            assert paths["/control.db"][1] and paths["/control.db"][0].parent != dest
            (dest / "candidate").mkdir()
            (dest / "candidate/six-copy.duckdb").write_bytes(b"synthetic six-copy database")
        elif stage == "reopen":
            assert paths["/control.db"][1] and paths["/candidate.db"][1]
            (dest / "reopen").mkdir()
            put(dest / "reopen/receipt.json", {"complete": True, "files_before": {
                "control": identity(paths["/control.db"][0]), "candidate": identity(paths["/candidate.db"][0])}})
        else:
            if self.scenario == "timeout" and stage == "always-spo":
                raise TimeoutError("synthetic deadline")
            assert paths["/query.db"][1] and paths["/registry"][1]
            if stage != "single":
                assert paths["/query.db"][0].name == "six-copy.duckdb"
            match = self.scenario != "mismatch" or stage != "always-spo"
            (dest / "results").mkdir()
            put(dest / "results/FINAL.json", {"complete": True, "eligible": match})
            return int(not match)
        return 0


def check():
    settings = json.loads((HERE / "REGISTRATION.json").read_text())
    with TemporaryDirectory() as temp:
        scratch = Path(temp)
        lock = scratch / "lock"
        lock.mkdir()
        retained = scratch / "retained"
        retained.mkdir()
        stopped = retained / "prior-failed-attempt"
        stopped.write_bytes(b"a" * 8192)
        for scenario in ("pass", "mismatch", "timeout"):
            reg = deepcopy(settings)
            reg.update(output_parent=str(scratch / scenario), free_floor_bytes=0, launch_free_bytes=0)
            reg["retained_output_parents"] = [str(retained)]
            attempt = Stub(reg, scenario)
            (lock / "owner").write_text(attempt.owner + "\n")
            with patch.object(supervise, "LOCK", lock):
                if scenario == "timeout":
                    try:
                        attempt.run("synthetic")
                    except TimeoutError:
                        pass
                    else:
                        raise AssertionError("timeout was not surfaced")
                else:
                    assert attempt.run("synthetic") == int(scenario == "mismatch")
            result = json.loads((attempt.root / "FINAL.json").read_text())
            assert result["sampled_combined_allocated_bytes"] >= stopped.stat().st_blocks * 512
            assert result["qualified"] == (scenario == "pass")
            assert ("longest-constant-prefix" in attempt.visits) == (scenario != "timeout")
            print(f"PASS host dry-run {scenario}: {attempt.visits}")


if __name__ == "__main__":
    check()
