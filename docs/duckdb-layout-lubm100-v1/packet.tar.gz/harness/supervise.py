"""Run one registered laptop qualification for the three DuckDB layouts."""
import argparse
from hashlib import file_digest, sha256
import json
import os
from pathlib import Path
import selectors
import shutil
import signal
import subprocess
import time
from urllib.request import urlopen

from qualify_queries import ARMS, put
from verify_layout import identity

HERE = Path(__file__).resolve().parent
LOCK = Path("/tmp/rdf-bench.lock")
LABEL = "org.triplelight.duckdb-layout-qualification"


def digest(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"expected a regular file: {path}")
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify_inputs(reg, dataset):
    for name, expected in reg["harness"].items():
        if digest(HERE / name) != expected:
            raise ValueError(f"harness file differs: {name}")
    registry = Path(reg["registry"]["path"])
    inventory = registry / "CONTENTS.sha256.json"
    if digest(inventory) != reg["registry"]["sha256"]:
        raise ValueError("reference registry identity differs")
    for name, expected in json.loads(inventory.read_text()).items():
        if digest(registry / name) != expected:
            raise ValueError(f"reference registry file differs: {name}")
    data = reg["datasets"][dataset]
    source = Path(data["path"])
    current = source.stat()
    if not source.is_file() or current.st_size != data["bytes"]:
        raise ValueError("registered RDF source is absent or changed in length")
    wheel = Path(reg["duckdb_wheel"]["path"])
    if digest(wheel) != reg["duckdb_wheel"]["sha256"]:
        raise ValueError("retained DuckDB wheel differs")
    return source, [current.st_dev, current.st_ino, current.st_mtime_ns, current.st_size]


def capture(process, output_paths, limit, check):
    with selectors.DefaultSelector() as ready, output_paths[0].open("xb") as stdout, output_paths[1].open("xb") as stderr:
        ready.register(process.stdout, selectors.EVENT_READ, stdout)
        ready.register(process.stderr, selectors.EVENT_READ, stderr)
        while ready.get_map():
            check()
            for key, _ in ready.select(timeout=0.25):
                block = os.read(key.fd, 64 << 10)
                if not block:
                    ready.unregister(key.fileobj)
                    continue
                log = key.data
                remaining = limit - log.tell()
                log.write(block[:remaining])
                if len(block) > remaining:
                    raise ValueError(f"log limit reached: {Path(log.name).name}")
        while process.poll() is None:
            check()
            time.sleep(0.05)
        check()


SETUP = """set -eu
df -Pk /tmp /pip-tmp /modules
TMPDIR=/pip-tmp python -m pip install --disable-pip-version-check --no-index --no-deps --target /modules /wheels/*.whl
test -z "$(ls -A /pip-tmp)"
PYTHONPATH=/modules python -s -B -c 'import duckdb, pyarrow, platform; print(platform.python_version(), duckdb.__version__, pyarrow.__version__)'
"""


class Attempt:
    def __init__(self, reg, dataset):
        self.reg = reg
        self.name = dataset
        self.dataset = reg["datasets"][dataset]
        self.owner = f"{reg['owner_prefix']} {dataset}"
        self.root = Path(reg["output_parent"]) / dataset
        self.registry = Path(reg["registry"]["path"])
        self.high_water = 0
        self.status = {"dataset": dataset, "qualified": False, "scored": False, "stages": {}}

    def guard(self, deadline):
        if (LOCK / "owner").read_text().strip() != self.owner:
            raise RuntimeError("exact owner mismatch")
        if time.monotonic() >= deadline:
            raise TimeoutError("stage deadline reached")
        if shutil.disk_usage(self.root.parent.parent).free < self.reg["free_floor_bytes"]:
            raise RuntimeError("shared disk floor reached")
        allocated = 0
        for parent in (self.root.parent, *(Path(path) for path in self.reg["retained_output_parents"])):
            for path in parent.rglob("*"):
                try:
                    allocated += path.lstat().st_blocks * 512
                except FileNotFoundError:
                    continue
        self.high_water = max(allocated, self.high_water)
        if allocated >= self.reg["sample_limit_bytes"]:
            raise RuntimeError("combined workload allocation ceiling reached")

    @staticmethod
    def docker(*args):
        return subprocess.check_output(["rtk", "proxy", "docker", *args], text=True, timeout=20).strip()

    def stage(self, stage, seconds, command, mounts=(), *, setup=False):
        deadline = time.monotonic() + seconds
        self.guard(deadline)
        name = f"{self.reg['container_prefix']}-{self.name}-{stage}"
        args = ["run", "--rm", "--name", name, "--label", f"{LABEL}={self.owner}",
                "--pull", "never", "--platform", "linux/arm64", "--network", "none", "--read-only",
                "--tmpfs", "/tmp:rw,nosuid,nodev,size=128m", "--cpus", "4", "--memory", "12g",
                "--memory-swap", "12g", "--log-driver", "none", "--entrypoint", "/bin/sh",
                "--env", "PYTHONPATH=/modules", "--env", "PIP_NO_CACHE_DIR=1"]
        mounts = [(HERE, "/suite", True), (LOCK, "/guard", True),
                  (self.root / "modules", "/modules", not setup), *mounts]
        for host, target, read_only in mounts:
            args += ["--mount", f"type=bind,src={host},dst={target}" + (",readonly" if read_only else "")]
        shell = 'set -eu\ntest "$(cat /guard/owner)" = "$1"\nshift\nexec "$@"'
        args += [self.reg["image"]["reference"], "-c", shell, "stage", self.owner, *command]

        def containers():
            rows = self.docker("ps", "-a", "--filter", f"label={LABEL}={self.owner}",
                               "--filter", f"name=^/{name}$", "--format", "{{.ID}} {{.Names}}")
            return [identifier for identifier, current in (row.split() for row in rows.splitlines()) if current == name]

        entry = self.status["stages"][stage] = {"exit_code": None, "stop": None, "container": name}
        logs = [self.root / f"{stage}.{stream}.log" for stream in ("stdout", "stderr")]
        if containers():
            raise RuntimeError("registered container already exists")
        process = subprocess.Popen(["rtk", "proxy", "docker", *args], stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        try:
            with process.stdout, process.stderr:
                capture(process, logs, self.reg["log_limit_bytes"], lambda: self.guard(deadline))
        except BaseException as error:
            entry["stop"] = f"{type(error).__name__}: {error}"
            raise
        finally:
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=5)
            entry["exit_code"] = process.returncode
            for identifier in containers():
                self.docker("rm", "-f", identifier)
            entry["cleanup_verified"] = not containers()
            if not entry["cleanup_verified"]:
                raise RuntimeError("owned container removal not verified")
        return process.returncode

    def wheels(self):
        folder = self.root / "wheels"
        folder.mkdir()
        duck = Path(self.reg["duckdb_wheel"]["path"])
        shutil.copyfile(duck, folder / duck.name)
        if digest(folder / duck.name) != self.reg["duckdb_wheel"]["sha256"]:
            raise ValueError("private DuckDB wheel copy differs")
        pin = self.reg["pyarrow_wheel"]
        with urlopen(pin["url"], timeout=30) as response:
            data = response.read(pin["bytes"] + 1)
        if len(data) != pin["bytes"] or sha256(data).hexdigest() != pin["sha256"]:
            raise ValueError("PyArrow wheel differs from registration")
        (folder / pin["name"]).write_bytes(data)
        return folder

    def run(self, registration_sha256):
        self.guard(time.monotonic() + 60)
        source, before = verify_inputs(self.reg, self.name)
        if shutil.disk_usage(self.root.parent.parent).free < self.reg["launch_free_bytes"]:
            raise RuntimeError("launch free-space requirement not met")
        image = self.reg["image"]
        observed = self.docker("image", "inspect", "--format", "{{.Os}}/{{.Architecture}} {{.Id}}", image["reference"])
        if observed != f"linux/arm64 {image['config']}":
            raise ValueError("local image differs from registration")
        self.root.parent.mkdir(exist_ok=True)
        self.root.mkdir(mode=0o700)
        self.status.update(registration_sha256=registration_sha256, image=observed, source_before=before)
        raw = self.root / "data"
        raw.mkdir()
        modules = self.root / "modules"
        modules.mkdir()
        opts = ["--threads", "4", "--memory-limit", "8GB", "--max-spill", "4GB"]
        bind_hash = self.reg["harness"]["WORKLOAD-SQL-DRAFT.json"]
        version = self.reg["duckdb_wheel"]["version"]
        store_opts = ["--version", version, "--expected-rows", str(self.dataset["triples"]), *opts]
        python = ["python", "-s", "-B"]
        control_stage = raw / "control"
        layout_stage = raw / "layout"
        reopen_stage = raw / "verification"
        query_stage = raw / "queries"
        for folder in (control_stage, layout_stage, reopen_stage, query_stage):
            folder.mkdir()
        control = control_stage / "control.db"
        candidate = layout_stage / "candidate/six-copy.duckdb"
        try:
            pip_temp = self.root / "pip-tmp"
            pip_temp.mkdir()
            setup = self.stage("setup", 180, ["/bin/sh", "-c", SETUP],
                               [(self.wheels(), "/wheels", True), (pip_temp, "/pip-tmp", False)], setup=True)
            if setup:
                raise ValueError(f"runtime setup exit {setup}")
            actual = (self.root / "setup.stdout.log").read_text().splitlines()[-1].split()
            if not actual[0].startswith("3.11.") or actual[1:] != [version, self.reg["pyarrow_wheel"]["version"]]:
                raise ValueError("effective runtime version differs")
            self.status["runtime"] = actual
            code = self.stage("import", self.reg["import_seconds"], [*python, "/suite/importer/source/duck_load.py",
                              "--source", "/input.nt", "--database", "/out/control.db",
                              "--spill", "/out/import-spill", "--report", "/out/import.json",
                              "--progress", "/out/progress.json", "--lock-owner", self.owner,
                              "--expected-sha256", self.dataset["sha256"], *opts],
                              [(source, "/input.nt", True), (control_stage, "/out", False)])
            receipt = json.loads((control_stage / "import.json").read_text())
            if code or not receipt["complete"] or (receipt["unique_triples"], receipt["source_sha256"]) != (
                    self.dataset["triples"], self.dataset["sha256"]):
                raise ValueError("control import did not pass")
            _, after = verify_inputs(self.reg, self.name)
            if before != after:
                raise ValueError("RDF source identity changed during import")
            self.status["source_after"] = after
            original = identity(control)
            code = self.stage("build", self.reg["layout_seconds"], [*python, "/suite/build_layout.py",
                              "--control", "/control.db", "--output", "/out/candidate", *store_opts],
                              [(control, "/control.db", True), (layout_stage, "/out", False)])
            if code or identity(control) != original:
                raise ValueError("six-copy build did not pass")
            copies = identity(candidate)
            code = self.stage("reopen", self.reg["layout_seconds"], [*python, "/suite/verify_layout.py",
                              "--control", "/control.db", "--candidate", "/candidate.db",
                              "--output", "/out/reopen", *store_opts],
                              [(control, "/control.db", True), (candidate, "/candidate.db", True),
                               (reopen_stage, "/out", False)])
            receipt = json.loads((reopen_stage / "reopen/receipt.json").read_text())
            if code or not receipt["complete"] or receipt["files_before"] != {"control": original, "candidate": copies}:
                raise ValueError("six-copy reopen did not pass")
            results = self.status["arms"] = {}
            for arm in ARMS:
                db, expected = (control, original) if arm == "single" else (candidate, copies)
                if identity(db) != expected:
                    raise ValueError(f"database identity changed before {arm}")
                arm_dir = query_stage / arm
                arm_dir.mkdir()
                code = self.stage(arm, self.reg["arm_seconds"], [*python, "/suite/qualify_queries.py",
                                  "--registry", "/registry", "--binding", "/suite/WORKLOAD-SQL-DRAFT.json",
                                  "--binding-sha256", bind_hash, "--database", "/query.db", "--output", "/out/results",
                                  "--dataset", self.name, "--arm", arm, "--duckdb-version", version, *opts],
                                  [(self.registry, "/registry", True), (db, "/query.db", True), (arm_dir, "/out", False)])
                result = json.loads((arm_dir / "results/FINAL.json").read_text())
                if code not in (0, 1) or not result["complete"] or code != int(not result["eligible"]):
                    raise ValueError(f"{arm} did not finish its registered checks")
                if identity(db) != expected:
                    raise ValueError(f"database identity changed after {arm}")
                results[arm] = result
            self.status["qualified"] = all(result["eligible"] for result in results.values())
            _, final_source = verify_inputs(self.reg, self.name)
            if final_source != before:
                raise ValueError("RDF source identity differs at postflight")
            self.status["source_final"] = final_source
            return 0 if self.status["qualified"] else 1
        except BaseException as error:
            self.status.update(qualified=False, stop=f"{type(error).__name__}: {error}")
            raise
        finally:
            self.status["sampled_combined_allocated_bytes"] = self.high_water
            put(self.root / "FINAL.json", self.status)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("registration_sha256")
    parser.add_argument("--dataset", choices=("bi10m", "lubm", "watdiv"), required=True)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    registration = HERE / "REGISTRATION.json"
    if digest(registration) != args.registration_sha256:
        parser.error("registration digest differs")
    reg = json.loads(registration.read_text())
    if args.verify_only:
        verify_inputs(reg, args.dataset)
        print("Harness, registry, source length and retained wheel verified. No engine started.")
    else:
        raise SystemExit(Attempt(reg, args.dataset).run(args.registration_sha256))
