"""Draft validator for the persisted six-copy DuckDB layout after a fresh open."""
import argparse
import hashlib
import json
from pathlib import Path

from build_layout import ORDERS, configure, metadata, scalar, sql_string, verify_copy


def identity(path):
    if not path.is_file() or path.with_name(path.name + ".wal").exists():
        raise ValueError(f"expected a checkpointed database file: {path}")
    stat = path.stat()
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns, "sha256": digest}


def physical_info(connection, table):
    return metadata(connection, """
        SELECT row_group_id, column_name, column_path, compression,
               count(*) AS segment_count, sum("count") AS segment_entries,
               count(DISTINCT block_id) FILTER (WHERE block_id >= 0) AS block_ids
        FROM pragma_storage_info(?)
        GROUP BY row_group_id, column_name, column_path, compression
        ORDER BY row_group_id, column_name, column_path, compression
    """, [table])


def verify(args):
    import duckdb

    if duckdb.__version__ != args.version:
        raise RuntimeError("DuckDB version differs from registration")
    control = args.control.resolve(strict=True)
    candidate = args.candidate.resolve(strict=True)
    if control == candidate or args.expected_rows <= 0:
        raise ValueError("expected separate databases and a positive registered row count")
    paths = {"control": control, "candidate": candidate}
    initial = {role: identity(path) for role, path in paths.items()}
    args.output.mkdir()
    spill = args.output / "spill"
    spill.mkdir()
    receipt = {"complete": False, "version": duckdb.__version__, "files_before": initial, "orders": {}}
    try:
        connection = duckdb.connect(str(candidate), read_only=True)
        try:
            configure(connection, args, spill)
            connection.execute("ATTACH " + sql_string(str(control)) + " AS source_store (READ_ONLY)")
            source_schema = connection.execute("DESCRIBE SELECT s,p,o FROM source_store.main.triples").fetchall()
            count = scalar(connection, "SELECT count(*) FROM source_store.main.triples")
            if count != args.expected_rows:
                raise ValueError("control row count differs from registration")
            expected_tables = {f"triples_{order}" for order in ORDERS}
            observed = {row[0] for row in connection.execute("""
                SELECT table_name FROM information_schema.tables
                WHERE table_catalog = current_database() AND table_schema = 'main'
                  AND table_type = 'BASE TABLE'
            """).fetchall()}
            if observed != expected_tables:
                raise ValueError(f"candidate table inventory differs: {sorted(observed)}")
            for order in ORDERS:
                result = receipt["orders"][order] = {}
                verify_copy(connection, order, source_schema, count, record=result)
                result["physical_segments"] = physical_info(connection, f"triples_{order}")
        finally:
            connection.close()
        receipt["files_after"] = {role: identity(path) for role, path in paths.items()}
        if initial != receipt["files_after"]:
            raise ValueError("read-only database identity changed")
        receipt["complete"] = True
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        with (args.output / "receipt.json").open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("control", "candidate", "output"):
        parser.add_argument(f"--{name}", type=Path, required=True)
    parser.add_argument("--version", required=True)
    parser.add_argument("--expected-rows", type=int, required=True)
    parser.add_argument("--threads", type=int, required=True)
    parser.add_argument("--memory-limit", required=True)
    parser.add_argument("--max-spill", required=True)
    verify(parser.parse_args())
