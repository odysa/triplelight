# DuckDB laptop workload qualification

The paper plan's analytical qualification runs one dataset at a time. Each attempt prepares a fresh single-table control from the registered N-Triples input and six sorted copies of that exact relation. It then verifies the stored schema, count, bag and row order after a fresh reopen. Three fresh read-only workers run the single, fixed-SPO and routed arms against the registered Jena answers. The two latter workers open the same database bytes.

The registration pins the same Python ARM64 image and DuckDB 2.0.0 wheel as the tiny fixture. The official PyArrow 26.0.1 wheel matches the earlier importer runtime. Installation is offline inside the container after the exact input wheels are available. Each SQL stage runs without network access under the announced exclusive lock, with four CPUs, a 12 GiB cgroup and swap disabled. The importer retains its graph-set schema, RDF parser and SQL. Its lock check reads the same owner file at the container's read-only mount.

Runtime and baseline import each have their own writable directories. Later stages mount the checkpointed databases read-only and write only their own receipts and spill. The loader checks the full N-Triples SHA while ingesting. The supervisor checks source identity after loading and at postflight. It checks both persisted database identities after every stage that opens them. All stage deadlines and captured log limits are registered. The common cap includes the retained v1 output parent and prior v2 dataset attempts. The v1 LUBM run stopped during pip installation with ENOSPC before any store was built. Setup now logs free space on its mounts and gives pip a dedicated writable temporary directory inside the guarded attempt root. Setup checks that pip has removed its temporary files before accepting the runtime. Do one dataset per named slot when the queue requires it.

The replay worker records exact typed checks and the frozen ranking gate independently. It records each query before execution and writes each complete answer immediately. If an arm finishes with ordinary query or answer failures, retain them and examine the other arms. A resource or identity stop ends the attempt and preserves its partial records. These are correctness observations. No query elapsed times or scores are recorded.

Use the approved registration before any launch.

```sh
python3.12 -B supervise.py <registration-sha256> --dataset lubm --verify-only
python3.12 -B supervise.py <registration-sha256> --dataset lubm
```

The offline control script checks all 132 archived Jena answers, all 396 SQL bindings, and rejection of five malformed or incompatible answers. Neither those controls nor the registration preflight execute DuckDB.
