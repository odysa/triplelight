"""Run source and answer controls using the archived oracle bytes. No DuckDB import."""
import argparse
from copy import deepcopy
from hashlib import sha256
from pathlib import Path

from qualify_queries import ARMS, EXPECTED_CASES, Workload, exact_bag


def check(registry, binding, digest):
    for dataset, count in EXPECTED_CASES.items():
        workload = Workload(registry, binding, digest, dataset)
        for name in workload.items:
            for arm in ARMS:
                _, _, reference = workload.prepared(name, arm)
            gate = workload.check(name, reference, reference)
            if not gate["exact_typed_bag"] or not workload.admitted(gate):
                raise ValueError(f"reference does not pass its own gate: {dataset}/{name}")
        print(f"{dataset}: {count} reference self-checks, {count * len(ARMS)} SQL bindings")

    lubm = Workload(registry, binding, digest, "lubm")
    name = "lubm/group_type.rq"
    _, _, reference = lubm.prepared(name, "single")
    group, count = (next(col for col, kind in lubm.items[name]["columns"] if kind == target)
                    for target in ("term", "count"))
    actual = deepcopy(reference)
    first = actual["results"]["bindings"][0]
    first[group]["type"] = "literal"
    assert not lubm.admitted(lubm.check(name, actual, reference))
    del first[count]
    try:
        lubm.check(name, actual, reference)
    except ValueError:
        pass
    else:
        raise AssertionError("missing COUNT binding passed")
    from qualify import exact_term
    empty = {"head": reference["head"], "results": {"bindings": []}}
    assert exact_bag(empty, empty, exact_term)
    wrong = {"head": {"vars": []}, "results": {"bindings": []}}
    assert not exact_bag(wrong, empty, exact_term)

    bi = Workload(registry, binding, digest, "bi10m")
    for template in (4, 7):
        found = False
        for name, request in bi.requests.items():
            if request["template"] != template:
                continue
            _, _, reference = bi.prepared(name, "single")
            if not reference["results"]["bindings"]:
                continue
            actual = deepcopy(reference)
            if template == 4:
                actual["results"]["bindings"][0]["priceRatio"]["value"] = "1.0E30"
            else:
                actual["results"]["bindings"][0]["product"]["value"] = "urn:invalid:unknown-product"
            if bi.admitted(bi.check(name, actual, reference)):
                raise AssertionError(f"invalid BI template {template} answer passed")
            found = True
            break
        if not found:
            raise AssertionError(f"no nonempty BI template {template} reference available")
    print("PASS changed term kind, missing COUNT, missing empty-result projection, BI numeric drift, BI cutoff membership")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("registry", type=Path)
    parser.add_argument("binding", type=Path)
    parser.add_argument("binding_sha256")
    args = parser.parse_args()
    check(args.registry, args.binding, args.binding_sha256)
