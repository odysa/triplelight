"""Draft builder for the six-copy DuckDB profile. Run only under a reviewed supervisor."""
import argparse
import json
from pathlib import Path
import time

ORDERS = ("spo", "sop", "pso", "pos", "osp", "ops")


def sql_string(text):
    return "'" + text.replace("'", "''") + "'"


def queries(order):
    if order not in ORDERS:
        raise ValueError("invalid triple order")
    table = f"triples_{order}"
    key = ", ".join(order)
    build = f"CREATE TABLE {table} AS SELECT s,p,o FROM source_store.main.triples ORDER BY {key}"
    source = "SELECT s,p,o FROM source_store.main.triples"
    copy = f"SELECT s,p,o FROM {table}"
    checks = [
        f"SELECT count(*) FROM ({left} EXCEPT ALL {right})"
        for left, right in ((source, copy), (copy, source))
    ]
    key_struct = ", ".join(f"k{i} := {column}" for i, column in enumerate(order))
    monotonicity = (
        "SELECT count(*) FROM ("
        "SELECT sort_key, lag(sort_key) OVER (ORDER BY rowid) AS prior FROM ("
        f"SELECT rowid, struct_pack({key_struct}) AS sort_key FROM {table}"
        ")) WHERE prior IS NOT NULL AND sort_key < prior"
    )
    return table, build, checks, monotonicity


def metadata(connection, query, params=()):
    cursor = connection.execute(query, params)
    names = [column[0] for column in cursor.description]
    return [dict(zip(names, row, strict=True)) for row in cursor.fetchall()]


def scalar(connection, query):
    row = connection.execute(query).fetchone()
    if row is None or len(row) != 1:
        raise ValueError("unexpected scalar result")
    return row[0]


def verify_copy(connection, order, source_schema, source_rows, *, record=None):
    table, _, checks, monotonicity = queries(order)
    schema = connection.execute(f"DESCRIBE SELECT s,p,o FROM {table}").fetchall()
    result = {} if record is None else record
    result["schema_matches"] = schema == source_schema
    result["rows"] = scalar(connection, f"SELECT count(*) FROM {table}")
    result["bag_differences"] = [scalar(connection, query) for query in checks]
    result["out_of_order_adjacent_pairs"] = scalar(connection, monotonicity)
    if (not result["schema_matches"] or result["rows"] != source_rows
            or result["bag_differences"] != [0, 0] or result["out_of_order_adjacent_pairs"] != 0):
        raise ValueError(f"{table} failed copy admission")
    return result


def configure(connection, args, spill):
    connection.execute("SET threads=?", [args.threads])
    connection.execute("SET memory_limit=?", [args.memory_limit])
    connection.execute("SET temp_directory=?", [str(spill.resolve())])
    connection.execute("SET max_temp_directory_size=?", [args.max_spill])
    connection.execute("SET preserve_insertion_order=true")


def build(args):
    import duckdb

    if duckdb.__version__ != args.version:
        raise RuntimeError("DuckDB version differs from registration")
    original = args.control.resolve(strict=True)
    if not original.is_file() or args.output.exists():
        raise ValueError("expected a regular, checkpointed control and a fresh output directory")
    wal = original.with_name(original.name + ".wal")
    if wal.exists():
        raise ValueError("control has a WAL")
    first = original.stat()
    args.output.mkdir()
    candidate = args.output / "six-copy.duckdb"
    spill = args.output / "spill"
    spill.mkdir()
    receipt = {"version": duckdb.__version__, "control_bytes": first.st_size, "orders": {},
               "source_mode": "read-only attachment", "complete": False}
    connection = duckdb.connect(str(candidate))
    try:
        configure(connection, args, spill)
        connection.execute("ATTACH " + sql_string(str(original)) + " AS source_store (READ_ONLY)")
        source_schema = connection.execute(
            "DESCRIBE SELECT s,p,o FROM source_store.main.triples"
        ).fetchall()
        source_rows = scalar(connection, "SELECT count(*) FROM source_store.main.triples")
        if source_rows != args.expected_rows or source_rows <= 0:
            raise ValueError("control row count differs from admitted input")
        receipt["source_rows"] = source_rows
        receipt["settings"] = metadata(connection, """SELECT name, value FROM duckdb_settings()
            WHERE name IN ('threads','memory_limit','temp_directory','max_temp_directory_size',
                           'preserve_insertion_order') ORDER BY name""")
        for order in ORDERS:
            _, ddl, _, _ = queries(order)
            entry = receipt["orders"][order] = {"ddl": ddl}
            start = time.monotonic()
            connection.execute(ddl)
            entry["create_seconds"] = time.monotonic() - start

            start = time.monotonic()
            try:
                verify_copy(connection, order, source_schema, source_rows, record=entry)
            finally:
                entry["checks_seconds"] = time.monotonic() - start
        connection.execute("DETACH source_store")
        start = time.monotonic()
        connection.execute("CHECKPOINT")
        receipt["checkpoint_seconds"] = time.monotonic() - start
        receipt["complete"] = True
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        try:
            connection.close()
        finally:
            after = original.stat()
            receipt["control_unchanged_stat"] = (first.st_size, first.st_mtime_ns) == (
                after.st_size, after.st_mtime_ns
            ) and not wal.exists()
            receipt["candidate_bytes"] = candidate.stat().st_size if candidate.exists() else None
            with (args.output / "receipt.json").open("x") as stream:
                json.dump(receipt, stream, indent=2)
                stream.write("\n")
    if not receipt["control_unchanged_stat"]:
        raise RuntimeError("read-only control identity changed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--control", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--version", required=True)
    parser.add_argument("--expected-rows", required=True, type=int)
    parser.add_argument("--threads", required=True, type=int)
    parser.add_argument("--memory-limit", required=True)
    parser.add_argument("--max-spill", required=True)
    build(parser.parse_args())
